if (function(i) {
        "use strict";

        function L(f) {
            var b = new Error(f);
            return b.name = "ValueError", b
        }

        function ut(f) {
            return function(b) {
                var p = Array.prototype.slice.call(arguments, 1),
                    x = 0,
                    y = "UNDEFINED";
                return b.replace(/([{}])\1|[{](.*?)(?:!(.+?))?[}]/g, function(N, C, T, B) {
                    if (null != C) return C;
                    var tt = T;
                    if (tt.length > 0) {
                        if ("IMPLICIT" === y) throw L("cannot switch from implicit to explicit numbering");
                        y = "EXPLICIT"
                    } else {
                        if ("EXPLICIT" === y) throw L("cannot switch from explicit to implicit numbering");
                        y = "IMPLICIT", tt = String(x), x += 1
                    }
                    var K = tt.split("."),
                        Y = (/^\d+$/.test(K[0]) ? K : ["0"].concat(K)).reduce(function(st, u) {
                            return st.reduce(function(ot, t) {
                                return null != t && u in Object(t) ? ["function" == typeof t[u] ? t[u]() : t[u]] : []
                            }, [])
                        }, [p]).reduce(function(st, u) {
                            return u
                        }, "");
                    if (null == B) return Y;
                    if (Object.prototype.hasOwnProperty.call(f, B)) return f[B](Y);
                    throw L('no transformer named "' + B + '"')
                })
            }
        }
        var it = ut({});
        it.create = ut, it.extend = function(f, b) {
            var p = ut(b);
            f.format = function() {
                var x = Array.prototype.slice.call(arguments);
                return x.unshift(this), p.apply(i, x)
            }
        }, "undefined" != typeof module ? module.exports = it : "function" == typeof define && define.amd ? define(function() {
            return it
        }) : i.format = it
    }.call(this, this), function(i, L) {
        "use strict";
        "object" == typeof module && "object" == typeof module.exports ? module.exports = i.document ? L(i, !0) : function(ut) {
            if (!ut.document) throw new Error("jQuery requires a window with a document");
            return L(ut)
        } : L(i)
    }("undefined" != typeof window ? window : this, function(i, L) {
        "use strict";
        var ut = [],
            it = i.document,
            f = Object.getPrototypeOf,
            b = ut.slice,
            p = ut.concat,
            x = ut.push,
            y = ut.indexOf,
            N = {},
            C = N.toString,
            T = N.hasOwnProperty,
            B = T.toString,
            tt = B.call(Object),
            K = {};

        function Y(o, a) {
            var h = (a = a || it).createElement("script");
            h.text = o, a.head.appendChild(h).parentNode.removeChild(h)
        }
        var u = function(o, a) {
                return new u.fn.init(o, a)
            },
            ot = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,
            t = /^-ms-/,
            e = /-([a-z])/g,
            n = function(o, a) {
                return a.toUpperCase()
            };

        function s(o) {
            var a = !!o && "length" in o && o.length,
                h = u.type(o);
            return "function" !== h && !u.isWindow(o) && ("array" === h || 0 === a || "number" == typeof a && a > 0 && a - 1 in o)
        }
        u.fn = u.prototype = {
            jquery: "3.1.1",
            constructor: u,
            length: 0,
            toArray: function() {
                return b.call(this)
            },
            get: function(o) {
                return null == o ? b.call(this) : o < 0 ? this[o + this.length] : this[o]
            },
            pushStack: function(o) {
                var a = u.merge(this.constructor(), o);
                return a.prevObject = this, a
            },
            each: function(o) {
                return u.each(this, o)
            },
            map: function(o) {
                return this.pushStack(u.map(this, function(a, h) {
                    return o.call(a, h, a)
                }))
            },
            slice: function() {
                return this.pushStack(b.apply(this, arguments))
            },
            first: function() {
                return this.eq(0)
            },
            last: function() {
                return this.eq(-1)
            },
            eq: function(o) {
                var a = this.length,
                    h = +o + (o < 0 ? a : 0);
                return this.pushStack(h >= 0 && h < a ? [this[h]] : [])
            },
            end: function() {
                return this.prevObject || this.constructor()
            },
            push: x,
            sort: ut.sort,
            splice: ut.splice
        }, u.extend = u.fn.extend = function() {
            var o, a, h, c, v, m, _ = arguments[0] || {},
                E = 1,
                $ = arguments.length,
                W = !1;
            for ("boolean" == typeof _ && (W = _, _ = arguments[E] || {}, E++), "object" == typeof _ || u.isFunction(_) || (_ = {}), E === $ && (_ = this, E--); E < $; E++)
                if (null != (o = arguments[E]))
                    for (a in o) h = _[a], _ !== (c = o[a]) && (W && c && (u.isPlainObject(c) || (v = u.isArray(c))) ? (v ? (v = !1, m = h && u.isArray(h) ? h : []) : m = h && u.isPlainObject(h) ? h : {}, _[a] = u.extend(W, m, c)) : void 0 !== c && (_[a] = c));
            return _
        }, u.extend({
            expando: "jQuery" + ("3.1.1" + Math.random()).replace(/\D/g, ""),
            isReady: !0,
            error: function(o) {
                throw new Error(o)
            },
            noop: function() {},
            isFunction: function(o) {
                return "function" === u.type(o)
            },
            isArray: Array.isArray,
            isWindow: function(o) {
                return null != o && o === o.window
            },
            isNumeric: function(o) {
                var a = u.type(o);
                return ("number" === a || "string" === a) && !isNaN(o - parseFloat(o))
            },
            isPlainObject: function(o) {
                var a, h;
                return !(!o || "[object Object]" !== C.call(o) || (a = f(o)) && (h = T.call(a, "constructor") && a.constructor, "function" != typeof h || B.call(h) !== tt))
            },
            isEmptyObject: function(o) {
                var a;
                for (a in o) return !1;
                return !0
            },
            type: function(o) {
                return null == o ? o + "" : "object" == typeof o || "function" == typeof o ? N[C.call(o)] || "object" : typeof o
            },
            globalEval: function(o) {
                Y(o)
            },
            camelCase: function(o) {
                return o.replace(t, "ms-").replace(e, n)
            },
            nodeName: function(o, a) {
                return o.nodeName && o.nodeName.toLowerCase() === a.toLowerCase()
            },
            each: function(o, a) {
                var h, c = 0;
                if (s(o))
                    for (h = o.length; c < h && !1 !== a.call(o[c], c, o[c]); c++);
                else
                    for (c in o)
                        if (!1 === a.call(o[c], c, o[c])) break;
                return o
            },
            trim: function(o) {
                return null == o ? "" : (o + "").replace(ot, "")
            },
            makeArray: function(o, a) {
                var h = a || [];
                return null != o && (s(Object(o)) ? u.merge(h, "string" == typeof o ? [o] : o) : x.call(h, o)), h
            },
            inArray: function(o, a, h) {
                return null == a ? -1 : y.call(a, o, h)
            },
            merge: function(o, a) {
                for (var h = +a.length, c = 0, v = o.length; c < h; c++) o[v++] = a[c];
                return o.length = v, o
            },
            grep: function(o, a, h) {
                for (var v = [], m = 0, _ = o.length, E = !h; m < _; m++) !a(o[m], m) !== E && v.push(o[m]);
                return v
            },
            map: function(o, a, h) {
                var c, v, m = 0,
                    _ = [];
                if (s(o))
                    for (c = o.length; m < c; m++) null != (v = a(o[m], m, h)) && _.push(v);
                else
                    for (m in o) null != (v = a(o[m], m, h)) && _.push(v);
                return p.apply([], _)
            },
            guid: 1,
            proxy: function(o, a) {
                var h, c, v;
                if ("string" == typeof a && (h = o[a], a = o, o = h), u.isFunction(o)) return c = b.call(arguments, 2), v = function() {
                    return o.apply(a || this, c.concat(b.call(arguments)))
                }, v.guid = o.guid = o.guid || u.guid++, v
            },
            now: Date.now,
            support: K
        }), "function" == typeof Symbol && (u.fn[Symbol.iterator] = ut[Symbol.iterator]), u.each("Boolean Number String Function Array Date RegExp Object Error Symbol".split(" "), function(o, a) {
            N["[object " + a + "]"] = a.toLowerCase()
        });
        var r = function(o) {
            var a, h, c, v, m, _, E, $, W, V, et, j, Q, bt, Ct, gt, Ft, zt, Jt, Et = "sizzle" + 1 * new Date,
                xt = o.document,
                Qt = 0,
                Dt = 0,
                Ht = li(),
                ze = li(),
                Ee = li(),
                ae = function(w, S) {
                    return w === S && (et = !0), 0
                },
                Le = {}.hasOwnProperty,
                Zt = [],
                fe = Zt.pop,
                me = Zt.push,
                Wt = Zt.push,
                Wi = Zt.slice,
                ye = function(w, S) {
                    for (var M = 0, U = w.length; M < U; M++)
                        if (w[M] === S) return M;
                    return -1
                },
                oi = "checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped",
                Pt = "[\\x20\\t\\r\\n\\f]",
                be = "(?:\\\\.|[\\w-]|[^\0-\\xa0])+",
                Ri = "\\[" + Pt + "*(" + be + ")(?:" + Pt + "*([*^$|!~]?=)" + Pt + "*(?:'((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\"|(" + be + "))|)" + Pt + "*\\]",
                ri = ":(" + be + ")(?:\\((('((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\")|((?:\\\\.|[^\\\\()[\\]]|" + Ri + ")*)|.*)\\)|)",
                Sn = new RegExp(Pt + "+", "g"),
                Ye = new RegExp("^" + Pt + "+|((?:^|[^\\\\])(?:\\\\.)*)" + Pt + "+$", "g"),
                In = new RegExp("^" + Pt + "*," + Pt + "*"),
                En = new RegExp("^" + Pt + "*([>+~]|" + Pt + ")" + Pt + "*"),
                Pn = new RegExp("=" + Pt + "*([^\\]'\"]*?)" + Pt + "*\\]", "g"),
                An = new RegExp(ri),
                Nn = new RegExp("^" + be + "$"),
                Ve = {
                    ID: new RegExp("^#(" + be + ")"),
                    CLASS: new RegExp("^\\.(" + be + ")"),
                    TAG: new RegExp("^(" + be + "|[*])"),
                    ATTR: new RegExp("^" + Ri),
                    PSEUDO: new RegExp("^" + ri),
                    CHILD: new RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\(" + Pt + "*(even|odd|(([+-]|)(\\d*)n|)" + Pt + "*(?:([+-]|)" + Pt + "*(\\d+)|))" + Pt + "*\\)|)", "i"),
                    bool: new RegExp("^(?:" + oi + ")$", "i"),
                    needsContext: new RegExp("^" + Pt + "*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\(" + Pt + "*((?:-\\d)?\\d*)" + Pt + "*\\)|)(?=[^-]|$)", "i")
                },
                Mn = /^(?:input|select|textarea|button)$/i,
                $n = /^h\d$/i,
                Fe = /^[^{]+\{\s*\[native \w/,
                On = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,
                ai = /[+~]/,
                ce = new RegExp("\\\\([\\da-f]{1,6}" + Pt + "?|(" + Pt + ")|.)", "ig"),
                de = function(w, S, M) {
                    var U = "0x" + S - 65536;
                    return U != U || M ? S : U < 0 ? String.fromCharCode(U + 65536) : String.fromCharCode(U >> 10 | 55296, 1023 & U | 56320)
                },
                ji = /([\0-\x1f\x7f]|^-?\d)|^-$|[^\0-\x1f\x7f-\uFFFF\w-]/g,
                qi = function(w, S) {
                    return S ? "\0" === w ? "\ufffd" : w.slice(0, -1) + "\\" + w.charCodeAt(w.length - 1).toString(16) + " " : "\\" + w
                },
                Bi = function() {
                    j()
                },
                Hn = Xe(function(w) {
                    return !0 === w.disabled && ("form" in w || "label" in w)
                }, {
                    dir: "parentNode",
                    next: "legend"
                });
            try {
                Wt.apply(Zt = Wi.call(xt.childNodes), xt.childNodes)
            } catch (w) {
                Wt = {
                    apply: Zt.length ? function(S, M) {
                        me.apply(S, Wi.call(M))
                    } : function(S, M) {
                        for (var U = S.length, z = 0; S[U++] = M[z++];);
                        S.length = U - 1
                    }
                }
            }

            function At(w, S, M, U) {
                var z, G, Z, rt, ht, _t, vt, wt = S && S.ownerDocument,
                    Tt = S ? S.nodeType : 9;
                if (M = M || [], "string" != typeof w || !w || 1 !== Tt && 9 !== Tt && 11 !== Tt) return M;
                if (!U && ((S ? S.ownerDocument || S : xt) !== Q && j(S), S = S || Q, Ct)) {
                    if (11 !== Tt && (ht = On.exec(w)))
                        if (z = ht[1]) {
                            if (9 === Tt) {
                                if (!(Z = S.getElementById(z))) return M;
                                if (Z.id === z) return M.push(Z), M
                            } else if (wt && (Z = wt.getElementById(z)) && Jt(S, Z) && Z.id === z) return M.push(Z), M
                        } else {
                            if (ht[2]) return Wt.apply(M, S.getElementsByTagName(w)), M;
                            if ((z = ht[3]) && h.getElementsByClassName && S.getElementsByClassName) return Wt.apply(M, S.getElementsByClassName(z)), M
                        }
                    if (h.qsa && !Ee[w + " "] && (!gt || !gt.test(w))) {
                        if (1 !== Tt) wt = S, vt = w;
                        else if ("object" !== S.nodeName.toLowerCase()) {
                            for ((rt = S.getAttribute("id")) ? rt = rt.replace(ji, qi) : S.setAttribute("id", rt = Et), G = (_t = _(w)).length; G--;) _t[G] = "#" + rt + " " + Ke(_t[G]);
                            vt = _t.join(","), wt = ai.test(w) && ui(S.parentNode) || S
                        }
                        if (vt) try {
                            return Wt.apply(M, wt.querySelectorAll(vt)), M
                        } catch (Nt) {} finally {
                            rt === Et && S.removeAttribute("id")
                        }
                    }
                }
                return $(w.replace(Ye, "$1"), S, M, U)
            }

            function li() {
                var w = [];
                return function S(M, U) {
                    return w.push(M + " ") > c.cacheLength && delete S[w.shift()], S[M + " "] = U
                }
            }

            function le(w) {
                return w[Et] = !0, w
            }

            function he(w) {
                var S = Q.createElement("fieldset");
                try {
                    return !!w(S)
                } catch (M) {
                    return !1
                } finally {
                    S.parentNode && S.parentNode.removeChild(S), S = null
                }
            }

            function hi(w, S) {
                for (var M = w.split("|"), U = M.length; U--;) c.attrHandle[M[U]] = S
            }

            function Ui(w, S) {
                var M = S && w,
                    U = M && 1 === w.nodeType && 1 === S.nodeType && w.sourceIndex - S.sourceIndex;
                if (U) return U;
                if (M)
                    for (; M = M.nextSibling;)
                        if (M === S) return -1;
                return w ? 1 : -1
            }

            function zn(w) {
                return function(S) {
                    return "input" === S.nodeName.toLowerCase() && S.type === w
                }
            }

            function Ln(w) {
                return function(S) {
                    var M = S.nodeName.toLowerCase();
                    return ("input" === M || "button" === M) && S.type === w
                }
            }

            function Yi(w) {
                return function(S) {
                    return "form" in S ? S.parentNode && !1 === S.disabled ? "label" in S ? "label" in S.parentNode ? S.parentNode.disabled === w : S.disabled === w : S.isDisabled === w || S.isDisabled !== !w && Hn(S) === w : S.disabled === w : "label" in S && S.disabled === w
                }
            }

            function we(w) {
                return le(function(S) {
                    return S = +S, le(function(M, U) {
                        for (var z, G = w([], M.length, S), Z = G.length; Z--;) M[z = G[Z]] && (M[z] = !(U[z] = M[z]))
                    })
                })
            }

            function ui(w) {
                return w && void 0 !== w.getElementsByTagName && w
            }
            for (a in h = At.support = {}, m = At.isXML = function(w) {
                    var S = w && (w.ownerDocument || w).documentElement;
                    return !!S && "HTML" !== S.nodeName
                }, j = At.setDocument = function(w) {
                    var S, M, U = w ? w.ownerDocument || w : xt;
                    return U !== Q && 9 === U.nodeType && U.documentElement && (bt = (Q = U).documentElement, Ct = !m(Q), xt !== Q && (M = Q.defaultView) && M.top !== M && (M.addEventListener ? M.addEventListener("unload", Bi, !1) : M.attachEvent && M.attachEvent("onunload", Bi)), h.attributes = he(function(z) {
                        return z.className = "i", !z.getAttribute("className")
                    }), h.getElementsByTagName = he(function(z) {
                        return z.appendChild(Q.createComment("")), !z.getElementsByTagName("*").length
                    }), h.getElementsByClassName = Fe.test(Q.getElementsByClassName), h.getById = he(function(z) {
                        return bt.appendChild(z).id = Et, !Q.getElementsByName || !Q.getElementsByName(Et).length
                    }), h.getById ? (c.filter.ID = function(z) {
                        var G = z.replace(ce, de);
                        return function(Z) {
                            return Z.getAttribute("id") === G
                        }
                    }, c.find.ID = function(z, G) {
                        if (void 0 !== G.getElementById && Ct) {
                            var Z = G.getElementById(z);
                            return Z ? [Z] : []
                        }
                    }) : (c.filter.ID = function(z) {
                        var G = z.replace(ce, de);
                        return function(Z) {
                            var rt = void 0 !== Z.getAttributeNode && Z.getAttributeNode("id");
                            return rt && rt.value === G
                        }
                    }, c.find.ID = function(z, G) {
                        if (void 0 !== G.getElementById && Ct) {
                            var Z, rt, ht, _t = G.getElementById(z);
                            if (_t) {
                                if ((Z = _t.getAttributeNode("id")) && Z.value === z) return [_t];
                                for (ht = G.getElementsByName(z), rt = 0; _t = ht[rt++];)
                                    if ((Z = _t.getAttributeNode("id")) && Z.value === z) return [_t]
                            }
                            return []
                        }
                    }), c.find.TAG = h.getElementsByTagName ? function(z, G) {
                        return void 0 !== G.getElementsByTagName ? G.getElementsByTagName(z) : h.qsa ? G.querySelectorAll(z) : void 0
                    } : function(z, G) {
                        var Z, rt = [],
                            ht = 0,
                            _t = G.getElementsByTagName(z);
                        if ("*" === z) {
                            for (; Z = _t[ht++];) 1 === Z.nodeType && rt.push(Z);
                            return rt
                        }
                        return _t
                    }, c.find.CLASS = h.getElementsByClassName && function(z, G) {
                        if (void 0 !== G.getElementsByClassName && Ct) return G.getElementsByClassName(z)
                    }, Ft = [], gt = [], (h.qsa = Fe.test(Q.querySelectorAll)) && (he(function(z) {
                        bt.appendChild(z).innerHTML = "<a id='" + Et + "'></a><select id='" + Et + "-\r\\' msallowcapture=''><option selected=''></option></select>", z.querySelectorAll("[msallowcapture^='']").length && gt.push("[*^$]=" + Pt + "*(?:''|\"\")"), z.querySelectorAll("[selected]").length || gt.push("\\[" + Pt + "*(?:value|" + oi + ")"), z.querySelectorAll("[id~=" + Et + "-]").length || gt.push("~="), z.querySelectorAll(":checked").length || gt.push(":checked"), z.querySelectorAll("a#" + Et + "+*").length || gt.push(".#.+[+~]")
                    }), he(function(z) {
                        z.innerHTML = "<a href='' disabled='disabled'></a><select disabled='disabled'><option/></select>";
                        var G = Q.createElement("input");
                        G.setAttribute("type", "hidden"), z.appendChild(G).setAttribute("name", "D"), z.querySelectorAll("[name=d]").length && gt.push("name" + Pt + "*[*^$|!~]?="), 2 !== z.querySelectorAll(":enabled").length && gt.push(":enabled", ":disabled"), bt.appendChild(z).disabled = !0, 2 !== z.querySelectorAll(":disabled").length && gt.push(":enabled", ":disabled"), z.querySelectorAll("*,:x"), gt.push(",.*:")
                    })), (h.matchesSelector = Fe.test(zt = bt.matches || bt.webkitMatchesSelector || bt.mozMatchesSelector || bt.oMatchesSelector || bt.msMatchesSelector)) && he(function(z) {
                        h.disconnectedMatch = zt.call(z, "*"), zt.call(z, "[s!='']:x"), Ft.push("!=", ri)
                    }), gt = gt.length && new RegExp(gt.join("|")), Ft = Ft.length && new RegExp(Ft.join("|")), S = Fe.test(bt.compareDocumentPosition), Jt = S || Fe.test(bt.contains) ? function(z, G) {
                        var Z = 9 === z.nodeType ? z.documentElement : z,
                            rt = G && G.parentNode;
                        return z === rt || !(!rt || 1 !== rt.nodeType || !(Z.contains ? Z.contains(rt) : z.compareDocumentPosition && 16 & z.compareDocumentPosition(rt)))
                    } : function(z, G) {
                        if (G)
                            for (; G = G.parentNode;)
                                if (G === z) return !0;
                        return !1
                    }, ae = S ? function(z, G) {
                        if (z === G) return et = !0, 0;
                        var Z = !z.compareDocumentPosition - !G.compareDocumentPosition;
                        return Z || (1 & (Z = (z.ownerDocument || z) === (G.ownerDocument || G) ? z.compareDocumentPosition(G) : 1) || !h.sortDetached && G.compareDocumentPosition(z) === Z ? z === Q || z.ownerDocument === xt && Jt(xt, z) ? -1 : G === Q || G.ownerDocument === xt && Jt(xt, G) ? 1 : V ? ye(V, z) - ye(V, G) : 0 : 4 & Z ? -1 : 1)
                    } : function(z, G) {
                        if (z === G) return et = !0, 0;
                        var Z, rt = 0,
                            ht = z.parentNode,
                            _t = G.parentNode,
                            vt = [z],
                            wt = [G];
                        if (!ht || !_t) return z === Q ? -1 : G === Q ? 1 : ht ? -1 : _t ? 1 : V ? ye(V, z) - ye(V, G) : 0;
                        if (ht === _t) return Ui(z, G);
                        for (Z = z; Z = Z.parentNode;) vt.unshift(Z);
                        for (Z = G; Z = Z.parentNode;) wt.unshift(Z);
                        for (; vt[rt] === wt[rt];) rt++;
                        return rt ? Ui(vt[rt], wt[rt]) : vt[rt] === xt ? -1 : wt[rt] === xt ? 1 : 0
                    }), Q
                }, At.matches = function(w, S) {
                    return At(w, null, null, S)
                }, At.matchesSelector = function(w, S) {
                    if ((w.ownerDocument || w) !== Q && j(w), S = S.replace(Pn, "='$1']"), h.matchesSelector && Ct && !Ee[S + " "] && (!Ft || !Ft.test(S)) && (!gt || !gt.test(S))) try {
                        var M = zt.call(w, S);
                        if (M || h.disconnectedMatch || w.document && 11 !== w.document.nodeType) return M
                    } catch (U) {}
                    return At(S, Q, null, [w]).length > 0
                }, At.contains = function(w, S) {
                    return (w.ownerDocument || w) !== Q && j(w), Jt(w, S)
                }, At.attr = function(w, S) {
                    (w.ownerDocument || w) !== Q && j(w);
                    var M = c.attrHandle[S.toLowerCase()],
                        U = M && Le.call(c.attrHandle, S.toLowerCase()) ? M(w, S, !Ct) : void 0;
                    return void 0 !== U ? U : h.attributes || !Ct ? w.getAttribute(S) : (U = w.getAttributeNode(S)) && U.specified ? U.value : null
                }, At.escape = function(w) {
                    return (w + "").replace(ji, qi)
                }, At.error = function(w) {
                    throw new Error("Syntax error, unrecognized expression: " + w)
                }, At.uniqueSort = function(w) {
                    var S, M = [],
                        U = 0,
                        z = 0;
                    if (et = !h.detectDuplicates, V = !h.sortStable && w.slice(0), w.sort(ae), et) {
                        for (; S = w[z++];) S === w[z] && (U = M.push(z));
                        for (; U--;) w.splice(M[U], 1)
                    }
                    return V = null, w
                }, v = At.getText = function(w) {
                    var S, M = "",
                        U = 0,
                        z = w.nodeType;
                    if (z) {
                        if (1 === z || 9 === z || 11 === z) {
                            if ("string" == typeof w.textContent) return w.textContent;
                            for (w = w.firstChild; w; w = w.nextSibling) M += v(w)
                        } else if (3 === z || 4 === z) return w.nodeValue
                    } else
                        for (; S = w[U++];) M += v(S);
                    return M
                }, (c = At.selectors = {
                    cacheLength: 50,
                    createPseudo: le,
                    match: Ve,
                    attrHandle: {},
                    find: {},
                    relative: {
                        ">": {
                            dir: "parentNode",
                            first: !0
                        },
                        " ": {
                            dir: "parentNode"
                        },
                        "+": {
                            dir: "previousSibling",
                            first: !0
                        },
                        "~": {
                            dir: "previousSibling"
                        }
                    },
                    preFilter: {
                        ATTR: function(w) {
                            return w[1] = w[1].replace(ce, de), w[3] = (w[3] || w[4] || w[5] || "").replace(ce, de), "~=" === w[2] && (w[3] = " " + w[3] + " "), w.slice(0, 4)
                        },
                        CHILD: function(w) {
                            return w[1] = w[1].toLowerCase(), "nth" === w[1].slice(0, 3) ? (w[3] || At.error(w[0]), w[4] = +(w[4] ? w[5] + (w[6] || 1) : 2 * ("even" === w[3] || "odd" === w[3])), w[5] = +(w[7] + w[8] || "odd" === w[3])) : w[3] && At.error(w[0]), w
                        },
                        PSEUDO: function(w) {
                            var S, M = !w[6] && w[2];
                            return Ve.CHILD.test(w[0]) ? null : (w[3] ? w[2] = w[4] || w[5] || "" : M && An.test(M) && (S = _(M, !0)) && (S = M.indexOf(")", M.length - S) - M.length) && (w[0] = w[0].slice(0, S), w[2] = M.slice(0, S)), w.slice(0, 3))
                        }
                    },
                    filter: {
                        TAG: function(w) {
                            var S = w.replace(ce, de).toLowerCase();
                            return "*" === w ? function() {
                                return !0
                            } : function(M) {
                                return M.nodeName && M.nodeName.toLowerCase() === S
                            }
                        },
                        CLASS: function(w) {
                            var S = Ht[w + " "];
                            return S || (S = new RegExp("(^|" + Pt + ")" + w + "(" + Pt + "|$)")) && Ht(w, function(M) {
                                return S.test("string" == typeof M.className && M.className || void 0 !== M.getAttribute && M.getAttribute("class") || "")
                            })
                        },
                        ATTR: function(w, S, M) {
                            return function(U) {
                                var z = At.attr(U, w);
                                return null == z ? "!=" === S : !S || (z += "", "=" === S ? z === M : "!=" === S ? z !== M : "^=" === S ? M && 0 === z.indexOf(M) : "*=" === S ? M && z.indexOf(M) > -1 : "$=" === S ? M && z.slice(-M.length) === M : "~=" === S ? (" " + z.replace(Sn, " ") + " ").indexOf(M) > -1 : "|=" === S && (z === M || z.slice(0, M.length + 1) === M + "-"))
                            }
                        },
                        CHILD: function(w, S, M, U, z) {
                            var G = "nth" !== w.slice(0, 3),
                                Z = "last" !== w.slice(-4),
                                rt = "of-type" === S;
                            return 1 === U && 0 === z ? function(ht) {
                                return !!ht.parentNode
                            } : function(ht, _t, vt) {
                                var wt, Tt, Nt, yt, Rt, Yt, te = G !== Z ? "nextSibling" : "previousSibling",
                                    $t = ht.parentNode,
                                    We = rt && ht.nodeName.toLowerCase(),
                                    Re = !vt && !rt,
                                    ee = !1;
                                if ($t) {
                                    if (G) {
                                        for (; te;) {
                                            for (yt = ht; yt = yt[te];)
                                                if (rt ? yt.nodeName.toLowerCase() === We : 1 === yt.nodeType) return !1;
                                            Yt = te = "only" === w && !Yt && "nextSibling"
                                        }
                                        return !0
                                    }
                                    if (Yt = [Z ? $t.firstChild : $t.lastChild], Z && Re) {
                                        for (ee = (Rt = (wt = (Tt = (Nt = (yt = $t)[Et] || (yt[Et] = {}))[yt.uniqueID] || (Nt[yt.uniqueID] = {}))[w] || [])[0] === Qt && wt[1]) && wt[2], yt = Rt && $t.childNodes[Rt]; yt = ++Rt && yt && yt[te] || (ee = Rt = 0) || Yt.pop();)
                                            if (1 === yt.nodeType && ++ee && yt === ht) {
                                                Tt[w] = [Qt, Rt, ee];
                                                break
                                            }
                                    } else if (Re && (ee = Rt = (wt = (Tt = (Nt = (yt = ht)[Et] || (yt[Et] = {}))[yt.uniqueID] || (Nt[yt.uniqueID] = {}))[w] || [])[0] === Qt && wt[1]), !1 === ee)
                                        for (;
                                            (yt = ++Rt && yt && yt[te] || (ee = Rt = 0) || Yt.pop()) && ((rt ? yt.nodeName.toLowerCase() !== We : 1 !== yt.nodeType) || !++ee || (Re && ((Tt = (Nt = yt[Et] || (yt[Et] = {}))[yt.uniqueID] || (Nt[yt.uniqueID] = {}))[w] = [Qt, ee]), yt !== ht)););
                                    return (ee -= z) === U || ee % U == 0 && ee / U >= 0
                                }
                            }
                        },
                        PSEUDO: function(w, S) {
                            var M, U = c.pseudos[w] || c.setFilters[w.toLowerCase()] || At.error("unsupported pseudo: " + w);
                            return U[Et] ? U(S) : U.length > 1 ? (M = [w, w, "", S], c.setFilters.hasOwnProperty(w.toLowerCase()) ? le(function(z, G) {
                                for (var Z, rt = U(z, S), ht = rt.length; ht--;) z[Z = ye(z, rt[ht])] = !(G[Z] = rt[ht])
                            }) : function(z) {
                                return U(z, 0, M)
                            }) : U
                        }
                    },
                    pseudos: {
                        not: le(function(w) {
                            var S = [],
                                M = [],
                                U = E(w.replace(Ye, "$1"));
                            return U[Et] ? le(function(z, G, Z, rt) {
                                for (var ht, _t = U(z, null, rt, []), vt = z.length; vt--;)(ht = _t[vt]) && (z[vt] = !(G[vt] = ht))
                            }) : function(z, G, Z) {
                                return S[0] = z, U(S, null, Z, M), S[0] = null, !M.pop()
                            }
                        }),
                        has: le(function(w) {
                            return function(S) {
                                return At(w, S).length > 0
                            }
                        }),
                        contains: le(function(w) {
                            return w = w.replace(ce, de),
                                function(S) {
                                    return (S.textContent || S.innerText || v(S)).indexOf(w) > -1
                                }
                        }),
                        lang: le(function(w) {
                            return Nn.test(w || "") || At.error("unsupported lang: " + w), w = w.replace(ce, de).toLowerCase(),
                                function(S) {
                                    var M;
                                    do {
                                        if (M = Ct ? S.lang : S.getAttribute("xml:lang") || S.getAttribute("lang")) return (M = M.toLowerCase()) === w || 0 === M.indexOf(w + "-")
                                    } while ((S = S.parentNode) && 1 === S.nodeType);
                                    return !1
                                }
                        }),
                        target: function(w) {
                            var S = o.location && o.location.hash;
                            return S && S.slice(1) === w.id
                        },
                        root: function(w) {
                            return w === bt
                        },
                        focus: function(w) {
                            return w === Q.activeElement && (!Q.hasFocus || Q.hasFocus()) && !!(w.type || w.href || ~w.tabIndex)
                        },
                        enabled: Yi(!1),
                        disabled: Yi(!0),
                        checked: function(w) {
                            var S = w.nodeName.toLowerCase();
                            return "input" === S && !!w.checked || "option" === S && !!w.selected
                        },
                        selected: function(w) {
                            return !0 === w.selected
                        },
                        empty: function(w) {
                            for (w = w.firstChild; w; w = w.nextSibling)
                                if (w.nodeType < 6) return !1;
                            return !0
                        },
                        parent: function(w) {
                            return !c.pseudos.empty(w)
                        },
                        header: function(w) {
                            return $n.test(w.nodeName)
                        },
                        input: function(w) {
                            return Mn.test(w.nodeName)
                        },
                        button: function(w) {
                            var S = w.nodeName.toLowerCase();
                            return "input" === S && "button" === w.type || "button" === S
                        },
                        text: function(w) {
                            var S;
                            return "input" === w.nodeName.toLowerCase() && "text" === w.type && (null == (S = w.getAttribute("type")) || "text" === S.toLowerCase())
                        },
                        first: we(function() {
                            return [0]
                        }),
                        last: we(function(w, S) {
                            return [S - 1]
                        }),
                        eq: we(function(w, S, M) {
                            return [M < 0 ? M + S : M]
                        }),
                        even: we(function(w, S) {
                            for (var M = 0; M < S; M += 2) w.push(M);
                            return w
                        }),
                        odd: we(function(w, S) {
                            for (var M = 1; M < S; M += 2) w.push(M);
                            return w
                        }),
                        lt: we(function(w, S, M) {
                            for (var U = M < 0 ? M + S : M; --U >= 0;) w.push(U);
                            return w
                        }),
                        gt: we(function(w, S, M) {
                            for (var U = M < 0 ? M + S : M; ++U < S;) w.push(U);
                            return w
                        })
                    }
                }).pseudos.nth = c.pseudos.eq, {
                    radio: !0,
                    checkbox: !0,
                    file: !0,
                    password: !0,
                    image: !0
                }) c.pseudos[a] = zn(a);
            for (a in {
                    submit: !0,
                    reset: !0
                }) c.pseudos[a] = Ln(a);

            function Vi() {}

            function Ke(w) {
                for (var S = 0, M = w.length, U = ""; S < M; S++) U += w[S].value;
                return U
            }

            function Xe(w, S, M) {
                var U = S.dir,
                    z = S.next,
                    G = z || U,
                    Z = M && "parentNode" === G,
                    rt = Dt++;
                return S.first ? function(ht, _t, vt) {
                    for (; ht = ht[U];)
                        if (1 === ht.nodeType || Z) return w(ht, _t, vt);
                    return !1
                } : function(ht, _t, vt) {
                    var wt, Tt, Nt, yt = [Qt, rt];
                    if (vt) {
                        for (; ht = ht[U];)
                            if ((1 === ht.nodeType || Z) && w(ht, _t, vt)) return !0
                    } else
                        for (; ht = ht[U];)
                            if (1 === ht.nodeType || Z)
                                if (Tt = (Nt = ht[Et] || (ht[Et] = {}))[ht.uniqueID] || (Nt[ht.uniqueID] = {}), z && z === ht.nodeName.toLowerCase()) ht = ht[U] || ht;
                                else {
                                    if ((wt = Tt[G]) && wt[0] === Qt && wt[1] === rt) return yt[2] = wt[2];
                                    if (Tt[G] = yt, yt[2] = w(ht, _t, vt)) return !0
                                } return !1
                }
            }

            function ci(w) {
                return w.length > 1 ? function(S, M, U) {
                    for (var z = w.length; z--;)
                        if (!w[z](S, M, U)) return !1;
                    return !0
                } : w[0]
            }

            function Ge(w, S, M, U, z) {
                for (var G, Z = [], rt = 0, ht = w.length, _t = null != S; rt < ht; rt++)(G = w[rt]) && (M && !M(G, U, z) || (Z.push(G), _t && S.push(rt)));
                return Z
            }

            function di(w, S, M, U, z, G) {
                return U && !U[Et] && (U = di(U)), z && !z[Et] && (z = di(z, G)), le(function(Z, rt, ht, _t) {
                    var vt, wt, Tt, Nt = [],
                        yt = [],
                        Rt = rt.length,
                        Yt = Z || function Fn(w, S, M) {
                            for (var U = 0, z = S.length; U < z; U++) At(w, S[U], M);
                            return M
                        }(S || "*", ht.nodeType ? [ht] : ht, []),
                        te = !w || !Z && S ? Yt : Ge(Yt, Nt, w, ht, _t),
                        $t = M ? z || (Z ? w : Rt || U) ? [] : rt : te;
                    if (M && M(te, $t, ht, _t), U)
                        for (vt = Ge($t, yt), U(vt, [], ht, _t), wt = vt.length; wt--;)(Tt = vt[wt]) && ($t[yt[wt]] = !(te[yt[wt]] = Tt));
                    if (Z) {
                        if (z || w) {
                            if (z) {
                                for (vt = [], wt = $t.length; wt--;)(Tt = $t[wt]) && vt.push(te[wt] = Tt);
                                z(null, $t = [], vt, _t)
                            }
                            for (wt = $t.length; wt--;)(Tt = $t[wt]) && (vt = z ? ye(Z, Tt) : Nt[wt]) > -1 && (Z[vt] = !(rt[vt] = Tt))
                        }
                    } else $t = Ge($t === rt ? $t.splice(Rt, $t.length) : $t), z ? z(null, rt, $t, _t) : Wt.apply(rt, $t)
                })
            }

            function pi(w) {
                for (var S, M, U, z = w.length, G = c.relative[w[0].type], Z = G || c.relative[" "], rt = G ? 1 : 0, ht = Xe(function(wt) {
                        return wt === S
                    }, Z, !0), _t = Xe(function(wt) {
                        return ye(S, wt) > -1
                    }, Z, !0), vt = [function(wt, Tt, Nt) {
                        var yt = !G && (Nt || Tt !== W) || ((S = Tt).nodeType ? ht(wt, Tt, Nt) : _t(wt, Tt, Nt));
                        return S = null, yt
                    }]; rt < z; rt++)
                    if (M = c.relative[w[rt].type]) vt = [Xe(ci(vt), M)];
                    else {
                        if ((M = c.filter[w[rt].type].apply(null, w[rt].matches))[Et]) {
                            for (U = ++rt; U < z && !c.relative[w[U].type]; U++);
                            return di(rt > 1 && ci(vt), rt > 1 && Ke(w.slice(0, rt - 1).concat({
                                value: " " === w[rt - 2].type ? "*" : ""
                            })).replace(Ye, "$1"), M, rt < U && pi(w.slice(rt, U)), U < z && pi(w = w.slice(U)), U < z && Ke(w))
                        }
                        vt.push(M)
                    }
                return ci(vt)
            }
            return Vi.prototype = c.filters = c.pseudos, c.setFilters = new Vi, _ = At.tokenize = function(w, S) {
                var M, U, z, G, Z, rt, ht, _t = ze[w + " "];
                if (_t) return S ? 0 : _t.slice(0);
                for (Z = w, rt = [], ht = c.preFilter; Z;) {
                    for (G in M && !(U = In.exec(Z)) || (U && (Z = Z.slice(U[0].length) || Z), rt.push(z = [])), M = !1, (U = En.exec(Z)) && (M = U.shift(), z.push({
                            value: M,
                            type: U[0].replace(Ye, " ")
                        }), Z = Z.slice(M.length)), c.filter) !(U = Ve[G].exec(Z)) || ht[G] && !(U = ht[G](U)) || (M = U.shift(), z.push({
                        value: M,
                        type: G,
                        matches: U
                    }), Z = Z.slice(M.length));
                    if (!M) break
                }
                return S ? Z.length : Z ? At.error(w) : ze(w, rt).slice(0)
            }, E = At.compile = function(w, S) {
                var M, U = [],
                    z = [],
                    G = Ee[w + " "];
                if (!G) {
                    for (S || (S = _(w)), M = S.length; M--;)(G = pi(S[M]))[Et] ? U.push(G) : z.push(G);
                    G = Ee(w, function Wn(w, S) {
                        var M = S.length > 0,
                            U = w.length > 0,
                            z = function(G, Z, rt, ht, _t) {
                                var vt, wt, Tt, Nt = 0,
                                    yt = "0",
                                    Rt = G && [],
                                    Yt = [],
                                    te = W,
                                    $t = G || U && c.find.TAG("*", _t),
                                    We = Qt += null == te ? 1 : Math.random() || .1,
                                    Re = $t.length;
                                for (_t && (W = Z === Q || Z || _t); yt !== Re && null != (vt = $t[yt]); yt++) {
                                    if (U && vt) {
                                        for (wt = 0, Z || vt.ownerDocument === Q || (j(vt), rt = !Ct); Tt = w[wt++];)
                                            if (Tt(vt, Z || Q, rt)) {
                                                ht.push(vt);
                                                break
                                            }
                                        _t && (Qt = We)
                                    }
                                    M && ((vt = !Tt && vt) && Nt--, G && Rt.push(vt))
                                }
                                if (Nt += yt, M && yt !== Nt) {
                                    for (wt = 0; Tt = S[wt++];) Tt(Rt, Yt, Z, rt);
                                    if (G) {
                                        if (Nt > 0)
                                            for (; yt--;) Rt[yt] || Yt[yt] || (Yt[yt] = fe.call(ht));
                                        Yt = Ge(Yt)
                                    }
                                    Wt.apply(ht, Yt), _t && !G && Yt.length > 0 && Nt + S.length > 1 && At.uniqueSort(ht)
                                }
                                return _t && (Qt = We, W = te), Rt
                            };
                        return M ? le(z) : z
                    }(z, U)), G.selector = w
                }
                return G
            }, $ = At.select = function(w, S, M, U) {
                var z, G, Z, rt, ht, _t = "function" == typeof w && w,
                    vt = !U && _(w = _t.selector || w);
                if (M = M || [], 1 === vt.length) {
                    if ((G = vt[0] = vt[0].slice(0)).length > 2 && "ID" === (Z = G[0]).type && 9 === S.nodeType && Ct && c.relative[G[1].type]) {
                        if (!(S = (c.find.ID(Z.matches[0].replace(ce, de), S) || [])[0])) return M;
                        _t && (S = S.parentNode), w = w.slice(G.shift().value.length)
                    }
                    for (z = Ve.needsContext.test(w) ? 0 : G.length; z-- && !c.relative[rt = (Z = G[z]).type];)
                        if ((ht = c.find[rt]) && (U = ht(Z.matches[0].replace(ce, de), ai.test(G[0].type) && ui(S.parentNode) || S))) {
                            if (G.splice(z, 1), !(w = U.length && Ke(G))) return Wt.apply(M, U), M;
                            break
                        }
                }
                return (_t || E(w, vt))(U, S, !Ct, M, !S || ai.test(w) && ui(S.parentNode) || S), M
            }, h.sortStable = Et.split("").sort(ae).join("") === Et, h.detectDuplicates = !!et, j(), h.sortDetached = he(function(w) {
                return 1 & w.compareDocumentPosition(Q.createElement("fieldset"))
            }), he(function(w) {
                return w.innerHTML = "<a href='#'></a>", "#" === w.firstChild.getAttribute("href")
            }) || hi("type|href|height|width", function(w, S, M) {
                if (!M) return w.getAttribute(S, "type" === S.toLowerCase() ? 1 : 2)
            }), h.attributes && he(function(w) {
                return w.innerHTML = "<input/>", w.firstChild.setAttribute("value", ""), "" === w.firstChild.getAttribute("value")
            }) || hi("value", function(w, S, M) {
                if (!M && "input" === w.nodeName.toLowerCase()) return w.defaultValue
            }), he(function(w) {
                return null == w.getAttribute("disabled")
            }) || hi(oi, function(w, S, M) {
                var U;
                if (!M) return !0 === w[S] ? S.toLowerCase() : (U = w.getAttributeNode(S)) && U.specified ? U.value : null
            }), At
        }(i);
        u.find = r, u.expr = r.selectors, u.expr[":"] = u.expr.pseudos, u.uniqueSort = u.unique = r.uniqueSort, u.text = r.getText, u.isXMLDoc = r.isXML, u.contains = r.contains, u.escapeSelector = r.escape;
        var l = function(o, a, h) {
                for (var c = [], v = void 0 !== h;
                    (o = o[a]) && 9 !== o.nodeType;)
                    if (1 === o.nodeType) {
                        if (v && u(o).is(h)) break;
                        c.push(o)
                    }
                return c
            },
            d = function(o, a) {
                for (var h = []; o; o = o.nextSibling) 1 === o.nodeType && o !== a && h.push(o);
                return h
            },
            g = u.expr.match.needsContext,
            k = /^<([a-z][^\/\0>:\x20\t\r\n\f]*)[\x20\t\r\n\f]*\/?>(?:<\/\1>|)$/i,
            D = /^.[^:#\[\.,]*$/;

        function I(o, a, h) {
            return u.isFunction(a) ? u.grep(o, function(c, v) {
                return !!a.call(c, v, c) !== h
            }) : a.nodeType ? u.grep(o, function(c) {
                return c === a !== h
            }) : "string" != typeof a ? u.grep(o, function(c) {
                return y.call(a, c) > -1 !== h
            }) : D.test(a) ? u.filter(a, o, h) : (a = u.filter(a, o), u.grep(o, function(c) {
                return y.call(a, c) > -1 !== h && 1 === c.nodeType
            }))
        }
        u.filter = function(o, a, h) {
            var c = a[0];
            return h && (o = ":not(" + o + ")"), 1 === a.length && 1 === c.nodeType ? u.find.matchesSelector(c, o) ? [c] : [] : u.find.matches(o, u.grep(a, function(v) {
                return 1 === v.nodeType
            }))
        }, u.fn.extend({
            find: function(o) {
                var a, h, c = this.length,
                    v = this;
                if ("string" != typeof o) return this.pushStack(u(o).filter(function() {
                    for (a = 0; a < c; a++)
                        if (u.contains(v[a], this)) return !0
                }));
                for (h = this.pushStack([]), a = 0; a < c; a++) u.find(o, v[a], h);
                return c > 1 ? u.uniqueSort(h) : h
            },
            filter: function(o) {
                return this.pushStack(I(this, o || [], !1))
            },
            not: function(o) {
                return this.pushStack(I(this, o || [], !0))
            },
            is: function(o) {
                return !!I(this, "string" == typeof o && g.test(o) ? u(o) : o || [], !1).length
            }
        });
        var R, P = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]+))$/,
            H = u.fn.init = function(o, a, h) {
                var c, v;
                if (!o) return this;
                if (h = h || R, "string" == typeof o) {
                    if (!(c = "<" === o[0] && ">" === o[o.length - 1] && o.length >= 3 ? [null, o, null] : P.exec(o)) || !c[1] && a) return !a || a.jquery ? (a || h).find(o) : this.constructor(a).find(o);
                    if (c[1]) {
                        if (u.merge(this, u.parseHTML(c[1], (a = a instanceof u ? a[0] : a) && a.nodeType ? a.ownerDocument || a : it, !0)), k.test(c[1]) && u.isPlainObject(a))
                            for (c in a) u.isFunction(this[c]) ? this[c](a[c]) : this.attr(c, a[c]);
                        return this
                    }
                    return (v = it.getElementById(c[2])) && (this[0] = v, this.length = 1), this
                }
                return o.nodeType ? (this[0] = o, this.length = 1, this) : u.isFunction(o) ? void 0 !== h.ready ? h.ready(o) : o(u) : u.makeArray(o, this)
            };
        H.prototype = u.fn, R = u(it);
        var F = /^(?:parents|prev(?:Until|All))/,
            A = {
                children: !0,
                contents: !0,
                next: !0,
                prev: !0
            };

        function O(o, a) {
            for (;
                (o = o[a]) && 1 !== o.nodeType;);
            return o
        }
        u.fn.extend({
            has: function(o) {
                var a = u(o, this),
                    h = a.length;
                return this.filter(function() {
                    for (var c = 0; c < h; c++)
                        if (u.contains(this, a[c])) return !0
                })
            },
            closest: function(o, a) {
                var h, c = 0,
                    v = this.length,
                    m = [],
                    _ = "string" != typeof o && u(o);
                if (!g.test(o))
                    for (; c < v; c++)
                        for (h = this[c]; h && h !== a; h = h.parentNode)
                            if (h.nodeType < 11 && (_ ? _.index(h) > -1 : 1 === h.nodeType && u.find.matchesSelector(h, o))) {
                                m.push(h);
                                break
                            }
                return this.pushStack(m.length > 1 ? u.uniqueSort(m) : m)
            },
            index: function(o) {
                return o ? "string" == typeof o ? y.call(u(o), this[0]) : y.call(this, o.jquery ? o[0] : o) : this[0] && this[0].parentNode ? this.first().prevAll().length : -1
            },
            add: function(o, a) {
                return this.pushStack(u.uniqueSort(u.merge(this.get(), u(o, a))))
            },
            addBack: function(o) {
                return this.add(null == o ? this.prevObject : this.prevObject.filter(o))
            }
        }), u.each({
            parent: function(o) {
                var a = o.parentNode;
                return a && 11 !== a.nodeType ? a : null
            },
            parents: function(o) {
                return l(o, "parentNode")
            },
            parentsUntil: function(o, a, h) {
                return l(o, "parentNode", h)
            },
            next: function(o) {
                return O(o, "nextSibling")
            },
            prev: function(o) {
                return O(o, "previousSibling")
            },
            nextAll: function(o) {
                return l(o, "nextSibling")
            },
            prevAll: function(o) {
                return l(o, "previousSibling")
            },
            nextUntil: function(o, a, h) {
                return l(o, "nextSibling", h)
            },
            prevUntil: function(o, a, h) {
                return l(o, "previousSibling", h)
            },
            siblings: function(o) {
                return d((o.parentNode || {}).firstChild, o)
            },
            children: function(o) {
                return d(o.firstChild)
            },
            contents: function(o) {
                return o.contentDocument || u.merge([], o.childNodes)
            }
        }, function(o, a) {
            u.fn[o] = function(h, c) {
                var v = u.map(this, a, h);
                return "Until" !== o.slice(-5) && (c = h), c && "string" == typeof c && (v = u.filter(c, v)), this.length > 1 && (A[o] || u.uniqueSort(v), F.test(o) && v.reverse()), this.pushStack(v)
            }
        });
        var q = /[^\x20\t\r\n\f]+/g;

        function J(o) {
            return o
        }

        function nt(o) {
            throw o
        }

        function pt(o, a, h) {
            var c;
            try {
                o && u.isFunction(c = o.promise) ? c.call(o).done(a).fail(h) : o && u.isFunction(c = o.then) ? c.call(o, a, h) : a.call(void 0, o)
            } catch (v) {
                h.call(void 0, v)
            }
        }
        u.Callbacks = function(o) {
            o = "string" == typeof o ? function X(o) {
                var a = {};
                return u.each(o.match(q) || [], function(h, c) {
                    a[c] = !0
                }), a
            }(o) : u.extend({}, o);
            var a, h, c, v, m = [],
                _ = [],
                E = -1,
                $ = function() {
                    for (v = o.once, c = a = !0; _.length; E = -1)
                        for (h = _.shift(); ++E < m.length;) !1 === m[E].apply(h[0], h[1]) && o.stopOnFalse && (E = m.length, h = !1);
                    o.memory || (h = !1), a = !1, v && (m = h ? [] : "")
                },
                W = {
                    add: function() {
                        return m && (h && !a && (E = m.length - 1, _.push(h)), function V(et) {
                            u.each(et, function(j, Q) {
                                u.isFunction(Q) ? o.unique && W.has(Q) || m.push(Q) : Q && Q.length && "string" !== u.type(Q) && V(Q)
                            })
                        }(arguments), h && !a && $()), this
                    },
                    remove: function() {
                        return u.each(arguments, function(V, et) {
                            for (var j;
                                (j = u.inArray(et, m, j)) > -1;) m.splice(j, 1), j <= E && E--
                        }), this
                    },
                    has: function(V) {
                        return V ? u.inArray(V, m) > -1 : m.length > 0
                    },
                    empty: function() {
                        return m && (m = []), this
                    },
                    disable: function() {
                        return v = _ = [], m = h = "", this
                    },
                    disabled: function() {
                        return !m
                    },
                    lock: function() {
                        return v = _ = [], h || a || (m = h = ""), this
                    },
                    locked: function() {
                        return !!v
                    },
                    fireWith: function(V, et) {
                        return v || (et = [V, (et = et || []).slice ? et.slice() : et], _.push(et), a || $()), this
                    },
                    fire: function() {
                        return W.fireWith(this, arguments), this
                    },
                    fired: function() {
                        return !!c
                    }
                };
            return W
        }, u.extend({
            Deferred: function(o) {
                var a = [
                        ["notify", "progress", u.Callbacks("memory"), u.Callbacks("memory"), 2],
                        ["resolve", "done", u.Callbacks("once memory"), u.Callbacks("once memory"), 0, "resolved"],
                        ["reject", "fail", u.Callbacks("once memory"), u.Callbacks("once memory"), 1, "rejected"]
                    ],
                    h = "pending",
                    c = {
                        state: function() {
                            return h
                        },
                        always: function() {
                            return v.done(arguments).fail(arguments), this
                        },
                        catch: function(m) {
                            return c.then(null, m)
                        },
                        pipe: function() {
                            var m = arguments;
                            return u.Deferred(function(_) {
                                u.each(a, function(E, $) {
                                    var W = u.isFunction(m[$[4]]) && m[$[4]];
                                    v[$[1]](function() {
                                        var V = W && W.apply(this, arguments);
                                        V && u.isFunction(V.promise) ? V.promise().progress(_.notify).done(_.resolve).fail(_.reject) : _[$[0] + "With"](this, W ? [V] : arguments)
                                    })
                                }), m = null
                            }).promise()
                        },
                        then: function(m, _, E) {
                            var $ = 0;

                            function W(V, et, j, Q) {
                                return function() {
                                    var bt = this,
                                        Ct = arguments,
                                        gt = function() {
                                            var zt, Jt;
                                            if (!(V < $)) {
                                                if ((zt = j.apply(bt, Ct)) === et.promise()) throw new TypeError("Thenable self-resolution");
                                                u.isFunction(Jt = zt && ("object" == typeof zt || "function" == typeof zt) && zt.then) ? Q ? Jt.call(zt, W($, et, J, Q), W($, et, nt, Q)) : ($++, Jt.call(zt, W($, et, J, Q), W($, et, nt, Q), W($, et, J, et.notifyWith))) : (j !== J && (bt = void 0, Ct = [zt]), (Q || et.resolveWith)(bt, Ct))
                                            }
                                        },
                                        Ft = Q ? gt : function() {
                                            try {
                                                gt()
                                            } catch (zt) {
                                                u.Deferred.exceptionHook && u.Deferred.exceptionHook(zt, Ft.stackTrace), V + 1 >= $ && (j !== nt && (bt = void 0, Ct = [zt]), et.rejectWith(bt, Ct))
                                            }
                                        };
                                    V ? Ft() : (u.Deferred.getStackHook && (Ft.stackTrace = u.Deferred.getStackHook()), i.setTimeout(Ft))
                                }
                            }
                            return u.Deferred(function(V) {
                                a[0][3].add(W(0, V, u.isFunction(E) ? E : J, V.notifyWith)), a[1][3].add(W(0, V, u.isFunction(m) ? m : J)), a[2][3].add(W(0, V, u.isFunction(_) ? _ : nt))
                            }).promise()
                        },
                        promise: function(m) {
                            return null != m ? u.extend(m, c) : c
                        }
                    },
                    v = {};
                return u.each(a, function(m, _) {
                    var E = _[2],
                        $ = _[5];
                    c[_[1]] = E.add, $ && E.add(function() {
                        h = $
                    }, a[3 - m][2].disable, a[0][2].lock), E.add(_[3].fire), v[_[0]] = function() {
                        return v[_[0] + "With"](this === v ? void 0 : this, arguments), this
                    }, v[_[0] + "With"] = E.fireWith
                }), c.promise(v), o && o.call(v, v), v
            },
            when: function(o) {
                var a = arguments.length,
                    h = a,
                    c = Array(h),
                    v = b.call(arguments),
                    m = u.Deferred(),
                    _ = function(E) {
                        return function($) {
                            c[E] = this, v[E] = arguments.length > 1 ? b.call(arguments) : $, --a || m.resolveWith(c, v)
                        }
                    };
                if (a <= 1 && (pt(o, m.done(_(h)).resolve, m.reject), "pending" === m.state() || u.isFunction(v[h] && v[h].then))) return m.then();
                for (; h--;) pt(v[h], _(h), m.reject);
                return m.promise()
            }
        });
        var ft = /^(Eval|Internal|Range|Reference|Syntax|Type|URI)Error$/;
        u.Deferred.exceptionHook = function(o, a) {
            i.console && i.console.warn && o && ft.test(o.name) && i.console.warn("jQuery.Deferred exception: " + o.message, o.stack, a)
        }, u.readyException = function(o) {
            i.setTimeout(function() {
                throw o
            })
        };
        var lt = u.Deferred();

        function ct() {
            it.removeEventListener("DOMContentLoaded", ct), i.removeEventListener("load", ct), u.ready()
        }
        u.fn.ready = function(o) {
            return lt.then(o).catch(function(a) {
                u.readyException(a)
            }), this
        }, u.extend({
            isReady: !1,
            readyWait: 1,
            holdReady: function(o) {
                o ? u.readyWait++ : u.ready(!0)
            },
            ready: function(o) {
                (!0 === o ? --u.readyWait : u.isReady) || (u.isReady = !0, !0 !== o && --u.readyWait > 0 || lt.resolveWith(it, [u]))
            }
        }), u.ready.then = lt.then, "complete" === it.readyState || "loading" !== it.readyState && !it.documentElement.doScroll ? i.setTimeout(u.ready) : (it.addEventListener("DOMContentLoaded", ct), i.addEventListener("load", ct));
        var mt = function(o, a, h, c, v, m, _) {
                var E = 0,
                    $ = o.length,
                    W = null == h;
                if ("object" === u.type(h))
                    for (E in v = !0, h) mt(o, a, E, h[E], !0, m, _);
                else if (void 0 !== c && (v = !0, u.isFunction(c) || (_ = !0), W && (_ ? (a.call(o, c), a = null) : (W = a, a = function(V, et, j) {
                        return W.call(u(V), j)
                    })), a))
                    for (; E < $; E++) a(o[E], h, _ ? c : c.call(o[E], E, a(o[E], h)));
                return v ? o : W ? a.call(o) : $ ? a(o[0], h) : m
            },
            dt = function(o) {
                return 1 === o.nodeType || 9 === o.nodeType || !+o.nodeType
            };

        function kt() {
            this.expando = u.expando + kt.uid++
        }
        kt.uid = 1, kt.prototype = {
            cache: function(o) {
                var a = o[this.expando];
                return a || (a = {}, dt(o) && (o.nodeType ? o[this.expando] = a : Object.defineProperty(o, this.expando, {
                    value: a,
                    configurable: !0
                }))), a
            },
            set: function(o, a, h) {
                var c, v = this.cache(o);
                if ("string" == typeof a) v[u.camelCase(a)] = h;
                else
                    for (c in a) v[u.camelCase(c)] = a[c];
                return v
            },
            get: function(o, a) {
                return void 0 === a ? this.cache(o) : o[this.expando] && o[this.expando][u.camelCase(a)]
            },
            access: function(o, a, h) {
                return void 0 === a || a && "string" == typeof a && void 0 === h ? this.get(o, a) : (this.set(o, a, h), void 0 !== h ? h : a)
            },
            remove: function(o, a) {
                var h, c = o[this.expando];
                if (void 0 !== c) {
                    if (void 0 !== a)
                        for ((h = (a = u.isArray(a) ? a.map(u.camelCase) : (a = u.camelCase(a)) in c ? [a] : a.match(q) || []).length); h--;) delete c[a[h]];
                    (void 0 === a || u.isEmptyObject(c)) && (o.nodeType ? o[this.expando] = void 0 : delete o[this.expando])
                }
            },
            hasData: function(o) {
                var a = o[this.expando];
                return void 0 !== a && !u.isEmptyObject(a)
            }
        };
        var at = new kt,
            St = new kt,
            ie = /^(?:\{[\w\W]*\}|\[[\w\W]*\])$/,
            ge = /[A-Z]/g;

        function Lt(o, a, h) {
            var c;
            if (void 0 === h && 1 === o.nodeType)
                if (c = "data-" + a.replace(ge, "-$&").toLowerCase(), "string" == typeof(h = o.getAttribute(c))) {
                    try {
                        h = function pe(o) {
                            return "true" === o || "false" !== o && ("null" === o ? null : o === +o + "" ? +o : ie.test(o) ? JSON.parse(o) : o)
                        }(h)
                    } catch (v) {}
                    St.set(o, a, h)
                } else h = void 0;
            return h
        }
        u.extend({
            hasData: function(o) {
                return St.hasData(o) || at.hasData(o)
            },
            data: function(o, a, h) {
                return St.access(o, a, h)
            },
            removeData: function(o, a) {
                St.remove(o, a)
            },
            _data: function(o, a, h) {
                return at.access(o, a, h)
            },
            _removeData: function(o, a) {
                at.remove(o, a)
            }
        }), u.fn.extend({
            data: function(o, a) {
                var h, c, v, m = this[0],
                    _ = m && m.attributes;
                if (void 0 === o) {
                    if (this.length && (v = St.get(m), 1 === m.nodeType && !at.get(m, "hasDataAttrs"))) {
                        for (h = _.length; h--;) _[h] && 0 === (c = _[h].name).indexOf("data-") && (c = u.camelCase(c.slice(5)), Lt(m, c, v[c]));
                        at.set(m, "hasDataAttrs", !0)
                    }
                    return v
                }
                return "object" == typeof o ? this.each(function() {
                    St.set(this, o)
                }) : mt(this, function(E) {
                    var $;
                    if (m && void 0 === E) {
                        if (void 0 !== ($ = St.get(m, o)) || void 0 !== ($ = Lt(m, o))) return $
                    } else this.each(function() {
                        St.set(this, o, E)
                    })
                }, null, a, arguments.length > 1, null, !0)
            },
            removeData: function(o) {
                return this.each(function() {
                    St.remove(this, o)
                })
            }
        }), u.extend({
            queue: function(o, a, h) {
                var c;
                if (o) return c = at.get(o, a = (a || "fx") + "queue"), h && (!c || u.isArray(h) ? c = at.access(o, a, u.makeArray(h)) : c.push(h)), c || []
            },
            dequeue: function(o, a) {
                var h = u.queue(o, a = a || "fx"),
                    c = h.length,
                    v = h.shift(),
                    m = u._queueHooks(o, a);
                "inprogress" === v && (v = h.shift(), c--), v && ("fx" === a && h.unshift("inprogress"), delete m.stop, v.call(o, function() {
                    u.dequeue(o, a)
                }, m)), !c && m && m.empty.fire()
            },
            _queueHooks: function(o, a) {
                var h = a + "queueHooks";
                return at.get(o, h) || at.access(o, h, {
                    empty: u.Callbacks("once memory").add(function() {
                        at.remove(o, [a + "queue", h])
                    })
                })
            }
        }), u.fn.extend({
            queue: function(o, a) {
                var h = 2;
                return "string" != typeof o && (a = o, o = "fx", h--), arguments.length < h ? u.queue(this[0], o) : void 0 === a ? this : this.each(function() {
                    var c = u.queue(this, o, a);
                    u._queueHooks(this, o), "fx" === o && "inprogress" !== c[0] && u.dequeue(this, o)
                })
            },
            dequeue: function(o) {
                return this.each(function() {
                    u.dequeue(this, o)
                })
            },
            clearQueue: function(o) {
                return this.queue(o || "fx", [])
            },
            promise: function(o, a) {
                var h, c = 1,
                    v = u.Deferred(),
                    m = this,
                    _ = this.length,
                    E = function() {
                        --c || v.resolveWith(m, [m])
                    };
                for ("string" != typeof o && (a = o, o = void 0), o = o || "fx"; _--;)(h = at.get(m[_], o + "queueHooks")) && h.empty && (c++, h.empty.add(E));
                return E(), v.promise(a)
            }
        });
        var It = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,
            Kt = new RegExp("^(?:([+-])=|)(" + It + ")([a-z%]*)$", "i"),
            jt = ["Top", "Right", "Bottom", "Left"],
            Xt = function(o, a) {
                return "none" === (o = a || o).style.display || "" === o.style.display && u.contains(o.ownerDocument, o) && "none" === u.css(o, "display")
            },
            Vt = function(o, a, h, c) {
                var v, m, _ = {};
                for (m in a) _[m] = o.style[m], o.style[m] = a[m];
                for (m in v = h.apply(o, c || []), a) o.style[m] = _[m];
                return v
            };

        function ne(o, a, h, c) {
            var v, m = 1,
                _ = 20,
                E = c ? function() {
                    return c.cur()
                } : function() {
                    return u.css(o, a, "")
                },
                $ = E(),
                W = h && h[3] || (u.cssNumber[a] ? "" : "px"),
                V = (u.cssNumber[a] || "px" !== W && +$) && Kt.exec(u.css(o, a));
            if (V && V[3] !== W) {
                W = W || V[3], h = h || [], V = +$ || 1;
                do {
                    u.style(o, a, (V /= m = m || ".5") + W)
                } while (m !== (m = E() / $) && 1 !== m && --_)
            }
            return h && (V = +V || +$ || 0, v = h[1] ? V + (h[1] + 1) * h[2] : +h[2], c && (c.unit = W, c.start = V, c.end = v)), v
        }
        var se = {};

        function Pe(o) {
            var a, h = o.ownerDocument,
                c = o.nodeName,
                v = se[c];
            return v || (a = h.body.appendChild(h.createElement(c)), v = u.css(a, "display"), a.parentNode.removeChild(a), "none" === v && (v = "block"), se[c] = v, v)
        }

        function Bt(o, a) {
            for (var h, c, v = [], m = 0, _ = o.length; m < _; m++)(c = o[m]).style && (h = c.style.display, a ? ("none" === h && (v[m] = at.get(c, "display") || null, v[m] || (c.style.display = "")), "" === c.style.display && Xt(c) && (v[m] = Pe(c))) : "none" !== h && (v[m] = "none", at.set(c, "display", h)));
            for (m = 0; m < _; m++) null != v[m] && (o[m].style.display = v[m]);
            return o
        }
        u.fn.extend({
            show: function() {
                return Bt(this, !0)
            },
            hide: function() {
                return Bt(this)
            },
            toggle: function(o) {
                return "boolean" == typeof o ? o ? this.show() : this.hide() : this.each(function() {
                    Xt(this) ? u(this).show() : u(this).hide()
                })
            }
        });
        var je = /^(?:checkbox|radio)$/i,
            Ae = /<([a-z][^\/\0>\x20\t\r\n\f]+)/i,
            xe = /^$|\/(?:java|ecma)script/i,
            Ot = {
                option: [1, "<select multiple='multiple'>", "</select>"],
                thead: [1, "<table>", "</table>"],
                col: [2, "<table><colgroup>", "</colgroup></table>"],
                tr: [2, "<table><tbody>", "</tbody></table>"],
                td: [3, "<table><tbody><tr>", "</tr></tbody></table>"],
                _default: [0, "", ""]
            };

        function Ut(o, a) {
            var h;
            return h = void 0 !== o.getElementsByTagName ? o.getElementsByTagName(a || "*") : void 0 !== o.querySelectorAll ? o.querySelectorAll(a || "*") : [], void 0 === a || a && u.nodeName(o, a) ? u.merge([o], h) : h
        }

        function ke(o, a) {
            for (var h = 0, c = o.length; h < c; h++) at.set(o[h], "globalEval", !a || at.get(a[h], "globalEval"))
        }
        Ot.optgroup = Ot.option, Ot.tbody = Ot.tfoot = Ot.colgroup = Ot.caption = Ot.thead, Ot.th = Ot.td;
        var a, h, Ne = /<|&#?\w+;/;

        function Ce(o, a, h, c, v) {
            for (var m, _, E, $, W, V, et = a.createDocumentFragment(), j = [], Q = 0, bt = o.length; Q < bt; Q++)
                if ((m = o[Q]) || 0 === m)
                    if ("object" === u.type(m)) u.merge(j, m.nodeType ? [m] : m);
                    else if (Ne.test(m)) {
                for (_ = _ || et.appendChild(a.createElement("div")), E = (Ae.exec(m) || ["", ""])[1].toLowerCase(), _.innerHTML = ($ = Ot[E] || Ot._default)[1] + u.htmlPrefilter(m) + $[2], V = $[0]; V--;) _ = _.lastChild;
                u.merge(j, _.childNodes), (_ = et.firstChild).textContent = ""
            } else j.push(a.createTextNode(m));
            for (et.textContent = "", Q = 0; m = j[Q++];)
                if (c && u.inArray(m, c) > -1) v && v.push(m);
                else if (W = u.contains(m.ownerDocument, m), _ = Ut(et.appendChild(m), "script"), W && ke(_), h)
                for (V = 0; m = _[V++];) xe.test(m.type || "") && h.push(m);
            return et
        }
        a = it.createDocumentFragment().appendChild(it.createElement("div")), (h = it.createElement("input")).setAttribute("type", "radio"), h.setAttribute("checked", "checked"), h.setAttribute("name", "t"), a.appendChild(h), K.checkClone = a.cloneNode(!0).cloneNode(!0).lastChild.checked, a.innerHTML = "<textarea>x</textarea>", K.noCloneChecked = !!a.cloneNode(!0).lastChild.defaultValue;
        var oe = it.documentElement,
            ue = /^key/,
            Mt = /^(?:mouse|pointer|contextmenu|drag|drop)|click/,
            qt = /^([^.]*)(?:\.(.+)|)/;

        function qe() {
            return !0
        }

        function Te() {
            return !1
        }

        function fi() {
            try {
                return it.activeElement
            } catch (o) {}
        }

        function Qe(o, a, h, c, v, m) {
            var _, E;
            if ("object" == typeof a) {
                for (E in "string" != typeof h && (c = c || h, h = void 0), a) Qe(o, E, h, c, a[E], m);
                return o
            }
            if (null == c && null == v ? (v = h, c = h = void 0) : null == v && ("string" == typeof h ? (v = c, c = void 0) : (v = c, c = h, h = void 0)), !1 === v) v = Te;
            else if (!v) return o;
            return 1 === m && (_ = v, v = function($) {
                return u().off($), _.apply(this, arguments)
            }, v.guid = _.guid || (_.guid = u.guid++)), o.each(function() {
                u.event.add(this, a, v, c, h)
            })
        }
        u.event = {
            global: {},
            add: function(o, a, h, c, v) {
                var m, _, E, $, W, V, et, j, Q, bt, Ct, gt = at.get(o);
                if (gt)
                    for (h.handler && (h = (m = h).handler, v = m.selector), v && u.find.matchesSelector(oe, v), h.guid || (h.guid = u.guid++), ($ = gt.events) || ($ = gt.events = {}), (_ = gt.handle) || (_ = gt.handle = function(Ft) {
                            return void 0 !== u && u.event.triggered !== Ft.type ? u.event.dispatch.apply(o, arguments) : void 0
                        }), W = (a = (a || "").match(q) || [""]).length; W--;) Q = Ct = (E = qt.exec(a[W]) || [])[1], bt = (E[2] || "").split(".").sort(), Q && (et = u.event.special[Q] || {}, et = u.event.special[Q = (v ? et.delegateType : et.bindType) || Q] || {}, V = u.extend({
                        type: Q,
                        origType: Ct,
                        data: c,
                        handler: h,
                        guid: h.guid,
                        selector: v,
                        needsContext: v && u.expr.match.needsContext.test(v),
                        namespace: bt.join(".")
                    }, m), (j = $[Q]) || ((j = $[Q] = []).delegateCount = 0, et.setup && !1 !== et.setup.call(o, c, bt, _) || o.addEventListener && o.addEventListener(Q, _)), et.add && (et.add.call(o, V), V.handler.guid || (V.handler.guid = h.guid)), v ? j.splice(j.delegateCount++, 0, V) : j.push(V), u.event.global[Q] = !0)
            },
            remove: function(o, a, h, c, v) {
                var m, _, E, $, W, V, et, j, Q, bt, Ct, gt = at.hasData(o) && at.get(o);
                if (gt && ($ = gt.events)) {
                    for (W = (a = (a || "").match(q) || [""]).length; W--;)
                        if (Q = Ct = (E = qt.exec(a[W]) || [])[1], bt = (E[2] || "").split(".").sort(), Q) {
                            for (et = u.event.special[Q] || {}, j = $[Q = (c ? et.delegateType : et.bindType) || Q] || [], E = E[2] && new RegExp("(^|\\.)" + bt.join("\\.(?:.*\\.|)") + "(\\.|$)"), _ = m = j.length; m--;) V = j[m], !v && Ct !== V.origType || h && h.guid !== V.guid || E && !E.test(V.namespace) || c && c !== V.selector && ("**" !== c || !V.selector) || (j.splice(m, 1), V.selector && j.delegateCount--, et.remove && et.remove.call(o, V));
                            _ && !j.length && (et.teardown && !1 !== et.teardown.call(o, bt, gt.handle) || u.removeEvent(o, Q, gt.handle), delete $[Q])
                        } else
                            for (Q in $) u.event.remove(o, Q + a[W], h, c, !0);
                    u.isEmptyObject($) && at.remove(o, "handle events")
                }
            },
            dispatch: function(o) {
                var h, c, v, m, _, E, a = u.event.fix(o),
                    $ = new Array(arguments.length),
                    W = (at.get(this, "events") || {})[a.type] || [],
                    V = u.event.special[a.type] || {};
                for ($[0] = a, h = 1; h < arguments.length; h++) $[h] = arguments[h];
                if (a.delegateTarget = this, !V.preDispatch || !1 !== V.preDispatch.call(this, a)) {
                    for (E = u.event.handlers.call(this, a, W), h = 0;
                        (m = E[h++]) && !a.isPropagationStopped();)
                        for (a.currentTarget = m.elem, c = 0;
                            (_ = m.handlers[c++]) && !a.isImmediatePropagationStopped();) a.rnamespace && !a.rnamespace.test(_.namespace) || (a.handleObj = _, a.data = _.data, void 0 !== (v = ((u.event.special[_.origType] || {}).handle || _.handler).apply(m.elem, $)) && !1 === (a.result = v) && (a.preventDefault(), a.stopPropagation()));
                    return V.postDispatch && V.postDispatch.call(this, a), a.result
                }
            },
            handlers: function(o, a) {
                var h, c, v, m, _, E = [],
                    $ = a.delegateCount,
                    W = o.target;
                if ($ && W.nodeType && !("click" === o.type && o.button >= 1))
                    for (; W !== this; W = W.parentNode || this)
                        if (1 === W.nodeType && ("click" !== o.type || !0 !== W.disabled)) {
                            for (m = [], _ = {}, h = 0; h < $; h++) void 0 === _[v = (c = a[h]).selector + " "] && (_[v] = c.needsContext ? u(v, this).index(W) > -1 : u.find(v, this, null, [W]).length), _[v] && m.push(c);
                            m.length && E.push({
                                elem: W,
                                handlers: m
                            })
                        }
                return W = this, $ < a.length && E.push({
                    elem: W,
                    handlers: a.slice($)
                }), E
            },
            addProp: function(o, a) {
                Object.defineProperty(u.Event.prototype, o, {
                    enumerable: !0,
                    configurable: !0,
                    get: u.isFunction(a) ? function() {
                        if (this.originalEvent) return a(this.originalEvent)
                    } : function() {
                        if (this.originalEvent) return this.originalEvent[o]
                    },
                    set: function(h) {
                        Object.defineProperty(this, o, {
                            enumerable: !0,
                            configurable: !0,
                            writable: !0,
                            value: h
                        })
                    }
                })
            },
            fix: function(o) {
                return o[u.expando] ? o : new u.Event(o)
            },
            special: {
                load: {
                    noBubble: !0
                },
                focus: {
                    trigger: function() {
                        if (this !== fi() && this.focus) return this.focus(), !1
                    },
                    delegateType: "focusin"
                },
                blur: {
                    trigger: function() {
                        if (this === fi() && this.blur) return this.blur(), !1
                    },
                    delegateType: "focusout"
                },
                click: {
                    trigger: function() {
                        if ("checkbox" === this.type && this.click && u.nodeName(this, "input")) return this.click(), !1
                    },
                    _default: function(o) {
                        return u.nodeName(o.target, "a")
                    }
                },
                beforeunload: {
                    postDispatch: function(o) {
                        void 0 !== o.result && o.originalEvent && (o.originalEvent.returnValue = o.result)
                    }
                }
            }
        }, u.removeEvent = function(o, a, h) {
            o.removeEventListener && o.removeEventListener(a, h)
        }, u.Event = function(o, a) {
            return this instanceof u.Event ? (o && o.type ? (this.originalEvent = o, this.type = o.type, this.isDefaultPrevented = o.defaultPrevented || void 0 === o.defaultPrevented && !1 === o.returnValue ? qe : Te, this.target = o.target && 3 === o.target.nodeType ? o.target.parentNode : o.target, this.currentTarget = o.currentTarget, this.relatedTarget = o.relatedTarget) : this.type = o, a && u.extend(this, a), this.timeStamp = o && o.timeStamp || u.now(), void(this[u.expando] = !0)) : new u.Event(o, a)
        }, u.Event.prototype = {
            constructor: u.Event,
            isDefaultPrevented: Te,
            isPropagationStopped: Te,
            isImmediatePropagationStopped: Te,
            isSimulated: !1,
            preventDefault: function() {
                var o = this.originalEvent;
                this.isDefaultPrevented = qe, o && !this.isSimulated && o.preventDefault()
            },
            stopPropagation: function() {
                var o = this.originalEvent;
                this.isPropagationStopped = qe, o && !this.isSimulated && o.stopPropagation()
            },
            stopImmediatePropagation: function() {
                var o = this.originalEvent;
                this.isImmediatePropagationStopped = qe, o && !this.isSimulated && o.stopImmediatePropagation(), this.stopPropagation()
            }
        }, u.each({
            altKey: !0,
            bubbles: !0,
            cancelable: !0,
            changedTouches: !0,
            ctrlKey: !0,
            detail: !0,
            eventPhase: !0,
            metaKey: !0,
            pageX: !0,
            pageY: !0,
            shiftKey: !0,
            view: !0,
            char: !0,
            charCode: !0,
            key: !0,
            keyCode: !0,
            button: !0,
            buttons: !0,
            clientX: !0,
            clientY: !0,
            offsetX: !0,
            offsetY: !0,
            pointerId: !0,
            pointerType: !0,
            screenX: !0,
            screenY: !0,
            targetTouches: !0,
            toElement: !0,
            touches: !0,
            which: function(o) {
                var a = o.button;
                return null == o.which && ue.test(o.type) ? null != o.charCode ? o.charCode : o.keyCode : !o.which && void 0 !== a && Mt.test(o.type) ? 1 & a ? 1 : 2 & a ? 3 : 4 & a ? 2 : 0 : o.which
            }
        }, u.event.addProp), u.each({
            mouseenter: "mouseover",
            mouseleave: "mouseout",
            pointerenter: "pointerover",
            pointerleave: "pointerout"
        }, function(o, a) {
            u.event.special[o] = {
                delegateType: a,
                bindType: a,
                handle: function(h) {
                    var c, v = this,
                        m = h.relatedTarget,
                        _ = h.handleObj;
                    return m && (m === v || u.contains(v, m)) || (h.type = _.origType, c = _.handler.apply(this, arguments), h.type = a), c
                }
            }
        }), u.fn.extend({
            on: function(o, a, h, c) {
                return Qe(this, o, a, h, c)
            },
            one: function(o, a, h, c) {
                return Qe(this, o, a, h, c, 1)
            },
            off: function(o, a, h) {
                var c, v;
                if (o && o.preventDefault && o.handleObj) return c = o.handleObj, u(o.delegateTarget).off(c.namespace ? c.origType + "." + c.namespace : c.origType, c.selector, c.handler), this;
                if ("object" == typeof o) {
                    for (v in o) this.off(v, a, o[v]);
                    return this
                }
                return !1 !== a && "function" != typeof a || (h = a, a = void 0), !1 === h && (h = Te), this.each(function() {
                    u.event.remove(this, o, h, a)
                })
            }
        });
        var Ki = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([a-z][^\/\0>\x20\t\r\n\f]*)[^>]*)\/>/gi,
            Xi = /<script|<style|<link/i,
            Gi = /checked\s*(?:[^=]|=\s*.checked.)/i,
            Qi = /^true\/(.*)/,
            Ji = /^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g;

        function mi(o, a) {
            return u.nodeName(o, "table") && u.nodeName(11 !== a.nodeType ? a : a.firstChild, "tr") && o.getElementsByTagName("tbody")[0] || o
        }

        function Zi(o) {
            return o.type = (null !== o.getAttribute("type")) + "/" + o.type, o
        }

        function tn(o) {
            var a = Qi.exec(o.type);
            return a ? o.type = a[1] : o.removeAttribute("type"), o
        }

        function gi(o, a) {
            var h, c, v, m, _, E, $, W;
            if (1 === a.nodeType) {
                if (at.hasData(o) && (m = at.access(o), _ = at.set(a, m), W = m.events))
                    for (v in delete _.handle, _.events = {}, W)
                        for (h = 0, c = W[v].length; h < c; h++) u.event.add(a, v, W[v][h]);
                St.hasData(o) && (E = St.access(o), $ = u.extend({}, E), St.set(a, $))
            }
        }

        function en(o, a) {
            var h = a.nodeName.toLowerCase();
            "input" === h && je.test(o.type) ? a.checked = o.checked : "input" !== h && "textarea" !== h || (a.defaultValue = o.defaultValue)
        }

        function De(o, a, h, c) {
            a = p.apply([], a);
            var v, m, _, E, $, W, V = 0,
                et = o.length,
                j = et - 1,
                Q = a[0],
                bt = u.isFunction(Q);
            if (bt || et > 1 && "string" == typeof Q && !K.checkClone && Gi.test(Q)) return o.each(function(Ct) {
                var gt = o.eq(Ct);
                bt && (a[0] = Q.call(this, Ct, gt.html())), De(gt, a, h, c)
            });
            if (et && (m = (v = Ce(a, o[0].ownerDocument, !1, o, c)).firstChild, 1 === v.childNodes.length && (v = m), m || c)) {
                for (E = (_ = u.map(Ut(v, "script"), Zi)).length; V < et; V++) $ = v, V !== j && ($ = u.clone($, !0, !0), E && u.merge(_, Ut($, "script"))), h.call(o[V], $, V);
                if (E)
                    for (W = _[_.length - 1].ownerDocument, u.map(_, tn), V = 0; V < E; V++) xe.test(($ = _[V]).type || "") && !at.access($, "globalEval") && u.contains(W, $) && ($.src ? u._evalUrl && u._evalUrl($.src) : Y($.textContent.replace(Ji, ""), W))
            }
            return o
        }

        function vi(o, a, h) {
            for (var c, v = a ? u.filter(a, o) : o, m = 0; null != (c = v[m]); m++) h || 1 !== c.nodeType || u.cleanData(Ut(c)), c.parentNode && (h && u.contains(c.ownerDocument, c) && ke(Ut(c, "script")), c.parentNode.removeChild(c));
            return o
        }
        u.extend({
            htmlPrefilter: function(o) {
                return o.replace(Ki, "<$1></$2>")
            },
            clone: function(o, a, h) {
                var c, v, m, _, E = o.cloneNode(!0),
                    $ = u.contains(o.ownerDocument, o);
                if (!(K.noCloneChecked || 1 !== o.nodeType && 11 !== o.nodeType || u.isXMLDoc(o)))
                    for (_ = Ut(E), c = 0, v = (m = Ut(o)).length; c < v; c++) en(m[c], _[c]);
                if (a)
                    if (h)
                        for (m = m || Ut(o), _ = _ || Ut(E), c = 0, v = m.length; c < v; c++) gi(m[c], _[c]);
                    else gi(o, E);
                return (_ = Ut(E, "script")).length > 0 && ke(_, !$ && Ut(o, "script")), E
            },
            cleanData: function(o) {
                for (var a, h, c, v = u.event.special, m = 0; void 0 !== (h = o[m]); m++)
                    if (dt(h)) {
                        if (a = h[at.expando]) {
                            if (a.events)
                                for (c in a.events) v[c] ? u.event.remove(h, c) : u.removeEvent(h, c, a.handle);
                            h[at.expando] = void 0
                        }
                        h[St.expando] && (h[St.expando] = void 0)
                    }
            }
        }), u.fn.extend({
            detach: function(o) {
                return vi(this, o, !0)
            },
            remove: function(o) {
                return vi(this, o)
            },
            text: function(o) {
                return mt(this, function(a) {
                    return void 0 === a ? u.text(this) : this.empty().each(function() {
                        1 !== this.nodeType && 11 !== this.nodeType && 9 !== this.nodeType || (this.textContent = a)
                    })
                }, null, o, arguments.length)
            },
            append: function() {
                return De(this, arguments, function(o) {
                    1 !== this.nodeType && 11 !== this.nodeType && 9 !== this.nodeType || mi(this, o).appendChild(o)
                })
            },
            prepend: function() {
                return De(this, arguments, function(o) {
                    if (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) {
                        var a = mi(this, o);
                        a.insertBefore(o, a.firstChild)
                    }
                })
            },
            before: function() {
                return De(this, arguments, function(o) {
                    this.parentNode && this.parentNode.insertBefore(o, this)
                })
            },
            after: function() {
                return De(this, arguments, function(o) {
                    this.parentNode && this.parentNode.insertBefore(o, this.nextSibling)
                })
            },
            empty: function() {
                for (var o, a = 0; null != (o = this[a]); a++) 1 === o.nodeType && (u.cleanData(Ut(o, !1)), o.textContent = "");
                return this
            },
            clone: function(o, a) {
                return o = null != o && o, a = null == a ? o : a, this.map(function() {
                    return u.clone(this, o, a)
                })
            },
            html: function(o) {
                return mt(this, function(a) {
                    var h = this[0] || {},
                        c = 0,
                        v = this.length;
                    if (void 0 === a && 1 === h.nodeType) return h.innerHTML;
                    if ("string" == typeof a && !Xi.test(a) && !Ot[(Ae.exec(a) || ["", ""])[1].toLowerCase()]) {
                        a = u.htmlPrefilter(a);
                        try {
                            for (; c < v; c++) 1 === (h = this[c] || {}).nodeType && (u.cleanData(Ut(h, !1)), h.innerHTML = a);
                            h = 0
                        } catch (m) {}
                    }
                    h && this.empty().append(a)
                }, null, o, arguments.length)
            },
            replaceWith: function() {
                var o = [];
                return De(this, arguments, function(a) {
                    var h = this.parentNode;
                    u.inArray(this, o) < 0 && (u.cleanData(Ut(this)), h && h.replaceChild(a, this))
                }, o)
            }
        }), u.each({
            appendTo: "append",
            prependTo: "prepend",
            insertBefore: "before",
            insertAfter: "after",
            replaceAll: "replaceWith"
        }, function(o, a) {
            u.fn[o] = function(h) {
                for (var c, v = [], m = u(h), _ = m.length - 1, E = 0; E <= _; E++) c = E === _ ? this : this.clone(!0), u(m[E])[a](c), x.apply(v, c.get());
                return this.pushStack(v)
            }
        });
        var _i = /^margin/,
            Je = new RegExp("^(" + It + ")(?!px)[a-z%]+$", "i"),
            Be = function(o) {
                var a = o.ownerDocument.defaultView;
                return a && a.opener || (a = i), a.getComputedStyle(o)
            };

        function Me(o, a, h) {
            var c, v, m, _, E = o.style;
            return (h = h || Be(o)) && ("" !== (_ = h.getPropertyValue(a) || h[a]) || u.contains(o.ownerDocument, o) || (_ = u.style(o, a)), !K.pixelMarginRight() && Je.test(_) && _i.test(a) && (c = E.width, v = E.minWidth, m = E.maxWidth, E.minWidth = E.maxWidth = E.width = _, _ = h.width, E.width = c, E.minWidth = v, E.maxWidth = m)), void 0 !== _ ? _ + "" : _
        }

        function yi(o, a) {
            return {
                get: function() {
                    return o() ? void delete this.get : (this.get = a).apply(this, arguments)
                }
            }
        }! function() {
            function o() {
                if (_) {
                    _.style.cssText = "box-sizing:border-box;position:relative;display:block;margin:auto;border:1px;padding:1px;top:1%;width:50%", _.innerHTML = "", oe.appendChild(m);
                    var E = i.getComputedStyle(_);
                    a = "1%" !== E.top, v = "2px" === E.marginLeft, h = "4px" === E.width, _.style.marginRight = "50%", c = "4px" === E.marginRight, oe.removeChild(m), _ = null
                }
            }
            var a, h, c, v, m = it.createElement("div"),
                _ = it.createElement("div");
            _.style && (_.style.backgroundClip = "content-box", _.cloneNode(!0).style.backgroundClip = "", K.clearCloneStyle = "content-box" === _.style.backgroundClip, m.style.cssText = "border:0;width:8px;height:0;top:0;left:-9999px;padding:0;margin-top:1px;position:absolute", m.appendChild(_), u.extend(K, {
                pixelPosition: function() {
                    return o(), a
                },
                boxSizingReliable: function() {
                    return o(), h
                },
                pixelMarginRight: function() {
                    return o(), c
                },
                reliableMarginLeft: function() {
                    return o(), v
                }
            }))
        }();
        var nn = /^(none|table(?!-c[ea]).+)/,
            sn = {
                position: "absolute",
                visibility: "hidden",
                display: "block"
            },
            bi = {
                letterSpacing: "0",
                fontWeight: "400"
            },
            wi = ["Webkit", "Moz", "ms"],
            xi = it.createElement("div").style;

        function ki(o) {
            if (o in xi) return o;
            for (var a = o[0].toUpperCase() + o.slice(1), h = wi.length; h--;)
                if ((o = wi[h] + a) in xi) return o
        }

        function Ci(o, a, h) {
            var c = Kt.exec(a);
            return c ? Math.max(0, c[2] - (h || 0)) + (c[3] || "px") : a
        }

        function Ti(o, a, h, c, v) {
            var m, _ = 0;
            for (m = h === (c ? "border" : "content") ? 4 : "width" === a ? 1 : 0; m < 4; m += 2) "margin" === h && (_ += u.css(o, h + jt[m], !0, v)), c ? ("content" === h && (_ -= u.css(o, "padding" + jt[m], !0, v)), "margin" !== h && (_ -= u.css(o, "border" + jt[m] + "Width", !0, v))) : (_ += u.css(o, "padding" + jt[m], !0, v), "padding" !== h && (_ += u.css(o, "border" + jt[m] + "Width", !0, v)));
            return _
        }

        function Di(o, a, h) {
            var c, v = !0,
                m = Be(o),
                _ = "border-box" === u.css(o, "boxSizing", !1, m);
            if (o.getClientRects().length && (c = o.getBoundingClientRect()[a]), c <= 0 || null == c) {
                if (((c = Me(o, a, m)) < 0 || null == c) && (c = o.style[a]), Je.test(c)) return c;
                v = _ && (K.boxSizingReliable() || c === o.style[a]), c = parseFloat(c) || 0
            }
            return c + Ti(o, a, h || (_ ? "border" : "content"), v, m) + "px"
        }

        function Gt(o, a, h, c, v) {
            return new Gt.prototype.init(o, a, h, c, v)
        }
        u.extend({
            cssHooks: {
                opacity: {
                    get: function(o, a) {
                        if (a) {
                            var h = Me(o, "opacity");
                            return "" === h ? "1" : h
                        }
                    }
                }
            },
            cssNumber: {
                animationIterationCount: !0,
                columnCount: !0,
                fillOpacity: !0,
                flexGrow: !0,
                flexShrink: !0,
                fontWeight: !0,
                lineHeight: !0,
                opacity: !0,
                order: !0,
                orphans: !0,
                widows: !0,
                zIndex: !0,
                zoom: !0
            },
            cssProps: {
                float: "cssFloat"
            },
            style: function(o, a, h, c) {
                if (o && 3 !== o.nodeType && 8 !== o.nodeType && o.style) {
                    var v, m, _, E = u.camelCase(a),
                        $ = o.style;
                    return a = u.cssProps[E] || (u.cssProps[E] = ki(E) || E), _ = u.cssHooks[a] || u.cssHooks[E], void 0 === h ? _ && "get" in _ && void 0 !== (v = _.get(o, !1, c)) ? v : $[a] : ("string" == (m = typeof h) && (v = Kt.exec(h)) && v[1] && (h = ne(o, a, v), m = "number"), void(null != h && h == h && ("number" === m && (h += v && v[3] || (u.cssNumber[E] ? "" : "px")), K.clearCloneStyle || "" !== h || 0 !== a.indexOf("background") || ($[a] = "inherit"), _ && "set" in _ && void 0 === (h = _.set(o, h, c)) || ($[a] = h))))
                }
            },
            css: function(o, a, h, c) {
                var v, m, _, E = u.camelCase(a);
                return a = u.cssProps[E] || (u.cssProps[E] = ki(E) || E), (_ = u.cssHooks[a] || u.cssHooks[E]) && "get" in _ && (v = _.get(o, !0, h)), void 0 === v && (v = Me(o, a, c)), "normal" === v && a in bi && (v = bi[a]), "" === h || h ? (m = parseFloat(v), !0 === h || isFinite(m) ? m || 0 : v) : v
            }
        }), u.each(["height", "width"], function(o, a) {
            u.cssHooks[a] = {
                get: function(h, c, v) {
                    if (c) return !nn.test(u.css(h, "display")) || h.getClientRects().length && h.getBoundingClientRect().width ? Di(h, a, v) : Vt(h, sn, function() {
                        return Di(h, a, v)
                    })
                },
                set: function(h, c, v) {
                    var m, _ = v && Be(h),
                        E = v && Ti(h, a, v, "border-box" === u.css(h, "boxSizing", !1, _), _);
                    return E && (m = Kt.exec(c)) && "px" !== (m[3] || "px") && (h.style[a] = c, c = u.css(h, a)), Ci(0, c, E)
                }
            }
        }), u.cssHooks.marginLeft = yi(K.reliableMarginLeft, function(o, a) {
            if (a) return (parseFloat(Me(o, "marginLeft")) || o.getBoundingClientRect().left - Vt(o, {
                marginLeft: 0
            }, function() {
                return o.getBoundingClientRect().left
            })) + "px"
        }), u.each({
            margin: "",
            padding: "",
            border: "Width"
        }, function(o, a) {
            u.cssHooks[o + a] = {
                expand: function(h) {
                    for (var c = 0, v = {}, m = "string" == typeof h ? h.split(" ") : [h]; c < 4; c++) v[o + jt[c] + a] = m[c] || m[c - 2] || m[0];
                    return v
                }
            }, _i.test(o) || (u.cssHooks[o + a].set = Ci)
        }), u.fn.extend({
            css: function(o, a) {
                return mt(this, function(h, c, v) {
                    var m, _, E = {},
                        $ = 0;
                    if (u.isArray(c)) {
                        for (m = Be(h), _ = c.length; $ < _; $++) E[c[$]] = u.css(h, c[$], !1, m);
                        return E
                    }
                    return void 0 !== v ? u.style(h, c, v) : u.css(h, c)
                }, o, a, arguments.length > 1)
            }
        }), u.Tween = Gt, (Gt.prototype = {
            constructor: Gt,
            init: function(o, a, h, c, v, m) {
                this.elem = o, this.prop = h, this.easing = v || u.easing._default, this.options = a, this.start = this.now = this.cur(), this.end = c, this.unit = m || (u.cssNumber[h] ? "" : "px")
            },
            cur: function() {
                var o = Gt.propHooks[this.prop];
                return o && o.get ? o.get(this) : Gt.propHooks._default.get(this)
            },
            run: function(o) {
                var a, h = Gt.propHooks[this.prop];
                return this.pos = a = this.options.duration ? u.easing[this.easing](o, this.options.duration * o, 0, 1, this.options.duration) : o, this.now = (this.end - this.start) * a + this.start, this.options.step && this.options.step.call(this.elem, this.now, this), h && h.set ? h.set(this) : Gt.propHooks._default.set(this), this
            }
        }).init.prototype = Gt.prototype, (Gt.propHooks = {
            _default: {
                get: function(o) {
                    var a;
                    return 1 !== o.elem.nodeType || null != o.elem[o.prop] && null == o.elem.style[o.prop] ? o.elem[o.prop] : (a = u.css(o.elem, o.prop, "")) && "auto" !== a ? a : 0
                },
                set: function(o) {
                    u.fx.step[o.prop] ? u.fx.step[o.prop](o) : 1 !== o.elem.nodeType || null == o.elem.style[u.cssProps[o.prop]] && !u.cssHooks[o.prop] ? o.elem[o.prop] = o.now : u.style(o.elem, o.prop, o.now + o.unit)
                }
            }
        }).scrollTop = Gt.propHooks.scrollLeft = {
            set: function(o) {
                o.elem.nodeType && o.elem.parentNode && (o.elem[o.prop] = o.now)
            }
        }, u.easing = {
            linear: function(o) {
                return o
            },
            swing: function(o) {
                return .5 - Math.cos(o * Math.PI) / 2
            },
            _default: "swing"
        }, u.fx = Gt.prototype.init, u.fx.step = {};
        var Se, Ie, on = /^(?:toggle|show|hide)$/,
            rn = /queueHooks$/;

        function Si() {
            Ie && (i.requestAnimationFrame(Si), u.fx.tick())
        }

        function Ii() {
            return i.setTimeout(function() {
                Se = void 0
            }), Se = u.now()
        }

        function Ue(o, a) {
            var h, c = 0,
                v = {
                    height: o
                };
            for (a = a ? 1 : 0; c < 4; c += 2 - a) v["margin" + (h = jt[c])] = v["padding" + h] = o;
            return a && (v.opacity = v.width = o), v
        }

        function Ei(o, a, h) {
            for (var c, v = (re.tweeners[a] || []).concat(re.tweeners["*"]), m = 0, _ = v.length; m < _; m++)
                if (c = v[m].call(h, a, o)) return c
        }

        function re(o, a, h) {
            var c, v, m = 0,
                _ = re.prefilters.length,
                E = u.Deferred().always(function() {
                    delete $.elem
                }),
                $ = function() {
                    if (v) return !1;
                    for (var et = Se || Ii(), j = Math.max(0, W.startTime + W.duration - et), bt = 1 - (j / W.duration || 0), Ct = 0, gt = W.tweens.length; Ct < gt; Ct++) W.tweens[Ct].run(bt);
                    return E.notifyWith(o, [W, bt, j]), bt < 1 && gt ? j : (E.resolveWith(o, [W]), !1)
                },
                W = E.promise({
                    elem: o,
                    props: u.extend({}, a),
                    opts: u.extend(!0, {
                        specialEasing: {},
                        easing: u.easing._default
                    }, h),
                    originalProperties: a,
                    originalOptions: h,
                    startTime: Se || Ii(),
                    duration: h.duration,
                    tweens: [],
                    createTween: function(et, j) {
                        var Q = u.Tween(o, W.opts, et, j, W.opts.specialEasing[et] || W.opts.easing);
                        return W.tweens.push(Q), Q
                    },
                    stop: function(et) {
                        var j = 0,
                            Q = et ? W.tweens.length : 0;
                        if (v) return this;
                        for (v = !0; j < Q; j++) W.tweens[j].run(1);
                        return et ? (E.notifyWith(o, [W, 1, 0]), E.resolveWith(o, [W, et])) : E.rejectWith(o, [W, et]), this
                    }
                }),
                V = W.props;
            for (function ln(o, a) {
                    var h, c, v, m, _;
                    for (h in o)
                        if (v = a[c = u.camelCase(h)], u.isArray(m = o[h]) && (v = m[1], m = o[h] = m[0]), h !== c && (o[c] = m, delete o[h]), (_ = u.cssHooks[c]) && "expand" in _)
                            for (h in m = _.expand(m), delete o[c], m) h in o || (o[h] = m[h], a[h] = v);
                        else a[c] = v
                }(V, W.opts.specialEasing); m < _; m++)
                if (c = re.prefilters[m].call(W, o, V, W.opts)) return u.isFunction(c.stop) && (u._queueHooks(W.elem, W.opts.queue).stop = u.proxy(c.stop, c)), c;
            return u.map(V, Ei, W), u.isFunction(W.opts.start) && W.opts.start.call(o, W), u.fx.timer(u.extend($, {
                elem: o,
                anim: W,
                queue: W.opts.queue
            })), W.progress(W.opts.progress).done(W.opts.done, W.opts.complete).fail(W.opts.fail).always(W.opts.always)
        }
        u.Animation = u.extend(re, {
                tweeners: {
                    "*": [function(o, a) {
                        var h = this.createTween(o, a);
                        return ne(h.elem, o, Kt.exec(a), h), h
                    }]
                },
                tweener: function(o, a) {
                    u.isFunction(o) ? (a = o, o = ["*"]) : o = o.match(q);
                    for (var h, c = 0, v = o.length; c < v; c++)(re.tweeners[h = o[c]] = re.tweeners[h] || []).unshift(a)
                },
                prefilters: [function an(o, a, h) {
                    var c, v, m, _, E, $, W, V, et = "width" in a || "height" in a,
                        j = this,
                        Q = {},
                        bt = o.style,
                        Ct = o.nodeType && Xt(o),
                        gt = at.get(o, "fxshow");
                    for (c in h.queue || (null == (_ = u._queueHooks(o, "fx")).unqueued && (_.unqueued = 0, E = _.empty.fire, _.empty.fire = function() {
                            _.unqueued || E()
                        }), _.unqueued++, j.always(function() {
                            j.always(function() {
                                _.unqueued--, u.queue(o, "fx").length || _.empty.fire()
                            })
                        })), a)
                        if (on.test(v = a[c])) {
                            if (delete a[c], m = m || "toggle" === v, v === (Ct ? "hide" : "show")) {
                                if ("show" !== v || !gt || void 0 === gt[c]) continue;
                                Ct = !0
                            }
                            Q[c] = gt && gt[c] || u.style(o, c)
                        }
                    if (($ = !u.isEmptyObject(a)) || !u.isEmptyObject(Q))
                        for (c in et && 1 === o.nodeType && (h.overflow = [bt.overflow, bt.overflowX, bt.overflowY], null == (W = gt && gt.display) && (W = at.get(o, "display")), "none" === (V = u.css(o, "display")) && (W ? V = W : (Bt([o], !0), W = o.style.display || W, V = u.css(o, "display"), Bt([o]))), ("inline" === V || "inline-block" === V && null != W) && "none" === u.css(o, "float") && ($ || (j.done(function() {
                                bt.display = W
                            }), null == W && (W = "none" === (V = bt.display) ? "" : V)), bt.display = "inline-block")), h.overflow && (bt.overflow = "hidden", j.always(function() {
                                bt.overflow = h.overflow[0], bt.overflowX = h.overflow[1], bt.overflowY = h.overflow[2]
                            })), $ = !1, Q) $ || (gt ? "hidden" in gt && (Ct = gt.hidden) : gt = at.access(o, "fxshow", {
                            display: W
                        }), m && (gt.hidden = !Ct), Ct && Bt([o], !0), j.done(function() {
                            for (c in Ct || Bt([o]), at.remove(o, "fxshow"), Q) u.style(o, c, Q[c])
                        })), $ = Ei(Ct ? gt[c] : 0, c, j), c in gt || (gt[c] = $.start, Ct && ($.end = $.start, $.start = 0))
                }],
                prefilter: function(o, a) {
                    a ? re.prefilters.unshift(o) : re.prefilters.push(o)
                }
            }), u.speed = function(o, a, h) {
                var c = o && "object" == typeof o ? u.extend({}, o) : {
                    complete: h || !h && a || u.isFunction(o) && o,
                    duration: o,
                    easing: h && a || a && !u.isFunction(a) && a
                };
                return u.fx.off || it.hidden ? c.duration = 0 : "number" != typeof c.duration && (c.duration = c.duration in u.fx.speeds ? u.fx.speeds[c.duration] : u.fx.speeds._default), null != c.queue && !0 !== c.queue || (c.queue = "fx"), c.old = c.complete, c.complete = function() {
                    u.isFunction(c.old) && c.old.call(this), c.queue && u.dequeue(this, c.queue)
                }, c
            }, u.fn.extend({
                fadeTo: function(o, a, h, c) {
                    return this.filter(Xt).css("opacity", 0).show().end().animate({
                        opacity: a
                    }, o, h, c)
                },
                animate: function(o, a, h, c) {
                    var v = u.isEmptyObject(o),
                        m = u.speed(a, h, c),
                        _ = function() {
                            var E = re(this, u.extend({}, o), m);
                            (v || at.get(this, "finish")) && E.stop(!0)
                        };
                    return _.finish = _, v || !1 === m.queue ? this.each(_) : this.queue(m.queue, _)
                },
                stop: function(o, a, h) {
                    var c = function(v) {
                        var m = v.stop;
                        delete v.stop, m(h)
                    };
                    return "string" != typeof o && (h = a, a = o, o = void 0), a && !1 !== o && this.queue(o || "fx", []), this.each(function() {
                        var v = !0,
                            m = null != o && o + "queueHooks",
                            _ = u.timers,
                            E = at.get(this);
                        if (m) E[m] && E[m].stop && c(E[m]);
                        else
                            for (m in E) E[m] && E[m].stop && rn.test(m) && c(E[m]);
                        for (m = _.length; m--;) _[m].elem !== this || null != o && _[m].queue !== o || (_[m].anim.stop(h), v = !1, _.splice(m, 1));
                        !v && h || u.dequeue(this, o)
                    })
                },
                finish: function(o) {
                    return !1 !== o && (o = o || "fx"), this.each(function() {
                        var a, h = at.get(this),
                            c = h[o + "queue"],
                            v = h[o + "queueHooks"],
                            m = u.timers,
                            _ = c ? c.length : 0;
                        for (h.finish = !0, u.queue(this, o, []), v && v.stop && v.stop.call(this, !0), a = m.length; a--;) m[a].elem === this && m[a].queue === o && (m[a].anim.stop(!0), m.splice(a, 1));
                        for (a = 0; a < _; a++) c[a] && c[a].finish && c[a].finish.call(this);
                        delete h.finish
                    })
                }
            }), u.each(["toggle", "show", "hide"], function(o, a) {
                var h = u.fn[a];
                u.fn[a] = function(c, v, m) {
                    return null == c || "boolean" == typeof c ? h.apply(this, arguments) : this.animate(Ue(a, !0), c, v, m)
                }
            }), u.each({
                slideDown: Ue("show"),
                slideUp: Ue("hide"),
                slideToggle: Ue("toggle"),
                fadeIn: {
                    opacity: "show"
                },
                fadeOut: {
                    opacity: "hide"
                },
                fadeToggle: {
                    opacity: "toggle"
                }
            }, function(o, a) {
                u.fn[o] = function(h, c, v) {
                    return this.animate(a, h, c, v)
                }
            }), u.timers = [], u.fx.tick = function() {
                var o, a = 0,
                    h = u.timers;
                for (Se = u.now(); a < h.length; a++)(o = h[a])() || h[a] !== o || h.splice(a--, 1);
                h.length || u.fx.stop(), Se = void 0
            }, u.fx.timer = function(o) {
                u.timers.push(o), o() ? u.fx.start() : u.timers.pop()
            }, u.fx.interval = 13, u.fx.start = function() {
                Ie || (Ie = i.requestAnimationFrame ? i.requestAnimationFrame(Si) : i.setInterval(u.fx.tick, u.fx.interval))
            }, u.fx.stop = function() {
                i.cancelAnimationFrame ? i.cancelAnimationFrame(Ie) : i.clearInterval(Ie), Ie = null
            }, u.fx.speeds = {
                slow: 600,
                fast: 200,
                _default: 400
            }, u.fn.delay = function(o, a) {
                return o = u.fx && u.fx.speeds[o] || o, this.queue(a = a || "fx", function(h, c) {
                    var v = i.setTimeout(h, o);
                    c.stop = function() {
                        i.clearTimeout(v)
                    }
                })
            },
            function() {
                var o = it.createElement("input"),
                    h = it.createElement("select").appendChild(it.createElement("option"));
                o.type = "checkbox", K.checkOn = "" !== o.value, K.optSelected = h.selected, (o = it.createElement("input")).value = "t", o.type = "radio", K.radioValue = "t" === o.value
            }();
        var Pi, $e = u.expr.attrHandle;
        u.fn.extend({
            attr: function(o, a) {
                return mt(this, u.attr, o, a, arguments.length > 1)
            },
            removeAttr: function(o) {
                return this.each(function() {
                    u.removeAttr(this, o)
                })
            }
        }), u.extend({
            attr: function(o, a, h) {
                var c, v, m = o.nodeType;
                if (3 !== m && 8 !== m && 2 !== m) return void 0 === o.getAttribute ? u.prop(o, a, h) : (1 === m && u.isXMLDoc(o) || (v = u.attrHooks[a.toLowerCase()] || (u.expr.match.bool.test(a) ? Pi : void 0)), void 0 !== h ? null === h ? void u.removeAttr(o, a) : v && "set" in v && void 0 !== (c = v.set(o, h, a)) ? c : (o.setAttribute(a, h + ""), h) : v && "get" in v && null !== (c = v.get(o, a)) ? c : null == (c = u.find.attr(o, a)) ? void 0 : c)
            },
            attrHooks: {
                type: {
                    set: function(o, a) {
                        if (!K.radioValue && "radio" === a && u.nodeName(o, "input")) {
                            var h = o.value;
                            return o.setAttribute("type", a), h && (o.value = h), a
                        }
                    }
                }
            },
            removeAttr: function(o, a) {
                var h, c = 0,
                    v = a && a.match(q);
                if (v && 1 === o.nodeType)
                    for (; h = v[c++];) o.removeAttribute(h)
            }
        }), Pi = {
            set: function(o, a, h) {
                return !1 === a ? u.removeAttr(o, h) : o.setAttribute(h, h), h
            }
        }, u.each(u.expr.match.bool.source.match(/\w+/g), function(o, a) {
            var h = $e[a] || u.find.attr;
            $e[a] = function(c, v, m) {
                var _, E, $ = v.toLowerCase();
                return m || (E = $e[$], $e[$] = _, _ = null != h(c, v, m) ? $ : null, $e[$] = E), _
            }
        });
        var hn = /^(?:input|select|textarea|button)$/i,
            un = /^(?:a|area)$/i;

        function ve(o) {
            return (o.match(q) || []).join(" ")
        }

        function _e(o) {
            return o.getAttribute && o.getAttribute("class") || ""
        }
        u.fn.extend({
            prop: function(o, a) {
                return mt(this, u.prop, o, a, arguments.length > 1)
            },
            removeProp: function(o) {
                return this.each(function() {
                    delete this[u.propFix[o] || o]
                })
            }
        }), u.extend({
            prop: function(o, a, h) {
                var c, v, m = o.nodeType;
                if (3 !== m && 8 !== m && 2 !== m) return 1 === m && u.isXMLDoc(o) || (v = u.propHooks[a = u.propFix[a] || a]), void 0 !== h ? v && "set" in v && void 0 !== (c = v.set(o, h, a)) ? c : o[a] = h : v && "get" in v && null !== (c = v.get(o, a)) ? c : o[a]
            },
            propHooks: {
                tabIndex: {
                    get: function(o) {
                        var a = u.find.attr(o, "tabindex");
                        return a ? parseInt(a, 10) : hn.test(o.nodeName) || un.test(o.nodeName) && o.href ? 0 : -1
                    }
                }
            },
            propFix: {
                for: "htmlFor",
                class: "className"
            }
        }), K.optSelected || (u.propHooks.selected = {
            get: function(o) {
                return null
            },
            set: function(o) {}
        }), u.each(["tabIndex", "readOnly", "maxLength", "cellSpacing", "cellPadding", "rowSpan", "colSpan", "useMap", "frameBorder", "contentEditable"], function() {
            u.propFix[this.toLowerCase()] = this
        }), u.fn.extend({
            addClass: function(o) {
                var a, h, c, v, m, _, E, $ = 0;
                if (u.isFunction(o)) return this.each(function(W) {
                    u(this).addClass(o.call(this, W, _e(this)))
                });
                if ("string" == typeof o && o)
                    for (a = o.match(q) || []; h = this[$++];)
                        if (v = _e(h), c = 1 === h.nodeType && " " + ve(v) + " ") {
                            for (_ = 0; m = a[_++];) c.indexOf(" " + m + " ") < 0 && (c += m + " ");
                            v !== (E = ve(c)) && h.setAttribute("class", E)
                        }
                return this
            },
            removeClass: function(o) {
                var a, h, c, v, m, _, E, $ = 0;
                if (u.isFunction(o)) return this.each(function(W) {
                    u(this).removeClass(o.call(this, W, _e(this)))
                });
                if (!arguments.length) return this.attr("class", "");
                if ("string" == typeof o && o)
                    for (a = o.match(q) || []; h = this[$++];)
                        if (v = _e(h), c = 1 === h.nodeType && " " + ve(v) + " ") {
                            for (_ = 0; m = a[_++];)
                                for (; c.indexOf(" " + m + " ") > -1;) c = c.replace(" " + m + " ", " ");
                            v !== (E = ve(c)) && h.setAttribute("class", E)
                        }
                return this
            },
            toggleClass: function(o, a) {
                var h = typeof o;
                return "boolean" == typeof a && "string" === h ? a ? this.addClass(o) : this.removeClass(o) : u.isFunction(o) ? this.each(function(c) {
                    u(this).toggleClass(o.call(this, c, _e(this), a), a)
                }) : this.each(function() {
                    var c, v, m, _;
                    if ("string" === h)
                        for (v = 0, m = u(this), _ = o.match(q) || []; c = _[v++];) m.hasClass(c) ? m.removeClass(c) : m.addClass(c);
                    else void 0 !== o && "boolean" !== h || ((c = _e(this)) && at.set(this, "__className__", c), this.setAttribute && this.setAttribute("class", c || !1 === o ? "" : at.get(this, "__className__") || ""))
                })
            },
            hasClass: function(o) {
                var a, h, c = 0;
                for (a = " " + o + " "; h = this[c++];)
                    if (1 === h.nodeType && (" " + ve(_e(h)) + " ").indexOf(a) > -1) return !0;
                return !1
            }
        });
        var cn = /\r/g;
        u.fn.extend({
            val: function(o) {
                var a, h, c, v = this[0];
                return arguments.length ? (c = u.isFunction(o), this.each(function(m) {
                    var _;
                    1 === this.nodeType && (null == (_ = c ? o.call(this, m, u(this).val()) : o) ? _ = "" : "number" == typeof _ ? _ += "" : u.isArray(_) && (_ = u.map(_, function(E) {
                        return null == E ? "" : E + ""
                    })), (a = u.valHooks[this.type] || u.valHooks[this.nodeName.toLowerCase()]) && "set" in a && void 0 !== a.set(this, _, "value") || (this.value = _))
                })) : v ? (a = u.valHooks[v.type] || u.valHooks[v.nodeName.toLowerCase()]) && "get" in a && void 0 !== (h = a.get(v, "value")) ? h : "string" == typeof(h = v.value) ? h.replace(cn, "") : null == h ? "" : h : void 0
            }
        }), u.extend({
            valHooks: {
                option: {
                    get: function(o) {
                        var a = u.find.attr(o, "value");
                        return null != a ? a : ve(u.text(o))
                    }
                },
                select: {
                    get: function(o) {
                        var a, h, c, v = o.options,
                            m = o.selectedIndex,
                            _ = "select-one" === o.type,
                            E = _ ? null : [],
                            $ = _ ? m + 1 : v.length;
                        for (c = m < 0 ? $ : _ ? m : 0; c < $; c++)
                            if (((h = v[c]).selected || c === m) && !h.disabled && (!h.parentNode.disabled || !u.nodeName(h.parentNode, "optgroup"))) {
                                if (a = u(h).val(), _) return a;
                                E.push(a)
                            }
                        return E
                    },
                    set: function(o, a) {
                        for (var h, c, v = o.options, m = u.makeArray(a), _ = v.length; _--;)((c = v[_]).selected = u.inArray(u.valHooks.option.get(c), m) > -1) && (h = !0);
                        return h || (o.selectedIndex = -1), m
                    }
                }
            }
        }), u.each(["radio", "checkbox"], function() {
            u.valHooks[this] = {
                set: function(o, a) {
                    if (u.isArray(a)) return o.checked = u.inArray(u(o).val(), a) > -1
                }
            }, K.checkOn || (u.valHooks[this].get = function(o) {
                return null === o.getAttribute("value") ? "on" : o.value
            })
        });
        var Ai = /^(?:focusinfocus|focusoutblur)$/;
        u.extend(u.event, {
            trigger: function(o, a, h, c) {
                var v, m, _, E, $, W, V, et = [h || it],
                    j = T.call(o, "type") ? o.type : o,
                    Q = T.call(o, "namespace") ? o.namespace.split(".") : [];
                if (m = _ = h = h || it, 3 !== h.nodeType && 8 !== h.nodeType && !Ai.test(j + u.event.triggered) && (j.indexOf(".") > -1 && (Q = j.split("."), j = Q.shift(), Q.sort()), $ = j.indexOf(":") < 0 && "on" + j, (o = o[u.expando] ? o : new u.Event(j, "object" == typeof o && o)).isTrigger = c ? 2 : 3, o.namespace = Q.join("."), o.rnamespace = o.namespace ? new RegExp("(^|\\.)" + Q.join("\\.(?:.*\\.|)") + "(\\.|$)") : null, o.result = void 0, o.target || (o.target = h), a = null == a ? [o] : u.makeArray(a, [o]), V = u.event.special[j] || {}, c || !V.trigger || !1 !== V.trigger.apply(h, a))) {
                    if (!c && !V.noBubble && !u.isWindow(h)) {
                        for (Ai.test((E = V.delegateType || j) + j) || (m = m.parentNode); m; m = m.parentNode) et.push(m), _ = m;
                        _ === (h.ownerDocument || it) && et.push(_.defaultView || _.parentWindow || i)
                    }
                    for (v = 0;
                        (m = et[v++]) && !o.isPropagationStopped();) o.type = v > 1 ? E : V.bindType || j, (W = (at.get(m, "events") || {})[o.type] && at.get(m, "handle")) && W.apply(m, a), (W = $ && m[$]) && W.apply && dt(m) && (o.result = W.apply(m, a), !1 === o.result && o.preventDefault());
                    return o.type = j, c || o.isDefaultPrevented() || V._default && !1 !== V._default.apply(et.pop(), a) || !dt(h) || $ && u.isFunction(h[j]) && !u.isWindow(h) && ((_ = h[$]) && (h[$] = null), u.event.triggered = j, h[j](), u.event.triggered = void 0, _ && (h[$] = _)), o.result
                }
            },
            simulate: function(o, a, h) {
                var c = u.extend(new u.Event, h, {
                    type: o,
                    isSimulated: !0
                });
                u.event.trigger(c, null, a)
            }
        }), u.fn.extend({
            trigger: function(o, a) {
                return this.each(function() {
                    u.event.trigger(o, a, this)
                })
            },
            triggerHandler: function(o, a) {
                var h = this[0];
                if (h) return u.event.trigger(o, a, h, !0)
            }
        }), u.each("blur focus focusin focusout resize scroll click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup contextmenu".split(" "), function(o, a) {
            u.fn[a] = function(h, c) {
                return arguments.length > 0 ? this.on(a, null, h, c) : this.trigger(a)
            }
        }), u.fn.extend({
            hover: function(o, a) {
                return this.mouseenter(o).mouseleave(a || o)
            }
        }), K.focusin = "onfocusin" in i, K.focusin || u.each({
            focus: "focusin",
            blur: "focusout"
        }, function(o, a) {
            var h = function(c) {
                u.event.simulate(a, c.target, u.event.fix(c))
            };
            u.event.special[a] = {
                setup: function() {
                    var c = this.ownerDocument || this,
                        v = at.access(c, a);
                    v || c.addEventListener(o, h, !0), at.access(c, a, (v || 0) + 1)
                },
                teardown: function() {
                    var c = this.ownerDocument || this,
                        v = at.access(c, a) - 1;
                    v ? at.access(c, a, v) : (c.removeEventListener(o, h, !0), at.remove(c, a))
                }
            }
        });
        var Oe = i.location,
            Ni = u.now(),
            Ze = /\?/;
        u.parseXML = function(o) {
            var a;
            if (!o || "string" != typeof o) return null;
            try {
                a = (new i.DOMParser).parseFromString(o, "text/xml")
            } catch (h) {
                a = void 0
            }
            return a && !a.getElementsByTagName("parsererror").length || u.error("Invalid XML: " + o), a
        };
        var dn = /\[\]$/,
            Mi = /\r?\n/g,
            pn = /^(?:submit|button|image|reset|file)$/i,
            fn = /^(?:input|select|textarea|keygen)/i;

        function ti(o, a, h, c) {
            var v;
            if (u.isArray(a)) u.each(a, function(m, _) {
                h || dn.test(o) ? c(o, _) : ti(o + "[" + ("object" == typeof _ && null != _ ? m : "") + "]", _, h, c)
            });
            else if (h || "object" !== u.type(a)) c(o, a);
            else
                for (v in a) ti(o + "[" + v + "]", a[v], h, c)
        }
        u.param = function(o, a) {
            var h, c = [],
                v = function(m, _) {
                    var E = u.isFunction(_) ? _() : _;
                    c[c.length] = encodeURIComponent(m) + "=" + encodeURIComponent(null == E ? "" : E)
                };
            if (u.isArray(o) || o.jquery && !u.isPlainObject(o)) u.each(o, function() {
                v(this.name, this.value)
            });
            else
                for (h in o) ti(h, o[h], a, v);
            return c.join("&")
        }, u.fn.extend({
            serialize: function() {
                return u.param(this.serializeArray())
            },
            serializeArray: function() {
                return this.map(function() {
                    var o = u.prop(this, "elements");
                    return o ? u.makeArray(o) : this
                }).filter(function() {
                    var o = this.type;
                    return this.name && !u(this).is(":disabled") && fn.test(this.nodeName) && !pn.test(o) && (this.checked || !je.test(o))
                }).map(function(o, a) {
                    var h = u(this).val();
                    return null == h ? null : u.isArray(h) ? u.map(h, function(c) {
                        return {
                            name: a.name,
                            value: c.replace(Mi, "\r\n")
                        }
                    }) : {
                        name: a.name,
                        value: h.replace(Mi, "\r\n")
                    }
                }).get()
            }
        });
        var mn = /%20/g,
            gn = /#.*$/,
            vn = /([?&])_=[^&]*/,
            _n = /^(.*?):[ \t]*([^\r\n]*)$/gm,
            bn = /^(?:GET|HEAD)$/,
            wn = /^\/\//,
            $i = {},
            ei = {},
            Oi = "*/".concat("*"),
            ii = it.createElement("a");

        function Hi(o) {
            return function(a, h) {
                "string" != typeof a && (h = a, a = "*");
                var c, v = 0,
                    m = a.toLowerCase().match(q) || [];
                if (u.isFunction(h))
                    for (; c = m[v++];) "+" === c[0] ? (c = c.slice(1) || "*", (o[c] = o[c] || []).unshift(h)) : (o[c] = o[c] || []).push(h)
            }
        }

        function zi(o, a, h, c) {
            var v = {},
                m = o === ei;

            function _(E) {
                var $;
                return v[E] = !0, u.each(o[E] || [], function(W, V) {
                    var et = V(a, h, c);
                    return "string" != typeof et || m || v[et] ? m ? !($ = et) : void 0 : (a.dataTypes.unshift(et), _(et), !1)
                }), $
            }
            return _(a.dataTypes[0]) || !v["*"] && _("*")
        }

        function ni(o, a) {
            var h, c, v = u.ajaxSettings.flatOptions || {};
            for (h in a) void 0 !== a[h] && ((v[h] ? o : c || (c = {}))[h] = a[h]);
            return c && u.extend(!0, o, c), o
        }
        ii.href = Oe.href, u.extend({
            active: 0,
            lastModified: {},
            etag: {},
            ajaxSettings: {
                url: Oe.href,
                type: "GET",
                isLocal: /^(?:about|app|app-storage|.+-extension|file|res|widget):$/.test(Oe.protocol),
                global: !0,
                processData: !0,
                async: !0,
                contentType: "application/x-www-form-urlencoded; charset=UTF-8",
                accepts: {
                    "*": Oi,
                    text: "text/plain",
                    html: "text/html",
                    xml: "application/xml, text/xml",
                    json: "application/json, text/javascript"
                },
                contents: {
                    xml: /\bxml\b/,
                    html: /\bhtml/,
                    json: /\bjson\b/
                },
                responseFields: {
                    xml: "responseXML",
                    text: "responseText",
                    json: "responseJSON"
                },
                converters: {
                    "* text": String,
                    "text html": !0,
                    "text json": JSON.parse,
                    "text xml": u.parseXML
                },
                flatOptions: {
                    url: !0,
                    context: !0
                }
            },
            ajaxSetup: function(o, a) {
                return a ? ni(ni(o, u.ajaxSettings), a) : ni(u.ajaxSettings, o)
            },
            ajaxPrefilter: Hi($i),
            ajaxTransport: Hi(ei),
            ajax: function(o, a) {
                "object" == typeof o && (a = o, o = void 0);
                var h, c, v, m, _, E, $, W, V, et, j = u.ajaxSetup({}, a = a || {}),
                    Q = j.context || j,
                    bt = j.context && (Q.nodeType || Q.jquery) ? u(Q) : u.event,
                    Ct = u.Deferred(),
                    gt = u.Callbacks("once memory"),
                    Ft = j.statusCode || {},
                    zt = {},
                    Jt = {},
                    Et = "canceled",
                    xt = {
                        readyState: 0,
                        getResponseHeader: function(Dt) {
                            var Ht;
                            if ($) {
                                if (!m)
                                    for (m = {}; Ht = _n.exec(v);) m[Ht[1].toLowerCase()] = Ht[2];
                                Ht = m[Dt.toLowerCase()]
                            }
                            return null == Ht ? null : Ht
                        },
                        getAllResponseHeaders: function() {
                            return $ ? v : null
                        },
                        setRequestHeader: function(Dt, Ht) {
                            return null == $ && (Dt = Jt[Dt.toLowerCase()] = Jt[Dt.toLowerCase()] || Dt, zt[Dt] = Ht), this
                        },
                        overrideMimeType: function(Dt) {
                            return null == $ && (j.mimeType = Dt), this
                        },
                        statusCode: function(Dt) {
                            var Ht;
                            if (Dt)
                                if ($) xt.always(Dt[xt.status]);
                                else
                                    for (Ht in Dt) Ft[Ht] = [Ft[Ht], Dt[Ht]];
                            return this
                        },
                        abort: function(Dt) {
                            var Ht = Dt || Et;
                            return h && h.abort(Ht), Qt(0, Ht), this
                        }
                    };
                if (Ct.promise(xt), j.url = ((o || j.url || Oe.href) + "").replace(wn, Oe.protocol + "//"), j.type = a.method || a.type || j.method || j.type, j.dataTypes = (j.dataType || "*").toLowerCase().match(q) || [""], null == j.crossDomain) {
                    E = it.createElement("a");
                    try {
                        E.href = j.url, E.href = E.href, j.crossDomain = ii.protocol + "//" + ii.host != E.protocol + "//" + E.host
                    } catch (Dt) {
                        j.crossDomain = !0
                    }
                }
                if (j.data && j.processData && "string" != typeof j.data && (j.data = u.param(j.data, j.traditional)), zi($i, j, a, xt), $) return xt;
                for (V in (W = u.event && j.global) && 0 == u.active++ && u.event.trigger("ajaxStart"), j.type = j.type.toUpperCase(), j.hasContent = !bn.test(j.type), c = j.url.replace(gn, ""), j.hasContent ? j.data && j.processData && 0 === (j.contentType || "").indexOf("application/x-www-form-urlencoded") && (j.data = j.data.replace(mn, "+")) : (et = j.url.slice(c.length), j.data && (c += (Ze.test(c) ? "&" : "?") + j.data, delete j.data), !1 === j.cache && (c = c.replace(vn, "$1"), et = (Ze.test(c) ? "&" : "?") + "_=" + Ni++ + et), j.url = c + et), j.ifModified && (u.lastModified[c] && xt.setRequestHeader("If-Modified-Since", u.lastModified[c]), u.etag[c] && xt.setRequestHeader("If-None-Match", u.etag[c])), (j.data && j.hasContent && !1 !== j.contentType || a.contentType) && xt.setRequestHeader("Content-Type", j.contentType), xt.setRequestHeader("Accept", j.dataTypes[0] && j.accepts[j.dataTypes[0]] ? j.accepts[j.dataTypes[0]] + ("*" !== j.dataTypes[0] ? ", " + Oi + "; q=0.01" : "") : j.accepts["*"]), j.headers) xt.setRequestHeader(V, j.headers[V]);
                if (j.beforeSend && (!1 === j.beforeSend.call(Q, xt, j) || $)) return xt.abort();
                if (Et = "abort", gt.add(j.complete), xt.done(j.success), xt.fail(j.error), h = zi(ei, j, a, xt)) {
                    if (xt.readyState = 1, W && bt.trigger("ajaxSend", [xt, j]), $) return xt;
                    j.async && j.timeout > 0 && (_ = i.setTimeout(function() {
                        xt.abort("timeout")
                    }, j.timeout));
                    try {
                        $ = !1, h.send(zt, Qt)
                    } catch (Dt) {
                        if ($) throw Dt;
                        Qt(-1, Dt)
                    }
                } else Qt(-1, "No Transport");

                function Qt(Dt, Ht, ze, Ee) {
                    var ae, Le, Zt, fe, me, Wt = Ht;
                    $ || ($ = !0, _ && i.clearTimeout(_), h = void 0, v = Ee || "", xt.readyState = Dt > 0 ? 4 : 0, ae = Dt >= 200 && Dt < 300 || 304 === Dt, ze && (fe = function xn(o, a, h) {
                        for (var c, v, m, _, E = o.contents, $ = o.dataTypes;
                            "*" === $[0];) $.shift(), void 0 === c && (c = o.mimeType || a.getResponseHeader("Content-Type"));
                        if (c)
                            for (v in E)
                                if (E[v] && E[v].test(c)) {
                                    $.unshift(v);
                                    break
                                }
                        if ($[0] in h) m = $[0];
                        else {
                            for (v in h) {
                                if (!$[0] || o.converters[v + " " + $[0]]) {
                                    m = v;
                                    break
                                }
                                _ || (_ = v)
                            }
                            m = m || _
                        }
                        if (m) return m !== $[0] && $.unshift(m), h[m]
                    }(j, xt, ze)), fe = function kn(o, a, h, c) {
                        var v, m, _, E, $, W = {},
                            V = o.dataTypes.slice();
                        if (V[1])
                            for (_ in o.converters) W[_.toLowerCase()] = o.converters[_];
                        for (m = V.shift(); m;)
                            if (o.responseFields[m] && (h[o.responseFields[m]] = a), !$ && c && o.dataFilter && (a = o.dataFilter(a, o.dataType)), $ = m, m = V.shift())
                                if ("*" === m) m = $;
                                else if ("*" !== $ && $ !== m) {
                            if (!(_ = W[$ + " " + m] || W["* " + m]))
                                for (v in W)
                                    if ((E = v.split(" "))[1] === m && (_ = W[$ + " " + E[0]] || W["* " + E[0]])) {
                                        !0 === _ ? _ = W[v] : !0 !== W[v] && (m = E[0], V.unshift(E[1]));
                                        break
                                    }
                            if (!0 !== _)
                                if (_ && o.throws) a = _(a);
                                else try {
                                    a = _(a)
                                } catch (et) {
                                    return {
                                        state: "parsererror",
                                        error: _ ? et : "No conversion from " + $ + " to " + m
                                    }
                                }
                        }
                        return {
                            state: "success",
                            data: a
                        }
                    }(j, fe, xt, ae), ae ? (j.ifModified && ((me = xt.getResponseHeader("Last-Modified")) && (u.lastModified[c] = me), (me = xt.getResponseHeader("etag")) && (u.etag[c] = me)), 204 === Dt || "HEAD" === j.type ? Wt = "nocontent" : 304 === Dt ? Wt = "notmodified" : (Wt = fe.state, Le = fe.data, ae = !(Zt = fe.error))) : (Zt = Wt, !Dt && Wt || (Wt = "error", Dt < 0 && (Dt = 0))), xt.status = Dt, xt.statusText = (Ht || Wt) + "", ae ? Ct.resolveWith(Q, [Le, Wt, xt]) : Ct.rejectWith(Q, [xt, Wt, Zt]), xt.statusCode(Ft), Ft = void 0, W && bt.trigger(ae ? "ajaxSuccess" : "ajaxError", [xt, j, ae ? Le : Zt]), gt.fireWith(Q, [xt, Wt]), W && (bt.trigger("ajaxComplete", [xt, j]), --u.active || u.event.trigger("ajaxStop")))
                }
                return xt
            },
            getJSON: function(o, a, h) {
                return u.get(o, a, h, "json")
            },
            getScript: function(o, a) {
                return u.get(o, void 0, a, "script")
            }
        }), u.each(["get", "post"], function(o, a) {
            u[a] = function(h, c, v, m) {
                return u.isFunction(c) && (m = m || v, v = c, c = void 0), u.ajax(u.extend({
                    url: h,
                    type: a,
                    dataType: m,
                    data: c,
                    success: v
                }, u.isPlainObject(h) && h))
            }
        }), u._evalUrl = function(o) {
            return u.ajax({
                url: o,
                type: "GET",
                dataType: "script",
                cache: !0,
                async: !1,
                global: !1,
                throws: !0
            })
        }, u.fn.extend({
            wrapAll: function(o) {
                var a;
                return this[0] && (u.isFunction(o) && (o = o.call(this[0])), a = u(o, this[0].ownerDocument).eq(0).clone(!0), this[0].parentNode && a.insertBefore(this[0]), a.map(function() {
                    for (var h = this; h.firstElementChild;) h = h.firstElementChild;
                    return h
                }).append(this)), this
            },
            wrapInner: function(o) {
                return u.isFunction(o) ? this.each(function(a) {
                    u(this).wrapInner(o.call(this, a))
                }) : this.each(function() {
                    var a = u(this),
                        h = a.contents();
                    h.length ? h.wrapAll(o) : a.append(o)
                })
            },
            wrap: function(o) {
                var a = u.isFunction(o);
                return this.each(function(h) {
                    u(this).wrapAll(a ? o.call(this, h) : o)
                })
            },
            unwrap: function(o) {
                return this.parent(o).not("body").each(function() {
                    u(this).replaceWith(this.childNodes)
                }), this
            }
        }), u.expr.pseudos.hidden = function(o) {
            return !u.expr.pseudos.visible(o)
        }, u.expr.pseudos.visible = function(o) {
            return !!(o.offsetWidth || o.offsetHeight || o.getClientRects().length)
        }, u.ajaxSettings.xhr = function() {
            try {
                return new i.XMLHttpRequest
            } catch (o) {}
        };
        var Cn = {
                0: 200,
                1223: 204
            },
            He = u.ajaxSettings.xhr();
        K.cors = !!He && "withCredentials" in He, K.ajax = He = !!He, u.ajaxTransport(function(o) {
            var a, h;
            if (K.cors || He && !o.crossDomain) return {
                send: function(c, v) {
                    var m, _ = o.xhr();
                    if (_.open(o.type, o.url, o.async, o.username, o.password), o.xhrFields)
                        for (m in o.xhrFields) _[m] = o.xhrFields[m];
                    for (m in o.mimeType && _.overrideMimeType && _.overrideMimeType(o.mimeType), o.crossDomain || c["X-Requested-With"] || (c["X-Requested-With"] = "XMLHttpRequest"), c) _.setRequestHeader(m, c[m]);
                    a = function(E) {
                        return function() {
                            a && (a = h = _.onload = _.onerror = _.onabort = _.onreadystatechange = null, "abort" === E ? _.abort() : "error" === E ? "number" != typeof _.status ? v(0, "error") : v(_.status, _.statusText) : v(Cn[_.status] || _.status, _.statusText, "text" !== (_.responseType || "text") || "string" != typeof _.responseText ? {
                                binary: _.response
                            } : {
                                text: _.responseText
                            }, _.getAllResponseHeaders()))
                        }
                    }, _.onload = a(), h = _.onerror = a("error"), void 0 !== _.onabort ? _.onabort = h : _.onreadystatechange = function() {
                        4 === _.readyState && i.setTimeout(function() {
                            a && h()
                        })
                    }, a = a("abort");
                    try {
                        _.send(o.hasContent && o.data || null)
                    } catch (E) {
                        if (a) throw E
                    }
                },
                abort: function() {
                    a && a()
                }
            }
        }), u.ajaxPrefilter(function(o) {
            o.crossDomain && (o.contents.script = !1)
        }), u.ajaxSetup({
            accepts: {
                script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"
            },
            contents: {
                script: /\b(?:java|ecma)script\b/
            },
            converters: {
                "text script": function(o) {
                    return u.globalEval(o), o
                }
            }
        }), u.ajaxPrefilter("script", function(o) {
            void 0 === o.cache && (o.cache = !1), o.crossDomain && (o.type = "GET")
        }), u.ajaxTransport("script", function(o) {
            var a, h;
            if (o.crossDomain) return {
                send: function(c, v) {
                    a = u("<script>").prop({
                        charset: o.scriptCharset,
                        src: o.url
                    }).on("load error", h = function(m) {
                        a.remove(), h = null, m && v("error" === m.type ? 404 : 200, m.type)
                    }), it.head.appendChild(a[0])
                },
                abort: function() {
                    h && h()
                }
            }
        });
        var o, Li = [],
            si = /(=)\?(?=&|$)|\?\?/;

        function Fi(o) {
            return u.isWindow(o) ? o : 9 === o.nodeType && o.defaultView
        }
        u.ajaxSetup({
            jsonp: "callback",
            jsonpCallback: function() {
                var o = Li.pop() || u.expando + "_" + Ni++;
                return this[o] = !0, o
            }
        }), u.ajaxPrefilter("json jsonp", function(o, a, h) {
            var c, v, m, _ = !1 !== o.jsonp && (si.test(o.url) ? "url" : "string" == typeof o.data && 0 === (o.contentType || "").indexOf("application/x-www-form-urlencoded") && si.test(o.data) && "data");
            if (_ || "jsonp" === o.dataTypes[0]) return c = o.jsonpCallback = u.isFunction(o.jsonpCallback) ? o.jsonpCallback() : o.jsonpCallback, _ ? o[_] = o[_].replace(si, "$1" + c) : !1 !== o.jsonp && (o.url += (Ze.test(o.url) ? "&" : "?") + o.jsonp + "=" + c), o.converters["script json"] = function() {
                return m || u.error(c + " was not called"), m[0]
            }, o.dataTypes[0] = "json", v = i[c], i[c] = function() {
                m = arguments
            }, h.always(function() {
                void 0 === v ? u(i).removeProp(c) : i[c] = v, o[c] && (o.jsonpCallback = a.jsonpCallback, Li.push(c)), m && u.isFunction(v) && v(m[0]), m = v = void 0
            }), "script"
        }), K.createHTMLDocument = ((o = it.implementation.createHTMLDocument("").body).innerHTML = "<form></form><form></form>", 2 === o.childNodes.length), u.parseHTML = function(o, a, h) {
            return "string" != typeof o ? [] : ("boolean" == typeof a && (h = a, a = !1), a || (K.createHTMLDocument ? ((c = (a = it.implementation.createHTMLDocument("")).createElement("base")).href = it.location.href, a.head.appendChild(c)) : a = it), m = !h && [], (v = k.exec(o)) ? [a.createElement(v[1])] : (v = Ce([o], a, m), m && m.length && u(m).remove(), u.merge([], v.childNodes)));
            var c, v, m
        }, u.fn.load = function(o, a, h) {
            var c, v, m, _ = this,
                E = o.indexOf(" ");
            return E > -1 && (c = ve(o.slice(E)), o = o.slice(0, E)), u.isFunction(a) ? (h = a, a = void 0) : a && "object" == typeof a && (v = "POST"), _.length > 0 && u.ajax({
                url: o,
                type: v || "GET",
                dataType: "html",
                data: a
            }).done(function($) {
                m = arguments, _.html(c ? u("<div>").append(u.parseHTML($)).find(c) : $)
            }).always(h && function($, W) {
                _.each(function() {
                    h.apply(this, m || [$.responseText, W, $])
                })
            }), this
        }, u.each(["ajaxStart", "ajaxStop", "ajaxComplete", "ajaxError", "ajaxSuccess", "ajaxSend"], function(o, a) {
            u.fn[a] = function(h) {
                return this.on(a, h)
            }
        }), u.expr.pseudos.animated = function(o) {
            return u.grep(u.timers, function(a) {
                return o === a.elem
            }).length
        }, u.offset = {
            setOffset: function(o, a, h) {
                var c, v, m, _, E, $, V = u.css(o, "position"),
                    et = u(o),
                    j = {};
                "static" === V && (o.style.position = "relative"), E = et.offset(), m = u.css(o, "top"), $ = u.css(o, "left"), ("absolute" === V || "fixed" === V) && (m + $).indexOf("auto") > -1 ? (_ = (c = et.position()).top, v = c.left) : (_ = parseFloat(m) || 0, v = parseFloat($) || 0), u.isFunction(a) && (a = a.call(o, h, u.extend({}, E))), null != a.top && (j.top = a.top - E.top + _), null != a.left && (j.left = a.left - E.left + v), "using" in a ? a.using.call(o, j) : et.css(j)
            }
        }, u.fn.extend({
            offset: function(o) {
                if (arguments.length) return void 0 === o ? this : this.each(function(_) {
                    u.offset.setOffset(this, o, _)
                });
                var a, h, c, v, m = this[0];
                return m ? m.getClientRects().length ? (c = m.getBoundingClientRect()).width || c.height ? (h = Fi(v = m.ownerDocument), {
                    top: c.top + h.pageYOffset - (a = v.documentElement).clientTop,
                    left: c.left + h.pageXOffset - a.clientLeft
                }) : c : {
                    top: 0,
                    left: 0
                } : void 0
            },
            position: function() {
                if (this[0]) {
                    var o, a, h = this[0],
                        c = {
                            top: 0,
                            left: 0
                        };
                    return "fixed" === u.css(h, "position") ? a = h.getBoundingClientRect() : (o = this.offsetParent(), a = this.offset(), u.nodeName(o[0], "html") || (c = o.offset()), c = {
                        top: c.top + u.css(o[0], "borderTopWidth", !0),
                        left: c.left + u.css(o[0], "borderLeftWidth", !0)
                    }), {
                        top: a.top - c.top - u.css(h, "marginTop", !0),
                        left: a.left - c.left - u.css(h, "marginLeft", !0)
                    }
                }
            },
            offsetParent: function() {
                return this.map(function() {
                    for (var o = this.offsetParent; o && "static" === u.css(o, "position");) o = o.offsetParent;
                    return o || oe
                })
            }
        }), u.each({
            scrollLeft: "pageXOffset",
            scrollTop: "pageYOffset"
        }, function(o, a) {
            var h = "pageYOffset" === a;
            u.fn[o] = function(c) {
                return mt(this, function(v, m, _) {
                    var E = Fi(v);
                    return void 0 === _ ? E ? E[a] : v[m] : void(E ? E.scrollTo(h ? E.pageXOffset : _, h ? _ : E.pageYOffset) : v[m] = _)
                }, o, c, arguments.length)
            }
        }), u.each(["top", "left"], function(o, a) {
            u.cssHooks[a] = yi(K.pixelPosition, function(h, c) {
                if (c) return c = Me(h, a), Je.test(c) ? u(h).position()[a] + "px" : c
            })
        }), u.each({
            Height: "height",
            Width: "width"
        }, function(o, a) {
            u.each({
                padding: "inner" + o,
                content: a,
                "": "outer" + o
            }, function(h, c) {
                u.fn[c] = function(v, m) {
                    var _ = arguments.length && (h || "boolean" != typeof v),
                        E = h || (!0 === v || !0 === m ? "margin" : "border");
                    return mt(this, function($, W, V) {
                        var et;
                        return u.isWindow($) ? 0 === c.indexOf("outer") ? $["inner" + o] : $.document.documentElement["client" + o] : 9 === $.nodeType ? (et = $.documentElement, Math.max($.body["scroll" + o], et["scroll" + o], $.body["offset" + o], et["offset" + o], et["client" + o])) : void 0 === V ? u.css($, W, E) : u.style($, W, V, E)
                    }, a, _ ? v : void 0, _)
                }
            })
        }), u.fn.extend({
            bind: function(o, a, h) {
                return this.on(o, null, a, h)
            },
            unbind: function(o, a) {
                return this.off(o, null, a)
            },
            delegate: function(o, a, h, c) {
                return this.on(a, o, h, c)
            },
            undelegate: function(o, a, h) {
                return 1 === arguments.length ? this.off(o, "**") : this.off(a, o || "**", h)
            }
        }), u.parseJSON = JSON.parse, "function" == typeof define && define.amd && define("jquery", [], function() {
            return u
        });
        var Tn = i.jQuery,
            Dn = i.$;
        return u.noConflict = function(o) {
            return i.$ === u && (i.$ = Dn), o && i.jQuery === u && (i.jQuery = Tn), u
        }, L || (i.jQuery = i.$ = u), u
    }), function(i) {
        "function" == typeof define && define.amd ? define(["jquery"], i) : i(jQuery)
    }(function(i) {
        function it() {
            this._curInst = null, this._keyEvent = !1, this._disabledInputs = [], this._datepickerShowing = !1, this._inDialog = !1, this._mainDivId = "ui-datepicker-div", this._inlineClass = "ui-datepicker-inline", this._appendClass = "ui-datepicker-append", this._triggerClass = "ui-datepicker-trigger", this._dialogClass = "ui-datepicker-dialog", this._disableClass = "ui-datepicker-disabled", this._unselectableClass = "ui-datepicker-unselectable", this._currentClass = "ui-datepicker-current-day", this._dayOverClass = "ui-datepicker-days-cell-over", this.regional = [], this.regional[""] = {
                closeText: "Done",
                prevText: "Prev",
                nextText: "Next",
                currentText: "Today",
                monthNames: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
                monthNamesShort: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
                dayNames: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
                dayNamesShort: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
                dayNamesMin: ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"],
                weekHeader: "Wk",
                dateFormat: "mm/dd/yy",
                firstDay: 0,
                isRTL: !1,
                showMonthAfterYear: !1,
                yearSuffix: ""
            }, this._defaults = {
                showOn: "focus",
                showAnim: "fadeIn",
                showOptions: {},
                defaultDate: null,
                appendText: "",
                buttonText: "...",
                buttonImage: "",
                buttonImageOnly: !1,
                hideIfNoPrevNext: !1,
                navigationAsDateFormat: !1,
                gotoCurrent: !1,
                changeMonth: !1,
                changeYear: !1,
                yearRange: "c-10:c+10",
                showOtherMonths: !1,
                selectOtherMonths: !1,
                showWeek: !1,
                calculateWeek: this.iso8601Week,
                shortYearCutoff: "+10",
                minDate: null,
                maxDate: null,
                duration: "fast",
                beforeShowDay: null,
                beforeShow: null,
                onSelect: null,
                onChangeMonthYear: null,
                onClose: null,
                numberOfMonths: 1,
                showCurrentAtPos: 0,
                stepMonths: 1,
                stepBigMonths: 12,
                altField: "",
                altFormat: "",
                constrainInput: !0,
                showButtonPanel: !1,
                autoSize: !1,
                disabled: !1
            }, i.extend(this._defaults, this.regional[""]), this.regional.en = i.extend(!0, {}, this.regional[""]), this.regional["en-US"] = i.extend(!0, {}, this.regional.en), this.dpDiv = f(i("<div id='" + this._mainDivId + "' class='ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all'></div>"))
        }

        function f(t) {
            var e = "button, .ui-datepicker-prev, .ui-datepicker-next, .ui-datepicker-calendar td a";
            return t.on("mouseout", e, function() {
                i(this).removeClass("ui-state-hover"), -1 !== this.className.indexOf("ui-datepicker-prev") && i(this).removeClass("ui-datepicker-prev-hover"), -1 !== this.className.indexOf("ui-datepicker-next") && i(this).removeClass("ui-datepicker-next-hover")
            }).on("mouseover", e, b)
        }

        function b() {
            i.datepicker._isDisabledDatepicker(st.inline ? st.dpDiv.parent()[0] : st.input[0]) || (i(this).parents(".ui-datepicker-calendar").find("a").removeClass("ui-state-hover"), i(this).addClass("ui-state-hover"), -1 !== this.className.indexOf("ui-datepicker-prev") && i(this).addClass("ui-datepicker-prev-hover"), -1 !== this.className.indexOf("ui-datepicker-next") && i(this).addClass("ui-datepicker-next-hover"))
        }

        function p(t, e) {
            for (var n in i.extend(t, e), e) null == e[n] && (t[n] = e[n]);
            return t
        }

        function x(t) {
            return function() {
                var e = this.element.val();
                t.apply(this, arguments), this._refresh(), e !== this.element.val() && this._trigger("change")
            }
        }
        i.ui = i.ui || {}, i.ui.version = "1.12.1";
        var t, y = 0,
            N = Array.prototype.slice;
        i.cleanData = (t = i.cleanData, function(e) {
                var n, s, r;
                for (r = 0; null != (s = e[r]); r++) try {
                    (n = i._data(s, "events")) && n.remove && i(s).triggerHandler("remove")
                } catch (l) {}
                t(e)
            }), i.widget = function(t, e, n) {
                var s, r, l, d = {},
                    g = t.split(".")[0],
                    k = g + "-" + (t = t.split(".")[1]);
                return n || (n = e, e = i.Widget), i.isArray(n) && (n = i.extend.apply(null, [{}].concat(n))), i.expr[":"][k.toLowerCase()] = function(D) {
                    return !!i.data(D, k)
                }, i[g] = i[g] || {}, s = i[g][t], r = i[g][t] = function(D, I) {
                    return this._createWidget ? void(arguments.length && this._createWidget(D, I)) : new r(D, I)
                }, i.extend(r, s, {
                    version: n.version,
                    _proto: i.extend({}, n),
                    _childConstructors: []
                }), (l = new e).options = i.widget.extend({}, l.options), i.each(n, function(D, I) {
                    return i.isFunction(I) ? void(d[D] = function() {
                        function R() {
                            return e.prototype[D].apply(this, arguments)
                        }

                        function P(H) {
                            return e.prototype[D].apply(this, H)
                        }
                        return function() {
                            var H, F = this._super,
                                A = this._superApply;
                            return this._super = R, this._superApply = P, H = I.apply(this, arguments), this._super = F, this._superApply = A, H
                        }
                    }()) : void(d[D] = I)
                }), r.prototype = i.widget.extend(l, {
                    widgetEventPrefix: s && l.widgetEventPrefix || t
                }, d, {
                    constructor: r,
                    namespace: g,
                    widgetName: t,
                    widgetFullName: k
                }), s ? (i.each(s._childConstructors, function(D, I) {
                    var R = I.prototype;
                    i.widget(R.namespace + "." + R.widgetName, r, I._proto)
                }), delete s._childConstructors) : e._childConstructors.push(r), i.widget.bridge(t, r), r
            }, i.widget.extend = function(t) {
                for (var e, n, s = N.call(arguments, 1), r = 0, l = s.length; l > r; r++)
                    for (e in s[r]) n = s[r][e], s[r].hasOwnProperty(e) && void 0 !== n && (t[e] = i.isPlainObject(n) ? i.isPlainObject(t[e]) ? i.widget.extend({}, t[e], n) : i.widget.extend({}, n) : n);
                return t
            }, i.widget.bridge = function(t, e) {
                var n = e.prototype.widgetFullName || t;
                i.fn[t] = function(s) {
                    var r = "string" == typeof s,
                        l = N.call(arguments, 1),
                        d = this;
                    return r ? this.length || "instance" !== s ? this.each(function() {
                        var g, k = i.data(this, n);
                        return "instance" === s ? (d = k, !1) : k ? i.isFunction(k[s]) && "_" !== s.charAt(0) ? (g = k[s].apply(k, l)) !== k && void 0 !== g ? (d = g && g.jquery ? d.pushStack(g.get()) : g, !1) : void 0 : i.error("no such method '" + s + "' for " + t + " widget instance") : i.error("cannot call methods on " + t + " prior to initialization; attempted to call method '" + s + "'")
                    }) : d = void 0 : (l.length && (s = i.widget.extend.apply(null, [s].concat(l))), this.each(function() {
                        var g = i.data(this, n);
                        g ? (g.option(s || {}), g._init && g._init()) : i.data(this, n, new e(s, this))
                    })), d
                }
            }, i.Widget = function() {}, i.Widget._childConstructors = [], i.Widget.prototype = {
                widgetName: "widget",
                widgetEventPrefix: "",
                defaultElement: "<div>",
                options: {
                    classes: {},
                    disabled: !1,
                    create: null
                },
                _createWidget: function(t, e) {
                    e = i(e || this.defaultElement || this)[0], this.element = i(e), this.uuid = y++, this.eventNamespace = "." + this.widgetName + this.uuid, this.bindings = i(), this.hoverable = i(), this.focusable = i(), this.classesElementLookup = {}, e !== this && (i.data(e, this.widgetFullName, this), this._on(!0, this.element, {
                        remove: function(n) {
                            n.target === e && this.destroy()
                        }
                    }), this.document = i(e.style ? e.ownerDocument : e.document || e), this.window = i(this.document[0].defaultView || this.document[0].parentWindow)), this.options = i.widget.extend({}, this.options, this._getCreateOptions(), t), this._create(), this.options.disabled && this._setOptionDisabled(this.options.disabled), this._trigger("create", null, this._getCreateEventData()), this._init()
                },
                _getCreateOptions: function() {
                    return {}
                },
                _getCreateEventData: i.noop,
                _create: i.noop,
                _init: i.noop,
                destroy: function() {
                    var t = this;
                    this._destroy(), i.each(this.classesElementLookup, function(e, n) {
                        t._removeClass(n, e)
                    }), this.element.off(this.eventNamespace).removeData(this.widgetFullName), this.widget().off(this.eventNamespace).removeAttr("aria-disabled"), this.bindings.off(this.eventNamespace)
                },
                _destroy: i.noop,
                widget: function() {
                    return this.element
                },
                option: function(t, e) {
                    var n, s, r, l = t;
                    if (0 === arguments.length) return i.widget.extend({}, this.options);
                    if ("string" == typeof t)
                        if (l = {}, n = t.split("."), t = n.shift(), n.length) {
                            for (s = l[t] = i.widget.extend({}, this.options[t]), r = 0; n.length - 1 > r; r++) s[n[r]] = s[n[r]] || {}, s = s[n[r]];
                            if (t = n.pop(), 1 === arguments.length) return void 0 === s[t] ? null : s[t];
                            s[t] = e
                        } else {
                            if (1 === arguments.length) return void 0 === this.options[t] ? null : this.options[t];
                            l[t] = e
                        }
                    return this._setOptions(l), this
                },
                _setOptions: function(t) {
                    var e;
                    for (e in t) this._setOption(e, t[e]);
                    return this
                },
                _setOption: function(t, e) {
                    return "classes" === t && this._setOptionClasses(e), this.options[t] = e, "disabled" === t && this._setOptionDisabled(e), this
                },
                _setOptionClasses: function(t) {
                    var e, n, s;
                    for (e in t) s = this.classesElementLookup[e], t[e] !== this.options.classes[e] && s && s.length && (n = i(s.get()), this._removeClass(s, e), n.addClass(this._classes({
                        element: n,
                        keys: e,
                        classes: t,
                        add: !0
                    })))
                },
                _setOptionDisabled: function(t) {
                    this._toggleClass(this.widget(), this.widgetFullName + "-disabled", null, !!t), t && (this._removeClass(this.hoverable, null, "ui-state-hover"), this._removeClass(this.focusable, null, "ui-state-focus"))
                },
                enable: function() {
                    return this._setOptions({
                        disabled: !1
                    })
                },
                disable: function() {
                    return this._setOptions({
                        disabled: !0
                    })
                },
                _classes: function(t) {
                    function e(r, l) {
                        var d, g;
                        for (g = 0; r.length > g; g++) d = s.classesElementLookup[r[g]] || i(), d = i(t.add ? i.unique(d.get().concat(t.element.get())) : d.not(t.element).get()), s.classesElementLookup[r[g]] = d, n.push(r[g]), l && t.classes[r[g]] && n.push(t.classes[r[g]])
                    }
                    var n = [],
                        s = this;
                    return t = i.extend({
                        element: this.element,
                        classes: this.options.classes || {}
                    }, t), this._on(t.element, {
                        remove: "_untrackClassesElement"
                    }), t.keys && e(t.keys.match(/\S+/g) || [], !0), t.extra && e(t.extra.match(/\S+/g) || []), n.join(" ")
                },
                _untrackClassesElement: function(t) {
                    var e = this;
                    i.each(e.classesElementLookup, function(n, s) {
                        -1 !== i.inArray(t.target, s) && (e.classesElementLookup[n] = i(s.not(t.target).get()))
                    })
                },
                _removeClass: function(t, e, n) {
                    return this._toggleClass(t, e, n, !1)
                },
                _addClass: function(t, e, n) {
                    return this._toggleClass(t, e, n, !0)
                },
                _toggleClass: function(t, e, n, s) {
                    var r = "string" == typeof t || null === t,
                        l = {
                            extra: r ? e : n,
                            keys: r ? t : e,
                            element: r ? this.element : t,
                            add: s = "boolean" == typeof s ? s : n
                        };
                    return l.element.toggleClass(this._classes(l), s), this
                },
                _on: function(t, e, n) {
                    var s, r = this;
                    "boolean" != typeof t && (n = e, e = t, t = !1), n ? (e = s = i(e), this.bindings = this.bindings.add(e)) : (n = e, e = this.element, s = this.widget()), i.each(n, function(l, d) {
                        function g() {
                            return t || !0 !== r.options.disabled && !i(this).hasClass("ui-state-disabled") ? ("string" == typeof d ? r[d] : d).apply(r, arguments) : void 0
                        }
                        "string" != typeof d && (g.guid = d.guid = d.guid || g.guid || i.guid++);
                        var k = l.match(/^([\w:-]*)\s*(.*)$/),
                            D = k[1] + r.eventNamespace,
                            I = k[2];
                        I ? s.on(D, I, g) : e.on(D, g)
                    })
                },
                _off: function(t, e) {
                    e = (e || "").split(" ").join(this.eventNamespace + " ") + this.eventNamespace, t.off(e).off(e), this.bindings = i(this.bindings.not(t).get()), this.focusable = i(this.focusable.not(t).get()), this.hoverable = i(this.hoverable.not(t).get())
                },
                _delay: function(t, e) {
                    var s = this;
                    return setTimeout(function n() {
                        return ("string" == typeof t ? s[t] : t).apply(s, arguments)
                    }, e || 0)
                },
                _hoverable: function(t) {
                    this.hoverable = this.hoverable.add(t), this._on(t, {
                        mouseenter: function(e) {
                            this._addClass(i(e.currentTarget), null, "ui-state-hover")
                        },
                        mouseleave: function(e) {
                            this._removeClass(i(e.currentTarget), null, "ui-state-hover")
                        }
                    })
                },
                _focusable: function(t) {
                    this.focusable = this.focusable.add(t), this._on(t, {
                        focusin: function(e) {
                            this._addClass(i(e.currentTarget), null, "ui-state-focus")
                        },
                        focusout: function(e) {
                            this._removeClass(i(e.currentTarget), null, "ui-state-focus")
                        }
                    })
                },
                _trigger: function(t, e, n) {
                    var s, r, l = this.options[t];
                    if (n = n || {}, (e = i.Event(e)).type = (t === this.widgetEventPrefix ? t : this.widgetEventPrefix + t).toLowerCase(), e.target = this.element[0], r = e.originalEvent)
                        for (s in r) s in e || (e[s] = r[s]);
                    return this.element.trigger(e, n), !(i.isFunction(l) && !1 === l.apply(this.element[0], [e].concat(n)) || e.isDefaultPrevented())
                }
            }, i.each({
                show: "fadeIn",
                hide: "fadeOut"
            }, function(t, e) {
                i.Widget.prototype["_" + t] = function(n, s, r) {
                    "string" == typeof s && (s = {
                        effect: s
                    });
                    var l, d = s ? !0 === s || "number" == typeof s ? e : s.effect || e : t;
                    "number" == typeof(s = s || {}) && (s = {
                        duration: s
                    }), l = !i.isEmptyObject(s), s.complete = r, s.delay && n.delay(s.delay), l && i.effects && i.effects.effect[d] ? n[t](s) : d !== t && n[d] ? n[d](s.duration, s.easing, r) : n.queue(function(g) {
                        i(this)[t](), r && r.call(n[0]), g()
                    })
                }
            }),
            function() {
                function t(P, H, F) {
                    return [parseFloat(P[0]) * (I.test(P[0]) ? H / 100 : 1), parseFloat(P[1]) * (I.test(P[1]) ? F / 100 : 1)]
                }

                function e(P, H) {
                    return parseInt(i.css(P, H), 10) || 0
                }

                function n(P) {
                    var H = P[0];
                    return 9 === H.nodeType ? {
                        width: P.width(),
                        height: P.height(),
                        offset: {
                            top: 0,
                            left: 0
                        }
                    } : i.isWindow(H) ? {
                        width: P.width(),
                        height: P.height(),
                        offset: {
                            top: P.scrollTop(),
                            left: P.scrollLeft()
                        }
                    } : H.preventDefault ? {
                        width: 0,
                        height: 0,
                        offset: {
                            top: H.pageY,
                            left: H.pageX
                        }
                    } : {
                        width: P.outerWidth(),
                        height: P.outerHeight(),
                        offset: P.offset()
                    }
                }
                var s, r = Math.max,
                    l = Math.abs,
                    d = /left|center|right/,
                    g = /top|center|bottom/,
                    k = /[\+\-]\d+(\.[\d]+)?%?/,
                    D = /^\w+/,
                    I = /%$/,
                    R = i.fn.position;
                i.position = {
                    scrollbarWidth: function() {
                        if (void 0 !== s) return s;
                        var P, H, F = i("<div style='display:block;position:absolute;width:50px;height:50px;overflow:hidden;'><div style='height:100px;width:auto;'></div></div>"),
                            A = F.children()[0];
                        return i("body").append(F), P = A.offsetWidth, F.css("overflow", "scroll"), P === (H = A.offsetWidth) && (H = F[0].clientWidth), F.remove(), s = P - H
                    },
                    getScrollInfo: function(P) {
                        var H = P.isWindow || P.isDocument ? "" : P.element.css("overflow-x"),
                            F = P.isWindow || P.isDocument ? "" : P.element.css("overflow-y"),
                            A = "scroll" === H || "auto" === H && P.width < P.element[0].scrollWidth;
                        return {
                            width: "scroll" === F || "auto" === F && P.height < P.element[0].scrollHeight ? i.position.scrollbarWidth() : 0,
                            height: A ? i.position.scrollbarWidth() : 0
                        }
                    },
                    getWithinInfo: function(P) {
                        var H = i(P || window),
                            F = i.isWindow(H[0]),
                            A = !!H[0] && 9 === H[0].nodeType;
                        return {
                            element: H,
                            isWindow: F,
                            isDocument: A,
                            offset: F || A ? {
                                left: 0,
                                top: 0
                            } : i(P).offset(),
                            scrollLeft: H.scrollLeft(),
                            scrollTop: H.scrollTop(),
                            width: H.outerWidth(),
                            height: H.outerHeight()
                        }
                    }
                }, i.fn.position = function(P) {
                    if (!P || !P.of) return R.apply(this, arguments);
                    P = i.extend({}, P);
                    var H, F, A, O, q, X, J = i(P.of),
                        nt = i.position.getWithinInfo(P.within),
                        pt = i.position.getScrollInfo(nt),
                        ft = (P.collision || "flip").split(" "),
                        lt = {};
                    return X = n(J), J[0].preventDefault && (P.at = "left top"), F = X.width, A = X.height, q = i.extend({}, O = X.offset), i.each(["my", "at"], function() {
                        var ct, mt, dt = (P[this] || "").split(" ");
                        1 === dt.length && (dt = d.test(dt[0]) ? dt.concat(["center"]) : g.test(dt[0]) ? ["center"].concat(dt) : ["center", "center"]), dt[0] = d.test(dt[0]) ? dt[0] : "center", dt[1] = g.test(dt[1]) ? dt[1] : "center", ct = k.exec(dt[0]), mt = k.exec(dt[1]), lt[this] = [ct ? ct[0] : 0, mt ? mt[0] : 0], P[this] = [D.exec(dt[0])[0], D.exec(dt[1])[0]]
                    }), 1 === ft.length && (ft[1] = ft[0]), "right" === P.at[0] ? q.left += F : "center" === P.at[0] && (q.left += F / 2), "bottom" === P.at[1] ? q.top += A : "center" === P.at[1] && (q.top += A / 2), H = t(lt.at, F, A), q.left += H[0], q.top += H[1], this.each(function() {
                        var ct, mt, dt = i(this),
                            kt = dt.outerWidth(),
                            at = dt.outerHeight(),
                            St = e(this, "marginLeft"),
                            ie = e(this, "marginTop"),
                            ge = kt + St + e(this, "marginRight") + pt.width,
                            pe = at + ie + e(this, "marginBottom") + pt.height,
                            Lt = i.extend({}, q),
                            It = t(lt.my, dt.outerWidth(), dt.outerHeight());
                        "right" === P.my[0] ? Lt.left -= kt : "center" === P.my[0] && (Lt.left -= kt / 2), "bottom" === P.my[1] ? Lt.top -= at : "center" === P.my[1] && (Lt.top -= at / 2), Lt.left += It[0], Lt.top += It[1], ct = {
                            marginLeft: St,
                            marginTop: ie
                        }, i.each(["left", "top"], function(Kt, jt) {
                            i.ui.position[ft[Kt]] && i.ui.position[ft[Kt]][jt](Lt, {
                                targetWidth: F,
                                targetHeight: A,
                                elemWidth: kt,
                                elemHeight: at,
                                collisionPosition: ct,
                                collisionWidth: ge,
                                collisionHeight: pe,
                                offset: [H[0] + It[0], H[1] + It[1]],
                                my: P.my,
                                at: P.at,
                                within: nt,
                                elem: dt
                            })
                        }), P.using && (mt = function(Kt) {
                            var jt = O.left - Lt.left,
                                Xt = jt + F - kt,
                                Vt = O.top - Lt.top,
                                ne = Vt + A - at,
                                se = {
                                    target: {
                                        element: J,
                                        left: O.left,
                                        top: O.top,
                                        width: F,
                                        height: A
                                    },
                                    element: {
                                        element: dt,
                                        left: Lt.left,
                                        top: Lt.top,
                                        width: kt,
                                        height: at
                                    },
                                    horizontal: 0 > Xt ? "left" : jt > 0 ? "right" : "center",
                                    vertical: 0 > ne ? "top" : Vt > 0 ? "bottom" : "middle"
                                };
                            kt > F && F > l(jt + Xt) && (se.horizontal = "center"), at > A && A > l(Vt + ne) && (se.vertical = "middle"), se.important = r(l(jt), l(Xt)) > r(l(Vt), l(ne)) ? "horizontal" : "vertical", P.using.call(this, Kt, se)
                        }), dt.offset(i.extend(Lt, {
                            using: mt
                        }))
                    })
                }, i.ui.position = {
                    fit: {
                        left: function(P, H) {
                            var A = H.within,
                                O = A.isWindow ? A.scrollLeft : A.offset.left,
                                q = A.width,
                                X = P.left - H.collisionPosition.marginLeft,
                                J = O - X,
                                nt = X + H.collisionWidth - q - O;
                            H.collisionWidth > q ? J > 0 && 0 >= nt ? P.left += J - (P.left + J + H.collisionWidth - q - O) : P.left = nt > 0 && 0 >= J ? O : J > nt ? O + q - H.collisionWidth : O : J > 0 ? P.left += J : nt > 0 ? P.left -= nt : P.left = r(P.left - X, P.left)
                        },
                        top: function(P, H) {
                            var A = H.within,
                                O = A.isWindow ? A.scrollTop : A.offset.top,
                                q = H.within.height,
                                X = P.top - H.collisionPosition.marginTop,
                                J = O - X,
                                nt = X + H.collisionHeight - q - O;
                            H.collisionHeight > q ? J > 0 && 0 >= nt ? P.top += J - (P.top + J + H.collisionHeight - q - O) : P.top = nt > 0 && 0 >= J ? O : J > nt ? O + q - H.collisionHeight : O : J > 0 ? P.top += J : nt > 0 ? P.top -= nt : P.top = r(P.top - X, P.top)
                        }
                    },
                    flip: {
                        left: function(P, H) {
                            var F, A, O = H.within,
                                X = O.width,
                                J = O.isWindow ? O.scrollLeft : O.offset.left,
                                nt = P.left - H.collisionPosition.marginLeft,
                                pt = nt - J,
                                ft = nt + H.collisionWidth - X - J,
                                lt = "left" === H.my[0] ? -H.elemWidth : "right" === H.my[0] ? H.elemWidth : 0,
                                ct = "left" === H.at[0] ? H.targetWidth : "right" === H.at[0] ? -H.targetWidth : 0,
                                mt = -2 * H.offset[0];
                            0 > pt ? (0 > (F = P.left + lt + ct + mt + H.collisionWidth - X - (O.offset.left + O.scrollLeft)) || l(pt) > F) && (P.left += lt + ct + mt) : ft > 0 && ((A = P.left - H.collisionPosition.marginLeft + lt + ct + mt - J) > 0 || ft > l(A)) && (P.left += lt + ct + mt)
                        },
                        top: function(P, H) {
                            var F, A, O = H.within,
                                X = O.height,
                                J = O.isWindow ? O.scrollTop : O.offset.top,
                                nt = P.top - H.collisionPosition.marginTop,
                                pt = nt - J,
                                ft = nt + H.collisionHeight - X - J,
                                ct = "top" === H.my[1] ? -H.elemHeight : "bottom" === H.my[1] ? H.elemHeight : 0,
                                mt = "top" === H.at[1] ? H.targetHeight : "bottom" === H.at[1] ? -H.targetHeight : 0,
                                dt = -2 * H.offset[1];
                            0 > pt ? (0 > (A = P.top + ct + mt + dt + H.collisionHeight - X - (O.offset.top + O.scrollTop)) || l(pt) > A) && (P.top += ct + mt + dt) : ft > 0 && ((F = P.top - H.collisionPosition.marginTop + ct + mt + dt - J) > 0 || ft > l(F)) && (P.top += ct + mt + dt)
                        }
                    },
                    flipfit: {
                        left: function() {
                            i.ui.position.flip.left.apply(this, arguments), i.ui.position.fit.left.apply(this, arguments)
                        },
                        top: function() {
                            i.ui.position.flip.top.apply(this, arguments), i.ui.position.fit.top.apply(this, arguments)
                        }
                    }
                }
            }(), i.extend(i.expr[":"], {
                data: i.expr.createPseudo ? i.expr.createPseudo(function(t) {
                    return function(e) {
                        return !!i.data(e, t)
                    }
                }) : function(t, e, n) {
                    return !!i.data(t, n[3])
                }
            }), i.fn.extend({
                disableSelection: function() {
                    var t = "onselectstart" in document.createElement("div") ? "selectstart" : "mousedown";
                    return function() {
                        return this.on(t + ".ui-disableSelection", function(e) {
                            e.preventDefault()
                        })
                    }
                }(),
                enableSelection: function() {
                    return this.off(".ui-disableSelection")
                }
            });
        var C = "ui-effects-",
            T = "ui-effects-style",
            B = "ui-effects-animated",
            tt = i;
        i.effects = {
                effect: {}
            },
            function(t, e) {
                function n(A, O, q) {
                    var X = R[O.type] || {};
                    return null == A ? q || !O.def ? null : O.def : (A = X.floor ? ~~A : parseFloat(A), isNaN(A) ? O.def : X.mod ? (A + X.mod) % X.mod : 0 > A ? 0 : A > X.max ? X.max : A)
                }

                function s(A) {
                    var O = D(),
                        q = O._rgba = [];
                    return A = A.toLowerCase(), F(k, function(X, J) {
                        var nt, pt = J.re.exec(A),
                            ft = pt && J.parse(pt),
                            lt = J.space || "rgba";
                        return ft ? (nt = O[lt](ft), O[I[lt].cache] = nt[I[lt].cache], q = O._rgba = nt._rgba, !1) : e
                    }), q.length ? ("0,0,0,0" === q.join() && t.extend(q, l.transparent), O) : l[A]
                }

                function r(A, O, q) {
                    return 1 > 6 * (q = (q + 1) % 1) ? A + 6 * (O - A) * q : 1 > 2 * q ? O : 2 > 3 * q ? A + 6 * (O - A) * (2 / 3 - q) : A
                }
                var l, g = /^([\-+])=\s*(\d+\.?\d*)/,
                    k = [{
                        re: /rgba?\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*(?:,\s*(\d?(?:\.\d+)?)\s*)?\)/,
                        parse: function(A) {
                            return [A[1], A[2], A[3], A[4]]
                        }
                    }, {
                        re: /rgba?\(\s*(\d+(?:\.\d+)?)\%\s*,\s*(\d+(?:\.\d+)?)\%\s*,\s*(\d+(?:\.\d+)?)\%\s*(?:,\s*(\d?(?:\.\d+)?)\s*)?\)/,
                        parse: function(A) {
                            return [2.55 * A[1], 2.55 * A[2], 2.55 * A[3], A[4]]
                        }
                    }, {
                        re: /#([a-f0-9]{2})([a-f0-9]{2})([a-f0-9]{2})/,
                        parse: function(A) {
                            return [parseInt(A[1], 16), parseInt(A[2], 16), parseInt(A[3], 16)]
                        }
                    }, {
                        re: /#([a-f0-9])([a-f0-9])([a-f0-9])/,
                        parse: function(A) {
                            return [parseInt(A[1] + A[1], 16), parseInt(A[2] + A[2], 16), parseInt(A[3] + A[3], 16)]
                        }
                    }, {
                        re: /hsla?\(\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)\%\s*,\s*(\d+(?:\.\d+)?)\%\s*(?:,\s*(\d?(?:\.\d+)?)\s*)?\)/,
                        space: "hsla",
                        parse: function(A) {
                            return [A[1], A[2] / 100, A[3] / 100, A[4]]
                        }
                    }],
                    D = t.Color = function(A, O, q, X) {
                        return new t.Color.fn.parse(A, O, q, X)
                    },
                    I = {
                        rgba: {
                            props: {
                                red: {
                                    idx: 0,
                                    type: "byte"
                                },
                                green: {
                                    idx: 1,
                                    type: "byte"
                                },
                                blue: {
                                    idx: 2,
                                    type: "byte"
                                }
                            }
                        },
                        hsla: {
                            props: {
                                hue: {
                                    idx: 0,
                                    type: "degrees"
                                },
                                saturation: {
                                    idx: 1,
                                    type: "percent"
                                },
                                lightness: {
                                    idx: 2,
                                    type: "percent"
                                }
                            }
                        }
                    },
                    R = {
                        byte: {
                            floor: !0,
                            max: 255
                        },
                        percent: {
                            max: 1
                        },
                        degrees: {
                            mod: 360,
                            floor: !0
                        }
                    },
                    P = D.support = {},
                    H = t("<p>")[0],
                    F = t.each;
                H.style.cssText = "background-color:rgba(1,1,1,.5)", P.rgba = H.style.backgroundColor.indexOf("rgba") > -1, F(I, function(A, O) {
                    O.cache = "_" + A, O.props.alpha = {
                        idx: 3,
                        type: "percent",
                        def: 1
                    }
                }), D.fn = t.extend(D.prototype, {
                    parse: function(A, O, q, X) {
                        if (A === e) return this._rgba = [null, null, null, null], this;
                        (A.jquery || A.nodeType) && (A = t(A).css(O), O = e);
                        var J = this,
                            nt = t.type(A),
                            pt = this._rgba = [];
                        return O !== e && (A = [A, O, q, X], nt = "array"), "string" === nt ? this.parse(s(A) || l._default) : "array" === nt ? (F(I.rgba.props, function(ft, lt) {
                            pt[lt.idx] = n(A[lt.idx], lt)
                        }), this) : "object" === nt ? (F(I, A instanceof D ? function(ft, lt) {
                            A[lt.cache] && (J[lt.cache] = A[lt.cache].slice())
                        } : function(ft, lt) {
                            var ct = lt.cache;
                            F(lt.props, function(mt, dt) {
                                if (!J[ct] && lt.to) {
                                    if ("alpha" === mt || null == A[mt]) return;
                                    J[ct] = lt.to(J._rgba)
                                }
                                J[ct][dt.idx] = n(A[mt], dt, !0)
                            }), J[ct] && 0 > t.inArray(null, J[ct].slice(0, 3)) && (J[ct][3] = 1, lt.from && (J._rgba = lt.from(J[ct])))
                        }), this) : e
                    },
                    is: function(A) {
                        var O = D(A),
                            q = !0,
                            X = this;
                        return F(I, function(J, nt) {
                            var pt, ft = O[nt.cache];
                            return ft && (pt = X[nt.cache] || nt.to && nt.to(X._rgba) || [], F(nt.props, function(lt, ct) {
                                return null != ft[ct.idx] ? q = ft[ct.idx] === pt[ct.idx] : e
                            })), q
                        }), q
                    },
                    _space: function() {
                        var A = [],
                            O = this;
                        return F(I, function(q, X) {
                            O[X.cache] && A.push(q)
                        }), A.pop()
                    },
                    transition: function(A, O) {
                        var q = D(A),
                            X = q._space(),
                            J = I[X],
                            nt = 0 === this.alpha() ? D("transparent") : this,
                            pt = nt[J.cache] || J.to(nt._rgba),
                            ft = pt.slice();
                        return q = q[J.cache], F(J.props, function(lt, ct) {
                            var mt = ct.idx,
                                dt = pt[mt],
                                kt = q[mt],
                                at = R[ct.type] || {};
                            null !== kt && (null === dt ? ft[mt] = kt : (at.mod && (kt - dt > at.mod / 2 ? dt += at.mod : dt - kt > at.mod / 2 && (dt -= at.mod)), ft[mt] = n((kt - dt) * O + dt, ct)))
                        }), this[X](ft)
                    },
                    blend: function(A) {
                        if (1 === this._rgba[3]) return this;
                        var O = this._rgba.slice(),
                            q = O.pop(),
                            X = D(A)._rgba;
                        return D(t.map(O, function(J, nt) {
                            return (1 - q) * X[nt] + q * J
                        }))
                    },
                    toRgbaString: function() {
                        var A = "rgba(",
                            O = t.map(this._rgba, function(q, X) {
                                return null == q ? X > 2 ? 1 : 0 : q
                            });
                        return 1 === O[3] && (O.pop(), A = "rgb("), A + O.join() + ")"
                    },
                    toHslaString: function() {
                        var A = "hsla(",
                            O = t.map(this.hsla(), function(q, X) {
                                return null == q && (q = X > 2 ? 1 : 0), X && 3 > X && (q = Math.round(100 * q) + "%"), q
                            });
                        return 1 === O[3] && (O.pop(), A = "hsl("), A + O.join() + ")"
                    },
                    toHexString: function(A) {
                        var O = this._rgba.slice(),
                            q = O.pop();
                        return A && O.push(~~(255 * q)), "#" + t.map(O, function(X) {
                            return 1 === (X = (X || 0).toString(16)).length ? "0" + X : X
                        }).join("")
                    },
                    toString: function() {
                        return 0 === this._rgba[3] ? "transparent" : this.toRgbaString()
                    }
                }), D.fn.parse.prototype = D.fn, I.hsla.to = function(A) {
                    if (null == A[0] || null == A[1] || null == A[2]) return [null, null, null, A[3]];
                    var q, X = A[0] / 255,
                        J = A[1] / 255,
                        nt = A[2] / 255,
                        pt = A[3],
                        ft = Math.max(X, J, nt),
                        lt = Math.min(X, J, nt),
                        ct = ft - lt,
                        mt = ft + lt,
                        dt = .5 * mt;
                    return q = 0 === ct ? 0 : .5 >= dt ? ct / mt : ct / (2 - mt), [Math.round(lt === ft ? 0 : X === ft ? 60 * (J - nt) / ct + 360 : J === ft ? 60 * (nt - X) / ct + 120 : 60 * (X - J) / ct + 240) % 360, q, dt, null == pt ? 1 : pt]
                }, I.hsla.from = function(A) {
                    if (null == A[0] || null == A[1] || null == A[2]) return [null, null, null, A[3]];
                    var O = A[0] / 360,
                        q = A[1],
                        X = A[2],
                        J = A[3],
                        nt = .5 >= X ? X * (1 + q) : X + q - X * q,
                        pt = 2 * X - nt;
                    return [Math.round(255 * r(pt, nt, O + 1 / 3)), Math.round(255 * r(pt, nt, O)), Math.round(255 * r(pt, nt, O - 1 / 3)), J]
                }, F(I, function(A, O) {
                    var q = O.props,
                        X = O.cache,
                        J = O.to,
                        nt = O.from;
                    D.fn[A] = function(pt) {
                        if (J && !this[X] && (this[X] = J(this._rgba)), pt === e) return this[X].slice();
                        var ft, lt = t.type(pt),
                            ct = "array" === lt || "object" === lt ? pt : arguments,
                            mt = this[X].slice();
                        return F(q, function(dt, kt) {
                            var at = ct["object" === lt ? dt : kt.idx];
                            null == at && (at = mt[kt.idx]), mt[kt.idx] = n(at, kt)
                        }), nt ? ((ft = D(nt(mt)))[X] = mt, ft) : D(mt)
                    }, F(q, function(pt, ft) {
                        D.fn[pt] || (D.fn[pt] = function(lt) {
                            var ct, mt = t.type(lt),
                                dt = "alpha" === pt ? this._hsla ? "hsla" : "rgba" : A,
                                kt = this[dt](),
                                at = kt[ft.idx];
                            return "undefined" === mt ? at : ("function" === mt && (lt = lt.call(this, at), mt = t.type(lt)), null == lt && ft.empty ? this : ("string" === mt && (ct = g.exec(lt)) && (lt = at + parseFloat(ct[2]) * ("+" === ct[1] ? 1 : -1)), kt[ft.idx] = lt, this[dt](kt)))
                        })
                    })
                }), D.hook = function(A) {
                    var O = A.split(" ");
                    F(O, function(q, X) {
                        t.cssHooks[X] = {
                            set: function(J, nt) {
                                var pt, ft, lt = "";
                                if ("transparent" !== nt && ("string" !== t.type(nt) || (pt = s(nt)))) {
                                    if (nt = D(pt || nt), !P.rgba && 1 !== nt._rgba[3]) {
                                        for (ft = "backgroundColor" === X ? J.parentNode : J;
                                            ("" === lt || "transparent" === lt) && ft && ft.style;) try {
                                            lt = t.css(ft, "backgroundColor"), ft = ft.parentNode
                                        } catch (ct) {}
                                        nt = nt.blend(lt && "transparent" !== lt ? lt : "_default")
                                    }
                                    nt = nt.toRgbaString()
                                }
                                try {
                                    J.style[X] = nt
                                } catch (ct) {}
                            }
                        }, t.fx.step[X] = function(J) {
                            J.colorInit || (J.start = D(J.elem, X), J.end = D(J.end), J.colorInit = !0), t.cssHooks[X].set(J.elem, J.start.transition(J.end, J.pos))
                        }
                    })
                }, D.hook("backgroundColor borderBottomColor borderLeftColor borderRightColor borderTopColor color columnRuleColor outlineColor textDecorationColor textEmphasisColor"), t.cssHooks.borderColor = {
                    expand: function(A) {
                        var O = {};
                        return F(["Top", "Right", "Bottom", "Left"], function(q, X) {
                            O["border" + X + "Color"] = A
                        }), O
                    }
                }, l = t.Color.names = {
                    aqua: "#00ffff",
                    black: "#000000",
                    blue: "#0000ff",
                    fuchsia: "#ff00ff",
                    gray: "#808080",
                    green: "#008000",
                    lime: "#00ff00",
                    maroon: "#800000",
                    navy: "#000080",
                    olive: "#808000",
                    purple: "#800080",
                    red: "#ff0000",
                    silver: "#c0c0c0",
                    teal: "#008080",
                    white: "#ffffff",
                    yellow: "#ffff00",
                    transparent: [null, null, null, 0],
                    _default: "#ffffff"
                }
            }(tt),
            function() {
                function t(r) {
                    var l, d, g = r.ownerDocument.defaultView ? r.ownerDocument.defaultView.getComputedStyle(r, null) : r.currentStyle,
                        k = {};
                    if (g && g.length && g[0] && g[g[0]])
                        for (d = g.length; d--;) "string" == typeof g[l = g[d]] && (k[i.camelCase(l)] = g[l]);
                    else
                        for (l in g) "string" == typeof g[l] && (k[l] = g[l]);
                    return k
                }
                var r, n = ["add", "remove", "toggle"],
                    s = {
                        border: 1,
                        borderBottom: 1,
                        borderColor: 1,
                        borderLeft: 1,
                        borderRight: 1,
                        borderTop: 1,
                        borderWidth: 1,
                        margin: 1,
                        padding: 1
                    };
                i.each(["borderLeftStyle", "borderRightStyle", "borderBottomStyle", "borderTopStyle"], function(r, l) {
                    i.fx.step[l] = function(d) {
                        ("none" !== d.end && !d.setAttr || 1 === d.pos && !d.setAttr) && (tt.style(d.elem, l, d.end), d.setAttr = !0)
                    }
                }), i.fn.addBack || (i.fn.addBack = function(r) {
                    return this.add(null == r ? this.prevObject : this.prevObject.filter(r))
                }), i.effects.animateClass = function(r, l, d, g) {
                    var k = i.speed(l, d, g);
                    return this.queue(function() {
                        var D, I = i(this),
                            R = I.attr("class") || "",
                            P = k.children ? I.find("*").addBack() : I;
                        P = P.map(function() {
                            return {
                                el: i(this),
                                start: t(this)
                            }
                        }), (D = function() {
                            i.each(n, function(H, F) {
                                r[F] && I[F + "Class"](r[F])
                            })
                        })(), P = P.map(function() {
                            return this.end = t(this.el[0]), this.diff = function e(r, l) {
                                var d, g, k = {};
                                for (d in l) r[d] !== (g = l[d]) && (s[d] || (i.fx.step[d] || !isNaN(parseFloat(g))) && (k[d] = g));
                                return k
                            }(this.start, this.end), this
                        }), I.attr("class", R), P = P.map(function() {
                            var H = this,
                                F = i.Deferred(),
                                A = i.extend({}, k, {
                                    queue: !1,
                                    complete: function() {
                                        F.resolve(H)
                                    }
                                });
                            return this.el.animate(this.diff, A), F.promise()
                        }), i.when.apply(i, P.get()).done(function() {
                            D(), i.each(arguments, function() {
                                var H = this.el;
                                i.each(this.diff, function(F) {
                                    H.css(F, "")
                                })
                            }), k.complete.call(I[0])
                        })
                    })
                }, i.fn.extend({
                    addClass: (r = i.fn.addClass, function(l, d, g, k) {
                        return d ? i.effects.animateClass.call(this, {
                            add: l
                        }, d, g, k) : r.apply(this, arguments)
                    }),
                    removeClass: function(r) {
                        return function(l, d, g, k) {
                            return arguments.length > 1 ? i.effects.animateClass.call(this, {
                                remove: l
                            }, d, g, k) : r.apply(this, arguments)
                        }
                    }(i.fn.removeClass),
                    toggleClass: function(r) {
                        return function(l, d, g, k, D) {
                            return "boolean" == typeof d || void 0 === d ? g ? i.effects.animateClass.call(this, d ? {
                                add: l
                            } : {
                                remove: l
                            }, g, k, D) : r.apply(this, arguments) : i.effects.animateClass.call(this, {
                                toggle: l
                            }, d, g, k)
                        }
                    }(i.fn.toggleClass),
                    switchClass: function(r, l, d, g, k) {
                        return i.effects.animateClass.call(this, {
                            add: l,
                            remove: r
                        }, d, g, k)
                    }
                })
            }(),
            function() {
                function t(s, r, l, d) {
                    return i.isPlainObject(s) && (r = s, s = s.effect), s = {
                        effect: s
                    }, null == r && (r = {}), i.isFunction(r) && (d = r, l = null, r = {}), ("number" == typeof r || i.fx.speeds[r]) && (d = l, l = r, r = {}), i.isFunction(l) && (d = l, l = null), r && i.extend(s, r), l = l || r.duration, s.duration = i.fx.off ? 0 : "number" == typeof l ? l : l in i.fx.speeds ? i.fx.speeds[l] : i.fx.speeds._default, s.complete = d || r.complete, s
                }

                function e(s) {
                    return !(s && "number" != typeof s && !i.fx.speeds[s] && ("string" != typeof s || i.effects.effect[s]) && !i.isFunction(s) && ("object" != typeof s || s.effect))
                }

                function n(s, r) {
                    var l = r.outerWidth(),
                        d = r.outerHeight(),
                        k = /^rect\((-?\d*\.?\d*px|-?\d+%|auto),?\s*(-?\d*\.?\d*px|-?\d+%|auto),?\s*(-?\d*\.?\d*px|-?\d+%|auto),?\s*(-?\d*\.?\d*px|-?\d+%|auto)\)$/.exec(s) || ["", 0, l, d, 0];
                    return {
                        top: parseFloat(k[1]) || 0,
                        right: "auto" === k[2] ? l : parseFloat(k[2]),
                        bottom: "auto" === k[3] ? d : parseFloat(k[3]),
                        left: parseFloat(k[4]) || 0
                    }
                }
                var s;
                i.expr && i.expr.filters && i.expr.filters.animated && (i.expr.filters.animated = (s = i.expr.filters.animated, function(r) {
                    return !!i(r).data(B) || s(r)
                })), !1 !== i.uiBackCompat && i.extend(i.effects, {
                    save: function(s, r) {
                        for (var l = 0, d = r.length; d > l; l++) null !== r[l] && s.data(C + r[l], s[0].style[r[l]])
                    },
                    restore: function(s, r) {
                        for (var l, d = 0, g = r.length; g > d; d++) null !== r[d] && (l = s.data(C + r[d]), s.css(r[d], l))
                    },
                    setMode: function(s, r) {
                        return "toggle" === r && (r = s.is(":hidden") ? "show" : "hide"), r
                    },
                    createWrapper: function(s) {
                        if (s.parent().is(".ui-effects-wrapper")) return s.parent();
                        var r = {
                                width: s.outerWidth(!0),
                                height: s.outerHeight(!0),
                                float: s.css("float")
                            },
                            l = i("<div></div>").addClass("ui-effects-wrapper").css({
                                fontSize: "100%",
                                background: "transparent",
                                border: "none",
                                margin: 0,
                                padding: 0
                            }),
                            d = {
                                width: s.width(),
                                height: s.height()
                            },
                            g = document.activeElement;
                        return s.wrap(l), (s[0] === g || i.contains(s[0], g)) && i(g).trigger("focus"), l = s.parent(), "static" === s.css("position") ? (l.css({
                            position: "relative"
                        }), s.css({
                            position: "relative"
                        })) : (i.extend(r, {
                            position: s.css("position"),
                            zIndex: s.css("z-index")
                        }), i.each(["top", "left", "bottom", "right"], function(k, D) {
                            r[D] = s.css(D), isNaN(parseInt(r[D], 10)) && (r[D] = "auto")
                        }), s.css({
                            position: "relative",
                            top: 0,
                            left: 0,
                            right: "auto",
                            bottom: "auto"
                        })), s.css(d), l.css(r).show()
                    },
                    removeWrapper: function(s) {
                        var r = document.activeElement;
                        return s.parent().is(".ui-effects-wrapper") && (s.parent().replaceWith(s), (s[0] === r || i.contains(s[0], r)) && i(r).trigger("focus")), s
                    }
                }), i.extend(i.effects, {
                    version: "1.12.1",
                    define: function(s, r, l) {
                        return l || (l = r, r = "effect"), i.effects.effect[s] = l, i.effects.effect[s].mode = r, l
                    },
                    scaledDimensions: function(s, r, l) {
                        if (0 === r) return {
                            height: 0,
                            width: 0,
                            outerHeight: 0,
                            outerWidth: 0
                        };
                        var d = "horizontal" !== l ? (r || 100) / 100 : 1,
                            g = "vertical" !== l ? (r || 100) / 100 : 1;
                        return {
                            height: s.height() * g,
                            width: s.width() * d,
                            outerHeight: s.outerHeight() * g,
                            outerWidth: s.outerWidth() * d
                        }
                    },
                    clipToBox: function(s) {
                        return {
                            width: s.clip.right - s.clip.left,
                            height: s.clip.bottom - s.clip.top,
                            left: s.clip.left,
                            top: s.clip.top
                        }
                    },
                    unshift: function(s, r, l) {
                        var d = s.queue();
                        r > 1 && d.splice.apply(d, [1, 0].concat(d.splice(r, l))), s.dequeue()
                    },
                    saveStyle: function(s) {
                        s.data(T, s[0].style.cssText)
                    },
                    restoreStyle: function(s) {
                        s[0].style.cssText = s.data(T) || "", s.removeData(T)
                    },
                    mode: function(s, r) {
                        var l = s.is(":hidden");
                        return "toggle" === r && (r = l ? "show" : "hide"), (l ? "hide" === r : "show" === r) && (r = "none"), r
                    },
                    getBaseline: function(s, r) {
                        var l, d;
                        switch (s[0]) {
                            case "top":
                                l = 0;
                                break;
                            case "middle":
                                l = .5;
                                break;
                            case "bottom":
                                l = 1;
                                break;
                            default:
                                l = s[0] / r.height
                        }
                        switch (s[1]) {
                            case "left":
                                d = 0;
                                break;
                            case "center":
                                d = .5;
                                break;
                            case "right":
                                d = 1;
                                break;
                            default:
                                d = s[1] / r.width
                        }
                        return {
                            x: d,
                            y: l
                        }
                    },
                    createPlaceholder: function(s) {
                        var r, l = s.css("position"),
                            d = s.position();
                        return s.css({
                            marginTop: s.css("marginTop"),
                            marginBottom: s.css("marginBottom"),
                            marginLeft: s.css("marginLeft"),
                            marginRight: s.css("marginRight")
                        }).outerWidth(s.outerWidth()).outerHeight(s.outerHeight()), /^(static|relative)/.test(l) && (l = "absolute", r = i("<" + s[0].nodeName + ">").insertAfter(s).css({
                            display: /^(inline|ruby)/.test(s.css("display")) ? "inline-block" : "block",
                            visibility: "hidden",
                            marginTop: s.css("marginTop"),
                            marginBottom: s.css("marginBottom"),
                            marginLeft: s.css("marginLeft"),
                            marginRight: s.css("marginRight"),
                            float: s.css("float")
                        }).outerWidth(s.outerWidth()).outerHeight(s.outerHeight()).addClass("ui-effects-placeholder"), s.data(C + "placeholder", r)), s.css({
                            position: l,
                            left: d.left,
                            top: d.top
                        }), r
                    },
                    removePlaceholder: function(s) {
                        var r = C + "placeholder",
                            l = s.data(r);
                        l && (l.remove(), s.removeData(r))
                    },
                    cleanUp: function(s) {
                        i.effects.restoreStyle(s), i.effects.removePlaceholder(s)
                    },
                    setTransition: function(s, r, l, d) {
                        return d = d || {}, i.each(r, function(g, k) {
                            var D = s.cssUnit(k);
                            D[0] > 0 && (d[k] = D[0] * l + D[1])
                        }), d
                    }
                }), i.fn.extend({
                    effect: function() {
                        function s(H) {
                            function A() {
                                i.isFunction(D) && D.call(O[0]), i.isFunction(H) && H()
                            }
                            var O = i(this);
                            r.mode = R.shift(), !1 === i.uiBackCompat || d ? "none" === r.mode ? (O[I](), A()) : l.call(O[0], r, function F() {
                                O.removeData(B), i.effects.cleanUp(O), "hide" === r.mode && O.hide(), A()
                            }) : (O.is(":hidden") ? "hide" === I : "show" === I) ? (O[I](), A()) : l.call(O[0], r, A)
                        }
                        var r = t.apply(this, arguments),
                            l = i.effects.effect[r.effect],
                            d = l.mode,
                            g = r.queue,
                            k = g || "fx",
                            D = r.complete,
                            I = r.mode,
                            R = [],
                            P = function(H) {
                                var F = i(this),
                                    A = i.effects.mode(F, I) || d;
                                F.data(B, !0), R.push(A), d && ("show" === A || A === d && "hide" === A) && F.show(), d && "none" === A || i.effects.saveStyle(F), i.isFunction(H) && H()
                            };
                        return i.fx.off || !l ? I ? this[I](r.duration, D) : this.each(function() {
                            D && D.call(this)
                        }) : !1 === g ? this.each(P).each(s) : this.queue(k, P).queue(k, s)
                    },
                    show: function(s) {
                        return function(r) {
                            if (e(r)) return s.apply(this, arguments);
                            var l = t.apply(this, arguments);
                            return l.mode = "show", this.effect.call(this, l)
                        }
                    }(i.fn.show),
                    hide: function(s) {
                        return function(r) {
                            if (e(r)) return s.apply(this, arguments);
                            var l = t.apply(this, arguments);
                            return l.mode = "hide", this.effect.call(this, l)
                        }
                    }(i.fn.hide),
                    toggle: function(s) {
                        return function(r) {
                            if (e(r) || "boolean" == typeof r) return s.apply(this, arguments);
                            var l = t.apply(this, arguments);
                            return l.mode = "toggle", this.effect.call(this, l)
                        }
                    }(i.fn.toggle),
                    cssUnit: function(s) {
                        var r = this.css(s),
                            l = [];
                        return i.each(["em", "px", "%", "pt"], function(d, g) {
                            r.indexOf(g) > 0 && (l = [parseFloat(r), g])
                        }), l
                    },
                    cssClip: function(s) {
                        return s ? this.css("clip", "rect(" + s.top + "px " + s.right + "px " + s.bottom + "px " + s.left + "px)") : n(this.css("clip"), this)
                    },
                    transfer: function(s, r) {
                        var l = i(this),
                            d = i(s.to),
                            g = "fixed" === d.css("position"),
                            k = i("body"),
                            D = g ? k.scrollTop() : 0,
                            I = g ? k.scrollLeft() : 0,
                            R = d.offset(),
                            P = {
                                top: R.top - D,
                                left: R.left - I,
                                height: d.innerHeight(),
                                width: d.innerWidth()
                            },
                            H = l.offset(),
                            F = i("<div class='ui-effects-transfer'></div>").appendTo("body").addClass(s.className).css({
                                top: H.top - D,
                                left: H.left - I,
                                height: l.innerHeight(),
                                width: l.innerWidth(),
                                position: g ? "fixed" : "absolute"
                            }).animate(P, s.duration, s.easing, function() {
                                F.remove(), i.isFunction(r) && r()
                            })
                    }
                }), i.fx.step.clip = function(s) {
                    s.clipInit || (s.start = i(s.elem).cssClip(), "string" == typeof s.end && (s.end = n(s.end, s.elem)), s.clipInit = !0), i(s.elem).cssClip({
                        top: s.pos * (s.end.top - s.start.top) + s.start.top,
                        right: s.pos * (s.end.right - s.start.right) + s.start.right,
                        bottom: s.pos * (s.end.bottom - s.start.bottom) + s.start.bottom,
                        left: s.pos * (s.end.left - s.start.left) + s.start.left
                    })
                }
            }(),
            function() {
                var t = {};
                i.each(["Quad", "Cubic", "Quart", "Quint", "Expo"], function(e, n) {
                    t[n] = function(s) {
                        return Math.pow(s, e + 2)
                    }
                }), i.extend(t, {
                    Sine: function(e) {
                        return 1 - Math.cos(e * Math.PI / 2)
                    },
                    Circ: function(e) {
                        return 1 - Math.sqrt(1 - e * e)
                    },
                    Elastic: function(e) {
                        return 0 === e || 1 === e ? e : -Math.pow(2, 8 * (e - 1)) * Math.sin((80 * (e - 1) - 7.5) * Math.PI / 15)
                    },
                    Back: function(e) {
                        return e * e * (3 * e - 2)
                    },
                    Bounce: function(e) {
                        for (var n, s = 4;
                            ((n = Math.pow(2, --s)) - 1) / 11 > e;);
                        return 1 / Math.pow(4, 3 - s) - 7.5625 * Math.pow((3 * n - 2) / 22 - e, 2)
                    }
                }), i.each(t, function(e, n) {
                    i.easing["easeIn" + e] = n, i.easing["easeOut" + e] = function(s) {
                        return 1 - n(1 - s)
                    }, i.easing["easeInOut" + e] = function(s) {
                        return .5 > s ? n(2 * s) / 2 : 1 - n(-2 * s + 2) / 2
                    }
                })
            }(), i.effects.define("blind", "hide", function(t, e) {
                var n = {
                        up: ["bottom", "top"],
                        vertical: ["bottom", "top"],
                        down: ["top", "bottom"],
                        left: ["right", "left"],
                        horizontal: ["right", "left"],
                        right: ["left", "right"]
                    },
                    s = i(this),
                    r = t.direction || "up",
                    l = s.cssClip(),
                    d = {
                        clip: i.extend({}, l)
                    },
                    g = i.effects.createPlaceholder(s);
                d.clip[n[r][0]] = d.clip[n[r][1]], "show" === t.mode && (s.cssClip(d.clip), g && g.css(i.effects.clipToBox(d)), d.clip = l), g && g.animate(i.effects.clipToBox(d), t.duration, t.easing), s.animate(d, {
                    queue: !1,
                    duration: t.duration,
                    easing: t.easing,
                    complete: e
                })
            }), i.effects.define("bounce", function(t, e) {
                var n, s, r, l = i(this),
                    d = t.mode,
                    g = "hide" === d,
                    k = "show" === d,
                    D = t.direction || "up",
                    I = t.distance,
                    R = t.times || 5,
                    P = 2 * R + (k || g ? 1 : 0),
                    H = t.duration / P,
                    F = t.easing,
                    A = "up" === D || "down" === D ? "top" : "left",
                    O = "up" === D || "left" === D,
                    q = 0,
                    X = l.queue().length;
                for (i.effects.createPlaceholder(l), r = l.css(A), I || (I = l["top" === A ? "outerHeight" : "outerWidth"]() / 3), k && ((s = {
                        opacity: 1
                    })[A] = r, l.css("opacity", 0).css(A, O ? 2 * -I : 2 * I).animate(s, H, F)), g && (I /= Math.pow(2, R - 1)), (s = {})[A] = r; R > q; q++)(n = {})[A] = (O ? "-=" : "+=") + I, l.animate(n, H, F).animate(s, H, F), I = g ? 2 * I : I / 2;
                g && ((n = {
                    opacity: 0
                })[A] = (O ? "-=" : "+=") + I, l.animate(n, H, F)), l.queue(e), i.effects.unshift(l, X, P + 1)
            }), i.effects.define("clip", "hide", function(t, e) {
                var n, s = {},
                    r = i(this),
                    l = t.direction || "vertical",
                    d = "both" === l,
                    g = d || "horizontal" === l,
                    k = d || "vertical" === l;
                n = r.cssClip(), s.clip = {
                    top: k ? (n.bottom - n.top) / 2 : n.top,
                    right: g ? (n.right - n.left) / 2 : n.right,
                    bottom: k ? (n.bottom - n.top) / 2 : n.bottom,
                    left: g ? (n.right - n.left) / 2 : n.left
                }, i.effects.createPlaceholder(r), "show" === t.mode && (r.cssClip(s.clip), s.clip = n), r.animate(s, {
                    queue: !1,
                    duration: t.duration,
                    easing: t.easing,
                    complete: e
                })
            }), i.effects.define("drop", "hide", function(t, e) {
                var n, s = i(this),
                    l = "show" === t.mode,
                    d = t.direction || "left",
                    g = "up" === d || "down" === d ? "top" : "left",
                    k = "up" === d || "left" === d ? "-=" : "+=",
                    D = "+=" === k ? "-=" : "+=",
                    I = {
                        opacity: 0
                    };
                i.effects.createPlaceholder(s), n = t.distance || s["top" === g ? "outerHeight" : "outerWidth"](!0) / 2, I[g] = k + n, l && (s.css(I), I[g] = D + n, I.opacity = 1), s.animate(I, {
                    queue: !1,
                    duration: t.duration,
                    easing: t.easing,
                    complete: e
                })
            }), i.effects.define("explode", "hide", function(t, e) {
                function n() {
                    X.push(this), X.length === I * R && function s() {
                        P.css({
                            visibility: "visible"
                        }), i(X).remove(), e()
                    }()
                }
                var r, l, d, g, k, D, I = t.pieces ? Math.round(Math.sqrt(t.pieces)) : 3,
                    R = I,
                    P = i(this),
                    F = "show" === t.mode,
                    A = P.show().css("visibility", "hidden").offset(),
                    O = Math.ceil(P.outerWidth() / R),
                    q = Math.ceil(P.outerHeight() / I),
                    X = [];
                for (r = 0; I > r; r++)
                    for (g = A.top + r * q, D = r - (I - 1) / 2, l = 0; R > l; l++) d = A.left + l * O, k = l - (R - 1) / 2, P.clone().appendTo("body").wrap("<div></div>").css({
                        position: "absolute",
                        visibility: "visible",
                        left: -l * O,
                        top: -r * q
                    }).parent().addClass("ui-effects-explode").css({
                        position: "absolute",
                        overflow: "hidden",
                        width: O,
                        height: q,
                        left: d + (F ? k * O : 0),
                        top: g + (F ? D * q : 0),
                        opacity: F ? 0 : 1
                    }).animate({
                        left: d + (F ? 0 : k * O),
                        top: g + (F ? 0 : D * q),
                        opacity: F ? 1 : 0
                    }, t.duration || 500, t.easing, n)
            }), i.effects.define("fade", "toggle", function(t, e) {
                var n = "show" === t.mode;
                i(this).css("opacity", n ? 0 : 1).animate({
                    opacity: n ? 1 : 0
                }, {
                    queue: !1,
                    duration: t.duration,
                    easing: t.easing,
                    complete: e
                })
            }), i.effects.define("fold", "hide", function(t, e) {
                var n = i(this),
                    s = t.mode,
                    r = "show" === s,
                    l = "hide" === s,
                    d = t.size || 15,
                    g = /([0-9]+)%/.exec(d),
                    D = t.horizFirst ? ["right", "bottom"] : ["bottom", "right"],
                    I = t.duration / 2,
                    R = i.effects.createPlaceholder(n),
                    P = n.cssClip(),
                    H = {
                        clip: i.extend({}, P)
                    },
                    F = {
                        clip: i.extend({}, P)
                    },
                    A = [P[D[0]], P[D[1]]],
                    O = n.queue().length;
                g && (d = parseInt(g[1], 10) / 100 * A[l ? 0 : 1]), H.clip[D[0]] = d, F.clip[D[0]] = d, F.clip[D[1]] = 0, r && (n.cssClip(F.clip), R && R.css(i.effects.clipToBox(F)), F.clip = P), n.queue(function(q) {
                    R && R.animate(i.effects.clipToBox(H), I, t.easing).animate(i.effects.clipToBox(F), I, t.easing), q()
                }).animate(H, I, t.easing).animate(F, I, t.easing).queue(e), i.effects.unshift(n, O, 4)
            }), i.effects.define("highlight", "show", function(t, e) {
                var n = i(this),
                    s = {
                        backgroundColor: n.css("backgroundColor")
                    };
                "hide" === t.mode && (s.opacity = 0), i.effects.saveStyle(n), n.css({
                    backgroundImage: "none",
                    backgroundColor: t.color || "#ffff99"
                }).animate(s, {
                    queue: !1,
                    duration: t.duration,
                    easing: t.easing,
                    complete: e
                })
            }), i.effects.define("size", function(t, e) {
                var n, s, r, l = i(this),
                    d = ["fontSize"],
                    g = ["borderTopWidth", "borderBottomWidth", "paddingTop", "paddingBottom"],
                    k = ["borderLeftWidth", "borderRightWidth", "paddingLeft", "paddingRight"],
                    D = t.mode,
                    I = "effect" !== D,
                    R = t.scale || "both",
                    P = t.origin || ["middle", "center"],
                    H = l.css("position"),
                    F = l.position(),
                    A = i.effects.scaledDimensions(l),
                    O = t.from || A,
                    q = t.to || i.effects.scaledDimensions(l, 0);
                i.effects.createPlaceholder(l), "show" === D && (r = O, O = q, q = r), s = {
                    from: {
                        y: O.height / A.height,
                        x: O.width / A.width
                    },
                    to: {
                        y: q.height / A.height,
                        x: q.width / A.width
                    }
                }, ("box" === R || "both" === R) && (s.from.y !== s.to.y && (O = i.effects.setTransition(l, g, s.from.y, O), q = i.effects.setTransition(l, g, s.to.y, q)), s.from.x !== s.to.x && (O = i.effects.setTransition(l, k, s.from.x, O), q = i.effects.setTransition(l, k, s.to.x, q))), ("content" === R || "both" === R) && s.from.y !== s.to.y && (O = i.effects.setTransition(l, d, s.from.y, O), q = i.effects.setTransition(l, d, s.to.y, q)), P && (n = i.effects.getBaseline(P, A), O.top = (A.outerHeight - O.outerHeight) * n.y + F.top, O.left = (A.outerWidth - O.outerWidth) * n.x + F.left, q.top = (A.outerHeight - q.outerHeight) * n.y + F.top, q.left = (A.outerWidth - q.outerWidth) * n.x + F.left), l.css(O), ("content" === R || "both" === R) && (g = g.concat(["marginTop", "marginBottom"]).concat(d), k = k.concat(["marginLeft", "marginRight"]), l.find("*[width]").each(function() {
                    var X = i(this),
                        J = i.effects.scaledDimensions(X),
                        nt = {
                            height: J.height * s.from.y,
                            width: J.width * s.from.x,
                            outerHeight: J.outerHeight * s.from.y,
                            outerWidth: J.outerWidth * s.from.x
                        },
                        pt = {
                            height: J.height * s.to.y,
                            width: J.width * s.to.x,
                            outerHeight: J.height * s.to.y,
                            outerWidth: J.width * s.to.x
                        };
                    s.from.y !== s.to.y && (nt = i.effects.setTransition(X, g, s.from.y, nt), pt = i.effects.setTransition(X, g, s.to.y, pt)), s.from.x !== s.to.x && (nt = i.effects.setTransition(X, k, s.from.x, nt), pt = i.effects.setTransition(X, k, s.to.x, pt)), I && i.effects.saveStyle(X), X.css(nt), X.animate(pt, t.duration, t.easing, function() {
                        I && i.effects.restoreStyle(X)
                    })
                })), l.animate(q, {
                    queue: !1,
                    duration: t.duration,
                    easing: t.easing,
                    complete: function() {
                        var X = l.offset();
                        0 === q.opacity && l.css("opacity", O.opacity), I || (l.css("position", "static" === H ? "relative" : H).offset(X), i.effects.saveStyle(l)), e()
                    }
                })
            }), i.effects.define("scale", function(t, e) {
                var n = i(this),
                    s = t.mode,
                    r = parseInt(t.percent, 10) || (0 === parseInt(t.percent, 10) || "effect" !== s ? 0 : 100),
                    l = i.extend(!0, {
                        from: i.effects.scaledDimensions(n),
                        to: i.effects.scaledDimensions(n, r, t.direction || "both"),
                        origin: t.origin || ["middle", "center"]
                    }, t);
                t.fade && (l.from.opacity = 1, l.to.opacity = 0), i.effects.effect.size.call(this, l, e)
            }), i.effects.define("puff", "hide", function(t, e) {
                var n = i.extend(!0, {}, t, {
                    fade: !0,
                    percent: parseInt(t.percent, 10) || 150
                });
                i.effects.effect.scale.call(this, n, e)
            }), i.effects.define("pulsate", "show", function(t, e) {
                var n = i(this),
                    s = t.mode,
                    r = "show" === s,
                    g = 2 * (t.times || 5) + (r || "hide" === s ? 1 : 0),
                    k = t.duration / g,
                    D = 0,
                    I = 1,
                    R = n.queue().length;
                for ((r || !n.is(":visible")) && (n.css("opacity", 0).show(), D = 1); g > I; I++) n.animate({
                    opacity: D
                }, k, t.easing), D = 1 - D;
                n.animate({
                    opacity: D
                }, k, t.easing), n.queue(e), i.effects.unshift(n, R, g + 1)
            }), i.effects.define("shake", function(t, e) {
                var n = 1,
                    s = i(this),
                    r = t.direction || "left",
                    l = t.distance || 20,
                    d = t.times || 3,
                    g = 2 * d + 1,
                    k = Math.round(t.duration / g),
                    D = "up" === r || "down" === r ? "top" : "left",
                    I = "up" === r || "left" === r,
                    R = {},
                    P = {},
                    H = {},
                    F = s.queue().length;
                for (i.effects.createPlaceholder(s), R[D] = (I ? "-=" : "+=") + l, P[D] = (I ? "+=" : "-=") + 2 * l, H[D] = (I ? "-=" : "+=") + 2 * l, s.animate(R, k, t.easing); d > n; n++) s.animate(P, k, t.easing).animate(H, k, t.easing);
                s.animate(P, k, t.easing).animate(R, k / 2, t.easing).queue(e), i.effects.unshift(s, F, g + 1)
            }), i.effects.define("slide", "show", function(t, e) {
                var n, s, r = i(this),
                    l = {
                        up: ["bottom", "top"],
                        down: ["top", "bottom"],
                        left: ["right", "left"],
                        right: ["left", "right"]
                    },
                    d = t.mode,
                    g = t.direction || "left",
                    k = "up" === g || "down" === g ? "top" : "left",
                    D = "up" === g || "left" === g,
                    I = t.distance || r["top" === k ? "outerHeight" : "outerWidth"](!0),
                    R = {};
                i.effects.createPlaceholder(r), n = r.cssClip(), s = r.position()[k], R[k] = (D ? -1 : 1) * I + s, R.clip = r.cssClip(), R.clip[l[g][1]] = R.clip[l[g][0]], "show" === d && (r.cssClip(R.clip), r.css(k, R[k]), R.clip = n, R[k] = s), r.animate(R, {
                    queue: !1,
                    duration: t.duration,
                    easing: t.easing,
                    complete: e
                })
            }), !1 !== i.uiBackCompat && i.effects.define("transfer", function(t, e) {
                i(this).transfer(t, e)
            }), i.ui.focusable = function(t, e) {
                var n, s, r, l, d, g = t.nodeName.toLowerCase();
                return "area" === g ? (s = (n = t.parentNode).name, !(!t.href || !s || "map" !== n.nodeName.toLowerCase()) && (r = i("img[usemap='#" + s + "']")).length > 0 && r.is(":visible")) : (/^(input|select|textarea|button|object)$/.test(g) ? (l = !t.disabled) && (d = i(t).closest("fieldset")[0]) && (l = !d.disabled) : l = "a" === g && t.href || e, l && i(t).is(":visible") && function L(t) {
                    for (var e = t.css("visibility");
                        "inherit" === e;) e = (t = t.parent()).css("visibility");
                    return "hidden" !== e
                }(i(t)))
            }, i.extend(i.expr[":"], {
                focusable: function(t) {
                    return i.ui.focusable(t, null != i.attr(t, "tabindex"))
                }
            }), i.fn.form = function() {
                return "string" == typeof this[0].form ? this.closest("form") : i(this[0].form)
            }, i.ui.formResetMixin = {
                _formResetHandler: function() {
                    var t = i(this);
                    setTimeout(function() {
                        var e = t.data("ui-form-reset-instances");
                        i.each(e, function() {
                            this.refresh()
                        })
                    })
                },
                _bindFormResetHandler: function() {
                    if (this.form = this.element.form(), this.form.length) {
                        var t = this.form.data("ui-form-reset-instances") || [];
                        t.length || this.form.on("reset.ui-form-reset", this._formResetHandler), t.push(this), this.form.data("ui-form-reset-instances", t)
                    }
                },
                _unbindFormResetHandler: function() {
                    if (this.form.length) {
                        var t = this.form.data("ui-form-reset-instances");
                        t.splice(i.inArray(this, t), 1), t.length ? this.form.data("ui-form-reset-instances", t) : this.form.removeData("ui-form-reset-instances").off("reset.ui-form-reset")
                    }
                }
            }, "1.7" === i.fn.jquery.substring(0, 3) && (i.each(["Width", "Height"], function(t, e) {
                function n(d, g, k, D) {
                    return i.each(s, function() {
                        g -= parseFloat(i.css(d, "padding" + this)) || 0, k && (g -= parseFloat(i.css(d, "border" + this + "Width")) || 0), D && (g -= parseFloat(i.css(d, "margin" + this)) || 0)
                    }), g
                }
                var s = "Width" === e ? ["Left", "Right"] : ["Top", "Bottom"],
                    r = e.toLowerCase(),
                    l = {
                        innerWidth: i.fn.innerWidth,
                        innerHeight: i.fn.innerHeight,
                        outerWidth: i.fn.outerWidth,
                        outerHeight: i.fn.outerHeight
                    };
                i.fn["inner" + e] = function(d) {
                    return void 0 === d ? l["inner" + e].call(this) : this.each(function() {
                        i(this).css(r, n(this, d) + "px")
                    })
                }, i.fn["outer" + e] = function(d, g) {
                    return "number" != typeof d ? l["outer" + e].call(this, d) : this.each(function() {
                        i(this).css(r, n(this, d, !0, g) + "px")
                    })
                }
            }), i.fn.addBack = function(t) {
                return this.add(null == t ? this.prevObject : this.prevObject.filter(t))
            }), i.ui.keyCode = {
                BACKSPACE: 8,
                COMMA: 188,
                DELETE: 46,
                DOWN: 40,
                END: 35,
                ENTER: 13,
                ESCAPE: 27,
                HOME: 36,
                LEFT: 37,
                PAGE_DOWN: 34,
                PAGE_UP: 33,
                PERIOD: 190,
                RIGHT: 39,
                SPACE: 32,
                TAB: 9,
                UP: 38
            }, i.ui.escapeSelector = function() {
                var t = /([!"#$%&'()*+,./:;<=>?@[\]^`{|}~])/g;
                return function(e) {
                    return e.replace(t, "\\$1")
                }
            }(), i.fn.labels = function() {
                var t, e, n, s, r;
                return this[0].labels && this[0].labels.length ? this.pushStack(this[0].labels) : (s = this.eq(0).parents("label"), (n = this.attr("id")) && (r = (t = this.eq(0).parents().last()).add(t.length ? t.siblings() : this.siblings()), e = "label[for='" + i.ui.escapeSelector(n) + "']", s = s.add(r.find(e).addBack(e))), this.pushStack(s))
            }, i.fn.scrollParent = function(t) {
                var e = this.css("position"),
                    n = "absolute" === e,
                    s = t ? /(auto|scroll|hidden)/ : /(auto|scroll)/,
                    r = this.parents().filter(function() {
                        var l = i(this);
                        return (!n || "static" !== l.css("position")) && s.test(l.css("overflow") + l.css("overflow-y") + l.css("overflow-x"))
                    }).eq(0);
                return "fixed" !== e && r.length ? r : i(this[0].ownerDocument || document)
            }, i.extend(i.expr[":"], {
                tabbable: function(t) {
                    var e = i.attr(t, "tabindex"),
                        n = null != e;
                    return (!n || e >= 0) && i.ui.focusable(t, n)
                }
            }), i.fn.extend({
                uniqueId: function() {
                    var t = 0;
                    return function() {
                        return this.each(function() {
                            this.id || (this.id = "ui-id-" + ++t)
                        })
                    }
                }(),
                removeUniqueId: function() {
                    return this.each(function() {
                        /^ui-id-\d+$/.test(this.id) && i(this).removeAttr("id")
                    })
                }
            }), i.widget("ui.accordion", {
                version: "1.12.1",
                options: {
                    active: 0,
                    animate: {},
                    classes: {
                        "ui-accordion-header": "ui-corner-top",
                        "ui-accordion-header-collapsed": "ui-corner-all",
                        "ui-accordion-content": "ui-corner-bottom"
                    },
                    collapsible: !1,
                    event: "click",
                    header: "> li > :first-child, > :not(li):even",
                    heightStyle: "auto",
                    icons: {
                        activeHeader: "ui-icon-triangle-1-s",
                        header: "ui-icon-triangle-1-e"
                    },
                    activate: null,
                    beforeActivate: null
                },
                hideProps: {
                    borderTopWidth: "hide",
                    borderBottomWidth: "hide",
                    paddingTop: "hide",
                    paddingBottom: "hide",
                    height: "hide"
                },
                showProps: {
                    borderTopWidth: "show",
                    borderBottomWidth: "show",
                    paddingTop: "show",
                    paddingBottom: "show",
                    height: "show"
                },
                _create: function() {
                    var t = this.options;
                    this.prevShow = this.prevHide = i(), this._addClass("ui-accordion", "ui-widget ui-helper-reset"), this.element.attr("role", "tablist"), t.collapsible || !1 !== t.active && null != t.active || (t.active = 0), this._processPanels(), 0 > t.active && (t.active += this.headers.length), this._refresh()
                },
                _getCreateEventData: function() {
                    return {
                        header: this.active,
                        panel: this.active.length ? this.active.next() : i()
                    }
                },
                _createIcons: function() {
                    var t, e, n = this.options.icons;
                    n && (t = i("<span>"), this._addClass(t, "ui-accordion-header-icon", "ui-icon " + n.header), t.prependTo(this.headers), e = this.active.children(".ui-accordion-header-icon"), this._removeClass(e, n.header)._addClass(e, null, n.activeHeader)._addClass(this.headers, "ui-accordion-icons"))
                },
                _destroyIcons: function() {
                    this._removeClass(this.headers, "ui-accordion-icons"), this.headers.children(".ui-accordion-header-icon").remove()
                },
                _destroy: function() {
                    var t;
                    this.element.removeAttr("role"), this.headers.removeAttr("role aria-expanded aria-selected aria-controls tabIndex").removeUniqueId(), this._destroyIcons(), t = this.headers.next().css("display", "").removeAttr("role aria-hidden aria-labelledby").removeUniqueId(), "content" !== this.options.heightStyle && t.css("height", "")
                },
                _setOption: function(t, e) {
                    return "active" === t ? void this._activate(e) : ("event" === t && (this.options.event && this._off(this.headers, this.options.event), this._setupEvents(e)), this._super(t, e), "collapsible" !== t || e || !1 !== this.options.active || this._activate(0), void("icons" === t && (this._destroyIcons(), e && this._createIcons())))
                },
                _setOptionDisabled: function(t) {
                    this._super(t), this.element.attr("aria-disabled", t), this._toggleClass(null, "ui-state-disabled", !!t), this._toggleClass(this.headers.add(this.headers.next()), null, "ui-state-disabled", !!t)
                },
                _keydown: function(t) {
                    if (!t.altKey && !t.ctrlKey) {
                        var e = i.ui.keyCode,
                            n = this.headers.length,
                            s = this.headers.index(t.target),
                            r = !1;
                        switch (t.keyCode) {
                            case e.RIGHT:
                            case e.DOWN:
                                r = this.headers[(s + 1) % n];
                                break;
                            case e.LEFT:
                            case e.UP:
                                r = this.headers[(s - 1 + n) % n];
                                break;
                            case e.SPACE:
                            case e.ENTER:
                                this._eventHandler(t);
                                break;
                            case e.HOME:
                                r = this.headers[0];
                                break;
                            case e.END:
                                r = this.headers[n - 1]
                        }
                        r && (i(t.target).attr("tabIndex", -1), i(r).attr("tabIndex", 0), i(r).trigger("focus"), t.preventDefault())
                    }
                },
                _panelKeyDown: function(t) {
                    t.keyCode === i.ui.keyCode.UP && t.ctrlKey && i(t.currentTarget).prev().trigger("focus")
                },
                refresh: function() {
                    var t = this.options;
                    this._processPanels(), !1 === t.active && !0 === t.collapsible || !this.headers.length ? (t.active = !1, this.active = i()) : !1 === t.active ? this._activate(0) : this.active.length && !i.contains(this.element[0], this.active[0]) ? this.headers.length === this.headers.find(".ui-state-disabled").length ? (t.active = !1, this.active = i()) : this._activate(Math.max(0, t.active - 1)) : t.active = this.headers.index(this.active), this._destroyIcons(), this._refresh()
                },
                _processPanels: function() {
                    var t = this.headers,
                        e = this.panels;
                    this.headers = this.element.find(this.options.header), this._addClass(this.headers, "ui-accordion-header ui-accordion-header-collapsed", "ui-state-default"), this.panels = this.headers.next().filter(":not(.ui-accordion-content-active)").hide(), this._addClass(this.panels, "ui-accordion-content", "ui-helper-reset ui-widget-content"), e && (this._off(t.not(this.headers)), this._off(e.not(this.panels)))
                },
                _refresh: function() {
                    var t, e = this.options,
                        n = e.heightStyle,
                        s = this.element.parent();
                    this.active = this._findActive(e.active), this._addClass(this.active, "ui-accordion-header-active", "ui-state-active")._removeClass(this.active, "ui-accordion-header-collapsed"), this._addClass(this.active.next(), "ui-accordion-content-active"), this.active.next().show(), this.headers.attr("role", "tab").each(function() {
                        var r = i(this),
                            l = r.uniqueId().attr("id"),
                            d = r.next(),
                            g = d.uniqueId().attr("id");
                        r.attr("aria-controls", g), d.attr("aria-labelledby", l)
                    }).next().attr("role", "tabpanel"), this.headers.not(this.active).attr({
                        "aria-selected": "false",
                        "aria-expanded": "false",
                        tabIndex: -1
                    }).next().attr({
                        "aria-hidden": "true"
                    }).hide(), this.active.length ? this.active.attr({
                        "aria-selected": "true",
                        "aria-expanded": "true",
                        tabIndex: 0
                    }).next().attr({
                        "aria-hidden": "false"
                    }) : this.headers.eq(0).attr("tabIndex", 0), this._createIcons(), this._setupEvents(e.event), "fill" === n ? (t = s.height(), this.element.siblings(":visible").each(function() {
                        var r = i(this),
                            l = r.css("position");
                        "absolute" !== l && "fixed" !== l && (t -= r.outerHeight(!0))
                    }), this.headers.each(function() {
                        t -= i(this).outerHeight(!0)
                    }), this.headers.next().each(function() {
                        i(this).height(Math.max(0, t - i(this).innerHeight() + i(this).height()))
                    }).css("overflow", "auto")) : "auto" === n && (t = 0, this.headers.next().each(function() {
                        var r = i(this).is(":visible");
                        r || i(this).show(), t = Math.max(t, i(this).css("height", "").height()), r || i(this).hide()
                    }).height(t))
                },
                _activate: function(t) {
                    var e = this._findActive(t)[0];
                    e !== this.active[0] && this._eventHandler({
                        target: e = e || this.active[0],
                        currentTarget: e,
                        preventDefault: i.noop
                    })
                },
                _findActive: function(t) {
                    return "number" == typeof t ? this.headers.eq(t) : i()
                },
                _setupEvents: function(t) {
                    var e = {
                        keydown: "_keydown"
                    };
                    t && i.each(t.split(" "), function(n, s) {
                        e[s] = "_eventHandler"
                    }), this._off(this.headers.add(this.headers.next())), this._on(this.headers, e), this._on(this.headers.next(), {
                        keydown: "_panelKeyDown"
                    }), this._hoverable(this.headers), this._focusable(this.headers)
                },
                _eventHandler: function(t) {
                    var e, n, s = this.options,
                        r = this.active,
                        l = i(t.currentTarget),
                        d = l[0] === r[0],
                        g = d && s.collapsible,
                        k = g ? i() : l.next(),
                        D = r.next(),
                        I = {
                            oldHeader: r,
                            oldPanel: D,
                            newHeader: g ? i() : l,
                            newPanel: k
                        };
                    t.preventDefault(), d && !s.collapsible || !1 === this._trigger("beforeActivate", t, I) || (s.active = !g && this.headers.index(l), this.active = d ? i() : l, this._toggle(I), this._removeClass(r, "ui-accordion-header-active", "ui-state-active"), s.icons && (e = r.children(".ui-accordion-header-icon"), this._removeClass(e, null, s.icons.activeHeader)._addClass(e, null, s.icons.header)), d || (this._removeClass(l, "ui-accordion-header-collapsed")._addClass(l, "ui-accordion-header-active", "ui-state-active"), s.icons && (n = l.children(".ui-accordion-header-icon"), this._removeClass(n, null, s.icons.header)._addClass(n, null, s.icons.activeHeader)), this._addClass(l.next(), "ui-accordion-content-active")))
                },
                _toggle: function(t) {
                    var e = t.newPanel,
                        n = this.prevShow.length ? this.prevShow : t.oldPanel;
                    this.prevShow.add(this.prevHide).stop(!0, !0), this.prevShow = e, this.prevHide = n, this.options.animate ? this._animate(e, n, t) : (n.hide(), e.show(), this._toggleComplete(t)), n.attr({
                        "aria-hidden": "true"
                    }), n.prev().attr({
                        "aria-selected": "false",
                        "aria-expanded": "false"
                    }), e.length && n.length ? n.prev().attr({
                        tabIndex: -1,
                        "aria-expanded": "false"
                    }) : e.length && this.headers.filter(function() {
                        return 0 === parseInt(i(this).attr("tabIndex"), 10)
                    }).attr("tabIndex", -1), e.attr("aria-hidden", "false").prev().attr({
                        "aria-selected": "true",
                        "aria-expanded": "true",
                        tabIndex: 0
                    })
                },
                _animate: function(t, e, n) {
                    var s, r, l, d = this,
                        g = 0,
                        k = t.css("box-sizing"),
                        D = t.length && (!e.length || t.index() < e.index()),
                        I = this.options.animate || {},
                        R = D && I.down || I,
                        P = function() {
                            d._toggleComplete(n)
                        };
                    return "number" == typeof R && (l = R), "string" == typeof R && (r = R), r = r || R.easing || I.easing, l = l || R.duration || I.duration, e.length ? t.length ? (s = t.show().outerHeight(), e.animate(this.hideProps, {
                        duration: l,
                        easing: r,
                        step: function(H, F) {
                            F.now = Math.round(H)
                        }
                    }), void t.hide().animate(this.showProps, {
                        duration: l,
                        easing: r,
                        complete: P,
                        step: function(H, F) {
                            F.now = Math.round(H), "height" !== F.prop ? "content-box" === k && (g += F.now) : "content" !== d.options.heightStyle && (F.now = Math.round(s - e.outerHeight() - g), g = 0)
                        }
                    })) : e.animate(this.hideProps, l, r, P) : t.animate(this.showProps, l, r, P)
                },
                _toggleComplete: function(t) {
                    var e = t.oldPanel,
                        n = e.prev();
                    this._removeClass(e, "ui-accordion-content-active"), this._removeClass(n, "ui-accordion-header-active")._addClass(n, "ui-accordion-header-collapsed"), e.length && (e.parent()[0].className = e.parent()[0].className), this._trigger("activate", null, t)
                }
            }), i.ui.safeActiveElement = function(t) {
                var e;
                try {
                    e = t.activeElement
                } catch (n) {
                    e = t.body
                }
                return e || (e = t.body), e.nodeName || (e = t.body), e
            }, i.widget("ui.menu", {
                version: "1.12.1",
                defaultElement: "<ul>",
                delay: 300,
                options: {
                    icons: {
                        submenu: "ui-icon-caret-1-e"
                    },
                    items: "> *",
                    menus: "ul",
                    position: {
                        my: "left top",
                        at: "right top"
                    },
                    role: "menu",
                    blur: null,
                    focus: null,
                    select: null
                },
                _create: function() {
                    this.activeMenu = this.element, this.mouseHandled = !1, this.element.uniqueId().attr({
                        role: this.options.role,
                        tabIndex: 0
                    }), this._addClass("ui-menu", "ui-widget ui-widget-content"), this._on({
                        "mousedown .ui-menu-item": function(t) {
                            t.preventDefault()
                        },
                        "click .ui-menu-item": function(t) {
                            var e = i(t.target),
                                n = i(i.ui.safeActiveElement(this.document[0]));
                            !this.mouseHandled && e.not(".ui-state-disabled").length && (this.select(t), t.isPropagationStopped() || (this.mouseHandled = !0), e.has(".ui-menu").length ? this.expand(t) : !this.element.is(":focus") && n.closest(".ui-menu").length && (this.element.trigger("focus", [!0]), this.active && 1 === this.active.parents(".ui-menu").length && clearTimeout(this.timer)))
                        },
                        "mouseenter .ui-menu-item": function(t) {
                            if (!this.previousFilter) {
                                var e = i(t.target).closest(".ui-menu-item"),
                                    n = i(t.currentTarget);
                                e[0] === n[0] && (this._removeClass(n.siblings().children(".ui-state-active"), null, "ui-state-active"), this.focus(t, n))
                            }
                        },
                        mouseleave: "collapseAll",
                        "mouseleave .ui-menu": "collapseAll",
                        focus: function(t, e) {
                            var n = this.active || this.element.find(this.options.items).eq(0);
                            e || this.focus(t, n)
                        },
                        blur: function(t) {
                            this._delay(function() {
                                !i.contains(this.element[0], i.ui.safeActiveElement(this.document[0])) && this.collapseAll(t)
                            })
                        },
                        keydown: "_keydown"
                    }), this.refresh(), this._on(this.document, {
                        click: function(t) {
                            this._closeOnDocumentClick(t) && this.collapseAll(t), this.mouseHandled = !1
                        }
                    })
                },
                _destroy: function() {
                    var e = this.element.find(".ui-menu-item").removeAttr("role aria-disabled").children(".ui-menu-item-wrapper").removeUniqueId().removeAttr("tabIndex role aria-haspopup");
                    this.element.removeAttr("aria-activedescendant").find(".ui-menu").addBack().removeAttr("role aria-labelledby aria-expanded aria-hidden aria-disabled tabIndex").removeUniqueId().show(), e.children().each(function() {
                        var n = i(this);
                        n.data("ui-menu-submenu-caret") && n.remove()
                    })
                },
                _keydown: function(t) {
                    var e, n, s, r, l = !0;
                    switch (t.keyCode) {
                        case i.ui.keyCode.PAGE_UP:
                            this.previousPage(t);
                            break;
                        case i.ui.keyCode.PAGE_DOWN:
                            this.nextPage(t);
                            break;
                        case i.ui.keyCode.HOME:
                            this._move("first", "first", t);
                            break;
                        case i.ui.keyCode.END:
                            this._move("last", "last", t);
                            break;
                        case i.ui.keyCode.UP:
                            this.previous(t);
                            break;
                        case i.ui.keyCode.DOWN:
                            this.next(t);
                            break;
                        case i.ui.keyCode.LEFT:
                            this.collapse(t);
                            break;
                        case i.ui.keyCode.RIGHT:
                            this.active && !this.active.is(".ui-state-disabled") && this.expand(t);
                            break;
                        case i.ui.keyCode.ENTER:
                        case i.ui.keyCode.SPACE:
                            this._activate(t);
                            break;
                        case i.ui.keyCode.ESCAPE:
                            this.collapse(t);
                            break;
                        default:
                            l = !1, n = this.previousFilter || "", r = !1, s = t.keyCode >= 96 && 105 >= t.keyCode ? "" + (t.keyCode - 96) : String.fromCharCode(t.keyCode), clearTimeout(this.filterTimer), s === n ? r = !0 : s = n + s, e = this._filterMenuItems(s), (e = r && -1 !== e.index(this.active.next()) ? this.active.nextAll(".ui-menu-item") : e).length || (s = String.fromCharCode(t.keyCode), e = this._filterMenuItems(s)), e.length ? (this.focus(t, e), this.previousFilter = s, this.filterTimer = this._delay(function() {
                                delete this.previousFilter
                            }, 1e3)) : delete this.previousFilter
                    }
                    l && t.preventDefault()
                },
                _activate: function(t) {
                    this.active && !this.active.is(".ui-state-disabled") && (this.active.children("[aria-haspopup='true']").length ? this.expand(t) : this.select(t))
                },
                refresh: function() {
                    var e, n, s, r, l = this,
                        d = this.options.icons.submenu,
                        g = this.element.find(this.options.menus);
                    this._toggleClass("ui-menu-icons", null, !!this.element.find(".ui-icon").length), n = g.filter(":not(.ui-menu)").hide().attr({
                        role: this.options.role,
                        "aria-hidden": "true",
                        "aria-expanded": "false"
                    }).each(function() {
                        var k = i(this),
                            D = k.prev(),
                            I = i("<span>").data("ui-menu-submenu-caret", !0);
                        l._addClass(I, "ui-menu-icon", "ui-icon " + d), D.attr("aria-haspopup", "true").prepend(I), k.attr("aria-labelledby", D.attr("id"))
                    }), this._addClass(n, "ui-menu", "ui-widget ui-widget-content ui-front"), (e = g.add(this.element).find(this.options.items)).not(".ui-menu-item").each(function() {
                        var k = i(this);
                        l._isDivider(k) && l._addClass(k, "ui-menu-divider", "ui-widget-content")
                    }), r = (s = e.not(".ui-menu-item, .ui-menu-divider")).children().not(".ui-menu").uniqueId().attr({
                        tabIndex: -1,
                        role: this._itemRole()
                    }), this._addClass(s, "ui-menu-item")._addClass(r, "ui-menu-item-wrapper"), e.filter(".ui-state-disabled").attr("aria-disabled", "true"), this.active && !i.contains(this.element[0], this.active[0]) && this.blur()
                },
                _itemRole: function() {
                    return {
                        menu: "menuitem",
                        listbox: "option"
                    }[this.options.role]
                },
                _setOption: function(t, e) {
                    if ("icons" === t) {
                        var n = this.element.find(".ui-menu-icon");
                        this._removeClass(n, null, this.options.icons.submenu)._addClass(n, null, e.submenu)
                    }
                    this._super(t, e)
                },
                _setOptionDisabled: function(t) {
                    this._super(t), this.element.attr("aria-disabled", t + ""), this._toggleClass(null, "ui-state-disabled", !!t)
                },
                focus: function(t, e) {
                    var n, s, r;
                    this.blur(t, t && "focus" === t.type), this._scrollIntoView(e), this.active = e.first(), s = this.active.children(".ui-menu-item-wrapper"), this._addClass(s, null, "ui-state-active"), this.options.role && this.element.attr("aria-activedescendant", s.attr("id")), r = this.active.parent().closest(".ui-menu-item").children(".ui-menu-item-wrapper"), this._addClass(r, null, "ui-state-active"), t && "keydown" === t.type ? this._close() : this.timer = this._delay(function() {
                        this._close()
                    }, this.delay), (n = e.children(".ui-menu")).length && t && /^mouse/.test(t.type) && this._startOpening(n), this.activeMenu = e.parent(), this._trigger("focus", t, {
                        item: e
                    })
                },
                _scrollIntoView: function(t) {
                    var e, n, s, r, l, d;
                    this._hasScroll() && (e = parseFloat(i.css(this.activeMenu[0], "borderTopWidth")) || 0, n = parseFloat(i.css(this.activeMenu[0], "paddingTop")) || 0, s = t.offset().top - this.activeMenu.offset().top - e - n, r = this.activeMenu.scrollTop(), l = this.activeMenu.height(), d = t.outerHeight(), 0 > s ? this.activeMenu.scrollTop(r + s) : s + d > l && this.activeMenu.scrollTop(r + s - l + d))
                },
                blur: function(t, e) {
                    e || clearTimeout(this.timer), this.active && (this._removeClass(this.active.children(".ui-menu-item-wrapper"), null, "ui-state-active"), this._trigger("blur", t, {
                        item: this.active
                    }), this.active = null)
                },
                _startOpening: function(t) {
                    clearTimeout(this.timer), "true" === t.attr("aria-hidden") && (this.timer = this._delay(function() {
                        this._close(), this._open(t)
                    }, this.delay))
                },
                _open: function(t) {
                    var e = i.extend({ of: this.active
                    }, this.options.position);
                    clearTimeout(this.timer), this.element.find(".ui-menu").not(t.parents(".ui-menu")).hide().attr("aria-hidden", "true"), t.show().removeAttr("aria-hidden").attr("aria-expanded", "true").position(e)
                },
                collapseAll: function(t, e) {
                    clearTimeout(this.timer), this.timer = this._delay(function() {
                        var n = e ? this.element : i(t && t.target).closest(this.element.find(".ui-menu"));
                        n.length || (n = this.element), this._close(n), this.blur(t), this._removeClass(n.find(".ui-state-active"), null, "ui-state-active"), this.activeMenu = n
                    }, this.delay)
                },
                _close: function(t) {
                    t || (t = this.active ? this.active.parent() : this.element), t.find(".ui-menu").hide().attr("aria-hidden", "true").attr("aria-expanded", "false")
                },
                _closeOnDocumentClick: function(t) {
                    return !i(t.target).closest(".ui-menu").length
                },
                _isDivider: function(t) {
                    return !/[^\-\u2014\u2013\s]/.test(t.text())
                },
                collapse: function(t) {
                    var e = this.active && this.active.parent().closest(".ui-menu-item", this.element);
                    e && e.length && (this._close(), this.focus(t, e))
                },
                expand: function(t) {
                    var e = this.active && this.active.children(".ui-menu ").find(this.options.items).first();
                    e && e.length && (this._open(e.parent()), this._delay(function() {
                        this.focus(t, e)
                    }))
                },
                next: function(t) {
                    this._move("next", "first", t)
                },
                previous: function(t) {
                    this._move("prev", "last", t)
                },
                isFirstItem: function() {
                    return this.active && !this.active.prevAll(".ui-menu-item").length
                },
                isLastItem: function() {
                    return this.active && !this.active.nextAll(".ui-menu-item").length
                },
                _move: function(t, e, n) {
                    var s;
                    this.active && (s = "first" === t || "last" === t ? this.active["first" === t ? "prevAll" : "nextAll"](".ui-menu-item").eq(-1) : this.active[t + "All"](".ui-menu-item").eq(0)), s && s.length && this.active || (s = this.activeMenu.find(this.options.items)[e]()), this.focus(n, s)
                },
                nextPage: function(t) {
                    var e, n, s;
                    return this.active ? void(this.isLastItem() || (this._hasScroll() ? (n = this.active.offset().top, s = this.element.height(), this.active.nextAll(".ui-menu-item").each(function() {
                        return 0 > (e = i(this)).offset().top - n - s
                    }), this.focus(t, e)) : this.focus(t, this.activeMenu.find(this.options.items)[this.active ? "last" : "first"]()))) : void this.next(t)
                },
                previousPage: function(t) {
                    var e, n, s;
                    return this.active ? void(this.isFirstItem() || (this._hasScroll() ? (n = this.active.offset().top, s = this.element.height(), this.active.prevAll(".ui-menu-item").each(function() {
                        return (e = i(this)).offset().top - n + s > 0
                    }), this.focus(t, e)) : this.focus(t, this.activeMenu.find(this.options.items).first()))) : void this.next(t)
                },
                _hasScroll: function() {
                    return this.element.outerHeight() < this.element.prop("scrollHeight")
                },
                select: function(t) {
                    this.active = this.active || i(t.target).closest(".ui-menu-item");
                    var e = {
                        item: this.active
                    };
                    this.active.has(".ui-menu").length || this.collapseAll(t, !0), this._trigger("select", t, e)
                },
                _filterMenuItems: function(t) {
                    var e = t.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, "\\$&"),
                        n = RegExp("^" + e, "i");
                    return this.activeMenu.find(this.options.items).filter(".ui-menu-item").filter(function() {
                        return n.test(i.trim(i(this).children(".ui-menu-item-wrapper").text()))
                    })
                }
            }), i.widget("ui.autocomplete", {
                version: "1.12.1",
                defaultElement: "<input>",
                options: {
                    appendTo: null,
                    autoFocus: !1,
                    delay: 300,
                    minLength: 1,
                    position: {
                        my: "left top",
                        at: "left bottom",
                        collision: "none"
                    },
                    source: null,
                    change: null,
                    close: null,
                    focus: null,
                    open: null,
                    response: null,
                    search: null,
                    select: null
                },
                requestIndex: 0,
                pending: 0,
                _create: function() {
                    var t, e, n, s = this.element[0].nodeName.toLowerCase(),
                        r = "textarea" === s,
                        l = "input" === s;
                    this.isMultiLine = r || !l && this._isContentEditable(this.element), this.valueMethod = this.element[r || l ? "val" : "text"], this.isNewMenu = !0, this._addClass("ui-autocomplete-input"), this.element.attr("autocomplete", "off"), this._on(this.element, {
                        keydown: function(d) {
                            if (this.element.prop("readOnly")) return t = !0, n = !0, void(e = !0);
                            t = !1, n = !1, e = !1;
                            var g = i.ui.keyCode;
                            switch (d.keyCode) {
                                case g.PAGE_UP:
                                    t = !0, this._move("previousPage", d);
                                    break;
                                case g.PAGE_DOWN:
                                    t = !0, this._move("nextPage", d);
                                    break;
                                case g.UP:
                                    t = !0, this._keyEvent("previous", d);
                                    break;
                                case g.DOWN:
                                    t = !0, this._keyEvent("next", d);
                                    break;
                                case g.ENTER:
                                    this.menu.active && (t = !0, d.preventDefault(), this.menu.select(d));
                                    break;
                                case g.TAB:
                                    this.menu.active && this.menu.select(d);
                                    break;
                                case g.ESCAPE:
                                    this.menu.element.is(":visible") && (this.isMultiLine || this._value(this.term), this.close(d), d.preventDefault());
                                    break;
                                default:
                                    e = !0, this._searchTimeout(d)
                            }
                        },
                        keypress: function(d) {
                            if (t) return t = !1, void((!this.isMultiLine || this.menu.element.is(":visible")) && d.preventDefault());
                            if (!e) {
                                var g = i.ui.keyCode;
                                switch (d.keyCode) {
                                    case g.PAGE_UP:
                                        this._move("previousPage", d);
                                        break;
                                    case g.PAGE_DOWN:
                                        this._move("nextPage", d);
                                        break;
                                    case g.UP:
                                        this._keyEvent("previous", d);
                                        break;
                                    case g.DOWN:
                                        this._keyEvent("next", d)
                                }
                            }
                        },
                        input: function(d) {
                            return n ? (n = !1, void d.preventDefault()) : void this._searchTimeout(d)
                        },
                        focus: function() {
                            this.selectedItem = null, this.previous = this._value()
                        },
                        blur: function(d) {
                            return this.cancelBlur ? void delete this.cancelBlur : (clearTimeout(this.searching), this.close(d), void this._change(d))
                        }
                    }), this._initSource(), this.menu = i("<ul>").appendTo(this._appendTo()).menu({
                        role: null
                    }).hide().menu("instance"), this._addClass(this.menu.element, "ui-autocomplete", "ui-front"), this._on(this.menu.element, {
                        mousedown: function(d) {
                            d.preventDefault(), this.cancelBlur = !0, this._delay(function() {
                                delete this.cancelBlur, this.element[0] !== i.ui.safeActiveElement(this.document[0]) && this.element.trigger("focus")
                            })
                        },
                        menufocus: function(d, g) {
                            var k, D;
                            return this.isNewMenu && (this.isNewMenu = !1, d.originalEvent && /^mouse/.test(d.originalEvent.type)) ? (this.menu.blur(), void this.document.one("mousemove", function() {
                                i(d.target).trigger(d.originalEvent)
                            })) : (D = g.item.data("ui-autocomplete-item"), !1 !== this._trigger("focus", d, {
                                item: D
                            }) && d.originalEvent && /^key/.test(d.originalEvent.type) && this._value(D.value), void((k = g.item.attr("aria-label") || D.value) && i.trim(k).length && (this.liveRegion.children().hide(), i("<div>").text(k).appendTo(this.liveRegion))))
                        },
                        menuselect: function(d, g) {
                            var k = g.item.data("ui-autocomplete-item"),
                                D = this.previous;
                            this.element[0] !== i.ui.safeActiveElement(this.document[0]) && (this.element.trigger("focus"), this.previous = D, this._delay(function() {
                                this.previous = D, this.selectedItem = k
                            })), !1 !== this._trigger("select", d, {
                                item: k
                            }) && this._value(k.value), this.term = this._value(), this.close(d), this.selectedItem = k
                        }
                    }), this.liveRegion = i("<div>", {
                        role: "status",
                        "aria-live": "assertive",
                        "aria-relevant": "additions"
                    }).appendTo(this.document[0].body), this._addClass(this.liveRegion, null, "ui-helper-hidden-accessible"), this._on(this.window, {
                        beforeunload: function() {
                            this.element.removeAttr("autocomplete")
                        }
                    })
                },
                _destroy: function() {
                    clearTimeout(this.searching), this.element.removeAttr("autocomplete"), this.menu.element.remove(), this.liveRegion.remove()
                },
                _setOption: function(t, e) {
                    this._super(t, e), "source" === t && this._initSource(), "appendTo" === t && this.menu.element.appendTo(this._appendTo()), "disabled" === t && e && this.xhr && this.xhr.abort()
                },
                _isEventTargetInWidget: function(t) {
                    var e = this.menu.element[0];
                    return t.target === this.element[0] || t.target === e || i.contains(e, t.target)
                },
                _closeOnClickOutside: function(t) {
                    this._isEventTargetInWidget(t) || this.close()
                },
                _appendTo: function() {
                    var t = this.options.appendTo;
                    return t && (t = t.jquery || t.nodeType ? i(t) : this.document.find(t).eq(0)), t && t[0] || (t = this.element.closest(".ui-front, dialog")), t.length || (t = this.document[0].body), t
                },
                _initSource: function() {
                    var t, e, n = this;
                    i.isArray(this.options.source) ? (t = this.options.source, this.source = function(s, r) {
                        r(i.ui.autocomplete.filter(t, s.term))
                    }) : "string" == typeof this.options.source ? (e = this.options.source, this.source = function(s, r) {
                        n.xhr && n.xhr.abort(), n.xhr = i.ajax({
                            url: e,
                            data: s,
                            dataType: "json",
                            success: function(l) {
                                r(l)
                            },
                            error: function() {
                                r([])
                            }
                        })
                    }) : this.source = this.options.source
                },
                _searchTimeout: function(t) {
                    clearTimeout(this.searching), this.searching = this._delay(function() {
                        var e = this.term === this._value(),
                            n = this.menu.element.is(":visible");
                        (!e || e && !n && !(t.altKey || t.ctrlKey || t.metaKey || t.shiftKey)) && (this.selectedItem = null, this.search(null, t))
                    }, this.options.delay)
                },
                search: function(t, e) {
                    return t = null != t ? t : this._value(), this.term = this._value(), t.length < this.options.minLength ? this.close(e) : !1 !== this._trigger("search", e) ? this._search(t) : void 0
                },
                _search: function(t) {
                    this.pending++, this._addClass("ui-autocomplete-loading"), this.cancelSearch = !1, this.source({
                        term: t
                    }, this._response())
                },
                _response: function() {
                    var t = ++this.requestIndex;
                    return i.proxy(function(e) {
                        t === this.requestIndex && this.__response(e), this.pending--, this.pending || this._removeClass("ui-autocomplete-loading")
                    }, this)
                },
                __response: function(t) {
                    t && (t = this._normalize(t)), this._trigger("response", null, {
                        content: t
                    }), !this.options.disabled && t && t.length && !this.cancelSearch ? (this._suggest(t), this._trigger("open")) : this._close()
                },
                close: function(t) {
                    this.cancelSearch = !0, this._close(t)
                },
                _close: function(t) {
                    this._off(this.document, "mousedown"), this.menu.element.is(":visible") && (this.menu.element.hide(), this.menu.blur(), this.isNewMenu = !0, this._trigger("close", t))
                },
                _change: function(t) {
                    this.previous !== this._value() && this._trigger("change", t, {
                        item: this.selectedItem
                    })
                },
                _normalize: function(t) {
                    return t.length && t[0].label && t[0].value ? t : i.map(t, function(e) {
                        return "string" == typeof e ? {
                            label: e,
                            value: e
                        } : i.extend({}, e, {
                            label: e.label || e.value,
                            value: e.value || e.label
                        })
                    })
                },
                _suggest: function(t) {
                    var e = this.menu.element.empty();
                    this._renderMenu(e, t), this.isNewMenu = !0, this.menu.refresh(), e.show(), this._resizeMenu(), e.position(i.extend({ of: this.element
                    }, this.options.position)), this.options.autoFocus && this.menu.next(), this._on(this.document, {
                        mousedown: "_closeOnClickOutside"
                    })
                },
                _resizeMenu: function() {
                    var t = this.menu.element;
                    t.outerWidth(Math.max(t.width("").outerWidth() + 1, this.element.outerWidth()))
                },
                _renderMenu: function(t, e) {
                    var n = this;
                    i.each(e, function(s, r) {
                        n._renderItemData(t, r)
                    })
                },
                _renderItemData: function(t, e) {
                    return this._renderItem(t, e).data("ui-autocomplete-item", e)
                },
                _renderItem: function(t, e) {
                    return i("<li>").append(i("<div>").text(e.label)).appendTo(t)
                },
                _move: function(t, e) {
                    return this.menu.element.is(":visible") ? this.menu.isFirstItem() && /^previous/.test(t) || this.menu.isLastItem() && /^next/.test(t) ? (this.isMultiLine || this._value(this.term), void this.menu.blur()) : void this.menu[t](e) : void this.search(null, e)
                },
                widget: function() {
                    return this.menu.element
                },
                _value: function() {
                    return this.valueMethod.apply(this.element, arguments)
                },
                _keyEvent: function(t, e) {
                    (!this.isMultiLine || this.menu.element.is(":visible")) && (this._move(t, e), e.preventDefault())
                },
                _isContentEditable: function(t) {
                    if (!t.length) return !1;
                    var e = t.prop("contentEditable");
                    return "inherit" === e ? this._isContentEditable(t.parent()) : "true" === e
                }
            }), i.extend(i.ui.autocomplete, {
                escapeRegex: function(t) {
                    return t.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, "\\$&")
                },
                filter: function(t, e) {
                    var n = RegExp(i.ui.autocomplete.escapeRegex(e), "i");
                    return i.grep(t, function(s) {
                        return n.test(s.label || s.value || s)
                    })
                }
            }), i.widget("ui.autocomplete", i.ui.autocomplete, {
                options: {
                    messages: {
                        noResults: "No search results.",
                        results: function(t) {
                            return t + (t > 1 ? " results are" : " result is") + " available, use up and down arrow keys to navigate."
                        }
                    }
                },
                __response: function(t) {
                    var e;
                    this._superApply(arguments), this.options.disabled || this.cancelSearch || (e = t && t.length ? this.options.messages.results(t.length) : this.options.messages.noResults, this.liveRegion.children().hide(), i("<div>").text(e).appendTo(this.liveRegion))
                }
            });
        var st, Y = /ui-corner-([a-z]){2,6}/g;
        i.widget("ui.controlgroup", {
            version: "1.12.1",
            defaultElement: "<div>",
            options: {
                direction: "horizontal",
                disabled: null,
                onlyVisible: !0,
                items: {
                    button: "input[type=button], input[type=submit], input[type=reset], button, a",
                    controlgroupLabel: ".ui-controlgroup-label",
                    checkboxradio: "input[type='checkbox'], input[type='radio']",
                    selectmenu: "select",
                    spinner: ".ui-spinner-input"
                }
            },
            _create: function() {
                this._enhance()
            },
            _enhance: function() {
                this.element.attr("role", "toolbar"), this.refresh()
            },
            _destroy: function() {
                this._callChildMethod("destroy"), this.childWidgets.removeData("ui-controlgroup-data"), this.element.removeAttr("role"), this.options.items.controlgroupLabel && this.element.find(this.options.items.controlgroupLabel).find(".ui-controlgroup-label-contents").contents().unwrap()
            },
            _initWidgets: function() {
                var t = this,
                    e = [];
                i.each(this.options.items, function(n, s) {
                    var r, l = {};
                    return s ? "controlgroupLabel" === n ? ((r = t.element.find(s)).each(function() {
                        var d = i(this);
                        d.children(".ui-controlgroup-label-contents").length || d.contents().wrapAll("<span class='ui-controlgroup-label-contents'></span>")
                    }), t._addClass(r, null, "ui-widget ui-widget-content ui-state-default"), void(e = e.concat(r.get()))) : void(i.fn[n] && (l = t["_" + n + "Options"] ? t["_" + n + "Options"]("middle") : {
                        classes: {}
                    }, t.element.find(s).each(function() {
                        var d = i(this),
                            g = d[n]("instance"),
                            k = i.widget.extend({}, l);
                        if ("button" !== n || !d.parent(".ui-spinner").length) {
                            g || (g = d[n]()[n]("instance")), g && (k.classes = t._resolveClassesValues(k.classes, g)), d[n](k);
                            var D = d[n]("widget");
                            i.data(D[0], "ui-controlgroup-data", g || d[n]("instance")), e.push(D[0])
                        }
                    }))) : void 0
                }), this.childWidgets = i(i.unique(e)), this._addClass(this.childWidgets, "ui-controlgroup-item")
            },
            _callChildMethod: function(t) {
                this.childWidgets.each(function() {
                    var n = i(this).data("ui-controlgroup-data");
                    n && n[t] && n[t]()
                })
            },
            _updateCornerClass: function(t, e) {
                var s = this._buildSimpleOptions(e, "label").classes.label;
                this._removeClass(t, null, "ui-corner-top ui-corner-bottom ui-corner-left ui-corner-right ui-corner-all"), this._addClass(t, null, s)
            },
            _buildSimpleOptions: function(t, e) {
                var n = "vertical" === this.options.direction,
                    s = {
                        classes: {}
                    };
                return s.classes[e] = {
                    middle: "",
                    first: "ui-corner-" + (n ? "top" : "left"),
                    last: "ui-corner-" + (n ? "bottom" : "right"),
                    only: "ui-corner-all"
                }[t], s
            },
            _spinnerOptions: function(t) {
                var e = this._buildSimpleOptions(t, "ui-spinner");
                return e.classes["ui-spinner-up"] = "", e.classes["ui-spinner-down"] = "", e
            },
            _buttonOptions: function(t) {
                return this._buildSimpleOptions(t, "ui-button")
            },
            _checkboxradioOptions: function(t) {
                return this._buildSimpleOptions(t, "ui-checkboxradio-label")
            },
            _selectmenuOptions: function(t) {
                var e = "vertical" === this.options.direction;
                return {
                    width: !!e && "auto",
                    classes: {
                        middle: {
                            "ui-selectmenu-button-open": "",
                            "ui-selectmenu-button-closed": ""
                        },
                        first: {
                            "ui-selectmenu-button-open": "ui-corner-" + (e ? "top" : "tl"),
                            "ui-selectmenu-button-closed": "ui-corner-" + (e ? "top" : "left")
                        },
                        last: {
                            "ui-selectmenu-button-open": e ? "" : "ui-corner-tr",
                            "ui-selectmenu-button-closed": "ui-corner-" + (e ? "bottom" : "right")
                        },
                        only: {
                            "ui-selectmenu-button-open": "ui-corner-top",
                            "ui-selectmenu-button-closed": "ui-corner-all"
                        }
                    }[t]
                }
            },
            _resolveClassesValues: function(t, e) {
                var n = {};
                return i.each(t, function(s) {
                    var r = e.options.classes[s] || "";
                    r = i.trim(r.replace(Y, "")), n[s] = (r + " " + t[s]).replace(/\s+/g, " ")
                }), n
            },
            _setOption: function(t, e) {
                return "direction" === t && this._removeClass("ui-controlgroup-" + this.options.direction), this._super(t, e), "disabled" === t ? void this._callChildMethod(e ? "disable" : "enable") : void this.refresh()
            },
            refresh: function() {
                var t, e = this;
                this._addClass("ui-controlgroup ui-controlgroup-" + this.options.direction), "horizontal" === this.options.direction && this._addClass(null, "ui-helper-clearfix"), this._initWidgets(), t = this.childWidgets, this.options.onlyVisible && (t = t.filter(":visible")), t.length && (i.each(["first", "last"], function(n, s) {
                    var r = t[s]().data("ui-controlgroup-data");
                    if (r && e["_" + r.widgetName + "Options"]) {
                        var l = e["_" + r.widgetName + "Options"](1 === t.length ? "only" : s);
                        l.classes = e._resolveClassesValues(l.classes, r), r.element[r.widgetName](l)
                    } else e._updateCornerClass(t[s](), s)
                }), this._callChildMethod("refresh"))
            }
        }), i.widget("ui.checkboxradio", [i.ui.formResetMixin, {
            version: "1.12.1",
            options: {
                disabled: null,
                label: null,
                icon: !0,
                classes: {
                    "ui-checkboxradio-label": "ui-corner-all",
                    "ui-checkboxradio-icon": "ui-corner-all"
                }
            },
            _getCreateOptions: function() {
                var t, e, n = this,
                    s = this._super() || {};
                return this._readType(), e = this.element.labels(), this.label = i(e[e.length - 1]), this.label.length || i.error("No label found for checkboxradio widget"), this.originalLabel = "", this.label.contents().not(this.element[0]).each(function() {
                    n.originalLabel += 3 === this.nodeType ? i(this).text() : this.outerHTML
                }), this.originalLabel && (s.label = this.originalLabel), null != (t = this.element[0].disabled) && (s.disabled = t), s
            },
            _create: function() {
                var t = this.element[0].checked;
                this._bindFormResetHandler(), null == this.options.disabled && (this.options.disabled = this.element[0].disabled), this._setOption("disabled", this.options.disabled), this._addClass("ui-checkboxradio", "ui-helper-hidden-accessible"), this._addClass(this.label, "ui-checkboxradio-label", "ui-button ui-widget"), "radio" === this.type && this._addClass(this.label, "ui-checkboxradio-radio-label"), this.options.label && this.options.label !== this.originalLabel ? this._updateLabel() : this.originalLabel && (this.options.label = this.originalLabel), this._enhance(), t && (this._addClass(this.label, "ui-checkboxradio-checked", "ui-state-active"), this.icon && this._addClass(this.icon, null, "ui-state-hover")), this._on({
                    change: "_toggleClasses",
                    focus: function() {
                        this._addClass(this.label, null, "ui-state-focus ui-visual-focus")
                    },
                    blur: function() {
                        this._removeClass(this.label, null, "ui-state-focus ui-visual-focus")
                    }
                })
            },
            _readType: function() {
                var t = this.element[0].nodeName.toLowerCase();
                this.type = this.element[0].type, "input" === t && /radio|checkbox/.test(this.type) || i.error("Can't create checkboxradio on element.nodeName=" + t + " and element.type=" + this.type)
            },
            _enhance: function() {
                this._updateIcon(this.element[0].checked)
            },
            widget: function() {
                return this.label
            },
            _getRadioGroup: function() {
                var e = this.element[0].name,
                    n = "input[name='" + i.ui.escapeSelector(e) + "']";
                return e ? (this.form.length ? i(this.form[0].elements).filter(n) : i(n).filter(function() {
                    return 0 === i(this).form().length
                })).not(this.element) : i([])
            },
            _toggleClasses: function() {
                var t = this.element[0].checked;
                this._toggleClass(this.label, "ui-checkboxradio-checked", "ui-state-active", t), this.options.icon && "checkbox" === this.type && this._toggleClass(this.icon, null, "ui-icon-check ui-state-checked", t)._toggleClass(this.icon, null, "ui-icon-blank", !t), "radio" === this.type && this._getRadioGroup().each(function() {
                    var e = i(this).checkboxradio("instance");
                    e && e._removeClass(e.label, "ui-checkboxradio-checked", "ui-state-active")
                })
            },
            _destroy: function() {
                this._unbindFormResetHandler(), this.icon && (this.icon.remove(), this.iconSpace.remove())
            },
            _setOption: function(t, e) {
                return "label" !== t || e ? (this._super(t, e), "disabled" === t ? (this._toggleClass(this.label, null, "ui-state-disabled", e), void(this.element[0].disabled = e)) : void this.refresh()) : void 0
            },
            _updateIcon: function(t) {
                var e = "ui-icon ui-icon-background ";
                this.options.icon ? (this.icon || (this.icon = i("<span>"), this.iconSpace = i("<span> </span>"), this._addClass(this.iconSpace, "ui-checkboxradio-icon-space")), "checkbox" === this.type ? (e += t ? "ui-icon-check ui-state-checked" : "ui-icon-blank", this._removeClass(this.icon, null, t ? "ui-icon-blank" : "ui-icon-check")) : e += "ui-icon-blank", this._addClass(this.icon, "ui-checkboxradio-icon", e), t || this._removeClass(this.icon, null, "ui-icon-check ui-state-checked"), this.icon.prependTo(this.label).after(this.iconSpace)) : void 0 !== this.icon && (this.icon.remove(), this.iconSpace.remove(), delete this.icon)
            },
            _updateLabel: function() {
                var t = this.label.contents().not(this.element[0]);
                this.icon && (t = t.not(this.icon[0])), this.iconSpace && (t = t.not(this.iconSpace[0])), t.remove(), this.label.append(this.options.label)
            },
            refresh: function() {
                var t = this.element[0].checked,
                    e = this.element[0].disabled;
                this._updateIcon(t), this._toggleClass(this.label, "ui-checkboxradio-checked", "ui-state-active", t), null !== this.options.label && this._updateLabel(), e !== this.options.disabled && this._setOptions({
                    disabled: e
                })
            }
        }]), i.widget("ui.button", {
            version: "1.12.1",
            defaultElement: "<button>",
            options: {
                classes: {
                    "ui-button": "ui-corner-all"
                },
                disabled: null,
                icon: null,
                iconPosition: "beginning",
                label: null,
                showLabel: !0
            },
            _getCreateOptions: function() {
                var t, e = this._super() || {};
                return this.isInput = this.element.is("input"), null != (t = this.element[0].disabled) && (e.disabled = t), this.originalLabel = this.isInput ? this.element.val() : this.element.html(), this.originalLabel && (e.label = this.originalLabel), e
            },
            _create: function() {
                !this.option.showLabel & !this.options.icon && (this.options.showLabel = !0), null == this.options.disabled && (this.options.disabled = this.element[0].disabled || !1), this.hasTitle = !!this.element.attr("title"), this.options.label && this.options.label !== this.originalLabel && (this.isInput ? this.element.val(this.options.label) : this.element.html(this.options.label)), this._addClass("ui-button", "ui-widget"), this._setOption("disabled", this.options.disabled), this._enhance(), this.element.is("a") && this._on({
                    keyup: function(t) {
                        t.keyCode === i.ui.keyCode.SPACE && (t.preventDefault(), this.element[0].click ? this.element[0].click() : this.element.trigger("click"))
                    }
                })
            },
            _enhance: function() {
                this.element.is("button") || this.element.attr("role", "button"), this.options.icon && (this._updateIcon("icon", this.options.icon), this._updateTooltip())
            },
            _updateTooltip: function() {
                this.title = this.element.attr("title"), this.options.showLabel || this.title || this.element.attr("title", this.options.label)
            },
            _updateIcon: function(t, e) {
                var n = "iconPosition" !== t,
                    s = n ? this.options.iconPosition : e,
                    r = "top" === s || "bottom" === s;
                this.icon ? n && this._removeClass(this.icon, null, this.options.icon) : (this.icon = i("<span>"), this._addClass(this.icon, "ui-button-icon", "ui-icon"), this.options.showLabel || this._addClass("ui-button-icon-only")), n && this._addClass(this.icon, null, e), this._attachIcon(s), r ? (this._addClass(this.icon, null, "ui-widget-icon-block"), this.iconSpace && this.iconSpace.remove()) : (this.iconSpace || (this.iconSpace = i("<span> </span>"), this._addClass(this.iconSpace, "ui-button-icon-space")), this._removeClass(this.icon, null, "ui-wiget-icon-block"), this._attachIconSpace(s))
            },
            _destroy: function() {
                this.element.removeAttr("role"), this.icon && this.icon.remove(), this.iconSpace && this.iconSpace.remove(), this.hasTitle || this.element.removeAttr("title")
            },
            _attachIconSpace: function(t) {
                this.icon[/^(?:end|bottom)/.test(t) ? "before" : "after"](this.iconSpace)
            },
            _attachIcon: function(t) {
                this.element[/^(?:end|bottom)/.test(t) ? "append" : "prepend"](this.icon)
            },
            _setOptions: function(t) {
                (void 0 === t.showLabel ? this.options.showLabel : t.showLabel) || (void 0 === t.icon ? this.options.icon : t.icon) || (t.showLabel = !0), this._super(t)
            },
            _setOption: function(t, e) {
                "icon" === t && (e ? this._updateIcon(t, e) : this.icon && (this.icon.remove(), this.iconSpace && this.iconSpace.remove())), "iconPosition" === t && this._updateIcon(t, e), "showLabel" === t && (this._toggleClass("ui-button-icon-only", null, !e), this._updateTooltip()), "label" === t && (this.isInput ? this.element.val(e) : (this.element.html(e), this.icon && (this._attachIcon(this.options.iconPosition), this._attachIconSpace(this.options.iconPosition)))), this._super(t, e), "disabled" === t && (this._toggleClass(null, "ui-state-disabled", e), this.element[0].disabled = e, e && this.element.blur())
            },
            refresh: function() {
                var t = this.element.is("input, button") ? this.element[0].disabled : this.element.hasClass("ui-button-disabled");
                t !== this.options.disabled && this._setOptions({
                    disabled: t
                }), this._updateTooltip()
            }
        }), !1 !== i.uiBackCompat && (i.widget("ui.button", i.ui.button, {
            options: {
                text: !0,
                icons: {
                    primary: null,
                    secondary: null
                }
            },
            _create: function() {
                this.options.showLabel && !this.options.text && (this.options.showLabel = this.options.text), !this.options.showLabel && this.options.text && (this.options.text = this.options.showLabel), this.options.icon || !this.options.icons.primary && !this.options.icons.secondary ? this.options.icon && (this.options.icons.primary = this.options.icon) : this.options.icons.primary ? this.options.icon = this.options.icons.primary : (this.options.icon = this.options.icons.secondary, this.options.iconPosition = "end"), this._super()
            },
            _setOption: function(t, e) {
                return "text" === t ? void this._super("showLabel", e) : ("showLabel" === t && (this.options.text = e), "icon" === t && (this.options.icons.primary = e), "icons" === t && (e.primary ? (this._super("icon", e.primary), this._super("iconPosition", "beginning")) : e.secondary && (this._super("icon", e.secondary), this._super("iconPosition", "end"))), void this._superApply(arguments))
            }
        }), i.fn.button = function(t) {
            return function() {
                return !this.length || this.length && "INPUT" !== this[0].tagName || this.length && "INPUT" === this[0].tagName && "checkbox" !== this.attr("type") && "radio" !== this.attr("type") ? t.apply(this, arguments) : (i.ui.checkboxradio || i.error("Checkboxradio widget missing"), 0 === arguments.length ? this.checkboxradio({
                    icon: !1
                }) : this.checkboxradio.apply(this, arguments))
            }
        }(i.fn.button), i.fn.buttonset = function() {
            return i.ui.controlgroup || i.error("Controlgroup widget missing"), "option" === arguments[0] && "items" === arguments[1] && arguments[2] ? this.controlgroup.apply(this, [arguments[0], "items.button", arguments[2]]) : "option" === arguments[0] && "items" === arguments[1] ? this.controlgroup.apply(this, [arguments[0], "items.button"]) : ("object" == typeof arguments[0] && arguments[0].items && (arguments[0].items = {
                button: arguments[0].items
            }), this.controlgroup.apply(this, arguments))
        }), i.extend(i.ui, {
            datepicker: {
                version: "1.12.1"
            }
        }), i.extend(it.prototype, {
            markerClassName: "hasDatepicker",
            maxRows: 4,
            _widgetDatepicker: function() {
                return this.dpDiv
            },
            setDefaults: function(t) {
                return p(this._defaults, t || {}), this
            },
            _attachDatepicker: function(t, e) {
                var n, s, r;
                s = "div" === (n = t.nodeName.toLowerCase()) || "span" === n, t.id || (this.uuid += 1, t.id = "dp" + this.uuid), (r = this._newInst(i(t), s)).settings = i.extend({}, e || {}), "input" === n ? this._connectDatepicker(t, r) : s && this._inlineDatepicker(t, r)
            },
            _newInst: function(t, e) {
                return {
                    id: t[0].id.replace(/([^A-Za-z0-9_\-])/g, "\\\\$1"),
                    input: t,
                    selectedDay: 0,
                    selectedMonth: 0,
                    selectedYear: 0,
                    drawMonth: 0,
                    drawYear: 0,
                    inline: e,
                    dpDiv: e ? f(i("<div class='" + this._inlineClass + " ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all'></div>")) : this.dpDiv
                }
            },
            _connectDatepicker: function(t, e) {
                var n = i(t);
                e.append = i([]), e.trigger = i([]), n.hasClass(this.markerClassName) || (this._attachments(n, e), n.addClass(this.markerClassName).on("keydown", this._doKeyDown).on("keypress", this._doKeyPress).on("keyup", this._doKeyUp), this._autoSize(e), i.data(t, "datepicker", e), e.settings.disabled && this._disableDatepicker(t))
            },
            _attachments: function(t, e) {
                var n, s, r, l = this._get(e, "appendText"),
                    d = this._get(e, "isRTL");
                e.append && e.append.remove(), l && (e.append = i("<span class='" + this._appendClass + "'>" + l + "</span>"), t[d ? "before" : "after"](e.append)), t.off("focus", this._showDatepicker), e.trigger && e.trigger.remove(), ("focus" === (n = this._get(e, "showOn")) || "both" === n) && t.on("focus", this._showDatepicker), ("button" === n || "both" === n) && (s = this._get(e, "buttonText"), r = this._get(e, "buttonImage"), e.trigger = i(this._get(e, "buttonImageOnly") ? i("<img/>").addClass(this._triggerClass).attr({
                    src: r,
                    alt: s,
                    title: s
                }) : i("<button type='button'></button>").addClass(this._triggerClass).html(r ? i("<img/>").attr({
                    src: r,
                    alt: s,
                    title: s
                }) : s)), t[d ? "before" : "after"](e.trigger), e.trigger.on("click", function() {
                    return i.datepicker._datepickerShowing && i.datepicker._lastInput === t[0] ? i.datepicker._hideDatepicker() : (i.datepicker._datepickerShowing && i.datepicker._lastInput !== t[0] && i.datepicker._hideDatepicker(), i.datepicker._showDatepicker(t[0])), !1
                }))
            },
            _autoSize: function(t) {
                if (this._get(t, "autoSize") && !t.inline) {
                    var e, n, s, r, l = new Date(2009, 11, 20),
                        d = this._get(t, "dateFormat");
                    d.match(/[DM]/) && (l.setMonth((e = function(g) {
                        for (n = 0, s = 0, r = 0; g.length > r; r++) g[r].length > n && (n = g[r].length, s = r);
                        return s
                    })(this._get(t, d.match(/MM/) ? "monthNames" : "monthNamesShort"))), l.setDate(e(this._get(t, d.match(/DD/) ? "dayNames" : "dayNamesShort")) + 20 - l.getDay())), t.input.attr("size", this._formatDate(t, l).length)
                }
            },
            _inlineDatepicker: function(t, e) {
                var n = i(t);
                n.hasClass(this.markerClassName) || (n.addClass(this.markerClassName).append(e.dpDiv), i.data(t, "datepicker", e), this._setDate(e, this._getDefaultDate(e), !0), this._updateDatepicker(e), this._updateAlternate(e), e.settings.disabled && this._disableDatepicker(t), e.dpDiv.css("display", "block"))
            },
            _dialogDatepicker: function(t, e, n, s, r) {
                var d, g, k, D, I = this._dialogInst;
                return I || (this.uuid += 1, this._dialogInput = i("<input type='text' id='dp" + this.uuid + "' style='position: absolute; top: -100px; width: 0px;'/>"), this._dialogInput.on("keydown", this._doKeyDown), i("body").append(this._dialogInput), (I = this._dialogInst = this._newInst(this._dialogInput, !1)).settings = {}, i.data(this._dialogInput[0], "datepicker", I)), p(I.settings, s || {}), e = e && e.constructor === Date ? this._formatDate(I, e) : e, this._dialogInput.val(e), this._pos = r ? r.length ? r : [r.pageX, r.pageY] : null, this._pos || (d = document.documentElement.clientWidth, g = document.documentElement.clientHeight, k = document.documentElement.scrollLeft || document.body.scrollLeft, D = document.documentElement.scrollTop || document.body.scrollTop, this._pos = [d / 2 - 100 + k, g / 2 - 150 + D]), this._dialogInput.css("left", this._pos[0] + 20 + "px").css("top", this._pos[1] + "px"), I.settings.onSelect = n, this._inDialog = !0, this.dpDiv.addClass(this._dialogClass), this._showDatepicker(this._dialogInput[0]), i.blockUI && i.blockUI(this.dpDiv), i.data(this._dialogInput[0], "datepicker", I), this
            },
            _destroyDatepicker: function(t) {
                var e, n = i(t),
                    s = i.data(t, "datepicker");
                n.hasClass(this.markerClassName) && (e = t.nodeName.toLowerCase(), i.removeData(t, "datepicker"), "input" === e ? (s.append.remove(), s.trigger.remove(), n.removeClass(this.markerClassName).off("focus", this._showDatepicker).off("keydown", this._doKeyDown).off("keypress", this._doKeyPress).off("keyup", this._doKeyUp)) : ("div" === e || "span" === e) && n.removeClass(this.markerClassName).empty(), st === s && (st = null))
            },
            _enableDatepicker: function(t) {
                var e, n, s = i(t),
                    r = i.data(t, "datepicker");
                s.hasClass(this.markerClassName) && ("input" === (e = t.nodeName.toLowerCase()) ? (t.disabled = !1, r.trigger.filter("button").each(function() {
                    this.disabled = !1
                }).end().filter("img").css({
                    opacity: "1.0",
                    cursor: ""
                })) : ("div" === e || "span" === e) && ((n = s.children("." + this._inlineClass)).children().removeClass("ui-state-disabled"), n.find("select.ui-datepicker-month, select.ui-datepicker-year").prop("disabled", !1)), this._disabledInputs = i.map(this._disabledInputs, function(l) {
                    return l === t ? null : l
                }))
            },
            _disableDatepicker: function(t) {
                var e, n, s = i(t),
                    r = i.data(t, "datepicker");
                s.hasClass(this.markerClassName) && ("input" === (e = t.nodeName.toLowerCase()) ? (t.disabled = !0, r.trigger.filter("button").each(function() {
                    this.disabled = !0
                }).end().filter("img").css({
                    opacity: "0.5",
                    cursor: "default"
                })) : ("div" === e || "span" === e) && ((n = s.children("." + this._inlineClass)).children().addClass("ui-state-disabled"), n.find("select.ui-datepicker-month, select.ui-datepicker-year").prop("disabled", !0)), this._disabledInputs = i.map(this._disabledInputs, function(l) {
                    return l === t ? null : l
                }), this._disabledInputs[this._disabledInputs.length] = t)
            },
            _isDisabledDatepicker: function(t) {
                if (!t) return !1;
                for (var e = 0; this._disabledInputs.length > e; e++)
                    if (this._disabledInputs[e] === t) return !0;
                return !1
            },
            _getInst: function(t) {
                try {
                    return i.data(t, "datepicker")
                } catch (e) {
                    throw "Missing instance data for this datepicker"
                }
            },
            _optionDatepicker: function(t, e, n) {
                var s, r, l, d, g = this._getInst(t);
                return 2 === arguments.length && "string" == typeof e ? "defaults" === e ? i.extend({}, i.datepicker._defaults) : g ? "all" === e ? i.extend({}, g.settings) : this._get(g, e) : null : (s = e || {}, "string" == typeof e && ((s = {})[e] = n), void(g && (this._curInst === g && this._hideDatepicker(), r = this._getDateDatepicker(t, !0), l = this._getMinMaxDate(g, "min"), d = this._getMinMaxDate(g, "max"), p(g.settings, s), null !== l && void 0 !== s.dateFormat && void 0 === s.minDate && (g.settings.minDate = this._formatDate(g, l)), null !== d && void 0 !== s.dateFormat && void 0 === s.maxDate && (g.settings.maxDate = this._formatDate(g, d)), "disabled" in s && (s.disabled ? this._disableDatepicker(t) : this._enableDatepicker(t)), this._attachments(i(t), g), this._autoSize(g), this._setDate(g, r), this._updateAlternate(g), this._updateDatepicker(g))))
            },
            _changeDatepicker: function(t, e, n) {
                this._optionDatepicker(t, e, n)
            },
            _refreshDatepicker: function(t) {
                var e = this._getInst(t);
                e && this._updateDatepicker(e)
            },
            _setDateDatepicker: function(t, e) {
                var n = this._getInst(t);
                n && (this._setDate(n, e), this._updateDatepicker(n), this._updateAlternate(n))
            },
            _getDateDatepicker: function(t, e) {
                var n = this._getInst(t);
                return n && !n.inline && this._setDateFromField(n, e), n ? this._getDate(n) : null
            },
            _doKeyDown: function(t) {
                var e, n, s, r = i.datepicker._getInst(t.target),
                    l = !0,
                    d = r.dpDiv.is(".ui-datepicker-rtl");
                if (r._keyEvent = !0, i.datepicker._datepickerShowing) switch (t.keyCode) {
                    case 9:
                        i.datepicker._hideDatepicker(), l = !1;
                        break;
                    case 13:
                        return (s = i("td." + i.datepicker._dayOverClass + ":not(." + i.datepicker._currentClass + ")", r.dpDiv))[0] && i.datepicker._selectDay(t.target, r.selectedMonth, r.selectedYear, s[0]), (e = i.datepicker._get(r, "onSelect")) ? (n = i.datepicker._formatDate(r), e.apply(r.input ? r.input[0] : null, [n, r])) : i.datepicker._hideDatepicker(), !1;
                    case 27:
                        i.datepicker._hideDatepicker();
                        break;
                    case 33:
                        i.datepicker._adjustDate(t.target, t.ctrlKey ? -i.datepicker._get(r, "stepBigMonths") : -i.datepicker._get(r, "stepMonths"), "M");
                        break;
                    case 34:
                        i.datepicker._adjustDate(t.target, t.ctrlKey ? +i.datepicker._get(r, "stepBigMonths") : +i.datepicker._get(r, "stepMonths"), "M");
                        break;
                    case 35:
                        (t.ctrlKey || t.metaKey) && i.datepicker._clearDate(t.target), l = t.ctrlKey || t.metaKey;
                        break;
                    case 36:
                        (t.ctrlKey || t.metaKey) && i.datepicker._gotoToday(t.target), l = t.ctrlKey || t.metaKey;
                        break;
                    case 37:
                        (t.ctrlKey || t.metaKey) && i.datepicker._adjustDate(t.target, d ? 1 : -1, "D"), l = t.ctrlKey || t.metaKey, t.originalEvent.altKey && i.datepicker._adjustDate(t.target, t.ctrlKey ? -i.datepicker._get(r, "stepBigMonths") : -i.datepicker._get(r, "stepMonths"), "M");
                        break;
                    case 38:
                        (t.ctrlKey || t.metaKey) && i.datepicker._adjustDate(t.target, -7, "D"), l = t.ctrlKey || t.metaKey;
                        break;
                    case 39:
                        (t.ctrlKey || t.metaKey) && i.datepicker._adjustDate(t.target, d ? -1 : 1, "D"), l = t.ctrlKey || t.metaKey, t.originalEvent.altKey && i.datepicker._adjustDate(t.target, t.ctrlKey ? +i.datepicker._get(r, "stepBigMonths") : +i.datepicker._get(r, "stepMonths"), "M");
                        break;
                    case 40:
                        (t.ctrlKey || t.metaKey) && i.datepicker._adjustDate(t.target, 7, "D"), l = t.ctrlKey || t.metaKey;
                        break;
                    default:
                        l = !1
                } else 36 === t.keyCode && t.ctrlKey ? i.datepicker._showDatepicker(this) : l = !1;
                l && (t.preventDefault(), t.stopPropagation())
            },
            _doKeyPress: function(t) {
                var e, n, s = i.datepicker._getInst(t.target);
                return i.datepicker._get(s, "constrainInput") ? (e = i.datepicker._possibleChars(i.datepicker._get(s, "dateFormat")), n = String.fromCharCode(null == t.charCode ? t.keyCode : t.charCode), t.ctrlKey || t.metaKey || " " > n || !e || e.indexOf(n) > -1) : void 0
            },
            _doKeyUp: function(t) {
                var n = i.datepicker._getInst(t.target);
                if (n.input.val() !== n.lastVal) try {
                    i.datepicker.parseDate(i.datepicker._get(n, "dateFormat"), n.input ? n.input.val() : null, i.datepicker._getFormatConfig(n)) && (i.datepicker._setDateFromField(n), i.datepicker._updateAlternate(n), i.datepicker._updateDatepicker(n))
                } catch (s) {}
                return !0
            },
            _showDatepicker: function(t) {
                var e, n, s, r, l, d, g;
                "input" !== (t = t.target || t).nodeName.toLowerCase() && (t = i("input", t.parentNode)[0]), i.datepicker._isDisabledDatepicker(t) || i.datepicker._lastInput === t || (e = i.datepicker._getInst(t), i.datepicker._curInst && i.datepicker._curInst !== e && (i.datepicker._curInst.dpDiv.stop(!0, !0), e && i.datepicker._datepickerShowing && i.datepicker._hideDatepicker(i.datepicker._curInst.input[0])), !1 !== (s = (n = i.datepicker._get(e, "beforeShow")) ? n.apply(t, [t, e]) : {}) && (p(e.settings, s), e.lastVal = null, i.datepicker._lastInput = t, i.datepicker._setDateFromField(e), i.datepicker._inDialog && (t.value = ""), i.datepicker._pos || (i.datepicker._pos = i.datepicker._findPos(t), i.datepicker._pos[1] += t.offsetHeight), r = !1, i(t).parents().each(function() {
                    return !(r |= "fixed" === i(this).css("position"))
                }), l = {
                    left: i.datepicker._pos[0],
                    top: i.datepicker._pos[1]
                }, i.datepicker._pos = null, e.dpDiv.empty(), e.dpDiv.css({
                    position: "absolute",
                    display: "block",
                    top: "-1000px"
                }), i.datepicker._updateDatepicker(e), l = i.datepicker._checkOffset(e, l, r), e.dpDiv.css({
                    position: i.datepicker._inDialog && i.blockUI ? "static" : r ? "fixed" : "absolute",
                    display: "none",
                    left: l.left + "px",
                    top: l.top + "px"
                }), e.inline || (d = i.datepicker._get(e, "showAnim"), g = i.datepicker._get(e, "duration"), e.dpDiv.css("z-index", function ut(t) {
                    for (var e, n; t.length && t[0] !== document;) {
                        if (("absolute" === (e = t.css("position")) || "relative" === e || "fixed" === e) && (n = parseInt(t.css("zIndex"), 10), !isNaN(n) && 0 !== n)) return n;
                        t = t.parent()
                    }
                    return 0
                }(i(t)) + 1), i.datepicker._datepickerShowing = !0, i.effects && i.effects.effect[d] ? e.dpDiv.show(d, i.datepicker._get(e, "showOptions"), g) : e.dpDiv[d || "show"](d ? g : null), i.datepicker._shouldFocusInput(e) && e.input.trigger("focus"), i.datepicker._curInst = e)))
            },
            _updateDatepicker: function(t) {
                this.maxRows = 4, st = t, t.dpDiv.empty().append(this._generateHTML(t)), this._attachHandlers(t);
                var e, n = this._getNumberOfMonths(t),
                    s = n[1],
                    l = t.dpDiv.find("." + this._dayOverClass + " a");
                l.length > 0 && b.apply(l.get(0)), t.dpDiv.removeClass("ui-datepicker-multi-2 ui-datepicker-multi-3 ui-datepicker-multi-4").width(""), s > 1 && t.dpDiv.addClass("ui-datepicker-multi-" + s).css("width", 17 * s + "em"), t.dpDiv[(1 !== n[0] || 1 !== n[1] ? "add" : "remove") + "Class"]("ui-datepicker-multi"), t.dpDiv[(this._get(t, "isRTL") ? "add" : "remove") + "Class"]("ui-datepicker-rtl"), t === i.datepicker._curInst && i.datepicker._datepickerShowing && i.datepicker._shouldFocusInput(t) && t.input.trigger("focus"), t.yearshtml && (e = t.yearshtml, setTimeout(function() {
                    e === t.yearshtml && t.yearshtml && t.dpDiv.find("select.ui-datepicker-year:first").replaceWith(t.yearshtml), e = t.yearshtml = null
                }, 0))
            },
            _shouldFocusInput: function(t) {
                return t.input && t.input.is(":visible") && !t.input.is(":disabled") && !t.input.is(":focus")
            },
            _checkOffset: function(t, e, n) {
                var s = t.dpDiv.outerWidth(),
                    r = t.dpDiv.outerHeight(),
                    l = t.input ? t.input.outerWidth() : 0,
                    d = t.input ? t.input.outerHeight() : 0,
                    g = document.documentElement.clientWidth + (n ? 0 : i(document).scrollLeft()),
                    k = document.documentElement.clientHeight + (n ? 0 : i(document).scrollTop());
                return e.left -= this._get(t, "isRTL") ? s - l : 0, e.left -= n && e.left === t.input.offset().left ? i(document).scrollLeft() : 0, e.top -= n && e.top === t.input.offset().top + d ? i(document).scrollTop() : 0, e.left -= Math.min(e.left, e.left + s > g && g > s ? Math.abs(e.left + s - g) : 0), e.top -= Math.min(e.top, e.top + r > k && k > r ? Math.abs(r + d) : 0), e
            },
            _findPos: function(t) {
                for (var e, n = this._getInst(t), s = this._get(n, "isRTL"); t && ("hidden" === t.type || 1 !== t.nodeType || i.expr.filters.hidden(t));) t = t[s ? "previousSibling" : "nextSibling"];
                return [(e = i(t).offset()).left, e.top]
            },
            _hideDatepicker: function(t) {
                var e, n, s, r, l = this._curInst;
                !l || t && l !== i.data(t, "datepicker") || this._datepickerShowing && (e = this._get(l, "showAnim"), n = this._get(l, "duration"), s = function() {
                    i.datepicker._tidyDialog(l)
                }, i.effects && (i.effects.effect[e] || i.effects[e]) ? l.dpDiv.hide(e, i.datepicker._get(l, "showOptions"), n, s) : l.dpDiv["slideDown" === e ? "slideUp" : "fadeIn" === e ? "fadeOut" : "hide"](e ? n : null, s), e || s(), this._datepickerShowing = !1, (r = this._get(l, "onClose")) && r.apply(l.input ? l.input[0] : null, [l.input ? l.input.val() : "", l]), this._lastInput = null, this._inDialog && (this._dialogInput.css({
                    position: "absolute",
                    left: "0",
                    top: "-100px"
                }), i.blockUI && (i.unblockUI(), i("body").append(this.dpDiv))), this._inDialog = !1)
            },
            _tidyDialog: function(t) {
                t.dpDiv.removeClass(this._dialogClass).off(".ui-datepicker-calendar")
            },
            _checkExternalClick: function(t) {
                if (i.datepicker._curInst) {
                    var e = i(t.target),
                        n = i.datepicker._getInst(e[0]);
                    (e[0].id !== i.datepicker._mainDivId && 0 === e.parents("#" + i.datepicker._mainDivId).length && !e.hasClass(i.datepicker.markerClassName) && !e.closest("." + i.datepicker._triggerClass).length && i.datepicker._datepickerShowing && (!i.datepicker._inDialog || !i.blockUI) || e.hasClass(i.datepicker.markerClassName) && i.datepicker._curInst !== n) && i.datepicker._hideDatepicker()
                }
            },
            _adjustDate: function(t, e, n) {
                var s = i(t),
                    r = this._getInst(s[0]);
                this._isDisabledDatepicker(s[0]) || (this._adjustInstDate(r, e + ("M" === n ? this._get(r, "showCurrentAtPos") : 0), n), this._updateDatepicker(r))
            },
            _gotoToday: function(t) {
                var e, n = i(t),
                    s = this._getInst(n[0]);
                this._get(s, "gotoCurrent") && s.currentDay ? (s.selectedDay = s.currentDay, s.drawMonth = s.selectedMonth = s.currentMonth, s.drawYear = s.selectedYear = s.currentYear) : (e = new Date, s.selectedDay = e.getDate(), s.drawMonth = s.selectedMonth = e.getMonth(), s.drawYear = s.selectedYear = e.getFullYear()), this._notifyChange(s), this._adjustDate(n)
            },
            _selectMonthYear: function(t, e, n) {
                var s = i(t),
                    r = this._getInst(s[0]);
                r["selected" + ("M" === n ? "Month" : "Year")] = r["draw" + ("M" === n ? "Month" : "Year")] = parseInt(e.options[e.selectedIndex].value, 10), this._notifyChange(r), this._adjustDate(s)
            },
            _selectDay: function(t, e, n, s) {
                var r, l = i(t);
                i(s).hasClass(this._unselectableClass) || this._isDisabledDatepicker(l[0]) || ((r = this._getInst(l[0])).selectedDay = r.currentDay = i("a", s).html(), r.selectedMonth = r.currentMonth = e, r.selectedYear = r.currentYear = n, this._selectDate(t, this._formatDate(r, r.currentDay, r.currentMonth, r.currentYear)))
            },
            _clearDate: function(t) {
                var e = i(t);
                this._selectDate(e, "")
            },
            _selectDate: function(t, e) {
                var n, s = i(t),
                    r = this._getInst(s[0]);
                e = null != e ? e : this._formatDate(r), r.input && r.input.val(e), this._updateAlternate(r), (n = this._get(r, "onSelect")) ? n.apply(r.input ? r.input[0] : null, [e, r]) : r.input && r.input.trigger("change"), r.inline ? this._updateDatepicker(r) : (this._hideDatepicker(), this._lastInput = r.input[0], "object" != typeof r.input[0] && r.input.trigger("focus"), this._lastInput = null)
            },
            _updateAlternate: function(t) {
                var e, n, s, r = this._get(t, "altField");
                r && (e = this._get(t, "altFormat") || this._get(t, "dateFormat"), n = this._getDate(t), s = this.formatDate(e, n, this._getFormatConfig(t)), i(r).val(s))
            },
            noWeekends: function(t) {
                var e = t.getDay();
                return [e > 0 && 6 > e, ""]
            },
            iso8601Week: function(t) {
                var e, n = new Date(t.getTime());
                return n.setDate(n.getDate() + 4 - (n.getDay() || 7)), e = n.getTime(), n.setMonth(0), n.setDate(1), Math.floor(Math.round((e - n) / 864e5) / 7) + 1
            },
            parseDate: function(t, e, n) {
                if (null == t || null == e) throw "Invalid arguments";
                if ("" == (e = "object" == typeof e ? "" + e : e + "")) return null;
                var s, r, l, d, g = 0,
                    k = (n ? n.shortYearCutoff : null) || this._defaults.shortYearCutoff,
                    D = "string" != typeof k ? k : (new Date).getFullYear() % 100 + parseInt(k, 10),
                    I = (n ? n.dayNamesShort : null) || this._defaults.dayNamesShort,
                    R = (n ? n.dayNames : null) || this._defaults.dayNames,
                    P = (n ? n.monthNamesShort : null) || this._defaults.monthNamesShort,
                    H = (n ? n.monthNames : null) || this._defaults.monthNames,
                    F = -1,
                    A = -1,
                    O = -1,
                    q = -1,
                    X = !1,
                    J = function(lt) {
                        var ct = t.length > s + 1 && t.charAt(s + 1) === lt;
                        return ct && s++, ct
                    },
                    nt = function(lt) {
                        var ct = J(lt),
                            mt = "@" === lt ? 14 : "!" === lt ? 20 : "y" === lt && ct ? 4 : "o" === lt ? 3 : 2,
                            kt = RegExp("^\\d{" + ("y" === lt ? mt : 1) + "," + mt + "}"),
                            at = e.substring(g).match(kt);
                        if (!at) throw "Missing number at position " + g;
                        return g += at[0].length, parseInt(at[0], 10)
                    },
                    pt = function(lt, ct, mt) {
                        var dt = -1,
                            kt = i.map(J(lt) ? mt : ct, function(at, St) {
                                return [
                                    [St, at]
                                ]
                            }).sort(function(at, St) {
                                return -(at[1].length - St[1].length)
                            });
                        if (i.each(kt, function(at, St) {
                                var ie = St[1];
                                return e.substr(g, ie.length).toLowerCase() === ie.toLowerCase() ? (dt = St[0], g += ie.length, !1) : void 0
                            }), -1 !== dt) return dt + 1;
                        throw "Unknown name at position " + g
                    },
                    ft = function() {
                        if (e.charAt(g) !== t.charAt(s)) throw "Unexpected literal at position " + g;
                        g++
                    };
                for (s = 0; t.length > s; s++)
                    if (X) "'" !== t.charAt(s) || J("'") ? ft() : X = !1;
                    else switch (t.charAt(s)) {
                        case "d":
                            O = nt("d");
                            break;
                        case "D":
                            pt("D", I, R);
                            break;
                        case "o":
                            q = nt("o");
                            break;
                        case "m":
                            A = nt("m");
                            break;
                        case "M":
                            A = pt("M", P, H);
                            break;
                        case "y":
                            F = nt("y");
                            break;
                        case "@":
                            F = (d = new Date(nt("@"))).getFullYear(), A = d.getMonth() + 1, O = d.getDate();
                            break;
                        case "!":
                            F = (d = new Date((nt("!") - this._ticksTo1970) / 1e4)).getFullYear(), A = d.getMonth() + 1, O = d.getDate();
                            break;
                        case "'":
                            J("'") ? ft() : X = !0;
                            break;
                        default:
                            ft()
                    }
                if (e.length > g && (l = e.substr(g), !/^\s+/.test(l))) throw "Extra/unparsed characters found in date: " + l;
                if (-1 === F ? F = (new Date).getFullYear() : 100 > F && (F += (new Date).getFullYear() - (new Date).getFullYear() % 100 + (D >= F ? 0 : -100)), q > -1)
                    for (A = 1, O = q; !((r = this._getDaysInMonth(F, A - 1)) >= O);) A++, O -= r;
                if ((d = this._daylightSavingAdjust(new Date(F, A - 1, O))).getFullYear() !== F || d.getMonth() + 1 !== A || d.getDate() !== O) throw "Invalid date";
                return d
            },
            ATOM: "yy-mm-dd",
            COOKIE: "D, dd M yy",
            ISO_8601: "yy-mm-dd",
            RFC_822: "D, d M y",
            RFC_850: "DD, dd-M-y",
            RFC_1036: "D, d M y",
            RFC_1123: "D, d M yy",
            RFC_2822: "D, d M yy",
            RSS: "D, d M y",
            TICKS: "!",
            TIMESTAMP: "@",
            W3C: "yy-mm-dd",
            _ticksTo1970: 864e9 * (718685 + Math.floor(492.5) - Math.floor(19.7) + Math.floor(4.925)),
            formatDate: function(t, e, n) {
                if (!e) return "";
                var s, r = (n ? n.dayNamesShort : null) || this._defaults.dayNamesShort,
                    l = (n ? n.dayNames : null) || this._defaults.dayNames,
                    d = (n ? n.monthNamesShort : null) || this._defaults.monthNamesShort,
                    g = (n ? n.monthNames : null) || this._defaults.monthNames,
                    k = function(H) {
                        var F = t.length > s + 1 && t.charAt(s + 1) === H;
                        return F && s++, F
                    },
                    D = function(H, F, A) {
                        var O = "" + F;
                        if (k(H))
                            for (; A > O.length;) O = "0" + O;
                        return O
                    },
                    I = function(H, F, A, O) {
                        return k(H) ? O[F] : A[F]
                    },
                    R = "",
                    P = !1;
                if (e)
                    for (s = 0; t.length > s; s++)
                        if (P) "'" !== t.charAt(s) || k("'") ? R += t.charAt(s) : P = !1;
                        else switch (t.charAt(s)) {
                            case "d":
                                R += D("d", e.getDate(), 2);
                                break;
                            case "D":
                                R += I("D", e.getDay(), r, l);
                                break;
                            case "o":
                                R += D("o", Math.round((new Date(e.getFullYear(), e.getMonth(), e.getDate()).getTime() - new Date(e.getFullYear(), 0, 0).getTime()) / 864e5), 3);
                                break;
                            case "m":
                                R += D("m", e.getMonth() + 1, 2);
                                break;
                            case "M":
                                R += I("M", e.getMonth(), d, g);
                                break;
                            case "y":
                                R += k("y") ? e.getFullYear() : (10 > e.getFullYear() % 100 ? "0" : "") + e.getFullYear() % 100;
                                break;
                            case "@":
                                R += e.getTime();
                                break;
                            case "!":
                                R += 1e4 * e.getTime() + this._ticksTo1970;
                                break;
                            case "'":
                                k("'") ? R += "'" : P = !0;
                                break;
                            default:
                                R += t.charAt(s)
                        }
                return R
            },
            _possibleChars: function(t) {
                var e, n = "",
                    s = !1,
                    r = function(l) {
                        var d = t.length > e + 1 && t.charAt(e + 1) === l;
                        return d && e++, d
                    };
                for (e = 0; t.length > e; e++)
                    if (s) "'" !== t.charAt(e) || r("'") ? n += t.charAt(e) : s = !1;
                    else switch (t.charAt(e)) {
                        case "d":
                        case "m":
                        case "y":
                        case "@":
                            n += "0123456789";
                            break;
                        case "D":
                        case "M":
                            return null;
                        case "'":
                            r("'") ? n += "'" : s = !0;
                            break;
                        default:
                            n += t.charAt(e)
                    }
                return n
            },
            _get: function(t, e) {
                return void 0 !== t.settings[e] ? t.settings[e] : this._defaults[e]
            },
            _setDateFromField: function(t, e) {
                if (t.input.val() !== t.lastVal) {
                    var n = this._get(t, "dateFormat"),
                        s = t.lastVal = t.input ? t.input.val() : null,
                        r = this._getDefaultDate(t),
                        l = r,
                        d = this._getFormatConfig(t);
                    try {
                        l = this.parseDate(n, s, d) || r
                    } catch (g) {
                        s = e ? "" : s
                    }
                    t.selectedDay = l.getDate(), t.drawMonth = t.selectedMonth = l.getMonth(), t.drawYear = t.selectedYear = l.getFullYear(), t.currentDay = s ? l.getDate() : 0, t.currentMonth = s ? l.getMonth() : 0, t.currentYear = s ? l.getFullYear() : 0, this._adjustInstDate(t)
                }
            },
            _getDefaultDate: function(t) {
                return this._restrictMinMax(t, this._determineDate(t, this._get(t, "defaultDate"), new Date))
            },
            _determineDate: function(t, e, n) {
                var d, g, l = null == e || "" === e ? n : "string" == typeof e ? function(d) {
                    try {
                        return i.datepicker.parseDate(i.datepicker._get(t, "dateFormat"), d, i.datepicker._getFormatConfig(t))
                    } catch (H) {}
                    for (var g = (d.toLowerCase().match(/^c/) ? i.datepicker._getDate(t) : null) || new Date, k = g.getFullYear(), D = g.getMonth(), I = g.getDate(), R = /([+\-]?[0-9]+)\s*(d|D|w|W|m|M|y|Y)?/g, P = R.exec(d); P;) {
                        switch (P[2] || "d") {
                            case "d":
                            case "D":
                                I += parseInt(P[1], 10);
                                break;
                            case "w":
                            case "W":
                                I += 7 * parseInt(P[1], 10);
                                break;
                            case "m":
                            case "M":
                                D += parseInt(P[1], 10), I = Math.min(I, i.datepicker._getDaysInMonth(k, D));
                                break;
                            case "y":
                            case "Y":
                                k += parseInt(P[1], 10), I = Math.min(I, i.datepicker._getDaysInMonth(k, D))
                        }
                        P = R.exec(d)
                    }
                    return new Date(k, D, I)
                }(e) : "number" == typeof e ? isNaN(e) ? n : (d = e, (g = new Date).setDate(g.getDate() + d), g) : new Date(e.getTime());
                return (l = l && "" + l == "Invalid Date" ? n : l) && (l.setHours(0), l.setMinutes(0), l.setSeconds(0), l.setMilliseconds(0)), this._daylightSavingAdjust(l)
            },
            _daylightSavingAdjust: function(t) {
                return t ? (t.setHours(t.getHours() > 12 ? t.getHours() + 2 : 0), t) : null
            },
            _setDate: function(t, e, n) {
                var s = !e,
                    r = t.selectedMonth,
                    l = t.selectedYear,
                    d = this._restrictMinMax(t, this._determineDate(t, e, new Date));
                t.selectedDay = t.currentDay = d.getDate(), t.drawMonth = t.selectedMonth = t.currentMonth = d.getMonth(), t.drawYear = t.selectedYear = t.currentYear = d.getFullYear(), r === t.selectedMonth && l === t.selectedYear || n || this._notifyChange(t), this._adjustInstDate(t), t.input && t.input.val(s ? "" : this._formatDate(t))
            },
            _getDate: function(t) {
                return !t.currentYear || t.input && "" === t.input.val() ? null : this._daylightSavingAdjust(new Date(t.currentYear, t.currentMonth, t.currentDay))
            },
            _attachHandlers: function(t) {
                var e = this._get(t, "stepMonths"),
                    n = "#" + t.id.replace(/\\\\/g, "\\");
                t.dpDiv.find("[data-handler]").map(function() {
                    var s = {
                        prev: function() {
                            i.datepicker._adjustDate(n, -e, "M")
                        },
                        next: function() {
                            i.datepicker._adjustDate(n, +e, "M")
                        },
                        hide: function() {
                            i.datepicker._hideDatepicker()
                        },
                        today: function() {
                            i.datepicker._gotoToday(n)
                        },
                        selectDay: function() {
                            return i.datepicker._selectDay(n, +this.getAttribute("data-month"), +this.getAttribute("data-year"), this), !1
                        },
                        selectMonth: function() {
                            return i.datepicker._selectMonthYear(n, this, "M"), !1
                        },
                        selectYear: function() {
                            return i.datepicker._selectMonthYear(n, this, "Y"), !1
                        }
                    };
                    i(this).on(this.getAttribute("data-event"), s[this.getAttribute("data-handler")])
                })
            },
            _generateHTML: function(t) {
                var e, n, s, r, l, d, g, k, D, I, R, P, H, F, A, O, q, X, J, nt, pt, ft, lt, ct, mt, dt, kt, at, St, ie, ge, pe, Lt, It, Kt, jt, Xt, Vt, ne, se = new Date,
                    Pe = this._daylightSavingAdjust(new Date(se.getFullYear(), se.getMonth(), se.getDate())),
                    Bt = this._get(t, "isRTL"),
                    je = this._get(t, "showButtonPanel"),
                    Ae = this._get(t, "hideIfNoPrevNext"),
                    xe = this._get(t, "navigationAsDateFormat"),
                    Ot = this._getNumberOfMonths(t),
                    Ut = this._get(t, "showCurrentAtPos"),
                    ke = this._get(t, "stepMonths"),
                    Ne = 1 !== Ot[0] || 1 !== Ot[1],
                    Ce = this._daylightSavingAdjust(t.currentDay ? new Date(t.currentYear, t.currentMonth, t.currentDay) : new Date(9999, 9, 9)),
                    oe = this._getMinMaxDate(t, "min"),
                    ue = this._getMinMaxDate(t, "max"),
                    Mt = t.drawMonth - Ut,
                    qt = t.drawYear;
                if (0 > Mt && (Mt += 12, qt--), ue)
                    for (e = this._daylightSavingAdjust(new Date(ue.getFullYear(), ue.getMonth() - Ot[0] * Ot[1] + 1, ue.getDate())), e = oe && oe > e ? oe : e; this._daylightSavingAdjust(new Date(qt, Mt, 1)) > e;) 0 > --Mt && (Mt = 11, qt--);
                for (t.drawMonth = Mt, t.drawYear = qt, n = this._get(t, "prevText"), n = xe ? this.formatDate(n, this._daylightSavingAdjust(new Date(qt, Mt - ke, 1)), this._getFormatConfig(t)) : n, s = this._canAdjustMonth(t, -1, qt, Mt) ? "<a class='ui-datepicker-prev ui-corner-all' data-handler='prev' data-event='click' title='" + n + "'><span class='ui-icon ui-icon-circle-triangle-" + (Bt ? "e" : "w") + "'>" + n + "</span></a>" : Ae ? "" : "<a class='ui-datepicker-prev ui-corner-all ui-state-disabled' title='" + n + "'><span class='ui-icon ui-icon-circle-triangle-" + (Bt ? "e" : "w") + "'>" + n + "</span></a>", r = this._get(t, "nextText"), r = xe ? this.formatDate(r, this._daylightSavingAdjust(new Date(qt, Mt + ke, 1)), this._getFormatConfig(t)) : r, l = this._canAdjustMonth(t, 1, qt, Mt) ? "<a class='ui-datepicker-next ui-corner-all' data-handler='next' data-event='click' title='" + r + "'><span class='ui-icon ui-icon-circle-triangle-" + (Bt ? "w" : "e") + "'>" + r + "</span></a>" : Ae ? "" : "<a class='ui-datepicker-next ui-corner-all ui-state-disabled' title='" + r + "'><span class='ui-icon ui-icon-circle-triangle-" + (Bt ? "w" : "e") + "'>" + r + "</span></a>", d = this._get(t, "currentText"), g = this._get(t, "gotoCurrent") && t.currentDay ? Ce : Pe, d = xe ? this.formatDate(d, g, this._getFormatConfig(t)) : d, k = t.inline ? "" : "<button type='button' class='ui-datepicker-close ui-state-default ui-priority-primary ui-corner-all' data-handler='hide' data-event='click'>" + this._get(t, "closeText") + "</button>", D = je ? "<div class='ui-datepicker-buttonpane ui-widget-content'>" + (Bt ? k : "") + (this._isInRange(t, g) ? "<button type='button' class='ui-datepicker-current ui-state-default ui-priority-secondary ui-corner-all' data-handler='today' data-event='click'>" + d + "</button>" : "") + (Bt ? "" : k) + "</div>" : "", I = parseInt(this._get(t, "firstDay"), 10), I = isNaN(I) ? 0 : I, R = this._get(t, "showWeek"), P = this._get(t, "dayNames"), H = this._get(t, "dayNamesMin"), F = this._get(t, "monthNames"), A = this._get(t, "monthNamesShort"), O = this._get(t, "beforeShowDay"), q = this._get(t, "showOtherMonths"), X = this._get(t, "selectOtherMonths"), J = this._getDefaultDate(t), nt = "", ft = 0; Ot[0] > ft; ft++) {
                    for (lt = "", this.maxRows = 4, ct = 0; Ot[1] > ct; ct++) {
                        if (mt = this._daylightSavingAdjust(new Date(qt, Mt, t.selectedDay)), dt = " ui-corner-all", kt = "", Ne) {
                            if (kt += "<div class='ui-datepicker-group", Ot[1] > 1) switch (ct) {
                                case 0:
                                    kt += " ui-datepicker-group-first", dt = " ui-corner-" + (Bt ? "right" : "left");
                                    break;
                                case Ot[1] - 1:
                                    kt += " ui-datepicker-group-last", dt = " ui-corner-" + (Bt ? "left" : "right");
                                    break;
                                default:
                                    kt += " ui-datepicker-group-middle", dt = ""
                            }
                            kt += "'>"
                        }
                        for (kt += "<div class='ui-datepicker-header ui-widget-header ui-helper-clearfix" + dt + "'>" + (/all|left/.test(dt) && 0 === ft ? Bt ? l : s : "") + (/all|right/.test(dt) && 0 === ft ? Bt ? s : l : "") + this._generateMonthYearHeader(t, Mt, qt, oe, ue, ft > 0 || ct > 0, F, A) + "</div><table class='ui-datepicker-calendar'><thead><tr>", at = R ? "<th class='ui-datepicker-week-col'>" + this._get(t, "weekHeader") + "</th>" : "", pt = 0; 7 > pt; pt++) at += "<th scope='col'" + ((pt + I + 6) % 7 >= 5 ? " class='ui-datepicker-week-end'" : "") + "><span title='" + P[St = (pt + I) % 7] + "'>" + H[St] + "</span></th>";
                        for (kt += at + "</tr></thead><tbody>", ie = this._getDaysInMonth(qt, Mt), qt === t.selectedYear && Mt === t.selectedMonth && (t.selectedDay = Math.min(t.selectedDay, ie)), ge = (this._getFirstDayOfMonth(qt, Mt) - I + 7) % 7, pe = Math.ceil((ge + ie) / 7), this.maxRows = Lt = Ne && this.maxRows > pe ? this.maxRows : pe, It = this._daylightSavingAdjust(new Date(qt, Mt, 1 - ge)), Kt = 0; Lt > Kt; Kt++) {
                            for (kt += "<tr>", jt = R ? "<td class='ui-datepicker-week-col'>" + this._get(t, "calculateWeek")(It) + "</td>" : "", pt = 0; 7 > pt; pt++) Xt = O ? O.apply(t.input ? t.input[0] : null, [It]) : [!0, ""], ne = (Vt = It.getMonth() !== Mt) && !X || !Xt[0] || oe && oe > It || ue && It > ue, jt += "<td class='" + ((pt + I + 6) % 7 >= 5 ? " ui-datepicker-week-end" : "") + (Vt ? " ui-datepicker-other-month" : "") + (It.getTime() === mt.getTime() && Mt === t.selectedMonth && t._keyEvent || J.getTime() === It.getTime() && J.getTime() === mt.getTime() ? " " + this._dayOverClass : "") + (ne ? " " + this._unselectableClass + " ui-state-disabled" : "") + (Vt && !q ? "" : " " + Xt[1] + (It.getTime() === Ce.getTime() ? " " + this._currentClass : "") + (It.getTime() === Pe.getTime() ? " ui-datepicker-today" : "")) + "'" + (Vt && !q || !Xt[2] ? "" : " title='" + Xt[2].replace(/'/g, "&#39;") + "'") + (ne ? "" : " data-handler='selectDay' data-event='click' data-month='" + It.getMonth() + "' data-year='" + It.getFullYear() + "'") + ">" + (Vt && !q ? "&#xa0;" : ne ? "<span class='ui-state-default'>" + It.getDate() + "</span>" : "<a class='ui-state-default" + (It.getTime() === Pe.getTime() ? " ui-state-highlight" : "") + (It.getTime() === Ce.getTime() ? " ui-state-active" : "") + (Vt ? " ui-priority-secondary" : "") + "' href='#'>" + It.getDate() + "</a>") + "</td>", It.setDate(It.getDate() + 1), It = this._daylightSavingAdjust(It);
                            kt += jt + "</tr>"
                        }++Mt > 11 && (Mt = 0, qt++), lt += kt += "</tbody></table>" + (Ne ? "</div>" + (Ot[0] > 0 && ct === Ot[1] - 1 ? "<div class='ui-datepicker-row-break'></div>" : "") : "")
                    }
                    nt += lt
                }
                return nt += D, t._keyEvent = !1, nt
            },
            _generateMonthYearHeader: function(t, e, n, s, r, l, d, g) {
                var k, D, I, R, P, H, F, A, O = this._get(t, "changeMonth"),
                    q = this._get(t, "changeYear"),
                    X = this._get(t, "showMonthAfterYear"),
                    J = "<div class='ui-datepicker-title'>",
                    nt = "";
                if (l || !O) nt += "<span class='ui-datepicker-month'>" + d[e] + "</span>";
                else {
                    for (k = s && s.getFullYear() === n, D = r && r.getFullYear() === n, nt += "<select class='ui-datepicker-month' data-handler='selectMonth' data-event='change'>", I = 0; 12 > I; I++)(!k || I >= s.getMonth()) && (!D || r.getMonth() >= I) && (nt += "<option value='" + I + "'" + (I === e ? " selected='selected'" : "") + ">" + g[I] + "</option>");
                    nt += "</select>"
                }
                if (X || (J += nt + (!l && O && q ? "" : "&#xa0;")), !t.yearshtml)
                    if (t.yearshtml = "", l || !q) J += "<span class='ui-datepicker-year'>" + n + "</span>";
                    else {
                        for (R = this._get(t, "yearRange").split(":"), P = (new Date).getFullYear(), F = (H = function(pt) {
                                var ft = pt.match(/c[+\-].*/) ? n + parseInt(pt.substring(1), 10) : pt.match(/[+\-].*/) ? P + parseInt(pt, 10) : parseInt(pt, 10);
                                return isNaN(ft) ? P : ft
                            })(R[0]), A = Math.max(F, H(R[1] || "")), F = s ? Math.max(F, s.getFullYear()) : F, A = r ? Math.min(A, r.getFullYear()) : A, t.yearshtml += "<select class='ui-datepicker-year' data-handler='selectYear' data-event='change'>"; A >= F; F++) t.yearshtml += "<option value='" + F + "'" + (F === n ? " selected='selected'" : "") + ">" + F + "</option>";
                        t.yearshtml += "</select>", J += t.yearshtml, t.yearshtml = null
                    }
                return J += this._get(t, "yearSuffix"), X && (J += (!l && O && q ? "" : "&#xa0;") + nt), J + "</div>"
            },
            _adjustInstDate: function(t, e, n) {
                var s = t.selectedYear + ("Y" === n ? e : 0),
                    r = t.selectedMonth + ("M" === n ? e : 0),
                    l = Math.min(t.selectedDay, this._getDaysInMonth(s, r)) + ("D" === n ? e : 0),
                    d = this._restrictMinMax(t, this._daylightSavingAdjust(new Date(s, r, l)));
                t.selectedDay = d.getDate(), t.drawMonth = t.selectedMonth = d.getMonth(), t.drawYear = t.selectedYear = d.getFullYear(), ("M" === n || "Y" === n) && this._notifyChange(t)
            },
            _restrictMinMax: function(t, e) {
                var n = this._getMinMaxDate(t, "min"),
                    s = this._getMinMaxDate(t, "max"),
                    r = n && n > e ? n : e;
                return s && r > s ? s : r
            },
            _notifyChange: function(t) {
                var e = this._get(t, "onChangeMonthYear");
                e && e.apply(t.input ? t.input[0] : null, [t.selectedYear, t.selectedMonth + 1, t])
            },
            _getNumberOfMonths: function(t) {
                var e = this._get(t, "numberOfMonths");
                return null == e ? [1, 1] : "number" == typeof e ? [1, e] : e
            },
            _getMinMaxDate: function(t, e) {
                return this._determineDate(t, this._get(t, e + "Date"), null)
            },
            _getDaysInMonth: function(t, e) {
                return 32 - this._daylightSavingAdjust(new Date(t, e, 32)).getDate()
            },
            _getFirstDayOfMonth: function(t, e) {
                return new Date(t, e, 1).getDay()
            },
            _canAdjustMonth: function(t, e, n, s) {
                var r = this._getNumberOfMonths(t),
                    l = this._daylightSavingAdjust(new Date(n, s + (0 > e ? e : r[0] * r[1]), 1));
                return 0 > e && l.setDate(this._getDaysInMonth(l.getFullYear(), l.getMonth())), this._isInRange(t, l)
            },
            _isInRange: function(t, e) {
                var n, s, r = this._getMinMaxDate(t, "min"),
                    l = this._getMinMaxDate(t, "max"),
                    d = null,
                    g = null,
                    k = this._get(t, "yearRange");
                return k && (n = k.split(":"), s = (new Date).getFullYear(), d = parseInt(n[0], 10), g = parseInt(n[1], 10), n[0].match(/[+\-].*/) && (d += s), n[1].match(/[+\-].*/) && (g += s)), (!r || e.getTime() >= r.getTime()) && (!l || e.getTime() <= l.getTime()) && (!d || e.getFullYear() >= d) && (!g || g >= e.getFullYear())
            },
            _getFormatConfig: function(t) {
                var e = this._get(t, "shortYearCutoff");
                return {
                    shortYearCutoff: e = "string" != typeof e ? e : (new Date).getFullYear() % 100 + parseInt(e, 10),
                    dayNamesShort: this._get(t, "dayNamesShort"),
                    dayNames: this._get(t, "dayNames"),
                    monthNamesShort: this._get(t, "monthNamesShort"),
                    monthNames: this._get(t, "monthNames")
                }
            },
            _formatDate: function(t, e, n, s) {
                e || (t.currentDay = t.selectedDay, t.currentMonth = t.selectedMonth, t.currentYear = t.selectedYear);
                var r = e ? "object" == typeof e ? e : this._daylightSavingAdjust(new Date(s, n, e)) : this._daylightSavingAdjust(new Date(t.currentYear, t.currentMonth, t.currentDay));
                return this.formatDate(this._get(t, "dateFormat"), r, this._getFormatConfig(t))
            }
        }), i.fn.datepicker = function(t) {
            if (!this.length) return this;
            i.datepicker.initialized || (i(document).on("mousedown", i.datepicker._checkExternalClick), i.datepicker.initialized = !0), 0 === i("#" + i.datepicker._mainDivId).length && i("body").append(i.datepicker.dpDiv);
            var e = Array.prototype.slice.call(arguments, 1);
            return "string" != typeof t || "isDisabled" !== t && "getDate" !== t && "widget" !== t ? "option" === t && 2 === arguments.length && "string" == typeof arguments[1] ? i.datepicker["_" + t + "Datepicker"].apply(i.datepicker, [this[0]].concat(e)) : this.each(function() {
                "string" == typeof t ? i.datepicker["_" + t + "Datepicker"].apply(i.datepicker, [this].concat(e)) : i.datepicker._attachDatepicker(this, t)
            }) : i.datepicker["_" + t + "Datepicker"].apply(i.datepicker, [this[0]].concat(e))
        }, i.datepicker = new it, i.datepicker.initialized = !1, i.datepicker.uuid = (new Date).getTime(), i.datepicker.version = "1.12.1", i.ui.ie = !!/msie [\w.]+/.exec(navigator.userAgent.toLowerCase());
        var u = !1;
        i(document).on("mouseup", function() {
            u = !1
        }), i.widget("ui.mouse", {
            version: "1.12.1",
            options: {
                cancel: "input, textarea, button, select, option",
                distance: 1,
                delay: 0
            },
            _mouseInit: function() {
                var t = this;
                this.element.on("mousedown." + this.widgetName, function(e) {
                    return t._mouseDown(e)
                }).on("click." + this.widgetName, function(e) {
                    return !0 === i.data(e.target, t.widgetName + ".preventClickEvent") ? (i.removeData(e.target, t.widgetName + ".preventClickEvent"), e.stopImmediatePropagation(), !1) : void 0
                }), this.started = !1
            },
            _mouseDestroy: function() {
                this.element.off("." + this.widgetName), this._mouseMoveDelegate && this.document.off("mousemove." + this.widgetName, this._mouseMoveDelegate).off("mouseup." + this.widgetName, this._mouseUpDelegate)
            },
            _mouseDown: function(t) {
                if (!u) {
                    this._mouseMoved = !1, this._mouseStarted && this._mouseUp(t), this._mouseDownEvent = t;
                    var e = this,
                        n = 1 === t.which,
                        s = !("string" != typeof this.options.cancel || !t.target.nodeName) && i(t.target).closest(this.options.cancel).length;
                    return !(n && !s && this._mouseCapture(t) && (this.mouseDelayMet = !this.options.delay, this.mouseDelayMet || (this._mouseDelayTimer = setTimeout(function() {
                        e.mouseDelayMet = !0
                    }, this.options.delay)), this._mouseDistanceMet(t) && this._mouseDelayMet(t) && (this._mouseStarted = !1 !== this._mouseStart(t), !this._mouseStarted) ? (t.preventDefault(), 0) : (!0 === i.data(t.target, this.widgetName + ".preventClickEvent") && i.removeData(t.target, this.widgetName + ".preventClickEvent"), this._mouseMoveDelegate = function(r) {
                        return e._mouseMove(r)
                    }, this._mouseUpDelegate = function(r) {
                        return e._mouseUp(r)
                    }, this.document.on("mousemove." + this.widgetName, this._mouseMoveDelegate).on("mouseup." + this.widgetName, this._mouseUpDelegate), t.preventDefault(), u = !0, 0)))
                }
            },
            _mouseMove: function(t) {
                if (this._mouseMoved) {
                    if (i.ui.ie && (!document.documentMode || 9 > document.documentMode) && !t.button) return this._mouseUp(t);
                    if (!t.which)
                        if (t.originalEvent.altKey || t.originalEvent.ctrlKey || t.originalEvent.metaKey || t.originalEvent.shiftKey) this.ignoreMissingWhich = !0;
                        else if (!this.ignoreMissingWhich) return this._mouseUp(t)
                }
                return (t.which || t.button) && (this._mouseMoved = !0), this._mouseStarted ? (this._mouseDrag(t), t.preventDefault()) : (this._mouseDistanceMet(t) && this._mouseDelayMet(t) && (this._mouseStarted = !1 !== this._mouseStart(this._mouseDownEvent, t), this._mouseStarted ? this._mouseDrag(t) : this._mouseUp(t)), !this._mouseStarted)
            },
            _mouseUp: function(t) {
                this.document.off("mousemove." + this.widgetName, this._mouseMoveDelegate).off("mouseup." + this.widgetName, this._mouseUpDelegate), this._mouseStarted && (this._mouseStarted = !1, t.target === this._mouseDownEvent.target && i.data(t.target, this.widgetName + ".preventClickEvent", !0), this._mouseStop(t)), this._mouseDelayTimer && (clearTimeout(this._mouseDelayTimer), delete this._mouseDelayTimer), this.ignoreMissingWhich = !1, u = !1, t.preventDefault()
            },
            _mouseDistanceMet: function(t) {
                return Math.max(Math.abs(this._mouseDownEvent.pageX - t.pageX), Math.abs(this._mouseDownEvent.pageY - t.pageY)) >= this.options.distance
            },
            _mouseDelayMet: function() {
                return this.mouseDelayMet
            },
            _mouseStart: function() {},
            _mouseDrag: function() {},
            _mouseStop: function() {},
            _mouseCapture: function() {
                return !0
            }
        }), i.ui.plugin = {
            add: function(t, e, n) {
                var s, r = i.ui[t].prototype;
                for (s in n) r.plugins[s] = r.plugins[s] || [], r.plugins[s].push([e, n[s]])
            },
            call: function(t, e, n, s) {
                var r, l = t.plugins[e];
                if (l && (s || t.element[0].parentNode && 11 !== t.element[0].parentNode.nodeType))
                    for (r = 0; l.length > r; r++) t.options[l[r][0]] && l[r][1].apply(t.element, n)
            }
        }, i.ui.safeBlur = function(t) {
            t && "body" !== t.nodeName.toLowerCase() && i(t).trigger("blur")
        }, i.widget("ui.draggable", i.ui.mouse, {
            version: "1.12.1",
            widgetEventPrefix: "drag",
            options: {
                addClasses: !0,
                appendTo: "parent",
                axis: !1,
                connectToSortable: !1,
                containment: !1,
                cursor: "auto",
                cursorAt: !1,
                grid: !1,
                handle: !1,
                helper: "original",
                iframeFix: !1,
                opacity: !1,
                refreshPositions: !1,
                revert: !1,
                revertDuration: 500,
                scope: "default",
                scroll: !0,
                scrollSensitivity: 20,
                scrollSpeed: 20,
                snap: !1,
                snapMode: "both",
                snapTolerance: 20,
                stack: !1,
                zIndex: !1,
                drag: null,
                start: null,
                stop: null
            },
            _create: function() {
                "original" === this.options.helper && this._setPositionRelative(), this.options.addClasses && this._addClass("ui-draggable"), this._setHandleClassName(), this._mouseInit()
            },
            _setOption: function(t, e) {
                this._super(t, e), "handle" === t && (this._removeHandleClassName(), this._setHandleClassName())
            },
            _destroy: function() {
                return (this.helper || this.element).is(".ui-draggable-dragging") ? void(this.destroyOnClear = !0) : (this._removeHandleClassName(), void this._mouseDestroy())
            },
            _mouseCapture: function(t) {
                var e = this.options;
                return !(this.helper || e.disabled || i(t.target).closest(".ui-resizable-handle").length > 0 || (this.handle = this._getHandle(t), !this.handle || (this._blurActiveElement(t), this._blockFrames(!0 === e.iframeFix ? "iframe" : e.iframeFix), 0)))
            },
            _blockFrames: function(t) {
                this.iframeBlocks = this.document.find(t).map(function() {
                    var e = i(this);
                    return i("<div>").css("position", "absolute").appendTo(e.parent()).outerWidth(e.outerWidth()).outerHeight(e.outerHeight()).offset(e.offset())[0]
                })
            },
            _unblockFrames: function() {
                this.iframeBlocks && (this.iframeBlocks.remove(), delete this.iframeBlocks)
            },
            _blurActiveElement: function(t) {
                var e = i.ui.safeActiveElement(this.document[0]);
                i(t.target).closest(e).length || i.ui.safeBlur(e)
            },
            _mouseStart: function(t) {
                var e = this.options;
                return this.helper = this._createHelper(t), this._addClass(this.helper, "ui-draggable-dragging"), this._cacheHelperProportions(), i.ui.ddmanager && (i.ui.ddmanager.current = this), this._cacheMargins(), this.cssPosition = this.helper.css("position"), this.scrollParent = this.helper.scrollParent(!0), this.offsetParent = this.helper.offsetParent(), this.hasFixedAncestor = this.helper.parents().filter(function() {
                    return "fixed" === i(this).css("position")
                }).length > 0, this.positionAbs = this.element.offset(), this._refreshOffsets(t), this.originalPosition = this.position = this._generatePosition(t, !1), this.originalPageX = t.pageX, this.originalPageY = t.pageY, e.cursorAt && this._adjustOffsetFromHelper(e.cursorAt), this._setContainment(), !1 === this._trigger("start", t) ? (this._clear(), !1) : (this._cacheHelperProportions(), i.ui.ddmanager && !e.dropBehaviour && i.ui.ddmanager.prepareOffsets(this, t), this._mouseDrag(t, !0), i.ui.ddmanager && i.ui.ddmanager.dragStart(this, t), !0)
            },
            _refreshOffsets: function(t) {
                this.offset = {
                    top: this.positionAbs.top - this.margins.top,
                    left: this.positionAbs.left - this.margins.left,
                    scroll: !1,
                    parent: this._getParentOffset(),
                    relative: this._getRelativeOffset()
                }, this.offset.click = {
                    left: t.pageX - this.offset.left,
                    top: t.pageY - this.offset.top
                }
            },
            _mouseDrag: function(t, e) {
                if (this.hasFixedAncestor && (this.offset.parent = this._getParentOffset()), this.position = this._generatePosition(t, !0), this.positionAbs = this._convertPositionTo("absolute"), !e) {
                    var n = this._uiHash();
                    if (!1 === this._trigger("drag", t, n)) return this._mouseUp(new i.Event("mouseup", t)), !1;
                    this.position = n.position
                }
                return this.helper[0].style.left = this.position.left + "px", this.helper[0].style.top = this.position.top + "px", i.ui.ddmanager && i.ui.ddmanager.drag(this, t), !1
            },
            _mouseStop: function(t) {
                var e = this,
                    n = !1;
                return i.ui.ddmanager && !this.options.dropBehaviour && (n = i.ui.ddmanager.drop(this, t)), this.dropped && (n = this.dropped, this.dropped = !1), "invalid" === this.options.revert && !n || "valid" === this.options.revert && n || !0 === this.options.revert || i.isFunction(this.options.revert) && this.options.revert.call(this.element, n) ? i(this.helper).animate(this.originalPosition, parseInt(this.options.revertDuration, 10), function() {
                    !1 !== e._trigger("stop", t) && e._clear()
                }) : !1 !== this._trigger("stop", t) && this._clear(), !1
            },
            _mouseUp: function(t) {
                return this._unblockFrames(), i.ui.ddmanager && i.ui.ddmanager.dragStop(this, t), this.handleElement.is(t.target) && this.element.trigger("focus"), i.ui.mouse.prototype._mouseUp.call(this, t)
            },
            cancel: function() {
                return this.helper.is(".ui-draggable-dragging") ? this._mouseUp(new i.Event("mouseup", {
                    target: this.element[0]
                })) : this._clear(), this
            },
            _getHandle: function(t) {
                return !this.options.handle || !!i(t.target).closest(this.element.find(this.options.handle)).length
            },
            _setHandleClassName: function() {
                this.handleElement = this.options.handle ? this.element.find(this.options.handle) : this.element, this._addClass(this.handleElement, "ui-draggable-handle")
            },
            _removeHandleClassName: function() {
                this._removeClass(this.handleElement, "ui-draggable-handle")
            },
            _createHelper: function(t) {
                var e = this.options,
                    n = i.isFunction(e.helper),
                    s = n ? i(e.helper.apply(this.element[0], [t])) : "clone" === e.helper ? this.element.clone().removeAttr("id") : this.element;
                return s.parents("body").length || s.appendTo("parent" === e.appendTo ? this.element[0].parentNode : e.appendTo), n && s[0] === this.element[0] && this._setPositionRelative(), s[0] === this.element[0] || /(fixed|absolute)/.test(s.css("position")) || s.css("position", "absolute"), s
            },
            _setPositionRelative: function() {
                /^(?:r|a|f)/.test(this.element.css("position")) || (this.element[0].style.position = "relative")
            },
            _adjustOffsetFromHelper: function(t) {
                "string" == typeof t && (t = t.split(" ")), i.isArray(t) && (t = {
                    left: +t[0],
                    top: +t[1] || 0
                }), "left" in t && (this.offset.click.left = t.left + this.margins.left), "right" in t && (this.offset.click.left = this.helperProportions.width - t.right + this.margins.left), "top" in t && (this.offset.click.top = t.top + this.margins.top), "bottom" in t && (this.offset.click.top = this.helperProportions.height - t.bottom + this.margins.top)
            },
            _isRootNode: function(t) {
                return /(html|body)/i.test(t.tagName) || t === this.document[0]
            },
            _getParentOffset: function() {
                var t = this.offsetParent.offset();
                return "absolute" === this.cssPosition && this.scrollParent[0] !== this.document[0] && i.contains(this.scrollParent[0], this.offsetParent[0]) && (t.left += this.scrollParent.scrollLeft(), t.top += this.scrollParent.scrollTop()), this._isRootNode(this.offsetParent[0]) && (t = {
                    top: 0,
                    left: 0
                }), {
                    top: t.top + (parseInt(this.offsetParent.css("borderTopWidth"), 10) || 0),
                    left: t.left + (parseInt(this.offsetParent.css("borderLeftWidth"), 10) || 0)
                }
            },
            _getRelativeOffset: function() {
                if ("relative" !== this.cssPosition) return {
                    top: 0,
                    left: 0
                };
                var t = this.element.position(),
                    e = this._isRootNode(this.scrollParent[0]);
                return {
                    top: t.top - (parseInt(this.helper.css("top"), 10) || 0) + (e ? 0 : this.scrollParent.scrollTop()),
                    left: t.left - (parseInt(this.helper.css("left"), 10) || 0) + (e ? 0 : this.scrollParent.scrollLeft())
                }
            },
            _cacheMargins: function() {
                this.margins = {
                    left: parseInt(this.element.css("marginLeft"), 10) || 0,
                    top: parseInt(this.element.css("marginTop"), 10) || 0,
                    right: parseInt(this.element.css("marginRight"), 10) || 0,
                    bottom: parseInt(this.element.css("marginBottom"), 10) || 0
                }
            },
            _cacheHelperProportions: function() {
                this.helperProportions = {
                    width: this.helper.outerWidth(),
                    height: this.helper.outerHeight()
                }
            },
            _setContainment: function() {
                var t, e, n, s = this.options,
                    r = this.document[0];
                return this.relativeContainer = null, s.containment ? "window" === s.containment ? void(this.containment = [i(window).scrollLeft() - this.offset.relative.left - this.offset.parent.left, i(window).scrollTop() - this.offset.relative.top - this.offset.parent.top, i(window).scrollLeft() + i(window).width() - this.helperProportions.width - this.margins.left, i(window).scrollTop() + (i(window).height() || r.body.parentNode.scrollHeight) - this.helperProportions.height - this.margins.top]) : "document" === s.containment ? void(this.containment = [0, 0, i(r).width() - this.helperProportions.width - this.margins.left, (i(r).height() || r.body.parentNode.scrollHeight) - this.helperProportions.height - this.margins.top]) : s.containment.constructor === Array ? void(this.containment = s.containment) : ("parent" === s.containment && (s.containment = this.helper[0].parentNode), void((n = (e = i(s.containment))[0]) && (t = /(scroll|auto)/.test(e.css("overflow")), this.containment = [(parseInt(e.css("borderLeftWidth"), 10) || 0) + (parseInt(e.css("paddingLeft"), 10) || 0), (parseInt(e.css("borderTopWidth"), 10) || 0) + (parseInt(e.css("paddingTop"), 10) || 0), (t ? Math.max(n.scrollWidth, n.offsetWidth) : n.offsetWidth) - (parseInt(e.css("borderRightWidth"), 10) || 0) - (parseInt(e.css("paddingRight"), 10) || 0) - this.helperProportions.width - this.margins.left - this.margins.right, (t ? Math.max(n.scrollHeight, n.offsetHeight) : n.offsetHeight) - (parseInt(e.css("borderBottomWidth"), 10) || 0) - (parseInt(e.css("paddingBottom"), 10) || 0) - this.helperProportions.height - this.margins.top - this.margins.bottom], this.relativeContainer = e))) : void(this.containment = null)
            },
            _convertPositionTo: function(t, e) {
                e || (e = this.position);
                var n = "absolute" === t ? 1 : -1,
                    s = this._isRootNode(this.scrollParent[0]);
                return {
                    top: e.top + this.offset.relative.top * n + this.offset.parent.top * n - ("fixed" === this.cssPosition ? -this.offset.scroll.top : s ? 0 : this.offset.scroll.top) * n,
                    left: e.left + this.offset.relative.left * n + this.offset.parent.left * n - ("fixed" === this.cssPosition ? -this.offset.scroll.left : s ? 0 : this.offset.scroll.left) * n
                }
            },
            _generatePosition: function(t, e) {
                var n, s, r, l, d = this.options,
                    g = this._isRootNode(this.scrollParent[0]),
                    k = t.pageX,
                    D = t.pageY;
                return g && this.offset.scroll || (this.offset.scroll = {
                    top: this.scrollParent.scrollTop(),
                    left: this.scrollParent.scrollLeft()
                }), e && (this.containment && (this.relativeContainer ? (s = this.relativeContainer.offset(), n = [this.containment[0] + s.left, this.containment[1] + s.top, this.containment[2] + s.left, this.containment[3] + s.top]) : n = this.containment, t.pageX - this.offset.click.left < n[0] && (k = n[0] + this.offset.click.left), t.pageY - this.offset.click.top < n[1] && (D = n[1] + this.offset.click.top), t.pageX - this.offset.click.left > n[2] && (k = n[2] + this.offset.click.left), t.pageY - this.offset.click.top > n[3] && (D = n[3] + this.offset.click.top)), d.grid && (r = d.grid[1] ? this.originalPageY + Math.round((D - this.originalPageY) / d.grid[1]) * d.grid[1] : this.originalPageY, D = n ? r - this.offset.click.top >= n[1] || r - this.offset.click.top > n[3] ? r : r - this.offset.click.top >= n[1] ? r - d.grid[1] : r + d.grid[1] : r, l = d.grid[0] ? this.originalPageX + Math.round((k - this.originalPageX) / d.grid[0]) * d.grid[0] : this.originalPageX, k = n ? l - this.offset.click.left >= n[0] || l - this.offset.click.left > n[2] ? l : l - this.offset.click.left >= n[0] ? l - d.grid[0] : l + d.grid[0] : l), "y" === d.axis && (k = this.originalPageX), "x" === d.axis && (D = this.originalPageY)), {
                    top: D - this.offset.click.top - this.offset.relative.top - this.offset.parent.top + ("fixed" === this.cssPosition ? -this.offset.scroll.top : g ? 0 : this.offset.scroll.top),
                    left: k - this.offset.click.left - this.offset.relative.left - this.offset.parent.left + ("fixed" === this.cssPosition ? -this.offset.scroll.left : g ? 0 : this.offset.scroll.left)
                }
            },
            _clear: function() {
                this._removeClass(this.helper, "ui-draggable-dragging"), this.helper[0] === this.element[0] || this.cancelHelperRemoval || this.helper.remove(), this.helper = null, this.cancelHelperRemoval = !1, this.destroyOnClear && this.destroy()
            },
            _trigger: function(t, e, n) {
                return n = n || this._uiHash(), i.ui.plugin.call(this, t, [e, n, this], !0), /^(drag|start|stop)/.test(t) && (this.positionAbs = this._convertPositionTo("absolute"), n.offset = this.positionAbs), i.Widget.prototype._trigger.call(this, t, e, n)
            },
            plugins: {},
            _uiHash: function() {
                return {
                    helper: this.helper,
                    position: this.position,
                    originalPosition: this.originalPosition,
                    offset: this.positionAbs
                }
            }
        }), i.ui.plugin.add("draggable", "connectToSortable", {
            start: function(t, e, n) {
                var s = i.extend({}, e, {
                    item: n.element
                });
                n.sortables = [], i(n.options.connectToSortable).each(function() {
                    var r = i(this).sortable("instance");
                    r && !r.options.disabled && (n.sortables.push(r), r.refreshPositions(), r._trigger("activate", t, s))
                })
            },
            stop: function(t, e, n) {
                var s = i.extend({}, e, {
                    item: n.element
                });
                n.cancelHelperRemoval = !1, i.each(n.sortables, function() {
                    var r = this;
                    r.isOver ? (r.isOver = 0, n.cancelHelperRemoval = !0, r.cancelHelperRemoval = !1, r._storedCSS = {
                        position: r.placeholder.css("position"),
                        top: r.placeholder.css("top"),
                        left: r.placeholder.css("left")
                    }, r._mouseStop(t), r.options.helper = r.options._helper) : (r.cancelHelperRemoval = !0, r._trigger("deactivate", t, s))
                })
            },
            drag: function(t, e, n) {
                i.each(n.sortables, function() {
                    var s = !1,
                        r = this;
                    r.positionAbs = n.positionAbs, r.helperProportions = n.helperProportions, r.offset.click = n.offset.click, r._intersectsWith(r.containerCache) && (s = !0, i.each(n.sortables, function() {
                        return this.positionAbs = n.positionAbs, this.helperProportions = n.helperProportions, this.offset.click = n.offset.click, this !== r && this._intersectsWith(this.containerCache) && i.contains(r.element[0], this.element[0]) && (s = !1), s
                    })), s ? (r.isOver || (r.isOver = 1, n._parent = e.helper.parent(), r.currentItem = e.helper.appendTo(r.element).data("ui-sortable-item", !0), r.options._helper = r.options.helper, r.options.helper = function() {
                        return e.helper[0]
                    }, t.target = r.currentItem[0], r._mouseCapture(t, !0), r._mouseStart(t, !0, !0), r.offset.click.top = n.offset.click.top, r.offset.click.left = n.offset.click.left, r.offset.parent.left -= n.offset.parent.left - r.offset.parent.left, r.offset.parent.top -= n.offset.parent.top - r.offset.parent.top, n._trigger("toSortable", t), n.dropped = r.element, i.each(n.sortables, function() {
                        this.refreshPositions()
                    }), n.currentItem = n.element, r.fromOutside = n), r.currentItem && (r._mouseDrag(t), e.position = r.position)) : r.isOver && (r.isOver = 0, r.cancelHelperRemoval = !0, r.options._revert = r.options.revert, r.options.revert = !1, r._trigger("out", t, r._uiHash(r)), r._mouseStop(t, !0), r.options.revert = r.options._revert, r.options.helper = r.options._helper, r.placeholder && r.placeholder.remove(), e.helper.appendTo(n._parent), n._refreshOffsets(t), e.position = n._generatePosition(t, !0), n._trigger("fromSortable", t), n.dropped = !1, i.each(n.sortables, function() {
                        this.refreshPositions()
                    }))
                })
            }
        }), i.ui.plugin.add("draggable", "cursor", {
            start: function(t, e, n) {
                var s = i("body"),
                    r = n.options;
                s.css("cursor") && (r._cursor = s.css("cursor")), s.css("cursor", r.cursor)
            },
            stop: function(t, e, n) {
                var s = n.options;
                s._cursor && i("body").css("cursor", s._cursor)
            }
        }), i.ui.plugin.add("draggable", "opacity", {
            start: function(t, e, n) {
                var s = i(e.helper),
                    r = n.options;
                s.css("opacity") && (r._opacity = s.css("opacity")), s.css("opacity", r.opacity)
            },
            stop: function(t, e, n) {
                var s = n.options;
                s._opacity && i(e.helper).css("opacity", s._opacity)
            }
        }), i.ui.plugin.add("draggable", "scroll", {
            start: function(t, e, n) {
                n.scrollParentNotHidden || (n.scrollParentNotHidden = n.helper.scrollParent(!1)), n.scrollParentNotHidden[0] !== n.document[0] && "HTML" !== n.scrollParentNotHidden[0].tagName && (n.overflowOffset = n.scrollParentNotHidden.offset())
            },
            drag: function(t, e, n) {
                var s = n.options,
                    r = !1,
                    l = n.scrollParentNotHidden[0],
                    d = n.document[0];
                l !== d && "HTML" !== l.tagName ? (s.axis && "x" === s.axis || (n.overflowOffset.top + l.offsetHeight - t.pageY < s.scrollSensitivity ? l.scrollTop = r = l.scrollTop + s.scrollSpeed : t.pageY - n.overflowOffset.top < s.scrollSensitivity && (l.scrollTop = r = l.scrollTop - s.scrollSpeed)), s.axis && "y" === s.axis || (n.overflowOffset.left + l.offsetWidth - t.pageX < s.scrollSensitivity ? l.scrollLeft = r = l.scrollLeft + s.scrollSpeed : t.pageX - n.overflowOffset.left < s.scrollSensitivity && (l.scrollLeft = r = l.scrollLeft - s.scrollSpeed))) : (s.axis && "x" === s.axis || (t.pageY - i(d).scrollTop() < s.scrollSensitivity ? r = i(d).scrollTop(i(d).scrollTop() - s.scrollSpeed) : i(window).height() - (t.pageY - i(d).scrollTop()) < s.scrollSensitivity && (r = i(d).scrollTop(i(d).scrollTop() + s.scrollSpeed))), s.axis && "y" === s.axis || (t.pageX - i(d).scrollLeft() < s.scrollSensitivity ? r = i(d).scrollLeft(i(d).scrollLeft() - s.scrollSpeed) : i(window).width() - (t.pageX - i(d).scrollLeft()) < s.scrollSensitivity && (r = i(d).scrollLeft(i(d).scrollLeft() + s.scrollSpeed)))), !1 !== r && i.ui.ddmanager && !s.dropBehaviour && i.ui.ddmanager.prepareOffsets(n, t)
            }
        }), i.ui.plugin.add("draggable", "snap", {
            start: function(t, e, n) {
                var s = n.options;
                n.snapElements = [], i(s.snap.constructor !== String ? s.snap.items || ":data(ui-draggable)" : s.snap).each(function() {
                    var r = i(this),
                        l = r.offset();
                    this !== n.element[0] && n.snapElements.push({
                        item: this,
                        width: r.outerWidth(),
                        height: r.outerHeight(),
                        top: l.top,
                        left: l.left
                    })
                })
            },
            drag: function(t, e, n) {
                var s, r, l, d, g, k, D, I, R, P, H = n.options,
                    F = H.snapTolerance,
                    A = e.offset.left,
                    O = A + n.helperProportions.width,
                    q = e.offset.top,
                    X = q + n.helperProportions.height;
                for (R = n.snapElements.length - 1; R >= 0; R--) k = (g = n.snapElements[R].left - n.margins.left) + n.snapElements[R].width, I = (D = n.snapElements[R].top - n.margins.top) + n.snapElements[R].height, g - F > O || A > k + F || D - F > X || q > I + F || !i.contains(n.snapElements[R].item.ownerDocument, n.snapElements[R].item) ? (n.snapElements[R].snapping && n.options.snap.release && n.options.snap.release.call(n.element, t, i.extend(n._uiHash(), {
                    snapItem: n.snapElements[R].item
                })), n.snapElements[R].snapping = !1) : ("inner" !== H.snapMode && (s = F >= Math.abs(D - X), r = F >= Math.abs(I - q), l = F >= Math.abs(g - O), d = F >= Math.abs(k - A), s && (e.position.top = n._convertPositionTo("relative", {
                    top: D - n.helperProportions.height,
                    left: 0
                }).top), r && (e.position.top = n._convertPositionTo("relative", {
                    top: I,
                    left: 0
                }).top), l && (e.position.left = n._convertPositionTo("relative", {
                    top: 0,
                    left: g - n.helperProportions.width
                }).left), d && (e.position.left = n._convertPositionTo("relative", {
                    top: 0,
                    left: k
                }).left)), P = s || r || l || d, "outer" !== H.snapMode && (s = F >= Math.abs(D - q), r = F >= Math.abs(I - X), l = F >= Math.abs(g - A), d = F >= Math.abs(k - O), s && (e.position.top = n._convertPositionTo("relative", {
                    top: D,
                    left: 0
                }).top), r && (e.position.top = n._convertPositionTo("relative", {
                    top: I - n.helperProportions.height,
                    left: 0
                }).top), l && (e.position.left = n._convertPositionTo("relative", {
                    top: 0,
                    left: g
                }).left), d && (e.position.left = n._convertPositionTo("relative", {
                    top: 0,
                    left: k - n.helperProportions.width
                }).left)), !n.snapElements[R].snapping && (s || r || l || d || P) && n.options.snap.snap && n.options.snap.snap.call(n.element, t, i.extend(n._uiHash(), {
                    snapItem: n.snapElements[R].item
                })), n.snapElements[R].snapping = s || r || l || d || P)
            }
        }), i.ui.plugin.add("draggable", "stack", {
            start: function(t, e, n) {
                var s, l = i.makeArray(i(n.options.stack)).sort(function(d, g) {
                    return (parseInt(i(d).css("zIndex"), 10) || 0) - (parseInt(i(g).css("zIndex"), 10) || 0)
                });
                l.length && (s = parseInt(i(l[0]).css("zIndex"), 10) || 0, i(l).each(function(d) {
                    i(this).css("zIndex", s + d)
                }), this.css("zIndex", s + l.length))
            }
        }), i.ui.plugin.add("draggable", "zIndex", {
            start: function(t, e, n) {
                var s = i(e.helper),
                    r = n.options;
                s.css("zIndex") && (r._zIndex = s.css("zIndex")), s.css("zIndex", r.zIndex)
            },
            stop: function(t, e, n) {
                var s = n.options;
                s._zIndex && i(e.helper).css("zIndex", s._zIndex)
            }
        }), i.widget("ui.resizable", i.ui.mouse, {
            version: "1.12.1",
            widgetEventPrefix: "resize",
            options: {
                alsoResize: !1,
                animate: !1,
                animateDuration: "slow",
                animateEasing: "swing",
                aspectRatio: !1,
                autoHide: !1,
                classes: {
                    "ui-resizable-se": "ui-icon ui-icon-gripsmall-diagonal-se"
                },
                containment: !1,
                ghost: !1,
                grid: !1,
                handles: "e,s,se",
                helper: !1,
                maxHeight: null,
                maxWidth: null,
                minHeight: 10,
                minWidth: 10,
                zIndex: 90,
                resize: null,
                start: null,
                stop: null
            },
            _num: function(t) {
                return parseFloat(t) || 0
            },
            _isNumber: function(t) {
                return !isNaN(parseFloat(t))
            },
            _hasScroll: function(t, e) {
                if ("hidden" === i(t).css("overflow")) return !1;
                var n = e && "left" === e ? "scrollLeft" : "scrollTop",
                    s = !1;
                return t[n] > 0 || (t[n] = 1, s = t[n] > 0, t[n] = 0, s)
            },
            _create: function() {
                var t, e = this.options,
                    n = this;
                this._addClass("ui-resizable"), i.extend(this, {
                    _aspectRatio: !!e.aspectRatio,
                    aspectRatio: e.aspectRatio,
                    originalElement: this.element,
                    _proportionallyResizeElements: [],
                    _helper: e.helper || e.ghost || e.animate ? e.helper || "ui-resizable-helper" : null
                }), this.element[0].nodeName.match(/^(canvas|textarea|input|select|button|img)$/i) && (this.element.wrap(i("<div class='ui-wrapper' style='overflow: hidden;'></div>").css({
                    position: this.element.css("position"),
                    width: this.element.outerWidth(),
                    height: this.element.outerHeight(),
                    top: this.element.css("top"),
                    left: this.element.css("left")
                })), this.element = this.element.parent().data("ui-resizable", this.element.resizable("instance")), this.elementIsWrapper = !0, t = {
                    marginTop: this.originalElement.css("marginTop"),
                    marginRight: this.originalElement.css("marginRight"),
                    marginBottom: this.originalElement.css("marginBottom"),
                    marginLeft: this.originalElement.css("marginLeft")
                }, this.element.css(t), this.originalElement.css("margin", 0), this.originalResizeStyle = this.originalElement.css("resize"), this.originalElement.css("resize", "none"), this._proportionallyResizeElements.push(this.originalElement.css({
                    position: "static",
                    zoom: 1,
                    display: "block"
                })), this.originalElement.css(t), this._proportionallyResize()), this._setupHandles(), e.autoHide && i(this.element).on("mouseenter", function() {
                    e.disabled || (n._removeClass("ui-resizable-autohide"), n._handles.show())
                }).on("mouseleave", function() {
                    e.disabled || n.resizing || (n._addClass("ui-resizable-autohide"), n._handles.hide())
                }), this._mouseInit()
            },
            _destroy: function() {
                this._mouseDestroy();
                var t, e = function(n) {
                    i(n).removeData("resizable").removeData("ui-resizable").off(".resizable").find(".ui-resizable-handle").remove()
                };
                return this.elementIsWrapper && (e(this.element), this.originalElement.css({
                    position: (t = this.element).css("position"),
                    width: t.outerWidth(),
                    height: t.outerHeight(),
                    top: t.css("top"),
                    left: t.css("left")
                }).insertAfter(t), t.remove()), this.originalElement.css("resize", this.originalResizeStyle), e(this.originalElement), this
            },
            _setOption: function(t, e) {
                "handles" === (this._super(t, e), t) && (this._removeHandles(), this._setupHandles())
            },
            _setupHandles: function() {
                var t, e, n, s, r, l = this.options,
                    d = this;
                if (this.handles = l.handles || (i(".ui-resizable-handle", this.element).length ? {
                        n: ".ui-resizable-n",
                        e: ".ui-resizable-e",
                        s: ".ui-resizable-s",
                        w: ".ui-resizable-w",
                        se: ".ui-resizable-se",
                        sw: ".ui-resizable-sw",
                        ne: ".ui-resizable-ne",
                        nw: ".ui-resizable-nw"
                    } : "e,s,se"), this._handles = i(), this.handles.constructor === String)
                    for ("all" === this.handles && (this.handles = "n,e,s,w,se,sw,ne,nw"), n = this.handles.split(","), this.handles = {}, e = 0; n.length > e; e++) s = "ui-resizable-" + (t = i.trim(n[e])), r = i("<div>"), this._addClass(r, "ui-resizable-handle " + s), r.css({
                        zIndex: l.zIndex
                    }), this.handles[t] = ".ui-resizable-" + t, this.element.append(r);
                this._renderAxis = function(g) {
                    var k, D, I, R;
                    for (k in g = g || this.element, this.handles) this.handles[k].constructor === String ? this.handles[k] = this.element.children(this.handles[k]).first().show() : (this.handles[k].jquery || this.handles[k].nodeType) && (this.handles[k] = i(this.handles[k]), this._on(this.handles[k], {
                        mousedown: d._mouseDown
                    })), this.elementIsWrapper && this.originalElement[0].nodeName.match(/^(textarea|input|select|button)$/i) && (D = i(this.handles[k], this.element), R = /sw|ne|nw|se|n|s/.test(k) ? D.outerHeight() : D.outerWidth(), I = ["padding", /ne|nw|n/.test(k) ? "Top" : /se|sw|s/.test(k) ? "Bottom" : /^e$/.test(k) ? "Right" : "Left"].join(""), g.css(I, R), this._proportionallyResize()), this._handles = this._handles.add(this.handles[k])
                }, this._renderAxis(this.element), this._handles = this._handles.add(this.element.find(".ui-resizable-handle")), this._handles.disableSelection(), this._handles.on("mouseover", function() {
                    d.resizing || (this.className && (r = this.className.match(/ui-resizable-(se|sw|ne|nw|n|e|s|w)/i)), d.axis = r && r[1] ? r[1] : "se")
                }), l.autoHide && (this._handles.hide(), this._addClass("ui-resizable-autohide"))
            },
            _removeHandles: function() {
                this._handles.remove()
            },
            _mouseCapture: function(t) {
                var e, n, s = !1;
                for (e in this.handles)((n = i(this.handles[e])[0]) === t.target || i.contains(n, t.target)) && (s = !0);
                return !this.options.disabled && s
            },
            _mouseStart: function(t) {
                var e, n, s, r = this.options,
                    l = this.element;
                return this.resizing = !0, this._renderProxy(), e = this._num(this.helper.css("left")), n = this._num(this.helper.css("top")), r.containment && (e += i(r.containment).scrollLeft() || 0, n += i(r.containment).scrollTop() || 0), this.offset = this.helper.offset(), this.position = {
                    left: e,
                    top: n
                }, this.size = this._helper ? {
                    width: this.helper.width(),
                    height: this.helper.height()
                } : {
                    width: l.width(),
                    height: l.height()
                }, this.originalSize = this._helper ? {
                    width: l.outerWidth(),
                    height: l.outerHeight()
                } : {
                    width: l.width(),
                    height: l.height()
                }, this.sizeDiff = {
                    width: l.outerWidth() - l.width(),
                    height: l.outerHeight() - l.height()
                }, this.originalPosition = {
                    left: e,
                    top: n
                }, this.originalMousePosition = {
                    left: t.pageX,
                    top: t.pageY
                }, this.aspectRatio = "number" == typeof r.aspectRatio ? r.aspectRatio : this.originalSize.width / this.originalSize.height || 1, s = i(".ui-resizable-" + this.axis).css("cursor"), i("body").css("cursor", "auto" === s ? this.axis + "-resize" : s), this._addClass("ui-resizable-resizing"), this._propagate("start", t), !0
            },
            _mouseDrag: function(t) {
                var e, n, s = this.originalMousePosition,
                    l = t.pageX - s.left || 0,
                    d = t.pageY - s.top || 0,
                    g = this._change[this.axis];
                return this._updatePrevProperties(), g && (e = g.apply(this, [t, l, d]), this._updateVirtualBoundaries(t.shiftKey), (this._aspectRatio || t.shiftKey) && (e = this._updateRatio(e, t)), e = this._respectSize(e, t), this._updateCache(e), this._propagate("resize", t), n = this._applyChanges(), !this._helper && this._proportionallyResizeElements.length && this._proportionallyResize(), i.isEmptyObject(n) || (this._updatePrevProperties(), this._trigger("resize", t, this.ui()), this._applyChanges())), !1
            },
            _mouseStop: function(t) {
                this.resizing = !1;
                var e, n, s, r, l, d, g, k = this.options,
                    D = this;
                return this._helper && (s = (n = (e = this._proportionallyResizeElements).length && /textarea/i.test(e[0].nodeName)) && this._hasScroll(e[0], "left") ? 0 : D.sizeDiff.height, r = n ? 0 : D.sizeDiff.width, l = {
                    width: D.helper.width() - r,
                    height: D.helper.height() - s
                }, d = parseFloat(D.element.css("left")) + (D.position.left - D.originalPosition.left) || null, g = parseFloat(D.element.css("top")) + (D.position.top - D.originalPosition.top) || null, k.animate || this.element.css(i.extend(l, {
                    top: g,
                    left: d
                })), D.helper.height(D.size.height), D.helper.width(D.size.width), this._helper && !k.animate && this._proportionallyResize()), i("body").css("cursor", "auto"), this._removeClass("ui-resizable-resizing"), this._propagate("stop", t), this._helper && this.helper.remove(), !1
            },
            _updatePrevProperties: function() {
                this.prevPosition = {
                    top: this.position.top,
                    left: this.position.left
                }, this.prevSize = {
                    width: this.size.width,
                    height: this.size.height
                }
            },
            _applyChanges: function() {
                var t = {};
                return this.position.top !== this.prevPosition.top && (t.top = this.position.top + "px"), this.position.left !== this.prevPosition.left && (t.left = this.position.left + "px"), this.size.width !== this.prevSize.width && (t.width = this.size.width + "px"), this.size.height !== this.prevSize.height && (t.height = this.size.height + "px"), this.helper.css(t), t
            },
            _updateVirtualBoundaries: function(t) {
                var e, n, s, r, l, d = this.options;
                l = {
                    minWidth: this._isNumber(d.minWidth) ? d.minWidth : 0,
                    maxWidth: this._isNumber(d.maxWidth) ? d.maxWidth : 1 / 0,
                    minHeight: this._isNumber(d.minHeight) ? d.minHeight : 0,
                    maxHeight: this._isNumber(d.maxHeight) ? d.maxHeight : 1 / 0
                }, (this._aspectRatio || t) && (s = l.minWidth / this.aspectRatio, n = l.maxHeight * this.aspectRatio, r = l.maxWidth / this.aspectRatio, (e = l.minHeight * this.aspectRatio) > l.minWidth && (l.minWidth = e), s > l.minHeight && (l.minHeight = s), l.maxWidth > n && (l.maxWidth = n), l.maxHeight > r && (l.maxHeight = r)), this._vBoundaries = l
            },
            _updateCache: function(t) {
                this.offset = this.helper.offset(), this._isNumber(t.left) && (this.position.left = t.left), this._isNumber(t.top) && (this.position.top = t.top), this._isNumber(t.height) && (this.size.height = t.height), this._isNumber(t.width) && (this.size.width = t.width)
            },
            _updateRatio: function(t) {
                var e = this.position,
                    n = this.size,
                    s = this.axis;
                return this._isNumber(t.height) ? t.width = t.height * this.aspectRatio : this._isNumber(t.width) && (t.height = t.width / this.aspectRatio), "sw" === s && (t.left = e.left + (n.width - t.width), t.top = null), "nw" === s && (t.top = e.top + (n.height - t.height), t.left = e.left + (n.width - t.width)), t
            },
            _respectSize: function(t) {
                var e = this._vBoundaries,
                    n = this.axis,
                    s = this._isNumber(t.width) && e.maxWidth && e.maxWidth < t.width,
                    r = this._isNumber(t.height) && e.maxHeight && e.maxHeight < t.height,
                    l = this._isNumber(t.width) && e.minWidth && e.minWidth > t.width,
                    d = this._isNumber(t.height) && e.minHeight && e.minHeight > t.height,
                    g = this.originalPosition.left + this.originalSize.width,
                    k = this.originalPosition.top + this.originalSize.height,
                    D = /sw|nw|w/.test(n),
                    I = /nw|ne|n/.test(n);
                return l && (t.width = e.minWidth), d && (t.height = e.minHeight), s && (t.width = e.maxWidth), r && (t.height = e.maxHeight), l && D && (t.left = g - e.minWidth), s && D && (t.left = g - e.maxWidth), d && I && (t.top = k - e.minHeight), r && I && (t.top = k - e.maxHeight), t.width || t.height || t.left || !t.top ? t.width || t.height || t.top || !t.left || (t.left = null) : t.top = null, t
            },
            _getPaddingPlusBorderDimensions: function(t) {
                for (var e = 0, n = [], s = [t.css("borderTopWidth"), t.css("borderRightWidth"), t.css("borderBottomWidth"), t.css("borderLeftWidth")], r = [t.css("paddingTop"), t.css("paddingRight"), t.css("paddingBottom"), t.css("paddingLeft")]; 4 > e; e++) n[e] = parseFloat(s[e]) || 0, n[e] += parseFloat(r[e]) || 0;
                return {
                    height: n[0] + n[2],
                    width: n[1] + n[3]
                }
            },
            _proportionallyResize: function() {
                if (this._proportionallyResizeElements.length)
                    for (var t, e = 0, n = this.helper || this.element; this._proportionallyResizeElements.length > e; e++) t = this._proportionallyResizeElements[e], this.outerDimensions || (this.outerDimensions = this._getPaddingPlusBorderDimensions(t)), t.css({
                        height: n.height() - this.outerDimensions.height || 0,
                        width: n.width() - this.outerDimensions.width || 0
                    })
            },
            _renderProxy: function() {
                var e = this.options;
                this.elementOffset = this.element.offset(), this._helper ? (this.helper = this.helper || i("<div style='overflow:hidden;'></div>"), this._addClass(this.helper, this._helper), this.helper.css({
                    width: this.element.outerWidth(),
                    height: this.element.outerHeight(),
                    position: "absolute",
                    left: this.elementOffset.left + "px",
                    top: this.elementOffset.top + "px",
                    zIndex: ++e.zIndex
                }), this.helper.appendTo("body").disableSelection()) : this.helper = this.element
            },
            _change: {
                e: function(t, e) {
                    return {
                        width: this.originalSize.width + e
                    }
                },
                w: function(t, e) {
                    return {
                        left: this.originalPosition.left + e,
                        width: this.originalSize.width - e
                    }
                },
                n: function(t, e, n) {
                    return {
                        top: this.originalPosition.top + n,
                        height: this.originalSize.height - n
                    }
                },
                s: function(t, e, n) {
                    return {
                        height: this.originalSize.height + n
                    }
                },
                se: function(t, e, n) {
                    return i.extend(this._change.s.apply(this, arguments), this._change.e.apply(this, [t, e, n]))
                },
                sw: function(t, e, n) {
                    return i.extend(this._change.s.apply(this, arguments), this._change.w.apply(this, [t, e, n]))
                },
                ne: function(t, e, n) {
                    return i.extend(this._change.n.apply(this, arguments), this._change.e.apply(this, [t, e, n]))
                },
                nw: function(t, e, n) {
                    return i.extend(this._change.n.apply(this, arguments), this._change.w.apply(this, [t, e, n]))
                }
            },
            _propagate: function(t, e) {
                i.ui.plugin.call(this, t, [e, this.ui()]), "resize" !== t && this._trigger(t, e, this.ui())
            },
            plugins: {},
            ui: function() {
                return {
                    originalElement: this.originalElement,
                    element: this.element,
                    helper: this.helper,
                    position: this.position,
                    size: this.size,
                    originalSize: this.originalSize,
                    originalPosition: this.originalPosition
                }
            }
        }), i.ui.plugin.add("resizable", "animate", {
            stop: function(t) {
                var e = i(this).resizable("instance"),
                    n = e.options,
                    s = e._proportionallyResizeElements,
                    r = s.length && /textarea/i.test(s[0].nodeName),
                    l = r && e._hasScroll(s[0], "left") ? 0 : e.sizeDiff.height,
                    g = {
                        width: e.size.width - (r ? 0 : e.sizeDiff.width),
                        height: e.size.height - l
                    },
                    k = parseFloat(e.element.css("left")) + (e.position.left - e.originalPosition.left) || null,
                    D = parseFloat(e.element.css("top")) + (e.position.top - e.originalPosition.top) || null;
                e.element.animate(i.extend(g, D && k ? {
                    top: D,
                    left: k
                } : {}), {
                    duration: n.animateDuration,
                    easing: n.animateEasing,
                    step: function() {
                        var I = {
                            width: parseFloat(e.element.css("width")),
                            height: parseFloat(e.element.css("height")),
                            top: parseFloat(e.element.css("top")),
                            left: parseFloat(e.element.css("left"))
                        };
                        s && s.length && i(s[0]).css({
                            width: I.width,
                            height: I.height
                        }), e._updateCache(I), e._propagate("resize", t)
                    }
                })
            }
        }), i.ui.plugin.add("resizable", "containment", {
            start: function() {
                var t, e, n, s, r, l, d, g = i(this).resizable("instance"),
                    D = g.element,
                    I = g.options.containment,
                    R = I instanceof i ? I.get(0) : /parent/.test(I) ? D.parent().get(0) : I;
                R && (g.containerElement = i(R), /document/.test(I) || I === document ? (g.containerOffset = {
                    left: 0,
                    top: 0
                }, g.containerPosition = {
                    left: 0,
                    top: 0
                }, g.parentData = {
                    element: i(document),
                    left: 0,
                    top: 0,
                    width: i(document).width(),
                    height: i(document).height() || document.body.parentNode.scrollHeight
                }) : (t = i(R), e = [], i(["Top", "Right", "Left", "Bottom"]).each(function(P, H) {
                    e[P] = g._num(t.css("padding" + H))
                }), g.containerOffset = t.offset(), g.containerPosition = t.position(), g.containerSize = {
                    height: t.innerHeight() - e[3],
                    width: t.innerWidth() - e[1]
                }, n = g.containerOffset, s = g.containerSize.height, r = g.containerSize.width, l = g._hasScroll(R, "left") ? R.scrollWidth : r, d = g._hasScroll(R) ? R.scrollHeight : s, g.parentData = {
                    element: R,
                    left: n.left,
                    top: n.top,
                    width: l,
                    height: d
                }))
            },
            resize: function(t) {
                var e, n, s, r, l = i(this).resizable("instance"),
                    d = l.options,
                    g = l.containerOffset,
                    k = l.position,
                    D = l._aspectRatio || t.shiftKey,
                    I = {
                        top: 0,
                        left: 0
                    },
                    R = l.containerElement,
                    P = !0;
                R[0] !== document && /static/.test(R.css("position")) && (I = g), k.left < (l._helper ? g.left : 0) && (l.size.width = l.size.width + (l._helper ? l.position.left - g.left : l.position.left - I.left), D && (l.size.height = l.size.width / l.aspectRatio, P = !1), l.position.left = d.helper ? g.left : 0), k.top < (l._helper ? g.top : 0) && (l.size.height = l.size.height + (l._helper ? l.position.top - g.top : l.position.top), D && (l.size.width = l.size.height * l.aspectRatio, P = !1), l.position.top = l._helper ? g.top : 0), s = l.containerElement.get(0) === l.element.parent().get(0), r = /relative|absolute/.test(l.containerElement.css("position")), s && r ? (l.offset.left = l.parentData.left + l.position.left, l.offset.top = l.parentData.top + l.position.top) : (l.offset.left = l.element.offset().left, l.offset.top = l.element.offset().top), e = Math.abs(l.sizeDiff.width + (l._helper ? l.offset.left - I.left : l.offset.left - g.left)), n = Math.abs(l.sizeDiff.height + (l._helper ? l.offset.top - I.top : l.offset.top - g.top)), e + l.size.width >= l.parentData.width && (l.size.width = l.parentData.width - e, D && (l.size.height = l.size.width / l.aspectRatio, P = !1)), n + l.size.height >= l.parentData.height && (l.size.height = l.parentData.height - n, D && (l.size.width = l.size.height * l.aspectRatio, P = !1)), P || (l.position.left = l.prevPosition.left, l.position.top = l.prevPosition.top, l.size.width = l.prevSize.width, l.size.height = l.prevSize.height)
            },
            stop: function() {
                var t = i(this).resizable("instance"),
                    e = t.options,
                    n = t.containerOffset,
                    s = t.containerPosition,
                    r = t.containerElement,
                    l = i(t.helper),
                    d = l.offset(),
                    g = l.outerWidth() - t.sizeDiff.width,
                    k = l.outerHeight() - t.sizeDiff.height;
                t._helper && !e.animate && /relative/.test(r.css("position")) && i(this).css({
                    left: d.left - s.left - n.left,
                    width: g,
                    height: k
                }), t._helper && !e.animate && /static/.test(r.css("position")) && i(this).css({
                    left: d.left - s.left - n.left,
                    width: g,
                    height: k
                })
            }
        }), i.ui.plugin.add("resizable", "alsoResize", {
            start: function() {
                var t = i(this).resizable("instance");
                i(t.options.alsoResize).each(function() {
                    var n = i(this);
                    n.data("ui-resizable-alsoresize", {
                        width: parseFloat(n.width()),
                        height: parseFloat(n.height()),
                        left: parseFloat(n.css("left")),
                        top: parseFloat(n.css("top"))
                    })
                })
            },
            resize: function(t, e) {
                var n = i(this).resizable("instance"),
                    r = n.originalSize,
                    l = n.originalPosition,
                    d = {
                        height: n.size.height - r.height || 0,
                        width: n.size.width - r.width || 0,
                        top: n.position.top - l.top || 0,
                        left: n.position.left - l.left || 0
                    };
                i(n.options.alsoResize).each(function() {
                    var g = i(this),
                        k = i(this).data("ui-resizable-alsoresize"),
                        D = {},
                        I = g.parents(e.originalElement[0]).length ? ["width", "height"] : ["width", "height", "top", "left"];
                    i.each(I, function(R, P) {
                        var H = (k[P] || 0) + (d[P] || 0);
                        H && H >= 0 && (D[P] = H || null)
                    }), g.css(D)
                })
            },
            stop: function() {
                i(this).removeData("ui-resizable-alsoresize")
            }
        }), i.ui.plugin.add("resizable", "ghost", {
            start: function() {
                var t = i(this).resizable("instance"),
                    e = t.size;
                t.ghost = t.originalElement.clone(), t.ghost.css({
                    opacity: .25,
                    display: "block",
                    position: "relative",
                    height: e.height,
                    width: e.width,
                    margin: 0,
                    left: 0,
                    top: 0
                }), t._addClass(t.ghost, "ui-resizable-ghost"), !1 !== i.uiBackCompat && "string" == typeof t.options.ghost && t.ghost.addClass(this.options.ghost), t.ghost.appendTo(t.helper)
            },
            resize: function() {
                var t = i(this).resizable("instance");
                t.ghost && t.ghost.css({
                    position: "relative",
                    height: t.size.height,
                    width: t.size.width
                })
            },
            stop: function() {
                var t = i(this).resizable("instance");
                t.ghost && t.helper && t.helper.get(0).removeChild(t.ghost.get(0))
            }
        }), i.ui.plugin.add("resizable", "grid", {
            resize: function() {
                var t, e = i(this).resizable("instance"),
                    n = e.options,
                    s = e.size,
                    r = e.originalSize,
                    l = e.originalPosition,
                    d = e.axis,
                    g = "number" == typeof n.grid ? [n.grid, n.grid] : n.grid,
                    k = g[0] || 1,
                    D = g[1] || 1,
                    I = Math.round((s.width - r.width) / k) * k,
                    R = Math.round((s.height - r.height) / D) * D,
                    P = r.width + I,
                    H = r.height + R,
                    F = n.maxWidth && P > n.maxWidth,
                    A = n.maxHeight && H > n.maxHeight,
                    O = n.minWidth && n.minWidth > P,
                    q = n.minHeight && n.minHeight > H;
                n.grid = g, O && (P += k), q && (H += D), F && (P -= k), A && (H -= D), /^(se|s|e)$/.test(d) ? (e.size.width = P, e.size.height = H) : /^(ne)$/.test(d) ? (e.size.width = P, e.size.height = H, e.position.top = l.top - R) : /^(sw)$/.test(d) ? (e.size.width = P, e.size.height = H, e.position.left = l.left - I) : ((0 >= H - D || 0 >= P - k) && (t = e._getPaddingPlusBorderDimensions(this)), H - D > 0 ? (e.size.height = H, e.position.top = l.top - R) : (e.size.height = H = D - t.height, e.position.top = l.top + r.height - H), P - k > 0 ? (e.size.width = P, e.position.left = l.left - I) : (e.size.width = P = k - t.width, e.position.left = l.left + r.width - P))
            }
        }), i.widget("ui.dialog", {
            version: "1.12.1",
            options: {
                appendTo: "body",
                autoOpen: !0,
                buttons: [],
                classes: {
                    "ui-dialog": "ui-corner-all",
                    "ui-dialog-titlebar": "ui-corner-all"
                },
                closeOnEscape: !0,
                closeText: "Close",
                draggable: !0,
                hide: null,
                height: "auto",
                maxHeight: null,
                maxWidth: null,
                minHeight: 150,
                minWidth: 150,
                modal: !1,
                position: {
                    my: "center",
                    at: "center",
                    of: window,
                    collision: "fit",
                    using: function(t) {
                        var e = i(this).css(t).offset().top;
                        0 > e && i(this).css("top", t.top - e)
                    }
                },
                resizable: !0,
                show: null,
                title: null,
                width: 300,
                beforeClose: null,
                close: null,
                drag: null,
                dragStart: null,
                dragStop: null,
                focus: null,
                open: null,
                resize: null,
                resizeStart: null,
                resizeStop: null
            },
            sizeRelatedOptions: {
                buttons: !0,
                height: !0,
                maxHeight: !0,
                maxWidth: !0,
                minHeight: !0,
                minWidth: !0,
                width: !0
            },
            resizableRelatedOptions: {
                maxHeight: !0,
                maxWidth: !0,
                minHeight: !0,
                minWidth: !0
            },
            _create: function() {
                this.originalCss = {
                    display: this.element[0].style.display,
                    width: this.element[0].style.width,
                    minHeight: this.element[0].style.minHeight,
                    maxHeight: this.element[0].style.maxHeight,
                    height: this.element[0].style.height
                }, this.originalPosition = {
                    parent: this.element.parent(),
                    index: this.element.parent().children().index(this.element)
                }, this.originalTitle = this.element.attr("title"), null == this.options.title && null != this.originalTitle && (this.options.title = this.originalTitle), this.options.disabled && (this.options.disabled = !1), this._createWrapper(), this.element.show().removeAttr("title").appendTo(this.uiDialog), this._addClass("ui-dialog-content", "ui-widget-content"), this._createTitlebar(), this._createButtonPane(), this.options.draggable && i.fn.draggable && this._makeDraggable(), this.options.resizable && i.fn.resizable && this._makeResizable(), this._isOpen = !1, this._trackFocus()
            },
            _init: function() {
                this.options.autoOpen && this.open()
            },
            _appendTo: function() {
                var t = this.options.appendTo;
                return t && (t.jquery || t.nodeType) ? i(t) : this.document.find(t || "body").eq(0)
            },
            _destroy: function() {
                var t, e = this.originalPosition;
                this._untrackInstance(), this._destroyOverlay(), this.element.removeUniqueId().css(this.originalCss).detach(), this.uiDialog.remove(), this.originalTitle && this.element.attr("title", this.originalTitle), (t = e.parent.children().eq(e.index)).length && t[0] !== this.element[0] ? t.before(this.element) : e.parent.append(this.element)
            },
            widget: function() {
                return this.uiDialog
            },
            disable: i.noop,
            enable: i.noop,
            close: function(t) {
                var e = this;
                this._isOpen && !1 !== this._trigger("beforeClose", t) && (this._isOpen = !1, this._focusedElement = null, this._destroyOverlay(), this._untrackInstance(), this.opener.filter(":focusable").trigger("focus").length || i.ui.safeBlur(i.ui.safeActiveElement(this.document[0])), this._hide(this.uiDialog, this.options.hide, function() {
                    e._trigger("close", t)
                }))
            },
            isOpen: function() {
                return this._isOpen
            },
            moveToTop: function() {
                this._moveToTop()
            },
            _moveToTop: function(t, e) {
                var n = !1,
                    s = this.uiDialog.siblings(".ui-front:visible").map(function() {
                        return +i(this).css("z-index")
                    }).get(),
                    r = Math.max.apply(null, s);
                return r >= +this.uiDialog.css("z-index") && (this.uiDialog.css("z-index", r + 1), n = !0), n && !e && this._trigger("focus", t), n
            },
            open: function() {
                var t = this;
                return this._isOpen ? void(this._moveToTop() && this._focusTabbable()) : (this._isOpen = !0, this.opener = i(i.ui.safeActiveElement(this.document[0])), this._size(), this._position(), this._createOverlay(), this._moveToTop(null, !0), this.overlay && this.overlay.css("z-index", this.uiDialog.css("z-index") - 1), this._show(this.uiDialog, this.options.show, function() {
                    t._focusTabbable(), t._trigger("focus")
                }), this._makeFocusTarget(), void this._trigger("open"))
            },
            _focusTabbable: function() {
                var t = this._focusedElement;
                t || (t = this.element.find("[autofocus]")), t.length || (t = this.element.find(":tabbable")), t.length || (t = this.uiDialogButtonPane.find(":tabbable")), t.length || (t = this.uiDialogTitlebarClose.filter(":tabbable")), t.length || (t = this.uiDialog), t.eq(0).trigger("focus")
            },
            _keepFocus: function(t) {
                function e() {
                    var n = i.ui.safeActiveElement(this.document[0]);
                    this.uiDialog[0] === n || i.contains(this.uiDialog[0], n) || this._focusTabbable()
                }
                t.preventDefault(), e.call(this), this._delay(e)
            },
            _createWrapper: function() {
                this.uiDialog = i("<div>").hide().attr({
                    tabIndex: -1,
                    role: "dialog"
                }).appendTo(this._appendTo()), this._addClass(this.uiDialog, "ui-dialog", "ui-widget ui-widget-content ui-front"), this._on(this.uiDialog, {
                    keydown: function(t) {
                        if (this.options.closeOnEscape && !t.isDefaultPrevented() && t.keyCode && t.keyCode === i.ui.keyCode.ESCAPE) return t.preventDefault(), void this.close(t);
                        if (t.keyCode === i.ui.keyCode.TAB && !t.isDefaultPrevented()) {
                            var e = this.uiDialog.find(":tabbable"),
                                n = e.filter(":first"),
                                s = e.filter(":last");
                            t.target !== s[0] && t.target !== this.uiDialog[0] || t.shiftKey ? t.target !== n[0] && t.target !== this.uiDialog[0] || !t.shiftKey || (this._delay(function() {
                                s.trigger("focus")
                            }), t.preventDefault()) : (this._delay(function() {
                                n.trigger("focus")
                            }), t.preventDefault())
                        }
                    },
                    mousedown: function(t) {
                        this._moveToTop(t) && this._focusTabbable()
                    }
                }), this.element.find("[aria-describedby]").length || this.uiDialog.attr({
                    "aria-describedby": this.element.uniqueId().attr("id")
                })
            },
            _createTitlebar: function() {
                var t;
                this.uiDialogTitlebar = i("<div>"), this._addClass(this.uiDialogTitlebar, "ui-dialog-titlebar", "ui-widget-header ui-helper-clearfix"), this._on(this.uiDialogTitlebar, {
                    mousedown: function(e) {
                        i(e.target).closest(".ui-dialog-titlebar-close") || this.uiDialog.trigger("focus")
                    }
                }), this.uiDialogTitlebarClose = i("<button type='button'></button>").button({
                    label: i("<a>").text(this.options.closeText).html(),
                    icon: "ui-icon-closethick",
                    showLabel: !1
                }).appendTo(this.uiDialogTitlebar), this._addClass(this.uiDialogTitlebarClose, "ui-dialog-titlebar-close"), this._on(this.uiDialogTitlebarClose, {
                    click: function(e) {
                        e.preventDefault(), this.close(e)
                    }
                }), t = i("<span>").uniqueId().prependTo(this.uiDialogTitlebar), this._addClass(t, "ui-dialog-title"), this._title(t), this.uiDialogTitlebar.prependTo(this.uiDialog), this.uiDialog.attr({
                    "aria-labelledby": t.attr("id")
                })
            },
            _title: function(t) {
                this.options.title ? t.text(this.options.title) : t.html("&#160;")
            },
            _createButtonPane: function() {
                this.uiDialogButtonPane = i("<div>"), this._addClass(this.uiDialogButtonPane, "ui-dialog-buttonpane", "ui-widget-content ui-helper-clearfix"), this.uiButtonSet = i("<div>").appendTo(this.uiDialogButtonPane), this._addClass(this.uiButtonSet, "ui-dialog-buttonset"), this._createButtons()
            },
            _createButtons: function() {
                var t = this,
                    e = this.options.buttons;
                return this.uiDialogButtonPane.remove(), this.uiButtonSet.empty(), i.isEmptyObject(e) || i.isArray(e) && !e.length ? void this._removeClass(this.uiDialog, "ui-dialog-buttons") : (i.each(e, function(n, s) {
                    var r, l;
                    s = i.isFunction(s) ? {
                        click: s,
                        text: n
                    } : s, s = i.extend({
                        type: "button"
                    }, s), r = s.click, l = {
                        icon: s.icon,
                        iconPosition: s.iconPosition,
                        showLabel: s.showLabel,
                        icons: s.icons,
                        text: s.text
                    }, delete s.click, delete s.icon, delete s.iconPosition, delete s.showLabel, delete s.icons, "boolean" == typeof s.text && delete s.text, i("<button></button>", s).button(l).appendTo(t.uiButtonSet).on("click", function() {
                        r.apply(t.element[0], arguments)
                    })
                }), this._addClass(this.uiDialog, "ui-dialog-buttons"), void this.uiDialogButtonPane.appendTo(this.uiDialog))
            },
            _makeDraggable: function() {
                function t(s) {
                    return {
                        position: s.position,
                        offset: s.offset
                    }
                }
                var e = this,
                    n = this.options;
                this.uiDialog.draggable({
                    cancel: ".ui-dialog-content, .ui-dialog-titlebar-close",
                    handle: ".ui-dialog-titlebar",
                    containment: "document",
                    start: function(s, r) {
                        e._addClass(i(this), "ui-dialog-dragging"), e._blockFrames(), e._trigger("dragStart", s, t(r))
                    },
                    drag: function(s, r) {
                        e._trigger("drag", s, t(r))
                    },
                    stop: function(s, r) {
                        var l = r.offset.left - e.document.scrollLeft(),
                            d = r.offset.top - e.document.scrollTop();
                        n.position = {
                            my: "left top",
                            at: "left" + (l >= 0 ? "+" : "") + l + " top" + (d >= 0 ? "+" : "") + d,
                            of: e.window
                        }, e._removeClass(i(this), "ui-dialog-dragging"), e._unblockFrames(), e._trigger("dragStop", s, t(r))
                    }
                })
            },
            _makeResizable: function() {
                function t(d) {
                    return {
                        originalPosition: d.originalPosition,
                        originalSize: d.originalSize,
                        position: d.position,
                        size: d.size
                    }
                }
                var e = this,
                    n = this.options,
                    s = n.resizable,
                    r = this.uiDialog.css("position"),
                    l = "string" == typeof s ? s : "n,e,s,w,se,sw,ne,nw";
                this.uiDialog.resizable({
                    cancel: ".ui-dialog-content",
                    containment: "document",
                    alsoResize: this.element,
                    maxWidth: n.maxWidth,
                    maxHeight: n.maxHeight,
                    minWidth: n.minWidth,
                    minHeight: this._minHeight(),
                    handles: l,
                    start: function(d, g) {
                        e._addClass(i(this), "ui-dialog-resizing"), e._blockFrames(), e._trigger("resizeStart", d, t(g))
                    },
                    resize: function(d, g) {
                        e._trigger("resize", d, t(g))
                    },
                    stop: function(d, g) {
                        var k = e.uiDialog.offset(),
                            D = k.left - e.document.scrollLeft(),
                            I = k.top - e.document.scrollTop();
                        n.height = e.uiDialog.height(), n.width = e.uiDialog.width(), n.position = {
                            my: "left top",
                            at: "left" + (D >= 0 ? "+" : "") + D + " top" + (I >= 0 ? "+" : "") + I,
                            of: e.window
                        }, e._removeClass(i(this), "ui-dialog-resizing"), e._unblockFrames(), e._trigger("resizeStop", d, t(g))
                    }
                }).css("position", r)
            },
            _trackFocus: function() {
                this._on(this.widget(), {
                    focusin: function(t) {
                        this._makeFocusTarget(), this._focusedElement = i(t.target)
                    }
                })
            },
            _makeFocusTarget: function() {
                this._untrackInstance(), this._trackingInstances().unshift(this)
            },
            _untrackInstance: function() {
                var t = this._trackingInstances(),
                    e = i.inArray(this, t); - 1 !== e && t.splice(e, 1)
            },
            _trackingInstances: function() {
                var t = this.document.data("ui-dialog-instances");
                return t || this.document.data("ui-dialog-instances", t = []), t
            },
            _minHeight: function() {
                var t = this.options;
                return "auto" === t.height ? t.minHeight : Math.min(t.minHeight, t.height)
            },
            _position: function() {
                var t = this.uiDialog.is(":visible");
                t || this.uiDialog.show(), this.uiDialog.position(this.options.position), t || this.uiDialog.hide()
            },
            _setOptions: function(t) {
                var e = this,
                    n = !1,
                    s = {};
                i.each(t, function(r, l) {
                    e._setOption(r, l), r in e.sizeRelatedOptions && (n = !0), r in e.resizableRelatedOptions && (s[r] = l)
                }), n && (this._size(), this._position()), this.uiDialog.is(":data(ui-resizable)") && this.uiDialog.resizable("option", s)
            },
            _setOption: function(t, e) {
                var n, s, r = this.uiDialog;
                "disabled" !== t && (this._super(t, e), "appendTo" === t && this.uiDialog.appendTo(this._appendTo()), "buttons" === t && this._createButtons(), "closeText" === t && this.uiDialogTitlebarClose.button({
                    label: i("<a>").text("" + this.options.closeText).html()
                }), "draggable" === t && ((n = r.is(":data(ui-draggable)")) && !e && r.draggable("destroy"), !n && e && this._makeDraggable()), "position" === t && this._position(), "resizable" === t && ((s = r.is(":data(ui-resizable)")) && !e && r.resizable("destroy"), s && "string" == typeof e && r.resizable("option", "handles", e), s || !1 === e || this._makeResizable()), "title" === t && this._title(this.uiDialogTitlebar.find(".ui-dialog-title")))
            },
            _size: function() {
                var t, e, n, s = this.options;
                this.element.show().css({
                    width: "auto",
                    minHeight: 0,
                    maxHeight: "none",
                    height: 0
                }), s.minWidth > s.width && (s.width = s.minWidth), t = this.uiDialog.css({
                    height: "auto",
                    width: s.width
                }).outerHeight(), e = Math.max(0, s.minHeight - t), n = "number" == typeof s.maxHeight ? Math.max(0, s.maxHeight - t) : "none", "auto" === s.height ? this.element.css({
                    minHeight: e,
                    maxHeight: n,
                    height: "auto"
                }) : this.element.height(Math.max(0, s.height - t)), this.uiDialog.is(":data(ui-resizable)") && this.uiDialog.resizable("option", "minHeight", this._minHeight())
            },
            _blockFrames: function() {
                this.iframeBlocks = this.document.find("iframe").map(function() {
                    var t = i(this);
                    return i("<div>").css({
                        position: "absolute",
                        width: t.outerWidth(),
                        height: t.outerHeight()
                    }).appendTo(t.parent()).offset(t.offset())[0]
                })
            },
            _unblockFrames: function() {
                this.iframeBlocks && (this.iframeBlocks.remove(), delete this.iframeBlocks)
            },
            _allowInteraction: function(t) {
                return !!i(t.target).closest(".ui-dialog").length || !!i(t.target).closest(".ui-datepicker").length
            },
            _createOverlay: function() {
                if (this.options.modal) {
                    var t = !0;
                    this._delay(function() {
                        t = !1
                    }), this.document.data("ui-dialog-overlays") || this._on(this.document, {
                        focusin: function(e) {
                            t || this._allowInteraction(e) || (e.preventDefault(), this._trackingInstances()[0]._focusTabbable())
                        }
                    }), this.overlay = i("<div>").appendTo(this._appendTo()), this._addClass(this.overlay, null, "ui-widget-overlay ui-front"), this._on(this.overlay, {
                        mousedown: "_keepFocus"
                    }), this.document.data("ui-dialog-overlays", (this.document.data("ui-dialog-overlays") || 0) + 1)
                }
            },
            _destroyOverlay: function() {
                if (this.options.modal && this.overlay) {
                    var t = this.document.data("ui-dialog-overlays") - 1;
                    t ? this.document.data("ui-dialog-overlays", t) : (this._off(this.document, "focusin"), this.document.removeData("ui-dialog-overlays")), this.overlay.remove(), this.overlay = null
                }
            }
        }), !1 !== i.uiBackCompat && i.widget("ui.dialog", i.ui.dialog, {
            options: {
                dialogClass: ""
            },
            _createWrapper: function() {
                this._super(), this.uiDialog.addClass(this.options.dialogClass)
            },
            _setOption: function(t, e) {
                "dialogClass" === t && this.uiDialog.removeClass(this.options.dialogClass).addClass(e), this._superApply(arguments)
            }
        }), i.widget("ui.droppable", {
            version: "1.12.1",
            widgetEventPrefix: "drop",
            options: {
                accept: "*",
                addClasses: !0,
                greedy: !1,
                scope: "default",
                tolerance: "intersect",
                activate: null,
                deactivate: null,
                drop: null,
                out: null,
                over: null
            },
            _create: function() {
                var t, e = this.options,
                    n = e.accept;
                this.isover = !1, this.isout = !0, this.accept = i.isFunction(n) ? n : function(s) {
                    return s.is(n)
                }, this.proportions = function() {
                    return arguments.length ? void(t = arguments[0]) : t || (t = {
                        width: this.element[0].offsetWidth,
                        height: this.element[0].offsetHeight
                    })
                }, this._addToManager(e.scope), e.addClasses && this._addClass("ui-droppable")
            },
            _addToManager: function(t) {
                i.ui.ddmanager.droppables[t] = i.ui.ddmanager.droppables[t] || [], i.ui.ddmanager.droppables[t].push(this)
            },
            _splice: function(t) {
                for (var e = 0; t.length > e; e++) t[e] === this && t.splice(e, 1)
            },
            _destroy: function() {
                this._splice(i.ui.ddmanager.droppables[this.options.scope])
            },
            _setOption: function(t, e) {
                "accept" === t ? this.accept = i.isFunction(e) ? e : function(s) {
                    return s.is(e)
                } : "scope" === t && (this._splice(i.ui.ddmanager.droppables[this.options.scope]), this._addToManager(e)), this._super(t, e)
            },
            _activate: function(t) {
                var e = i.ui.ddmanager.current;
                this._addActiveClass(), e && this._trigger("activate", t, this.ui(e))
            },
            _deactivate: function(t) {
                var e = i.ui.ddmanager.current;
                this._removeActiveClass(), e && this._trigger("deactivate", t, this.ui(e))
            },
            _over: function(t) {
                var e = i.ui.ddmanager.current;
                e && (e.currentItem || e.element)[0] !== this.element[0] && this.accept.call(this.element[0], e.currentItem || e.element) && (this._addHoverClass(), this._trigger("over", t, this.ui(e)))
            },
            _out: function(t) {
                var e = i.ui.ddmanager.current;
                e && (e.currentItem || e.element)[0] !== this.element[0] && this.accept.call(this.element[0], e.currentItem || e.element) && (this._removeHoverClass(), this._trigger("out", t, this.ui(e)))
            },
            _drop: function(t, e) {
                var n = e || i.ui.ddmanager.current,
                    s = !1;
                return !(!n || (n.currentItem || n.element)[0] === this.element[0]) && (this.element.find(":data(ui-droppable)").not(".ui-draggable-dragging").each(function() {
                    var r = i(this).droppable("instance");
                    return r.options.greedy && !r.options.disabled && r.options.scope === n.options.scope && r.accept.call(r.element[0], n.currentItem || n.element) && ot(n, i.extend(r, {
                        offset: r.element.offset()
                    }), r.options.tolerance, t) ? (s = !0, !1) : void 0
                }), !s && !!this.accept.call(this.element[0], n.currentItem || n.element) && (this._removeActiveClass(), this._removeHoverClass(), this._trigger("drop", t, this.ui(n)), this.element))
            },
            ui: function(t) {
                return {
                    draggable: t.currentItem || t.element,
                    helper: t.helper,
                    position: t.position,
                    offset: t.positionAbs
                }
            },
            _addHoverClass: function() {
                this._addClass("ui-droppable-hover")
            },
            _removeHoverClass: function() {
                this._removeClass("ui-droppable-hover")
            },
            _addActiveClass: function() {
                this._addClass("ui-droppable-active")
            },
            _removeActiveClass: function() {
                this._removeClass("ui-droppable-active")
            }
        });
        var ot = i.ui.intersect = function() {
            function t(e, n, s) {
                return e >= n && n + s > e
            }
            return function(e, n, s, r) {
                if (!n.offset) return !1;
                var l = (e.positionAbs || e.position.absolute).left + e.margins.left,
                    d = (e.positionAbs || e.position.absolute).top + e.margins.top,
                    g = l + e.helperProportions.width,
                    k = d + e.helperProportions.height,
                    D = n.offset.left,
                    I = n.offset.top,
                    R = D + n.proportions().width,
                    P = I + n.proportions().height;
                switch (s) {
                    case "fit":
                        return l >= D && R >= g && d >= I && P >= k;
                    case "intersect":
                        return l + e.helperProportions.width / 2 > D && R > g - e.helperProportions.width / 2 && d + e.helperProportions.height / 2 > I && P > k - e.helperProportions.height / 2;
                    case "pointer":
                        return t(r.pageY, I, n.proportions().height) && t(r.pageX, D, n.proportions().width);
                    case "touch":
                        return (d >= I && P >= d || k >= I && P >= k || I > d && k > P) && (l >= D && R >= l || g >= D && R >= g || D > l && g > R);
                    default:
                        return !1
                }
            }
        }();
        i.ui.ddmanager = {
            current: null,
            droppables: {
                default: []
            },
            prepareOffsets: function(t, e) {
                var n, s, r = i.ui.ddmanager.droppables[t.options.scope] || [],
                    l = e ? e.type : null,
                    d = (t.currentItem || t.element).find(":data(ui-droppable)").addBack();
                t: for (n = 0; r.length > n; n++)
                    if (!(r[n].options.disabled || t && !r[n].accept.call(r[n].element[0], t.currentItem || t.element))) {
                        for (s = 0; d.length > s; s++)
                            if (d[s] === r[n].element[0]) {
                                r[n].proportions().height = 0;
                                continue t
                            }
                        r[n].visible = "none" !== r[n].element.css("display"), r[n].visible && ("mousedown" === l && r[n]._activate.call(r[n], e), r[n].offset = r[n].element.offset(), r[n].proportions({
                            width: r[n].element[0].offsetWidth,
                            height: r[n].element[0].offsetHeight
                        }))
                    }
            },
            drop: function(t, e) {
                var n = !1;
                return i.each((i.ui.ddmanager.droppables[t.options.scope] || []).slice(), function() {
                    this.options && (!this.options.disabled && this.visible && ot(t, this, this.options.tolerance, e) && (n = this._drop.call(this, e) || n), !this.options.disabled && this.visible && this.accept.call(this.element[0], t.currentItem || t.element) && (this.isout = !0, this.isover = !1, this._deactivate.call(this, e)))
                }), n
            },
            dragStart: function(t, e) {
                t.element.parentsUntil("body").on("scroll.droppable", function() {
                    t.options.refreshPositions || i.ui.ddmanager.prepareOffsets(t, e)
                })
            },
            drag: function(t, e) {
                t.options.refreshPositions && i.ui.ddmanager.prepareOffsets(t, e), i.each(i.ui.ddmanager.droppables[t.options.scope] || [], function() {
                    if (!this.options.disabled && !this.greedyChild && this.visible) {
                        var n, s, r, l = ot(t, this, this.options.tolerance, e),
                            d = !l && this.isover ? "isout" : l && !this.isover ? "isover" : null;
                        d && (this.options.greedy && (s = this.options.scope, (r = this.element.parents(":data(ui-droppable)").filter(function() {
                            return i(this).droppable("instance").options.scope === s
                        })).length && ((n = i(r[0]).droppable("instance")).greedyChild = "isover" === d)), n && "isover" === d && (n.isover = !1, n.isout = !0, n._out.call(n, e)), this[d] = !0, this["isout" === d ? "isover" : "isout"] = !1, this["isover" === d ? "_over" : "_out"].call(this, e), n && "isout" === d && (n.isout = !1, n.isover = !0, n._over.call(n, e)))
                    }
                })
            },
            dragStop: function(t, e) {
                t.element.parentsUntil("body").off("scroll.droppable"), t.options.refreshPositions || i.ui.ddmanager.prepareOffsets(t, e)
            }
        }, !1 !== i.uiBackCompat && i.widget("ui.droppable", i.ui.droppable, {
            options: {
                hoverClass: !1,
                activeClass: !1
            },
            _addActiveClass: function() {
                this._super(), this.options.activeClass && this.element.addClass(this.options.activeClass)
            },
            _removeActiveClass: function() {
                this._super(), this.options.activeClass && this.element.removeClass(this.options.activeClass)
            },
            _addHoverClass: function() {
                this._super(), this.options.hoverClass && this.element.addClass(this.options.hoverClass)
            },
            _removeHoverClass: function() {
                this._super(), this.options.hoverClass && this.element.removeClass(this.options.hoverClass)
            }
        }), i.widget("ui.progressbar", {
            version: "1.12.1",
            options: {
                classes: {
                    "ui-progressbar": "ui-corner-all",
                    "ui-progressbar-value": "ui-corner-left",
                    "ui-progressbar-complete": "ui-corner-right"
                },
                max: 100,
                value: 0,
                change: null,
                complete: null
            },
            min: 0,
            _create: function() {
                this.oldValue = this.options.value = this._constrainedValue(), this.element.attr({
                    role: "progressbar",
                    "aria-valuemin": this.min
                }), this._addClass("ui-progressbar", "ui-widget ui-widget-content"), this.valueDiv = i("<div>").appendTo(this.element), this._addClass(this.valueDiv, "ui-progressbar-value", "ui-widget-header"), this._refreshValue()
            },
            _destroy: function() {
                this.element.removeAttr("role aria-valuemin aria-valuemax aria-valuenow"), this.valueDiv.remove()
            },
            value: function(t) {
                return void 0 === t ? this.options.value : (this.options.value = this._constrainedValue(t), void this._refreshValue())
            },
            _constrainedValue: function(t) {
                return void 0 === t && (t = this.options.value), this.indeterminate = !1 === t, "number" != typeof t && (t = 0), !this.indeterminate && Math.min(this.options.max, Math.max(this.min, t))
            },
            _setOptions: function(t) {
                var e = t.value;
                delete t.value, this._super(t), this.options.value = this._constrainedValue(e), this._refreshValue()
            },
            _setOption: function(t, e) {
                "max" === t && (e = Math.max(this.min, e)), this._super(t, e)
            },
            _setOptionDisabled: function(t) {
                this._super(t), this.element.attr("aria-disabled", t), this._toggleClass(null, "ui-state-disabled", !!t)
            },
            _percentage: function() {
                return this.indeterminate ? 100 : 100 * (this.options.value - this.min) / (this.options.max - this.min)
            },
            _refreshValue: function() {
                var t = this.options.value,
                    e = this._percentage();
                this.valueDiv.toggle(this.indeterminate || t > this.min).width(e.toFixed(0) + "%"), this._toggleClass(this.valueDiv, "ui-progressbar-complete", null, t === this.options.max)._toggleClass("ui-progressbar-indeterminate", null, this.indeterminate), this.indeterminate ? (this.element.removeAttr("aria-valuenow"), this.overlayDiv || (this.overlayDiv = i("<div>").appendTo(this.valueDiv), this._addClass(this.overlayDiv, "ui-progressbar-overlay"))) : (this.element.attr({
                    "aria-valuemax": this.options.max,
                    "aria-valuenow": t
                }), this.overlayDiv && (this.overlayDiv.remove(), this.overlayDiv = null)), this.oldValue !== t && (this.oldValue = t, this._trigger("change")), t === this.options.max && this._trigger("complete")
            }
        }), i.widget("ui.selectable", i.ui.mouse, {
            version: "1.12.1",
            options: {
                appendTo: "body",
                autoRefresh: !0,
                distance: 0,
                filter: "*",
                tolerance: "touch",
                selected: null,
                selecting: null,
                start: null,
                stop: null,
                unselected: null,
                unselecting: null
            },
            _create: function() {
                var t = this;
                this._addClass("ui-selectable"), this.dragged = !1, this.refresh = function() {
                    t.elementPos = i(t.element[0]).offset(), t.selectees = i(t.options.filter, t.element[0]), t._addClass(t.selectees, "ui-selectee"), t.selectees.each(function() {
                        var e = i(this),
                            n = e.offset(),
                            s = {
                                left: n.left - t.elementPos.left,
                                top: n.top - t.elementPos.top
                            };
                        i.data(this, "selectable-item", {
                            element: this,
                            $element: e,
                            left: s.left,
                            top: s.top,
                            right: s.left + e.outerWidth(),
                            bottom: s.top + e.outerHeight(),
                            startselected: !1,
                            selected: e.hasClass("ui-selected"),
                            selecting: e.hasClass("ui-selecting"),
                            unselecting: e.hasClass("ui-unselecting")
                        })
                    })
                }, this.refresh(), this._mouseInit(), this.helper = i("<div>"), this._addClass(this.helper, "ui-selectable-helper")
            },
            _destroy: function() {
                this.selectees.removeData("selectable-item"), this._mouseDestroy()
            },
            _mouseStart: function(t) {
                var e = this,
                    n = this.options;
                this.opos = [t.pageX, t.pageY], this.elementPos = i(this.element[0]).offset(), this.options.disabled || (this.selectees = i(n.filter, this.element[0]), this._trigger("start", t), i(n.appendTo).append(this.helper), this.helper.css({
                    left: t.pageX,
                    top: t.pageY,
                    width: 0,
                    height: 0
                }), n.autoRefresh && this.refresh(), this.selectees.filter(".ui-selected").each(function() {
                    var s = i.data(this, "selectable-item");
                    s.startselected = !0, t.metaKey || t.ctrlKey || (e._removeClass(s.$element, "ui-selected"), s.selected = !1, e._addClass(s.$element, "ui-unselecting"), s.unselecting = !0, e._trigger("unselecting", t, {
                        unselecting: s.element
                    }))
                }), i(t.target).parents().addBack().each(function() {
                    var s, r = i.data(this, "selectable-item");
                    return r ? (s = !t.metaKey && !t.ctrlKey || !r.$element.hasClass("ui-selected"), e._removeClass(r.$element, s ? "ui-unselecting" : "ui-selected")._addClass(r.$element, s ? "ui-selecting" : "ui-unselecting"), r.unselecting = !s, r.selecting = s, r.selected = s, s ? e._trigger("selecting", t, {
                        selecting: r.element
                    }) : e._trigger("unselecting", t, {
                        unselecting: r.element
                    }), !1) : void 0
                }))
            },
            _mouseDrag: function(t) {
                if (this.dragged = !0, !this.options.disabled) {
                    var e, n = this,
                        s = this.options,
                        r = this.opos[0],
                        l = this.opos[1],
                        d = t.pageX,
                        g = t.pageY;
                    return r > d && (e = d, d = r, r = e), l > g && (e = g, g = l, l = e), this.helper.css({
                        left: r,
                        top: l,
                        width: d - r,
                        height: g - l
                    }), this.selectees.each(function() {
                        var k = i.data(this, "selectable-item"),
                            D = !1,
                            I = {};
                        k && k.element !== n.element[0] && (I.left = k.left + n.elementPos.left, I.right = k.right + n.elementPos.left, I.top = k.top + n.elementPos.top, I.bottom = k.bottom + n.elementPos.top, "touch" === s.tolerance ? D = !(I.left > d || r > I.right || I.top > g || l > I.bottom) : "fit" === s.tolerance && (D = I.left > r && d > I.right && I.top > l && g > I.bottom), D ? (k.selected && (n._removeClass(k.$element, "ui-selected"), k.selected = !1), k.unselecting && (n._removeClass(k.$element, "ui-unselecting"), k.unselecting = !1), k.selecting || (n._addClass(k.$element, "ui-selecting"), k.selecting = !0, n._trigger("selecting", t, {
                            selecting: k.element
                        }))) : (k.selecting && ((t.metaKey || t.ctrlKey) && k.startselected ? (n._removeClass(k.$element, "ui-selecting"), k.selecting = !1, n._addClass(k.$element, "ui-selected"), k.selected = !0) : (n._removeClass(k.$element, "ui-selecting"), k.selecting = !1, k.startselected && (n._addClass(k.$element, "ui-unselecting"), k.unselecting = !0), n._trigger("unselecting", t, {
                            unselecting: k.element
                        }))), k.selected && (t.metaKey || t.ctrlKey || k.startselected || (n._removeClass(k.$element, "ui-selected"), k.selected = !1, n._addClass(k.$element, "ui-unselecting"), k.unselecting = !0, n._trigger("unselecting", t, {
                            unselecting: k.element
                        })))))
                    }), !1
                }
            },
            _mouseStop: function(t) {
                var e = this;
                return this.dragged = !1, i(".ui-unselecting", this.element[0]).each(function() {
                    var n = i.data(this, "selectable-item");
                    e._removeClass(n.$element, "ui-unselecting"), n.unselecting = !1, n.startselected = !1, e._trigger("unselected", t, {
                        unselected: n.element
                    })
                }), i(".ui-selecting", this.element[0]).each(function() {
                    var n = i.data(this, "selectable-item");
                    e._removeClass(n.$element, "ui-selecting")._addClass(n.$element, "ui-selected"), n.selecting = !1, n.selected = !0, n.startselected = !0, e._trigger("selected", t, {
                        selected: n.element
                    })
                }), this._trigger("stop", t), this.helper.remove(), !1
            }
        }), i.widget("ui.selectmenu", [i.ui.formResetMixin, {
            version: "1.12.1",
            defaultElement: "<select>",
            options: {
                appendTo: null,
                classes: {
                    "ui-selectmenu-button-open": "ui-corner-top",
                    "ui-selectmenu-button-closed": "ui-corner-all"
                },
                disabled: null,
                icons: {
                    button: "ui-icon-triangle-1-s"
                },
                position: {
                    my: "left top",
                    at: "left bottom",
                    collision: "none"
                },
                width: !1,
                change: null,
                close: null,
                focus: null,
                open: null,
                select: null
            },
            _create: function() {
                var t = this.element.uniqueId().attr("id");
                this.ids = {
                    element: t,
                    button: t + "-button",
                    menu: t + "-menu"
                }, this._drawButton(), this._drawMenu(), this._bindFormResetHandler(), this._rendered = !1, this.menuItems = i()
            },
            _drawButton: function() {
                var t, e = this,
                    n = this._parseOption(this.element.find("option:selected"), this.element[0].selectedIndex);
                this.labels = this.element.labels().attr("for", this.ids.button), this._on(this.labels, {
                    click: function(s) {
                        this.button.focus(), s.preventDefault()
                    }
                }), this.element.hide(), this.button = i("<span>", {
                    tabindex: this.options.disabled ? -1 : 0,
                    id: this.ids.button,
                    role: "combobox",
                    "aria-expanded": "false",
                    "aria-autocomplete": "list",
                    "aria-owns": this.ids.menu,
                    "aria-haspopup": "true",
                    title: this.element.attr("title")
                }).insertAfter(this.element), this._addClass(this.button, "ui-selectmenu-button ui-selectmenu-button-closed", "ui-button ui-widget"), t = i("<span>").appendTo(this.button), this._addClass(t, "ui-selectmenu-icon", "ui-icon " + this.options.icons.button), this.buttonItem = this._renderButtonItem(n).appendTo(this.button), !1 !== this.options.width && this._resizeButton(), this._on(this.button, this._buttonEvents), this.button.one("focusin", function() {
                    e._rendered || e._refreshMenu()
                })
            },
            _drawMenu: function() {
                var t = this;
                this.menu = i("<ul>", {
                    "aria-hidden": "true",
                    "aria-labelledby": this.ids.button,
                    id: this.ids.menu
                }), this.menuWrap = i("<div>").append(this.menu), this._addClass(this.menuWrap, "ui-selectmenu-menu", "ui-front"), this.menuWrap.appendTo(this._appendTo()), this.menuInstance = this.menu.menu({
                    classes: {
                        "ui-menu": "ui-corner-bottom"
                    },
                    role: "listbox",
                    select: function(e, n) {
                        e.preventDefault(), t._setSelection(), t._select(n.item.data("ui-selectmenu-item"), e)
                    },
                    focus: function(e, n) {
                        var s = n.item.data("ui-selectmenu-item");
                        null != t.focusIndex && s.index !== t.focusIndex && (t._trigger("focus", e, {
                            item: s
                        }), t.isOpen || t._select(s, e)), t.focusIndex = s.index, t.button.attr("aria-activedescendant", t.menuItems.eq(s.index).attr("id"))
                    }
                }).menu("instance"), this.menuInstance._off(this.menu, "mouseleave"), this.menuInstance._closeOnDocumentClick = function() {
                    return !1
                }, this.menuInstance._isDivider = function() {
                    return !1
                }
            },
            refresh: function() {
                this._refreshMenu(), this.buttonItem.replaceWith(this.buttonItem = this._renderButtonItem(this._getSelectedItem().data("ui-selectmenu-item") || {})), null === this.options.width && this._resizeButton()
            },
            _refreshMenu: function() {
                var t, e = this.element.find("option");
                this.menu.empty(), this._parseOptions(e), this._renderMenu(this.menu, this.items), this.menuInstance.refresh(), this.menuItems = this.menu.find("li").not(".ui-selectmenu-optgroup").find(".ui-menu-item-wrapper"), this._rendered = !0, e.length && (t = this._getSelectedItem(), this.menuInstance.focus(null, t), this._setAria(t.data("ui-selectmenu-item")), this._setOption("disabled", this.element.prop("disabled")))
            },
            open: function(t) {
                this.options.disabled || (this._rendered ? (this._removeClass(this.menu.find(".ui-state-active"), null, "ui-state-active"), this.menuInstance.focus(null, this._getSelectedItem())) : this._refreshMenu(), this.menuItems.length && (this.isOpen = !0, this._toggleAttr(), this._resizeMenu(), this._position(), this._on(this.document, this._documentClick), this._trigger("open", t)))
            },
            _position: function() {
                this.menuWrap.position(i.extend({ of: this.button
                }, this.options.position))
            },
            close: function(t) {
                this.isOpen && (this.isOpen = !1, this._toggleAttr(), this.range = null, this._off(this.document), this._trigger("close", t))
            },
            widget: function() {
                return this.button
            },
            menuWidget: function() {
                return this.menu
            },
            _renderButtonItem: function(t) {
                var e = i("<span>");
                return this._setText(e, t.label), this._addClass(e, "ui-selectmenu-text"), e
            },
            _renderMenu: function(t, e) {
                var n = this,
                    s = "";
                i.each(e, function(r, l) {
                    var d;
                    l.optgroup !== s && (d = i("<li>", {
                        text: l.optgroup
                    }), n._addClass(d, "ui-selectmenu-optgroup", "ui-menu-divider" + (l.element.parent("optgroup").prop("disabled") ? " ui-state-disabled" : "")), d.appendTo(t), s = l.optgroup), n._renderItemData(t, l)
                })
            },
            _renderItemData: function(t, e) {
                return this._renderItem(t, e).data("ui-selectmenu-item", e)
            },
            _renderItem: function(t, e) {
                var n = i("<li>"),
                    s = i("<div>", {
                        title: e.element.attr("title")
                    });
                return e.disabled && this._addClass(n, null, "ui-state-disabled"), this._setText(s, e.label), n.append(s).appendTo(t)
            },
            _setText: function(t, e) {
                e ? t.text(e) : t.html("&#160;")
            },
            _move: function(t, e) {
                var n, s, r = ".ui-menu-item";
                this.isOpen ? n = this.menuItems.eq(this.focusIndex).parent("li") : (n = this.menuItems.eq(this.element[0].selectedIndex).parent("li"), r += ":not(.ui-state-disabled)"), (s = "first" === t || "last" === t ? n["first" === t ? "prevAll" : "nextAll"](r).eq(-1) : n[t + "All"](r).eq(0)).length && this.menuInstance.focus(e, s)
            },
            _getSelectedItem: function() {
                return this.menuItems.eq(this.element[0].selectedIndex).parent("li")
            },
            _toggle: function(t) {
                this[this.isOpen ? "close" : "open"](t)
            },
            _setSelection: function() {
                var t;
                this.range && (window.getSelection ? ((t = window.getSelection()).removeAllRanges(), t.addRange(this.range)) : this.range.select(), this.button.focus())
            },
            _documentClick: {
                mousedown: function(t) {
                    this.isOpen && (i(t.target).closest(".ui-selectmenu-menu, #" + i.ui.escapeSelector(this.ids.button)).length || this.close(t))
                }
            },
            _buttonEvents: {
                mousedown: function() {
                    var t;
                    window.getSelection ? (t = window.getSelection()).rangeCount && (this.range = t.getRangeAt(0)) : this.range = document.selection.createRange()
                },
                click: function(t) {
                    this._setSelection(), this._toggle(t)
                },
                keydown: function(t) {
                    var e = !0;
                    switch (t.keyCode) {
                        case i.ui.keyCode.TAB:
                        case i.ui.keyCode.ESCAPE:
                            this.close(t), e = !1;
                            break;
                        case i.ui.keyCode.ENTER:
                            this.isOpen && this._selectFocusedItem(t);
                            break;
                        case i.ui.keyCode.UP:
                            t.altKey ? this._toggle(t) : this._move("prev", t);
                            break;
                        case i.ui.keyCode.DOWN:
                            t.altKey ? this._toggle(t) : this._move("next", t);
                            break;
                        case i.ui.keyCode.SPACE:
                            this.isOpen ? this._selectFocusedItem(t) : this._toggle(t);
                            break;
                        case i.ui.keyCode.LEFT:
                            this._move("prev", t);
                            break;
                        case i.ui.keyCode.RIGHT:
                            this._move("next", t);
                            break;
                        case i.ui.keyCode.HOME:
                        case i.ui.keyCode.PAGE_UP:
                            this._move("first", t);
                            break;
                        case i.ui.keyCode.END:
                        case i.ui.keyCode.PAGE_DOWN:
                            this._move("last", t);
                            break;
                        default:
                            this.menu.trigger(t), e = !1
                    }
                    e && t.preventDefault()
                }
            },
            _selectFocusedItem: function(t) {
                var e = this.menuItems.eq(this.focusIndex).parent("li");
                e.hasClass("ui-state-disabled") || this._select(e.data("ui-selectmenu-item"), t)
            },
            _select: function(t, e) {
                var n = this.element[0].selectedIndex;
                this.element[0].selectedIndex = t.index, this.buttonItem.replaceWith(this.buttonItem = this._renderButtonItem(t)), this._setAria(t), this._trigger("select", e, {
                    item: t
                }), t.index !== n && this._trigger("change", e, {
                    item: t
                }), this.close(e)
            },
            _setAria: function(t) {
                var e = this.menuItems.eq(t.index).attr("id");
                this.button.attr({
                    "aria-labelledby": e,
                    "aria-activedescendant": e
                }), this.menu.attr("aria-activedescendant", e)
            },
            _setOption: function(t, e) {
                if ("icons" === t) {
                    var n = this.button.find("span.ui-icon");
                    this._removeClass(n, null, this.options.icons.button)._addClass(n, null, e.button)
                }
                this._super(t, e), "appendTo" === t && this.menuWrap.appendTo(this._appendTo()), "width" === t && this._resizeButton()
            },
            _setOptionDisabled: function(t) {
                this._super(t), this.menuInstance.option("disabled", t), this.button.attr("aria-disabled", t), this._toggleClass(this.button, null, "ui-state-disabled", t), this.element.prop("disabled", t), t ? (this.button.attr("tabindex", -1), this.close()) : this.button.attr("tabindex", 0)
            },
            _appendTo: function() {
                var t = this.options.appendTo;
                return t && (t = t.jquery || t.nodeType ? i(t) : this.document.find(t).eq(0)), t && t[0] || (t = this.element.closest(".ui-front, dialog")), t.length || (t = this.document[0].body), t
            },
            _toggleAttr: function() {
                this.button.attr("aria-expanded", this.isOpen), this._removeClass(this.button, "ui-selectmenu-button-" + (this.isOpen ? "closed" : "open"))._addClass(this.button, "ui-selectmenu-button-" + (this.isOpen ? "open" : "closed"))._toggleClass(this.menuWrap, "ui-selectmenu-open", null, this.isOpen), this.menu.attr("aria-hidden", !this.isOpen)
            },
            _resizeButton: function() {
                var t = this.options.width;
                return !1 === t ? void this.button.css("width", "") : (null === t && (t = this.element.show().outerWidth(), this.element.hide()), void this.button.outerWidth(t))
            },
            _resizeMenu: function() {
                this.menu.outerWidth(Math.max(this.button.outerWidth(), this.menu.width("").outerWidth() + 1))
            },
            _getCreateOptions: function() {
                var t = this._super();
                return t.disabled = this.element.prop("disabled"), t
            },
            _parseOptions: function(t) {
                var e = this,
                    n = [];
                t.each(function(s, r) {
                    n.push(e._parseOption(i(r), s))
                }), this.items = n
            },
            _parseOption: function(t, e) {
                var n = t.parent("optgroup");
                return {
                    element: t,
                    index: e,
                    value: t.val(),
                    label: t.text(),
                    optgroup: n.attr("label") || "",
                    disabled: n.prop("disabled") || t.prop("disabled")
                }
            },
            _destroy: function() {
                this._unbindFormResetHandler(), this.menuWrap.remove(), this.button.remove(), this.element.show(), this.element.removeUniqueId(), this.labels.attr("for", this.ids.element)
            }
        }]), i.widget("ui.slider", i.ui.mouse, {
            version: "1.12.1",
            widgetEventPrefix: "slide",
            options: {
                animate: !1,
                classes: {
                    "ui-slider": "ui-corner-all",
                    "ui-slider-handle": "ui-corner-all",
                    "ui-slider-range": "ui-corner-all ui-widget-header"
                },
                distance: 0,
                max: 100,
                min: 0,
                orientation: "horizontal",
                range: !1,
                step: 1,
                value: 0,
                values: null,
                change: null,
                slide: null,
                start: null,
                stop: null
            },
            numPages: 5,
            _create: function() {
                this._keySliding = !1, this._mouseSliding = !1, this._animateOff = !0, this._handleIndex = null, this._detectOrientation(), this._mouseInit(), this._calculateNewMax(), this._addClass("ui-slider ui-slider-" + this.orientation, "ui-widget ui-widget-content"), this._refresh(), this._animateOff = !1
            },
            _refresh: function() {
                this._createRange(), this._createHandles(), this._setupEvents(), this._refreshValue()
            },
            _createHandles: function() {
                var t, e, n = this.options,
                    s = this.element.find(".ui-slider-handle"),
                    l = [];
                for (s.length > (e = n.values && n.values.length || 1) && (s.slice(e).remove(), s = s.slice(0, e)), t = s.length; e > t; t++) l.push("<span tabindex='0'></span>");
                this.handles = s.add(i(l.join("")).appendTo(this.element)), this._addClass(this.handles, "ui-slider-handle", "ui-state-default"), this.handle = this.handles.eq(0), this.handles.each(function(d) {
                    i(this).data("ui-slider-handle-index", d).attr("tabIndex", 0)
                })
            },
            _createRange: function() {
                var t = this.options;
                t.range ? (!0 === t.range && (t.values ? t.values.length && 2 !== t.values.length ? t.values = [t.values[0], t.values[0]] : i.isArray(t.values) && (t.values = t.values.slice(0)) : t.values = [this._valueMin(), this._valueMin()]), this.range && this.range.length ? (this._removeClass(this.range, "ui-slider-range-min ui-slider-range-max"), this.range.css({
                    left: "",
                    bottom: ""
                })) : (this.range = i("<div>").appendTo(this.element), this._addClass(this.range, "ui-slider-range")), ("min" === t.range || "max" === t.range) && this._addClass(this.range, "ui-slider-range-" + t.range)) : (this.range && this.range.remove(), this.range = null)
            },
            _setupEvents: function() {
                this._off(this.handles), this._on(this.handles, this._handleEvents), this._hoverable(this.handles), this._focusable(this.handles)
            },
            _destroy: function() {
                this.handles.remove(), this.range && this.range.remove(), this._mouseDestroy()
            },
            _mouseCapture: function(t) {
                var n, s, r, l, g, k, D = this,
                    I = this.options;
                return !I.disabled && (this.elementSize = {
                    width: this.element.outerWidth(),
                    height: this.element.outerHeight()
                }, this.elementOffset = this.element.offset(), n = this._normValueFromMouse({
                    x: t.pageX,
                    y: t.pageY
                }), s = this._valueMax() - this._valueMin() + 1, this.handles.each(function(R) {
                    var P = Math.abs(n - D.values(R));
                    (s > P || s === P && (R === D._lastChangedValue || D.values(R) === I.min)) && (s = P, r = i(this), l = R)
                }), !1 !== this._start(t, l) && (this._mouseSliding = !0, this._handleIndex = l, this._addClass(r, null, "ui-state-active"), r.trigger("focus"), g = r.offset(), k = !i(t.target).parents().addBack().is(".ui-slider-handle"), this._clickOffset = k ? {
                    left: 0,
                    top: 0
                } : {
                    left: t.pageX - g.left - r.width() / 2,
                    top: t.pageY - g.top - r.height() / 2 - (parseInt(r.css("borderTopWidth"), 10) || 0) - (parseInt(r.css("borderBottomWidth"), 10) || 0) + (parseInt(r.css("marginTop"), 10) || 0)
                }, this.handles.hasClass("ui-state-hover") || this._slide(t, l, n), this._animateOff = !0, !0))
            },
            _mouseStart: function() {
                return !0
            },
            _mouseDrag: function(t) {
                var n = this._normValueFromMouse({
                    x: t.pageX,
                    y: t.pageY
                });
                return this._slide(t, this._handleIndex, n), !1
            },
            _mouseStop: function(t) {
                return this._removeClass(this.handles, null, "ui-state-active"), this._mouseSliding = !1, this._stop(t, this._handleIndex), this._change(t, this._handleIndex), this._handleIndex = null, this._clickOffset = null, this._animateOff = !1, !1
            },
            _detectOrientation: function() {
                this.orientation = "vertical" === this.options.orientation ? "vertical" : "horizontal"
            },
            _normValueFromMouse: function(t) {
                var e, n, s, r, l;
                return "horizontal" === this.orientation ? (e = this.elementSize.width, n = t.x - this.elementOffset.left - (this._clickOffset ? this._clickOffset.left : 0)) : (e = this.elementSize.height, n = t.y - this.elementOffset.top - (this._clickOffset ? this._clickOffset.top : 0)), (s = n / e) > 1 && (s = 1), 0 > s && (s = 0), "vertical" === this.orientation && (s = 1 - s), r = this._valueMax() - this._valueMin(), l = this._valueMin() + s * r, this._trimAlignValue(l)
            },
            _uiHash: function(t, e, n) {
                var s = {
                    handle: this.handles[t],
                    handleIndex: t,
                    value: void 0 !== e ? e : this.value()
                };
                return this._hasMultipleValues() && (s.value = void 0 !== e ? e : this.values(t), s.values = n || this.values()), s
            },
            _hasMultipleValues: function() {
                return this.options.values && this.options.values.length
            },
            _start: function(t, e) {
                return this._trigger("start", t, this._uiHash(e))
            },
            _slide: function(t, e, n) {
                var r, l = this.value(),
                    d = this.values();
                this._hasMultipleValues() && (r = this.values(e ? 0 : 1), l = this.values(e), 2 === this.options.values.length && !0 === this.options.range && (n = 0 === e ? Math.min(r, n) : Math.max(r, n)), d[e] = n), n !== l && !1 !== this._trigger("slide", t, this._uiHash(e, n, d)) && (this._hasMultipleValues() ? this.values(e, n) : this.value(n))
            },
            _stop: function(t, e) {
                this._trigger("stop", t, this._uiHash(e))
            },
            _change: function(t, e) {
                this._keySliding || this._mouseSliding || (this._lastChangedValue = e, this._trigger("change", t, this._uiHash(e)))
            },
            value: function(t) {
                return arguments.length ? (this.options.value = this._trimAlignValue(t), this._refreshValue(), void this._change(null, 0)) : this._value()
            },
            values: function(t, e) {
                var n, s, r;
                if (arguments.length > 1) return this.options.values[t] = this._trimAlignValue(e), this._refreshValue(), void this._change(null, t);
                if (!arguments.length) return this._values();
                if (!i.isArray(arguments[0])) return this._hasMultipleValues() ? this._values(t) : this.value();
                for (n = this.options.values, s = arguments[0], r = 0; n.length > r; r += 1) n[r] = this._trimAlignValue(s[r]), this._change(null, r);
                this._refreshValue()
            },
            _setOption: function(t, e) {
                var n, s = 0;
                switch ("range" === t && !0 === this.options.range && ("min" === e ? (this.options.value = this._values(0), this.options.values = null) : "max" === e && (this.options.value = this._values(this.options.values.length - 1), this.options.values = null)), i.isArray(this.options.values) && (s = this.options.values.length), this._super(t, e), t) {
                    case "orientation":
                        this._detectOrientation(), this._removeClass("ui-slider-horizontal ui-slider-vertical")._addClass("ui-slider-" + this.orientation), this._refreshValue(), this.options.range && this._refreshRange(e), this.handles.css("horizontal" === e ? "bottom" : "left", "");
                        break;
                    case "value":
                        this._animateOff = !0, this._refreshValue(), this._change(null, 0), this._animateOff = !1;
                        break;
                    case "values":
                        for (this._animateOff = !0, this._refreshValue(), n = s - 1; n >= 0; n--) this._change(null, n);
                        this._animateOff = !1;
                        break;
                    case "step":
                    case "min":
                    case "max":
                        this._animateOff = !0, this._calculateNewMax(), this._refreshValue(), this._animateOff = !1;
                        break;
                    case "range":
                        this._animateOff = !0, this._refresh(), this._animateOff = !1
                }
            },
            _setOptionDisabled: function(t) {
                this._super(t), this._toggleClass(null, "ui-state-disabled", !!t)
            },
            _value: function() {
                return this._trimAlignValue(this.options.value)
            },
            _values: function(t) {
                var n, s;
                if (arguments.length) return this._trimAlignValue(this.options.values[t]);
                if (this._hasMultipleValues()) {
                    for (n = this.options.values.slice(), s = 0; n.length > s; s += 1) n[s] = this._trimAlignValue(n[s]);
                    return n
                }
                return []
            },
            _trimAlignValue: function(t) {
                if (this._valueMin() >= t) return this._valueMin();
                if (t >= this._valueMax()) return this._valueMax();
                var e = this.options.step > 0 ? this.options.step : 1,
                    n = (t - this._valueMin()) % e,
                    s = t - n;
                return 2 * Math.abs(n) >= e && (s += n > 0 ? e : -e), parseFloat(s.toFixed(5))
            },
            _calculateNewMax: function() {
                var t = this.options.max,
                    e = this._valueMin(),
                    n = this.options.step;
                (t = Math.round((t - e) / n) * n + e) > this.options.max && (t -= n), this.max = parseFloat(t.toFixed(this._precision()))
            },
            _precision: function() {
                var t = this._precisionOf(this.options.step);
                return null !== this.options.min && (t = Math.max(t, this._precisionOf(this.options.min))), t
            },
            _precisionOf: function(t) {
                var e = "" + t,
                    n = e.indexOf(".");
                return -1 === n ? 0 : e.length - n - 1
            },
            _valueMin: function() {
                return this.options.min
            },
            _valueMax: function() {
                return this.max
            },
            _refreshRange: function(t) {
                "vertical" === t && this.range.css({
                    width: "",
                    left: ""
                }), "horizontal" === t && this.range.css({
                    height: "",
                    bottom: ""
                })
            },
            _refreshValue: function() {
                var t, e, n, s, r, l = this.options.range,
                    d = this.options,
                    g = this,
                    k = !this._animateOff && d.animate,
                    D = {};
                this._hasMultipleValues() ? this.handles.each(function(I) {
                    e = (g.values(I) - g._valueMin()) / (g._valueMax() - g._valueMin()) * 100, D["horizontal" === g.orientation ? "left" : "bottom"] = e + "%", i(this).stop(1, 1)[k ? "animate" : "css"](D, d.animate), !0 === g.options.range && ("horizontal" === g.orientation ? (0 === I && g.range.stop(1, 1)[k ? "animate" : "css"]({
                        left: e + "%"
                    }, d.animate), 1 === I && g.range[k ? "animate" : "css"]({
                        width: e - t + "%"
                    }, {
                        queue: !1,
                        duration: d.animate
                    })) : (0 === I && g.range.stop(1, 1)[k ? "animate" : "css"]({
                        bottom: e + "%"
                    }, d.animate), 1 === I && g.range[k ? "animate" : "css"]({
                        height: e - t + "%"
                    }, {
                        queue: !1,
                        duration: d.animate
                    }))), t = e
                }) : (n = this.value(), s = this._valueMin(), r = this._valueMax(), D["horizontal" === this.orientation ? "left" : "bottom"] = (e = r !== s ? (n - s) / (r - s) * 100 : 0) + "%", this.handle.stop(1, 1)[k ? "animate" : "css"](D, d.animate), "min" === l && "horizontal" === this.orientation && this.range.stop(1, 1)[k ? "animate" : "css"]({
                    width: e + "%"
                }, d.animate), "max" === l && "horizontal" === this.orientation && this.range.stop(1, 1)[k ? "animate" : "css"]({
                    width: 100 - e + "%"
                }, d.animate), "min" === l && "vertical" === this.orientation && this.range.stop(1, 1)[k ? "animate" : "css"]({
                    height: e + "%"
                }, d.animate), "max" === l && "vertical" === this.orientation && this.range.stop(1, 1)[k ? "animate" : "css"]({
                    height: 100 - e + "%"
                }, d.animate))
            },
            _handleEvents: {
                keydown: function(t) {
                    var n, s, r, l = i(t.target).data("ui-slider-handle-index");
                    switch (t.keyCode) {
                        case i.ui.keyCode.HOME:
                        case i.ui.keyCode.END:
                        case i.ui.keyCode.PAGE_UP:
                        case i.ui.keyCode.PAGE_DOWN:
                        case i.ui.keyCode.UP:
                        case i.ui.keyCode.RIGHT:
                        case i.ui.keyCode.DOWN:
                        case i.ui.keyCode.LEFT:
                            if (t.preventDefault(), !this._keySliding && (this._keySliding = !0, this._addClass(i(t.target), null, "ui-state-active"), !1 === this._start(t, l))) return
                    }
                    switch (r = this.options.step, n = s = this._hasMultipleValues() ? this.values(l) : this.value(), t.keyCode) {
                        case i.ui.keyCode.HOME:
                            s = this._valueMin();
                            break;
                        case i.ui.keyCode.END:
                            s = this._valueMax();
                            break;
                        case i.ui.keyCode.PAGE_UP:
                            s = this._trimAlignValue(n + (this._valueMax() - this._valueMin()) / this.numPages);
                            break;
                        case i.ui.keyCode.PAGE_DOWN:
                            s = this._trimAlignValue(n - (this._valueMax() - this._valueMin()) / this.numPages);
                            break;
                        case i.ui.keyCode.UP:
                        case i.ui.keyCode.RIGHT:
                            if (n === this._valueMax()) return;
                            s = this._trimAlignValue(n + r);
                            break;
                        case i.ui.keyCode.DOWN:
                        case i.ui.keyCode.LEFT:
                            if (n === this._valueMin()) return;
                            s = this._trimAlignValue(n - r)
                    }
                    this._slide(t, l, s)
                },
                keyup: function(t) {
                    var e = i(t.target).data("ui-slider-handle-index");
                    this._keySliding && (this._keySliding = !1, this._stop(t, e), this._change(t, e), this._removeClass(i(t.target), null, "ui-state-active"))
                }
            }
        }), i.widget("ui.sortable", i.ui.mouse, {
            version: "1.12.1",
            widgetEventPrefix: "sort",
            ready: !1,
            options: {
                appendTo: "parent",
                axis: !1,
                connectWith: !1,
                containment: !1,
                cursor: "auto",
                cursorAt: !1,
                dropOnEmpty: !0,
                forcePlaceholderSize: !1,
                forceHelperSize: !1,
                grid: !1,
                handle: !1,
                helper: "original",
                items: "> *",
                opacity: !1,
                placeholder: !1,
                revert: !1,
                scroll: !0,
                scrollSensitivity: 20,
                scrollSpeed: 20,
                scope: "default",
                tolerance: "intersect",
                zIndex: 1e3,
                activate: null,
                beforeStop: null,
                change: null,
                deactivate: null,
                out: null,
                over: null,
                receive: null,
                remove: null,
                sort: null,
                start: null,
                stop: null,
                update: null
            },
            _isOverAxis: function(t, e, n) {
                return t >= e && e + n > t
            },
            _isFloating: function(t) {
                return /left|right/.test(t.css("float")) || /inline|table-cell/.test(t.css("display"))
            },
            _create: function() {
                this.containerCache = {}, this._addClass("ui-sortable"), this.refresh(), this.offset = this.element.offset(), this._mouseInit(), this._setHandleClassName(), this.ready = !0
            },
            _setOption: function(t, e) {
                this._super(t, e), "handle" === t && this._setHandleClassName()
            },
            _setHandleClassName: function() {
                var t = this;
                this._removeClass(this.element.find(".ui-sortable-handle"), "ui-sortable-handle"), i.each(this.items, function() {
                    t._addClass(this.instance.options.handle ? this.item.find(this.instance.options.handle) : this.item, "ui-sortable-handle")
                })
            },
            _destroy: function() {
                this._mouseDestroy();
                for (var t = this.items.length - 1; t >= 0; t--) this.items[t].item.removeData(this.widgetName + "-item");
                return this
            },
            _mouseCapture: function(t, e) {
                var n = null,
                    s = !1,
                    r = this;
                return !(this.reverting || this.options.disabled || "static" === this.options.type || (this._refreshItems(t), i(t.target).parents().each(function() {
                    return i.data(this, r.widgetName + "-item") === r ? (n = i(this), !1) : void 0
                }), i.data(t.target, r.widgetName + "-item") === r && (n = i(t.target)), !n || this.options.handle && !e && (i(this.options.handle, n).find("*").addBack().each(function() {
                    this === t.target && (s = !0)
                }), !s) || (this.currentItem = n, this._removeCurrentsFromItems(), 0)))
            },
            _mouseStart: function(t, e, n) {
                var s, r, l = this.options;
                if (this.currentContainer = this, this.refreshPositions(), this.helper = this._createHelper(t), this._cacheHelperProportions(), this._cacheMargins(), this.scrollParent = this.helper.scrollParent(), this.offset = this.currentItem.offset(), this.offset = {
                        top: this.offset.top - this.margins.top,
                        left: this.offset.left - this.margins.left
                    }, i.extend(this.offset, {
                        click: {
                            left: t.pageX - this.offset.left,
                            top: t.pageY - this.offset.top
                        },
                        parent: this._getParentOffset(),
                        relative: this._getRelativeOffset()
                    }), this.helper.css("position", "absolute"), this.cssPosition = this.helper.css("position"), this.originalPosition = this._generatePosition(t), this.originalPageX = t.pageX, this.originalPageY = t.pageY, l.cursorAt && this._adjustOffsetFromHelper(l.cursorAt), this.domPosition = {
                        prev: this.currentItem.prev()[0],
                        parent: this.currentItem.parent()[0]
                    }, this.helper[0] !== this.currentItem[0] && this.currentItem.hide(), this._createPlaceholder(), l.containment && this._setContainment(), l.cursor && "auto" !== l.cursor && (r = this.document.find("body"), this.storedCursor = r.css("cursor"), r.css("cursor", l.cursor), this.storedStylesheet = i("<style>*{ cursor: " + l.cursor + " !important; }</style>").appendTo(r)), l.opacity && (this.helper.css("opacity") && (this._storedOpacity = this.helper.css("opacity")), this.helper.css("opacity", l.opacity)), l.zIndex && (this.helper.css("zIndex") && (this._storedZIndex = this.helper.css("zIndex")), this.helper.css("zIndex", l.zIndex)), this.scrollParent[0] !== this.document[0] && "HTML" !== this.scrollParent[0].tagName && (this.overflowOffset = this.scrollParent.offset()), this._trigger("start", t, this._uiHash()), this._preserveHelperProportions || this._cacheHelperProportions(), !n)
                    for (s = this.containers.length - 1; s >= 0; s--) this.containers[s]._trigger("activate", t, this._uiHash(this));
                return i.ui.ddmanager && (i.ui.ddmanager.current = this), i.ui.ddmanager && !l.dropBehaviour && i.ui.ddmanager.prepareOffsets(this, t), this.dragging = !0, this._addClass(this.helper, "ui-sortable-helper"), this._mouseDrag(t), !0
            },
            _mouseDrag: function(t) {
                var e, n, s, r, l = this.options,
                    d = !1;
                for (this.position = this._generatePosition(t), this.positionAbs = this._convertPositionTo("absolute"), this.lastPositionAbs || (this.lastPositionAbs = this.positionAbs), this.options.scroll && (this.scrollParent[0] !== this.document[0] && "HTML" !== this.scrollParent[0].tagName ? (this.overflowOffset.top + this.scrollParent[0].offsetHeight - t.pageY < l.scrollSensitivity ? this.scrollParent[0].scrollTop = d = this.scrollParent[0].scrollTop + l.scrollSpeed : t.pageY - this.overflowOffset.top < l.scrollSensitivity && (this.scrollParent[0].scrollTop = d = this.scrollParent[0].scrollTop - l.scrollSpeed), this.overflowOffset.left + this.scrollParent[0].offsetWidth - t.pageX < l.scrollSensitivity ? this.scrollParent[0].scrollLeft = d = this.scrollParent[0].scrollLeft + l.scrollSpeed : t.pageX - this.overflowOffset.left < l.scrollSensitivity && (this.scrollParent[0].scrollLeft = d = this.scrollParent[0].scrollLeft - l.scrollSpeed)) : (t.pageY - this.document.scrollTop() < l.scrollSensitivity ? d = this.document.scrollTop(this.document.scrollTop() - l.scrollSpeed) : this.window.height() - (t.pageY - this.document.scrollTop()) < l.scrollSensitivity && (d = this.document.scrollTop(this.document.scrollTop() + l.scrollSpeed)), t.pageX - this.document.scrollLeft() < l.scrollSensitivity ? d = this.document.scrollLeft(this.document.scrollLeft() - l.scrollSpeed) : this.window.width() - (t.pageX - this.document.scrollLeft()) < l.scrollSensitivity && (d = this.document.scrollLeft(this.document.scrollLeft() + l.scrollSpeed))), !1 !== d && i.ui.ddmanager && !l.dropBehaviour && i.ui.ddmanager.prepareOffsets(this, t)), this.positionAbs = this._convertPositionTo("absolute"), this.options.axis && "y" === this.options.axis || (this.helper[0].style.left = this.position.left + "px"), this.options.axis && "x" === this.options.axis || (this.helper[0].style.top = this.position.top + "px"), e = this.items.length - 1; e >= 0; e--)
                    if (s = (n = this.items[e]).item[0], (r = this._intersectsWithPointer(n)) && n.instance === this.currentContainer && s !== this.currentItem[0] && this.placeholder[1 === r ? "next" : "prev"]()[0] !== s && !i.contains(this.placeholder[0], s) && ("semi-dynamic" !== this.options.type || !i.contains(this.element[0], s))) {
                        if (this.direction = 1 === r ? "down" : "up", "pointer" !== this.options.tolerance && !this._intersectsWithSides(n)) break;
                        this._rearrange(t, n), this._trigger("change", t, this._uiHash());
                        break
                    }
                return this._contactContainers(t), i.ui.ddmanager && i.ui.ddmanager.drag(this, t), this._trigger("sort", t, this._uiHash()), this.lastPositionAbs = this.positionAbs, !1
            },
            _mouseStop: function(t, e) {
                if (t) {
                    if (i.ui.ddmanager && !this.options.dropBehaviour && i.ui.ddmanager.drop(this, t), this.options.revert) {
                        var n = this,
                            s = this.placeholder.offset(),
                            r = this.options.axis,
                            l = {};
                        r && "x" !== r || (l.left = s.left - this.offset.parent.left - this.margins.left + (this.offsetParent[0] === this.document[0].body ? 0 : this.offsetParent[0].scrollLeft)), r && "y" !== r || (l.top = s.top - this.offset.parent.top - this.margins.top + (this.offsetParent[0] === this.document[0].body ? 0 : this.offsetParent[0].scrollTop)), this.reverting = !0, i(this.helper).animate(l, parseInt(this.options.revert, 10) || 500, function() {
                            n._clear(t)
                        })
                    } else this._clear(t, e);
                    return !1
                }
            },
            cancel: function() {
                if (this.dragging) {
                    this._mouseUp(new i.Event("mouseup", {
                        target: null
                    })), "original" === this.options.helper ? (this.currentItem.css(this._storedCSS), this._removeClass(this.currentItem, "ui-sortable-helper")) : this.currentItem.show();
                    for (var t = this.containers.length - 1; t >= 0; t--) this.containers[t]._trigger("deactivate", null, this._uiHash(this)), this.containers[t].containerCache.over && (this.containers[t]._trigger("out", null, this._uiHash(this)), this.containers[t].containerCache.over = 0)
                }
                return this.placeholder && (this.placeholder[0].parentNode && this.placeholder[0].parentNode.removeChild(this.placeholder[0]), "original" !== this.options.helper && this.helper && this.helper[0].parentNode && this.helper.remove(), i.extend(this, {
                    helper: null,
                    dragging: !1,
                    reverting: !1,
                    _noFinalSort: null
                }), this.domPosition.prev ? i(this.domPosition.prev).after(this.currentItem) : i(this.domPosition.parent).prepend(this.currentItem)), this
            },
            serialize: function(t) {
                var e = this._getItemsAsjQuery(t && t.connected),
                    n = [];
                return t = t || {}, i(e).each(function() {
                    var s = (i(t.item || this).attr(t.attribute || "id") || "").match(t.expression || /(.+)[\-=_](.+)/);
                    s && n.push((t.key || s[1] + "[]") + "=" + (t.key && t.expression ? s[1] : s[2]))
                }), !n.length && t.key && n.push(t.key + "="), n.join("&")
            },
            toArray: function(t) {
                var e = this._getItemsAsjQuery(t && t.connected),
                    n = [];
                return t = t || {}, e.each(function() {
                    n.push(i(t.item || this).attr(t.attribute || "id") || "")
                }), n
            },
            _intersectsWith: function(t) {
                var e = this.positionAbs.left,
                    s = this.positionAbs.top,
                    l = t.left,
                    d = l + t.width,
                    g = t.top,
                    k = g + t.height,
                    D = this.offset.click.top,
                    I = this.offset.click.left;
                return "pointer" === this.options.tolerance || this.options.forcePointerForContainers || "pointer" !== this.options.tolerance && this.helperProportions[this.floating ? "width" : "height"] > t[this.floating ? "width" : "height"] ? ("x" === this.options.axis || s + D > g && k > s + D) && ("y" === this.options.axis || e + I > l && d > e + I) : e + this.helperProportions.width / 2 > l && d > e + this.helperProportions.width - this.helperProportions.width / 2 && s + this.helperProportions.height / 2 > g && k > s + this.helperProportions.height - this.helperProportions.height / 2
            },
            _intersectsWithPointer: function(t) {
                var e, n, s = "x" === this.options.axis || this._isOverAxis(this.positionAbs.top + this.offset.click.top, t.top, t.height),
                    r = "y" === this.options.axis || this._isOverAxis(this.positionAbs.left + this.offset.click.left, t.left, t.width);
                return !(!s || !r) && (e = this._getDragVerticalDirection(), n = this._getDragHorizontalDirection(), this.floating ? "right" === n || "down" === e ? 2 : 1 : e && ("down" === e ? 2 : 1))
            },
            _intersectsWithSides: function(t) {
                var e = this._isOverAxis(this.positionAbs.top + this.offset.click.top, t.top + t.height / 2, t.height),
                    n = this._isOverAxis(this.positionAbs.left + this.offset.click.left, t.left + t.width / 2, t.width),
                    s = this._getDragVerticalDirection(),
                    r = this._getDragHorizontalDirection();
                return this.floating && r ? "right" === r && n || "left" === r && !n : s && ("down" === s && e || "up" === s && !e)
            },
            _getDragVerticalDirection: function() {
                var t = this.positionAbs.top - this.lastPositionAbs.top;
                return 0 !== t && (t > 0 ? "down" : "up")
            },
            _getDragHorizontalDirection: function() {
                var t = this.positionAbs.left - this.lastPositionAbs.left;
                return 0 !== t && (t > 0 ? "right" : "left")
            },
            refresh: function(t) {
                return this._refreshItems(t), this._setHandleClassName(), this.refreshPositions(), this
            },
            _connectWith: function() {
                var t = this.options;
                return t.connectWith.constructor === String ? [t.connectWith] : t.connectWith
            },
            _getItemsAsjQuery: function(t) {
                function e() {
                    d.push(this)
                }
                var n, s, r, l, d = [],
                    g = [],
                    k = this._connectWith();
                if (k && t)
                    for (n = k.length - 1; n >= 0; n--)
                        for (s = (r = i(k[n], this.document[0])).length - 1; s >= 0; s--)(l = i.data(r[s], this.widgetFullName)) && l !== this && !l.options.disabled && g.push([i.isFunction(l.options.items) ? l.options.items.call(l.element) : i(l.options.items, l.element).not(".ui-sortable-helper").not(".ui-sortable-placeholder"), l]);
                for (g.push([i.isFunction(this.options.items) ? this.options.items.call(this.element, null, {
                        options: this.options,
                        item: this.currentItem
                    }) : i(this.options.items, this.element).not(".ui-sortable-helper").not(".ui-sortable-placeholder"), this]), n = g.length - 1; n >= 0; n--) g[n][0].each(e);
                return i(d)
            },
            _removeCurrentsFromItems: function() {
                var t = this.currentItem.find(":data(" + this.widgetName + "-item)");
                this.items = i.grep(this.items, function(e) {
                    for (var n = 0; t.length > n; n++)
                        if (t[n] === e.item[0]) return !1;
                    return !0
                })
            },
            _refreshItems: function(t) {
                this.items = [], this.containers = [this];
                var e, n, s, r, l, d, g, k, D = this.items,
                    I = [
                        [i.isFunction(this.options.items) ? this.options.items.call(this.element[0], t, {
                            item: this.currentItem
                        }) : i(this.options.items, this.element), this]
                    ],
                    R = this._connectWith();
                if (R && this.ready)
                    for (e = R.length - 1; e >= 0; e--)
                        for (n = (s = i(R[e], this.document[0])).length - 1; n >= 0; n--)(r = i.data(s[n], this.widgetFullName)) && r !== this && !r.options.disabled && (I.push([i.isFunction(r.options.items) ? r.options.items.call(r.element[0], t, {
                            item: this.currentItem
                        }) : i(r.options.items, r.element), r]), this.containers.push(r));
                for (e = I.length - 1; e >= 0; e--)
                    for (l = I[e][1], n = 0, k = (d = I[e][0]).length; k > n; n++)(g = i(d[n])).data(this.widgetName + "-item", l), D.push({
                        item: g,
                        instance: l,
                        width: 0,
                        height: 0,
                        left: 0,
                        top: 0
                    })
            },
            refreshPositions: function(t) {
                var e, n, s, r;
                for (this.floating = !!this.items.length && ("x" === this.options.axis || this._isFloating(this.items[0].item)), this.offsetParent && this.helper && (this.offset.parent = this._getParentOffset()), e = this.items.length - 1; e >= 0; e--)(n = this.items[e]).instance !== this.currentContainer && this.currentContainer && n.item[0] !== this.currentItem[0] || (s = this.options.toleranceElement ? i(this.options.toleranceElement, n.item) : n.item, t || (n.width = s.outerWidth(), n.height = s.outerHeight()), r = s.offset(), n.left = r.left, n.top = r.top);
                if (this.options.custom && this.options.custom.refreshContainers) this.options.custom.refreshContainers.call(this);
                else
                    for (e = this.containers.length - 1; e >= 0; e--) r = this.containers[e].element.offset(), this.containers[e].containerCache.left = r.left, this.containers[e].containerCache.top = r.top, this.containers[e].containerCache.width = this.containers[e].element.outerWidth(), this.containers[e].containerCache.height = this.containers[e].element.outerHeight();
                return this
            },
            _createPlaceholder: function(t) {
                var e, n = (t = t || this).options;
                n.placeholder && n.placeholder.constructor !== String || (e = n.placeholder, n.placeholder = {
                    element: function() {
                        var s = t.currentItem[0].nodeName.toLowerCase(),
                            r = i("<" + s + ">", t.document[0]);
                        return t._addClass(r, "ui-sortable-placeholder", e || t.currentItem[0].className)._removeClass(r, "ui-sortable-helper"), "tbody" === s ? t._createTrPlaceholder(t.currentItem.find("tr").eq(0), i("<tr>", t.document[0]).appendTo(r)) : "tr" === s ? t._createTrPlaceholder(t.currentItem, r) : "img" === s && r.attr("src", t.currentItem.attr("src")), e || r.css("visibility", "hidden"), r
                    },
                    update: function(s, r) {
                        (!e || n.forcePlaceholderSize) && (r.height() || r.height(t.currentItem.innerHeight() - parseInt(t.currentItem.css("paddingTop") || 0, 10) - parseInt(t.currentItem.css("paddingBottom") || 0, 10)), r.width() || r.width(t.currentItem.innerWidth() - parseInt(t.currentItem.css("paddingLeft") || 0, 10) - parseInt(t.currentItem.css("paddingRight") || 0, 10)))
                    }
                }), t.placeholder = i(n.placeholder.element.call(t.element, t.currentItem)), t.currentItem.after(t.placeholder), n.placeholder.update(t, t.placeholder)
            },
            _createTrPlaceholder: function(t, e) {
                var n = this;
                t.children().each(function() {
                    i("<td>&#160;</td>", n.document[0]).attr("colspan", i(this).attr("colspan") || 1).appendTo(e)
                })
            },
            _contactContainers: function(t) {
                var e, n, s, r, l, d, g, k, D, I, R = null,
                    P = null;
                for (e = this.containers.length - 1; e >= 0; e--)
                    if (!i.contains(this.currentItem[0], this.containers[e].element[0]))
                        if (this._intersectsWith(this.containers[e].containerCache)) {
                            if (R && i.contains(this.containers[e].element[0], R.element[0])) continue;
                            R = this.containers[e], P = e
                        } else this.containers[e].containerCache.over && (this.containers[e]._trigger("out", t, this._uiHash(this)), this.containers[e].containerCache.over = 0);
                if (R)
                    if (1 === this.containers.length) this.containers[P].containerCache.over || (this.containers[P]._trigger("over", t, this._uiHash(this)), this.containers[P].containerCache.over = 1);
                    else {
                        for (s = 1e4, r = null, l = (D = R.floating || this._isFloating(this.currentItem)) ? "left" : "top", d = D ? "width" : "height", I = D ? "pageX" : "pageY", n = this.items.length - 1; n >= 0; n--) i.contains(this.containers[P].element[0], this.items[n].item[0]) && this.items[n].item[0] !== this.currentItem[0] && (g = this.items[n].item.offset()[l], k = !1, t[I] - g > this.items[n][d] / 2 && (k = !0), s > Math.abs(t[I] - g) && (s = Math.abs(t[I] - g), r = this.items[n], this.direction = k ? "up" : "down"));
                        if (!r && !this.options.dropOnEmpty) return;
                        if (this.currentContainer === this.containers[P]) return void(this.currentContainer.containerCache.over || (this.containers[P]._trigger("over", t, this._uiHash()), this.currentContainer.containerCache.over = 1));
                        r ? this._rearrange(t, r, null, !0) : this._rearrange(t, null, this.containers[P].element, !0), this._trigger("change", t, this._uiHash()), this.containers[P]._trigger("change", t, this._uiHash(this)), this.currentContainer = this.containers[P], this.options.placeholder.update(this.currentContainer, this.placeholder), this.containers[P]._trigger("over", t, this._uiHash(this)), this.containers[P].containerCache.over = 1
                    }
            },
            _createHelper: function(t) {
                var e = this.options,
                    n = i.isFunction(e.helper) ? i(e.helper.apply(this.element[0], [t, this.currentItem])) : "clone" === e.helper ? this.currentItem.clone() : this.currentItem;
                return n.parents("body").length || i("parent" !== e.appendTo ? e.appendTo : this.currentItem[0].parentNode)[0].appendChild(n[0]), n[0] === this.currentItem[0] && (this._storedCSS = {
                    width: this.currentItem[0].style.width,
                    height: this.currentItem[0].style.height,
                    position: this.currentItem.css("position"),
                    top: this.currentItem.css("top"),
                    left: this.currentItem.css("left")
                }), (!n[0].style.width || e.forceHelperSize) && n.width(this.currentItem.width()), (!n[0].style.height || e.forceHelperSize) && n.height(this.currentItem.height()), n
            },
            _adjustOffsetFromHelper: function(t) {
                "string" == typeof t && (t = t.split(" ")), i.isArray(t) && (t = {
                    left: +t[0],
                    top: +t[1] || 0
                }), "left" in t && (this.offset.click.left = t.left + this.margins.left), "right" in t && (this.offset.click.left = this.helperProportions.width - t.right + this.margins.left), "top" in t && (this.offset.click.top = t.top + this.margins.top), "bottom" in t && (this.offset.click.top = this.helperProportions.height - t.bottom + this.margins.top)
            },
            _getParentOffset: function() {
                this.offsetParent = this.helper.offsetParent();
                var t = this.offsetParent.offset();
                return "absolute" === this.cssPosition && this.scrollParent[0] !== this.document[0] && i.contains(this.scrollParent[0], this.offsetParent[0]) && (t.left += this.scrollParent.scrollLeft(), t.top += this.scrollParent.scrollTop()), (this.offsetParent[0] === this.document[0].body || this.offsetParent[0].tagName && "html" === this.offsetParent[0].tagName.toLowerCase() && i.ui.ie) && (t = {
                    top: 0,
                    left: 0
                }), {
                    top: t.top + (parseInt(this.offsetParent.css("borderTopWidth"), 10) || 0),
                    left: t.left + (parseInt(this.offsetParent.css("borderLeftWidth"), 10) || 0)
                }
            },
            _getRelativeOffset: function() {
                if ("relative" === this.cssPosition) {
                    var t = this.currentItem.position();
                    return {
                        top: t.top - (parseInt(this.helper.css("top"), 10) || 0) + this.scrollParent.scrollTop(),
                        left: t.left - (parseInt(this.helper.css("left"), 10) || 0) + this.scrollParent.scrollLeft()
                    }
                }
                return {
                    top: 0,
                    left: 0
                }
            },
            _cacheMargins: function() {
                this.margins = {
                    left: parseInt(this.currentItem.css("marginLeft"), 10) || 0,
                    top: parseInt(this.currentItem.css("marginTop"), 10) || 0
                }
            },
            _cacheHelperProportions: function() {
                this.helperProportions = {
                    width: this.helper.outerWidth(),
                    height: this.helper.outerHeight()
                }
            },
            _setContainment: function() {
                var t, e, n, s = this.options;
                "parent" === s.containment && (s.containment = this.helper[0].parentNode), ("document" === s.containment || "window" === s.containment) && (this.containment = [0 - this.offset.relative.left - this.offset.parent.left, 0 - this.offset.relative.top - this.offset.parent.top, "document" === s.containment ? this.document.width() : this.window.width() - this.helperProportions.width - this.margins.left, ("document" === s.containment ? this.document.height() || document.body.parentNode.scrollHeight : this.window.height() || this.document[0].body.parentNode.scrollHeight) - this.helperProportions.height - this.margins.top]), /^(document|window|parent)$/.test(s.containment) || (t = i(s.containment)[0], e = i(s.containment).offset(), n = "hidden" !== i(t).css("overflow"), this.containment = [e.left + (parseInt(i(t).css("borderLeftWidth"), 10) || 0) + (parseInt(i(t).css("paddingLeft"), 10) || 0) - this.margins.left, e.top + (parseInt(i(t).css("borderTopWidth"), 10) || 0) + (parseInt(i(t).css("paddingTop"), 10) || 0) - this.margins.top, e.left + (n ? Math.max(t.scrollWidth, t.offsetWidth) : t.offsetWidth) - (parseInt(i(t).css("borderLeftWidth"), 10) || 0) - (parseInt(i(t).css("paddingRight"), 10) || 0) - this.helperProportions.width - this.margins.left, e.top + (n ? Math.max(t.scrollHeight, t.offsetHeight) : t.offsetHeight) - (parseInt(i(t).css("borderTopWidth"), 10) || 0) - (parseInt(i(t).css("paddingBottom"), 10) || 0) - this.helperProportions.height - this.margins.top])
            },
            _convertPositionTo: function(t, e) {
                e || (e = this.position);
                var n = "absolute" === t ? 1 : -1,
                    s = "absolute" !== this.cssPosition || this.scrollParent[0] !== this.document[0] && i.contains(this.scrollParent[0], this.offsetParent[0]) ? this.scrollParent : this.offsetParent,
                    r = /(html|body)/i.test(s[0].tagName);
                return {
                    top: e.top + this.offset.relative.top * n + this.offset.parent.top * n - ("fixed" === this.cssPosition ? -this.scrollParent.scrollTop() : r ? 0 : s.scrollTop()) * n,
                    left: e.left + this.offset.relative.left * n + this.offset.parent.left * n - ("fixed" === this.cssPosition ? -this.scrollParent.scrollLeft() : r ? 0 : s.scrollLeft()) * n
                }
            },
            _generatePosition: function(t) {
                var e, n, s = this.options,
                    r = t.pageX,
                    l = t.pageY,
                    d = "absolute" !== this.cssPosition || this.scrollParent[0] !== this.document[0] && i.contains(this.scrollParent[0], this.offsetParent[0]) ? this.scrollParent : this.offsetParent,
                    g = /(html|body)/i.test(d[0].tagName);
                return "relative" !== this.cssPosition || this.scrollParent[0] !== this.document[0] && this.scrollParent[0] !== this.offsetParent[0] || (this.offset.relative = this._getRelativeOffset()), this.originalPosition && (this.containment && (t.pageX - this.offset.click.left < this.containment[0] && (r = this.containment[0] + this.offset.click.left), t.pageY - this.offset.click.top < this.containment[1] && (l = this.containment[1] + this.offset.click.top), t.pageX - this.offset.click.left > this.containment[2] && (r = this.containment[2] + this.offset.click.left), t.pageY - this.offset.click.top > this.containment[3] && (l = this.containment[3] + this.offset.click.top)), s.grid && (e = this.originalPageY + Math.round((l - this.originalPageY) / s.grid[1]) * s.grid[1], l = this.containment ? e - this.offset.click.top >= this.containment[1] && e - this.offset.click.top <= this.containment[3] ? e : e - this.offset.click.top >= this.containment[1] ? e - s.grid[1] : e + s.grid[1] : e, n = this.originalPageX + Math.round((r - this.originalPageX) / s.grid[0]) * s.grid[0], r = this.containment ? n - this.offset.click.left >= this.containment[0] && n - this.offset.click.left <= this.containment[2] ? n : n - this.offset.click.left >= this.containment[0] ? n - s.grid[0] : n + s.grid[0] : n)), {
                    top: l - this.offset.click.top - this.offset.relative.top - this.offset.parent.top + ("fixed" === this.cssPosition ? -this.scrollParent.scrollTop() : g ? 0 : d.scrollTop()),
                    left: r - this.offset.click.left - this.offset.relative.left - this.offset.parent.left + ("fixed" === this.cssPosition ? -this.scrollParent.scrollLeft() : g ? 0 : d.scrollLeft())
                }
            },
            _rearrange: function(t, e, n, s) {
                n ? n[0].appendChild(this.placeholder[0]) : e.item[0].parentNode.insertBefore(this.placeholder[0], "down" === this.direction ? e.item[0] : e.item[0].nextSibling), this.counter = this.counter ? ++this.counter : 1;
                var r = this.counter;
                this._delay(function() {
                    r === this.counter && this.refreshPositions(!s)
                })
            },
            _clear: function(t, e) {
                function n(l, d, g) {
                    return function(k) {
                        g._trigger(l, k, d._uiHash(d))
                    }
                }
                this.reverting = !1;
                var s, r = [];
                if (!this._noFinalSort && this.currentItem.parent().length && this.placeholder.before(this.currentItem), this._noFinalSort = null, this.helper[0] === this.currentItem[0]) {
                    for (s in this._storedCSS)("auto" === this._storedCSS[s] || "static" === this._storedCSS[s]) && (this._storedCSS[s] = "");
                    this.currentItem.css(this._storedCSS), this._removeClass(this.currentItem, "ui-sortable-helper")
                } else this.currentItem.show();
                for (this.fromOutside && !e && r.push(function(l) {
                        this._trigger("receive", l, this._uiHash(this.fromOutside))
                    }), !this.fromOutside && this.domPosition.prev === this.currentItem.prev().not(".ui-sortable-helper")[0] && this.domPosition.parent === this.currentItem.parent()[0] || e || r.push(function(l) {
                        this._trigger("update", l, this._uiHash())
                    }), this !== this.currentContainer && (e || (r.push(function(l) {
                        this._trigger("remove", l, this._uiHash())
                    }), r.push(function(l) {
                        return function(d) {
                            l._trigger("receive", d, this._uiHash(this))
                        }
                    }.call(this, this.currentContainer)), r.push(function(l) {
                        return function(d) {
                            l._trigger("update", d, this._uiHash(this))
                        }
                    }.call(this, this.currentContainer)))), s = this.containers.length - 1; s >= 0; s--) e || r.push(n("deactivate", this, this.containers[s])), this.containers[s].containerCache.over && (r.push(n("out", this, this.containers[s])), this.containers[s].containerCache.over = 0);
                if (this.storedCursor && (this.document.find("body").css("cursor", this.storedCursor), this.storedStylesheet.remove()), this._storedOpacity && this.helper.css("opacity", this._storedOpacity), this._storedZIndex && this.helper.css("zIndex", "auto" === this._storedZIndex ? "" : this._storedZIndex), this.dragging = !1, e || this._trigger("beforeStop", t, this._uiHash()), this.placeholder[0].parentNode.removeChild(this.placeholder[0]), this.cancelHelperRemoval || (this.helper[0] !== this.currentItem[0] && this.helper.remove(), this.helper = null), !e) {
                    for (s = 0; r.length > s; s++) r[s].call(this, t);
                    this._trigger("stop", t, this._uiHash())
                }
                return this.fromOutside = !1, !this.cancelHelperRemoval
            },
            _trigger: function() {
                !1 === i.Widget.prototype._trigger.apply(this, arguments) && this.cancel()
            },
            _uiHash: function(t) {
                var e = t || this;
                return {
                    helper: e.helper,
                    placeholder: e.placeholder || i([]),
                    position: e.position,
                    originalPosition: e.originalPosition,
                    offset: e.positionAbs,
                    item: e.currentItem,
                    sender: t ? t.element : null
                }
            }
        }), i.widget("ui.spinner", {
            version: "1.12.1",
            defaultElement: "<input>",
            widgetEventPrefix: "spin",
            options: {
                classes: {
                    "ui-spinner": "ui-corner-all",
                    "ui-spinner-down": "ui-corner-br",
                    "ui-spinner-up": "ui-corner-tr"
                },
                culture: null,
                icons: {
                    down: "ui-icon-triangle-1-s",
                    up: "ui-icon-triangle-1-n"
                },
                incremental: !0,
                max: null,
                min: null,
                numberFormat: null,
                page: 10,
                step: 1,
                change: null,
                spin: null,
                start: null,
                stop: null
            },
            _create: function() {
                this._setOption("max", this.options.max), this._setOption("min", this.options.min), this._setOption("step", this.options.step), "" !== this.value() && this._value(this.element.val(), !0), this._draw(), this._on(this._events), this._refresh(), this._on(this.window, {
                    beforeunload: function() {
                        this.element.removeAttr("autocomplete")
                    }
                })
            },
            _getCreateOptions: function() {
                var t = this._super(),
                    e = this.element;
                return i.each(["min", "max", "step"], function(n, s) {
                    var r = e.attr(s);
                    null != r && r.length && (t[s] = r)
                }), t
            },
            _events: {
                keydown: function(t) {
                    this._start(t) && this._keydown(t) && t.preventDefault()
                },
                keyup: "_stop",
                focus: function() {
                    this.previous = this.element.val()
                },
                blur: function(t) {
                    return this.cancelBlur ? void delete this.cancelBlur : (this._stop(), this._refresh(), void(this.previous !== this.element.val() && this._trigger("change", t)))
                },
                mousewheel: function(t, e) {
                    if (e) {
                        if (!this.spinning && !this._start(t)) return !1;
                        this._spin((e > 0 ? 1 : -1) * this.options.step, t), clearTimeout(this.mousewheelTimer), this.mousewheelTimer = this._delay(function() {
                            this.spinning && this._stop(t)
                        }, 100), t.preventDefault()
                    }
                },
                "mousedown .ui-spinner-button": function(t) {
                    function e() {
                        this.element[0] === i.ui.safeActiveElement(this.document[0]) || (this.element.trigger("focus"), this.previous = n, this._delay(function() {
                            this.previous = n
                        }))
                    }
                    var n;
                    n = this.element[0] === i.ui.safeActiveElement(this.document[0]) ? this.previous : this.element.val(), t.preventDefault(), e.call(this), this.cancelBlur = !0, this._delay(function() {
                        delete this.cancelBlur, e.call(this)
                    }), !1 !== this._start(t) && this._repeat(null, i(t.currentTarget).hasClass("ui-spinner-up") ? 1 : -1, t)
                },
                "mouseup .ui-spinner-button": "_stop",
                "mouseenter .ui-spinner-button": function(t) {
                    return i(t.currentTarget).hasClass("ui-state-active") ? !1 !== this._start(t) && void this._repeat(null, i(t.currentTarget).hasClass("ui-spinner-up") ? 1 : -1, t) : void 0
                },
                "mouseleave .ui-spinner-button": "_stop"
            },
            _enhance: function() {
                this.uiSpinner = this.element.attr("autocomplete", "off").wrap("<span>").parent().append("<a></a><a></a>")
            },
            _draw: function() {
                this._enhance(), this._addClass(this.uiSpinner, "ui-spinner", "ui-widget ui-widget-content"), this._addClass("ui-spinner-input"), this.element.attr("role", "spinbutton"), this.buttons = this.uiSpinner.children("a").attr("tabIndex", -1).attr("aria-hidden", !0).button({
                    classes: {
                        "ui-button": ""
                    }
                }), this._removeClass(this.buttons, "ui-corner-all"), this._addClass(this.buttons.first(), "ui-spinner-button ui-spinner-up"), this._addClass(this.buttons.last(), "ui-spinner-button ui-spinner-down"), this.buttons.first().button({
                    icon: this.options.icons.up,
                    showLabel: !1
                }), this.buttons.last().button({
                    icon: this.options.icons.down,
                    showLabel: !1
                }), this.buttons.height() > Math.ceil(.5 * this.uiSpinner.height()) && this.uiSpinner.height() > 0 && this.uiSpinner.height(this.uiSpinner.height())
            },
            _keydown: function(t) {
                var e = this.options,
                    n = i.ui.keyCode;
                switch (t.keyCode) {
                    case n.UP:
                        return this._repeat(null, 1, t), !0;
                    case n.DOWN:
                        return this._repeat(null, -1, t), !0;
                    case n.PAGE_UP:
                        return this._repeat(null, e.page, t), !0;
                    case n.PAGE_DOWN:
                        return this._repeat(null, -e.page, t), !0
                }
                return !1
            },
            _start: function(t) {
                return !(!this.spinning && !1 === this._trigger("start", t) || (this.counter || (this.counter = 1), this.spinning = !0, 0))
            },
            _repeat: function(t, e, n) {
                t = t || 500, clearTimeout(this.timer), this.timer = this._delay(function() {
                    this._repeat(40, e, n)
                }, t), this._spin(e * this.options.step, n)
            },
            _spin: function(t, e) {
                var n = this.value() || 0;
                this.counter || (this.counter = 1), n = this._adjustValue(n + t * this._increment(this.counter)), this.spinning && !1 === this._trigger("spin", e, {
                    value: n
                }) || (this._value(n), this.counter++)
            },
            _increment: function(t) {
                var e = this.options.incremental;
                return e ? i.isFunction(e) ? e(t) : Math.floor(t * t * t / 5e4 - t * t / 500 + 17 * t / 200 + 1) : 1
            },
            _precision: function() {
                var t = this._precisionOf(this.options.step);
                return null !== this.options.min && (t = Math.max(t, this._precisionOf(this.options.min))), t
            },
            _precisionOf: function(t) {
                var e = "" + t,
                    n = e.indexOf(".");
                return -1 === n ? 0 : e.length - n - 1
            },
            _adjustValue: function(t) {
                var e, n, s = this.options;
                return n = t - (e = null !== s.min ? s.min : 0), t = e + (n = Math.round(n / s.step) * s.step), t = parseFloat(t.toFixed(this._precision())), null !== s.max && t > s.max ? s.max : null !== s.min && s.min > t ? s.min : t
            },
            _stop: function(t) {
                this.spinning && (clearTimeout(this.timer), clearTimeout(this.mousewheelTimer), this.counter = 0, this.spinning = !1, this._trigger("stop", t))
            },
            _setOption: function(t, e) {
                var n, s, r;
                return "culture" === t || "numberFormat" === t ? (n = this._parse(this.element.val()), this.options[t] = e, void this.element.val(this._format(n))) : (("max" === t || "min" === t || "step" === t) && "string" == typeof e && (e = this._parse(e)), "icons" === t && (s = this.buttons.first().find(".ui-icon"), this._removeClass(s, null, this.options.icons.up), this._addClass(s, null, e.up), r = this.buttons.last().find(".ui-icon"), this._removeClass(r, null, this.options.icons.down), this._addClass(r, null, e.down)), void this._super(t, e))
            },
            _setOptionDisabled: function(t) {
                this._super(t), this._toggleClass(this.uiSpinner, null, "ui-state-disabled", !!t), this.element.prop("disabled", !!t), this.buttons.button(t ? "disable" : "enable")
            },
            _setOptions: x(function(t) {
                this._super(t)
            }),
            _parse: function(t) {
                return "string" == typeof t && "" !== t && (t = window.Globalize && this.options.numberFormat ? Globalize.parseFloat(t, 10, this.options.culture) : +t), "" === t || isNaN(t) ? null : t
            },
            _format: function(t) {
                return "" === t ? "" : window.Globalize && this.options.numberFormat ? Globalize.format(t, this.options.numberFormat, this.options.culture) : t
            },
            _refresh: function() {
                this.element.attr({
                    "aria-valuemin": this.options.min,
                    "aria-valuemax": this.options.max,
                    "aria-valuenow": this._parse(this.element.val())
                })
            },
            isValid: function() {
                var t = this.value();
                return null !== t && t === this._adjustValue(t)
            },
            _value: function(t, e) {
                var n;
                "" !== t && null !== (n = this._parse(t)) && (e || (n = this._adjustValue(n)), t = this._format(n)), this.element.val(t), this._refresh()
            },
            _destroy: function() {
                this.element.prop("disabled", !1).removeAttr("autocomplete role aria-valuemin aria-valuemax aria-valuenow"), this.uiSpinner.replaceWith(this.element)
            },
            stepUp: x(function(t) {
                this._stepUp(t)
            }),
            _stepUp: function(t) {
                this._start() && (this._spin((t || 1) * this.options.step), this._stop())
            },
            stepDown: x(function(t) {
                this._stepDown(t)
            }),
            _stepDown: function(t) {
                this._start() && (this._spin((t || 1) * -this.options.step), this._stop())
            },
            pageUp: x(function(t) {
                this._stepUp((t || 1) * this.options.page)
            }),
            pageDown: x(function(t) {
                this._stepDown((t || 1) * this.options.page)
            }),
            value: function(t) {
                return arguments.length ? void x(this._value).call(this, t) : this._parse(this.element.val())
            },
            widget: function() {
                return this.uiSpinner
            }
        }), !1 !== i.uiBackCompat && i.widget("ui.spinner", i.ui.spinner, {
            _enhance: function() {
                this.uiSpinner = this.element.attr("autocomplete", "off").wrap(this._uiSpinnerHtml()).parent().append(this._buttonHtml())
            },
            _uiSpinnerHtml: function() {
                return "<span>"
            },
            _buttonHtml: function() {
                return "<a></a><a></a>"
            }
        }), i.widget("ui.tabs", {
            version: "1.12.1",
            delay: 300,
            options: {
                active: null,
                classes: {
                    "ui-tabs": "ui-corner-all",
                    "ui-tabs-nav": "ui-corner-all",
                    "ui-tabs-panel": "ui-corner-bottom",
                    "ui-tabs-tab": "ui-corner-top"
                },
                collapsible: !1,
                event: "click",
                heightStyle: "content",
                hide: null,
                show: null,
                activate: null,
                beforeActivate: null,
                beforeLoad: null,
                load: null
            },
            _isLocal: function() {
                var t = /#.*$/;
                return function(e) {
                    var n, s;
                    n = e.href.replace(t, ""), s = location.href.replace(t, "");
                    try {
                        n = decodeURIComponent(n)
                    } catch (r) {}
                    try {
                        s = decodeURIComponent(s)
                    } catch (r) {}
                    return e.hash.length > 1 && n === s
                }
            }(),
            _create: function() {
                var t = this,
                    e = this.options;
                this.running = !1, this._addClass("ui-tabs", "ui-widget ui-widget-content"), this._toggleClass("ui-tabs-collapsible", null, e.collapsible), this._processTabs(), e.active = this._initialActive(), i.isArray(e.disabled) && (e.disabled = i.unique(e.disabled.concat(i.map(this.tabs.filter(".ui-state-disabled"), function(n) {
                    return t.tabs.index(n)
                }))).sort()), this.active = !1 !== this.options.active && this.anchors.length ? this._findActive(e.active) : i(), this._refresh(), this.active.length && this.load(e.active)
            },
            _initialActive: function() {
                var t = this.options.active,
                    e = this.options.collapsible,
                    n = location.hash.substring(1);
                return null === t && (n && this.tabs.each(function(s, r) {
                    return i(r).attr("aria-controls") === n ? (t = s, !1) : void 0
                }), null === t && (t = this.tabs.index(this.tabs.filter(".ui-tabs-active"))), (null === t || -1 === t) && (t = !!this.tabs.length && 0)), !1 !== t && -1 === (t = this.tabs.index(this.tabs.eq(t))) && (t = !e && 0), !e && !1 === t && this.anchors.length && (t = 0), t
            },
            _getCreateEventData: function() {
                return {
                    tab: this.active,
                    panel: this.active.length ? this._getPanelForTab(this.active) : i()
                }
            },
            _tabKeydown: function(t) {
                var e = i(i.ui.safeActiveElement(this.document[0])).closest("li"),
                    n = this.tabs.index(e),
                    s = !0;
                if (!this._handlePageNav(t)) {
                    switch (t.keyCode) {
                        case i.ui.keyCode.RIGHT:
                        case i.ui.keyCode.DOWN:
                            n++;
                            break;
                        case i.ui.keyCode.UP:
                        case i.ui.keyCode.LEFT:
                            s = !1, n--;
                            break;
                        case i.ui.keyCode.END:
                            n = this.anchors.length - 1;
                            break;
                        case i.ui.keyCode.HOME:
                            n = 0;
                            break;
                        case i.ui.keyCode.SPACE:
                            return t.preventDefault(), clearTimeout(this.activating), void this._activate(n);
                        case i.ui.keyCode.ENTER:
                            return t.preventDefault(), clearTimeout(this.activating), void this._activate(n !== this.options.active && n);
                        default:
                            return
                    }
                    t.preventDefault(), clearTimeout(this.activating), n = this._focusNextTab(n, s), t.ctrlKey || t.metaKey || (e.attr("aria-selected", "false"), this.tabs.eq(n).attr("aria-selected", "true"), this.activating = this._delay(function() {
                        this.option("active", n)
                    }, this.delay))
                }
            },
            _panelKeydown: function(t) {
                this._handlePageNav(t) || t.ctrlKey && t.keyCode === i.ui.keyCode.UP && (t.preventDefault(), this.active.trigger("focus"))
            },
            _handlePageNav: function(t) {
                return t.altKey && t.keyCode === i.ui.keyCode.PAGE_UP ? (this._activate(this._focusNextTab(this.options.active - 1, !1)), !0) : t.altKey && t.keyCode === i.ui.keyCode.PAGE_DOWN ? (this._activate(this._focusNextTab(this.options.active + 1, !0)), !0) : void 0
            },
            _findNextTab: function(t, e) {
                for (var s = this.tabs.length - 1; - 1 !== i.inArray((t > s && (t = 0), 0 > t && (t = s), t), this.options.disabled);) t = e ? t + 1 : t - 1;
                return t
            },
            _focusNextTab: function(t, e) {
                return t = this._findNextTab(t, e), this.tabs.eq(t).trigger("focus"), t
            },
            _setOption: function(t, e) {
                return "active" === t ? void this._activate(e) : (this._super(t, e), "collapsible" === t && (this._toggleClass("ui-tabs-collapsible", null, e), e || !1 !== this.options.active || this._activate(0)), "event" === t && this._setupEvents(e), void("heightStyle" === t && this._setupHeightStyle(e)))
            },
            _sanitizeSelector: function(t) {
                return t ? t.replace(/[!"$%&'()*+,.\/:;<=>?@\[\]\^`{|}~]/g, "\\$&") : ""
            },
            refresh: function() {
                var t = this.options,
                    e = this.tablist.children(":has(a[href])");
                t.disabled = i.map(e.filter(".ui-state-disabled"), function(n) {
                    return e.index(n)
                }), this._processTabs(), !1 !== t.active && this.anchors.length ? this.active.length && !i.contains(this.tablist[0], this.active[0]) ? this.tabs.length === t.disabled.length ? (t.active = !1, this.active = i()) : this._activate(this._findNextTab(Math.max(0, t.active - 1), !1)) : t.active = this.tabs.index(this.active) : (t.active = !1, this.active = i()), this._refresh()
            },
            _refresh: function() {
                this._setOptionDisabled(this.options.disabled), this._setupEvents(this.options.event), this._setupHeightStyle(this.options.heightStyle), this.tabs.not(this.active).attr({
                    "aria-selected": "false",
                    "aria-expanded": "false",
                    tabIndex: -1
                }), this.panels.not(this._getPanelForTab(this.active)).hide().attr({
                    "aria-hidden": "true"
                }), this.active.length ? (this.active.attr({
                    "aria-selected": "true",
                    "aria-expanded": "true",
                    tabIndex: 0
                }), this._addClass(this.active, "ui-tabs-active", "ui-state-active"), this._getPanelForTab(this.active).show().attr({
                    "aria-hidden": "false"
                })) : this.tabs.eq(0).attr("tabIndex", 0)
            },
            _processTabs: function() {
                var t = this,
                    e = this.tabs,
                    n = this.anchors,
                    s = this.panels;
                this.tablist = this._getList().attr("role", "tablist"), this._addClass(this.tablist, "ui-tabs-nav", "ui-helper-reset ui-helper-clearfix ui-widget-header"), this.tablist.on("mousedown" + this.eventNamespace, "> li", function(r) {
                    i(this).is(".ui-state-disabled") && r.preventDefault()
                }).on("focus" + this.eventNamespace, ".ui-tabs-anchor", function() {
                    i(this).closest("li").is(".ui-state-disabled") && this.blur()
                }), this.tabs = this.tablist.find("> li:has(a[href])").attr({
                    role: "tab",
                    tabIndex: -1
                }), this._addClass(this.tabs, "ui-tabs-tab", "ui-state-default"), this.anchors = this.tabs.map(function() {
                    return i("a", this)[0]
                }).attr({
                    role: "presentation",
                    tabIndex: -1
                }), this._addClass(this.anchors, "ui-tabs-anchor"), this.panels = i(), this.anchors.each(function(r, l) {
                    var d, g, k, D = i(l).uniqueId().attr("id"),
                        I = i(l).closest("li"),
                        R = I.attr("aria-controls");
                    t._isLocal(l) ? (k = (d = l.hash).substring(1), g = t.element.find(t._sanitizeSelector(d))) : (k = I.attr("aria-controls") || i({}).uniqueId()[0].id, (g = t.element.find(d = "#" + k)).length || (g = t._createPanel(k)).insertAfter(t.panels[r - 1] || t.tablist), g.attr("aria-live", "polite")), g.length && (t.panels = t.panels.add(g)), R && I.data("ui-tabs-aria-controls", R), I.attr({
                        "aria-controls": k,
                        "aria-labelledby": D
                    }), g.attr("aria-labelledby", D)
                }), this.panels.attr("role", "tabpanel"), this._addClass(this.panels, "ui-tabs-panel", "ui-widget-content"), e && (this._off(e.not(this.tabs)), this._off(n.not(this.anchors)), this._off(s.not(this.panels)))
            },
            _getList: function() {
                return this.tablist || this.element.find("ol, ul").eq(0)
            },
            _createPanel: function(t) {
                return i("<div>").attr("id", t).data("ui-tabs-destroy", !0)
            },
            _setOptionDisabled: function(t) {
                var e, n, s;
                for (i.isArray(t) && (t.length ? t.length === this.anchors.length && (t = !0) : t = !1), s = 0; n = this.tabs[s]; s++) e = i(n), !0 === t || -1 !== i.inArray(s, t) ? (e.attr("aria-disabled", "true"), this._addClass(e, null, "ui-state-disabled")) : (e.removeAttr("aria-disabled"), this._removeClass(e, null, "ui-state-disabled"));
                this.options.disabled = t, this._toggleClass(this.widget(), this.widgetFullName + "-disabled", null, !0 === t)
            },
            _setupEvents: function(t) {
                var e = {};
                t && i.each(t.split(" "), function(n, s) {
                    e[s] = "_eventHandler"
                }), this._off(this.anchors.add(this.tabs).add(this.panels)), this._on(!0, this.anchors, {
                    click: function(n) {
                        n.preventDefault()
                    }
                }), this._on(this.anchors, e), this._on(this.tabs, {
                    keydown: "_tabKeydown"
                }), this._on(this.panels, {
                    keydown: "_panelKeydown"
                }), this._focusable(this.tabs), this._hoverable(this.tabs)
            },
            _setupHeightStyle: function(t) {
                var e, n = this.element.parent();
                "fill" === t ? (e = n.height(), e -= this.element.outerHeight() - this.element.height(), this.element.siblings(":visible").each(function() {
                    var s = i(this),
                        r = s.css("position");
                    "absolute" !== r && "fixed" !== r && (e -= s.outerHeight(!0))
                }), this.element.children().not(this.panels).each(function() {
                    e -= i(this).outerHeight(!0)
                }), this.panels.each(function() {
                    i(this).height(Math.max(0, e - i(this).innerHeight() + i(this).height()))
                }).css("overflow", "auto")) : "auto" === t && (e = 0, this.panels.each(function() {
                    e = Math.max(e, i(this).height("").height())
                }).height(e))
            },
            _eventHandler: function(t) {
                var e = this.options,
                    n = this.active,
                    r = i(t.currentTarget).closest("li"),
                    l = r[0] === n[0],
                    d = l && e.collapsible,
                    g = d ? i() : this._getPanelForTab(r),
                    k = n.length ? this._getPanelForTab(n) : i(),
                    D = {
                        oldTab: n,
                        oldPanel: k,
                        newTab: d ? i() : r,
                        newPanel: g
                    };
                t.preventDefault(), r.hasClass("ui-state-disabled") || r.hasClass("ui-tabs-loading") || this.running || l && !e.collapsible || !1 === this._trigger("beforeActivate", t, D) || (e.active = !d && this.tabs.index(r), this.active = l ? i() : r, this.xhr && this.xhr.abort(), k.length || g.length || i.error("jQuery UI Tabs: Mismatching fragment identifier."), g.length && this.load(this.tabs.index(r), t), this._toggle(t, D))
            },
            _toggle: function(t, e) {
                function n() {
                    r.running = !1, r._trigger("activate", t, e)
                }

                function s() {
                    r._addClass(e.newTab.closest("li"), "ui-tabs-active", "ui-state-active"), l.length && r.options.show ? r._show(l, r.options.show, n) : (l.show(), n())
                }
                var r = this,
                    l = e.newPanel,
                    d = e.oldPanel;
                this.running = !0, d.length && this.options.hide ? this._hide(d, this.options.hide, function() {
                    r._removeClass(e.oldTab.closest("li"), "ui-tabs-active", "ui-state-active"), s()
                }) : (this._removeClass(e.oldTab.closest("li"), "ui-tabs-active", "ui-state-active"), d.hide(), s()), d.attr("aria-hidden", "true"), e.oldTab.attr({
                    "aria-selected": "false",
                    "aria-expanded": "false"
                }), l.length && d.length ? e.oldTab.attr("tabIndex", -1) : l.length && this.tabs.filter(function() {
                    return 0 === i(this).attr("tabIndex")
                }).attr("tabIndex", -1), l.attr("aria-hidden", "false"), e.newTab.attr({
                    "aria-selected": "true",
                    "aria-expanded": "true",
                    tabIndex: 0
                })
            },
            _activate: function(t) {
                var e, n = this._findActive(t);
                n[0] !== this.active[0] && (n.length || (n = this.active), e = n.find(".ui-tabs-anchor")[0], this._eventHandler({
                    target: e,
                    currentTarget: e,
                    preventDefault: i.noop
                }))
            },
            _findActive: function(t) {
                return !1 === t ? i() : this.tabs.eq(t)
            },
            _getIndex: function(t) {
                return "string" == typeof t && (t = this.anchors.index(this.anchors.filter("[href$='" + i.ui.escapeSelector(t) + "']"))), t
            },
            _destroy: function() {
                this.xhr && this.xhr.abort(), this.tablist.removeAttr("role").off(this.eventNamespace), this.anchors.removeAttr("role tabIndex").removeUniqueId(), this.tabs.add(this.panels).each(function() {
                    i.data(this, "ui-tabs-destroy") ? i(this).remove() : i(this).removeAttr("role tabIndex aria-live aria-busy aria-selected aria-labelledby aria-hidden aria-expanded")
                }), this.tabs.each(function() {
                    var t = i(this),
                        e = t.data("ui-tabs-aria-controls");
                    e ? t.attr("aria-controls", e).removeData("ui-tabs-aria-controls") : t.removeAttr("aria-controls")
                }), this.panels.show(), "content" !== this.options.heightStyle && this.panels.css("height", "")
            },
            enable: function(t) {
                var e = this.options.disabled;
                !1 !== e && (void 0 === t ? e = !1 : (t = this._getIndex(t), e = i.isArray(e) ? i.map(e, function(n) {
                    return n !== t ? n : null
                }) : i.map(this.tabs, function(n, s) {
                    return s !== t ? s : null
                })), this._setOptionDisabled(e))
            },
            disable: function(t) {
                var e = this.options.disabled;
                if (!0 !== e) {
                    if (void 0 === t) e = !0;
                    else {
                        if (t = this._getIndex(t), -1 !== i.inArray(t, e)) return;
                        e = i.isArray(e) ? i.merge([t], e).sort() : [t]
                    }
                    this._setOptionDisabled(e)
                }
            },
            load: function(t, e) {
                t = this._getIndex(t);
                var n = this,
                    s = this.tabs.eq(t),
                    r = s.find(".ui-tabs-anchor"),
                    l = this._getPanelForTab(s),
                    d = {
                        tab: s,
                        panel: l
                    },
                    g = function(k, D) {
                        "abort" === D && n.panels.stop(!1, !0), n._removeClass(s, "ui-tabs-loading"), l.removeAttr("aria-busy"), k === n.xhr && delete n.xhr
                    };
                this._isLocal(r[0]) || (this.xhr = i.ajax(this._ajaxSettings(r, e, d)), this.xhr && "canceled" !== this.xhr.statusText && (this._addClass(s, "ui-tabs-loading"), l.attr("aria-busy", "true"), this.xhr.done(function(k, D, I) {
                    setTimeout(function() {
                        l.html(k), n._trigger("load", e, d), g(I, D)
                    }, 1)
                }).fail(function(k, D) {
                    setTimeout(function() {
                        g(k, D)
                    }, 1)
                })))
            },
            _ajaxSettings: function(t, e, n) {
                var s = this;
                return {
                    url: t.attr("href").replace(/#.*$/, ""),
                    beforeSend: function(r, l) {
                        return s._trigger("beforeLoad", e, i.extend({
                            jqXHR: r,
                            ajaxSettings: l
                        }, n))
                    }
                }
            },
            _getPanelForTab: function(t) {
                var e = i(t).attr("aria-controls");
                return this.element.find(this._sanitizeSelector("#" + e))
            }
        }), !1 !== i.uiBackCompat && i.widget("ui.tabs", i.ui.tabs, {
            _processTabs: function() {
                this._superApply(arguments), this._addClass(this.tabs, "ui-tab")
            }
        }), i.widget("ui.tooltip", {
            version: "1.12.1",
            options: {
                classes: {
                    "ui-tooltip": "ui-corner-all ui-widget-shadow"
                },
                content: function() {
                    var t = i(this).attr("title") || "";
                    return i("<a>").text(t).html()
                },
                hide: !0,
                items: "[title]:not([disabled])",
                position: {
                    my: "left top+15",
                    at: "left bottom",
                    collision: "flipfit flip"
                },
                show: !0,
                track: !1,
                close: null,
                open: null
            },
            _addDescribedBy: function(t, e) {
                var n = (t.attr("aria-describedby") || "").split(/\s+/);
                n.push(e), t.data("ui-tooltip-id", e).attr("aria-describedby", i.trim(n.join(" ")))
            },
            _removeDescribedBy: function(t) {
                var e = t.data("ui-tooltip-id"),
                    n = (t.attr("aria-describedby") || "").split(/\s+/),
                    s = i.inArray(e, n); - 1 !== s && n.splice(s, 1), t.removeData("ui-tooltip-id"), (n = i.trim(n.join(" "))) ? t.attr("aria-describedby", n) : t.removeAttr("aria-describedby")
            },
            _create: function() {
                this._on({
                    mouseover: "open",
                    focusin: "open"
                }), this.tooltips = {}, this.parents = {}, this.liveRegion = i("<div>").attr({
                    role: "log",
                    "aria-live": "assertive",
                    "aria-relevant": "additions"
                }).appendTo(this.document[0].body), this._addClass(this.liveRegion, null, "ui-helper-hidden-accessible"), this.disabledTitles = i([])
            },
            _setOption: function(t, e) {
                var n = this;
                this._super(t, e), "content" === t && i.each(this.tooltips, function(s, r) {
                    n._updateContent(r.element)
                })
            },
            _setOptionDisabled: function(t) {
                this[t ? "_disable" : "_enable"]()
            },
            _disable: function() {
                var t = this;
                i.each(this.tooltips, function(e, n) {
                    var s = i.Event("blur");
                    s.target = s.currentTarget = n.element[0], t.close(s, !0)
                }), this.disabledTitles = this.disabledTitles.add(this.element.find(this.options.items).addBack().filter(function() {
                    var e = i(this);
                    return e.is("[title]") ? e.data("ui-tooltip-title", e.attr("title")).removeAttr("title") : void 0
                }))
            },
            _enable: function() {
                this.disabledTitles.each(function() {
                    var t = i(this);
                    t.data("ui-tooltip-title") && t.attr("title", t.data("ui-tooltip-title"))
                }), this.disabledTitles = i([])
            },
            open: function(t) {
                var e = this,
                    n = i(t ? t.target : this.element).closest(this.options.items);
                n.length && !n.data("ui-tooltip-id") && (n.attr("title") && n.data("ui-tooltip-title", n.attr("title")), n.data("ui-tooltip-open", !0), t && "mouseover" === t.type && n.parents().each(function() {
                    var s, r = i(this);
                    r.data("ui-tooltip-open") && ((s = i.Event("blur")).target = s.currentTarget = this, e.close(s, !0)), r.attr("title") && (r.uniqueId(), e.parents[this.id] = {
                        element: this,
                        title: r.attr("title")
                    }, r.attr("title", ""))
                }), this._registerCloseHandlers(t, n), this._updateContent(n, t))
            },
            _updateContent: function(t, e) {
                var n, s = this.options.content,
                    r = this,
                    l = e ? e.type : null;
                return "string" == typeof s || s.nodeType || s.jquery ? this._open(e, t, s) : void((n = s.call(t[0], function(d) {
                    r._delay(function() {
                        t.data("ui-tooltip-open") && (e && (e.type = l), this._open(e, t, d))
                    })
                })) && this._open(e, t, n))
            },
            _open: function(t, e, n) {
                function s(D) {
                    k.of = D, l.is(":hidden") || l.position(k)
                }
                var r, l, d, g, k = i.extend({}, this.options.position);
                if (n) {
                    if (r = this._find(e)) return void r.tooltip.find(".ui-tooltip-content").html(n);
                    e.is("[title]") && (t && "mouseover" === t.type ? e.attr("title", "") : e.removeAttr("title")), r = this._tooltip(e), this._addDescribedBy(e, (l = r.tooltip).attr("id")), l.find(".ui-tooltip-content").html(n), this.liveRegion.children().hide(), (g = i("<div>").html(l.find(".ui-tooltip-content").html())).removeAttr("name").find("[name]").removeAttr("name"), g.removeAttr("id").find("[id]").removeAttr("id"), g.appendTo(this.liveRegion), this.options.track && t && /^mouse/.test(t.type) ? (this._on(this.document, {
                        mousemove: s
                    }), s(t)) : l.position(i.extend({ of: e
                    }, this.options.position)), l.hide(), this._show(l, this.options.show), this.options.track && this.options.show && this.options.show.delay && (d = this.delayedShow = setInterval(function() {
                        l.is(":visible") && (s(k.of), clearInterval(d))
                    }, i.fx.interval)), this._trigger("open", t, {
                        tooltip: l
                    })
                }
            },
            _registerCloseHandlers: function(t, e) {
                var n = {
                    keyup: function(s) {
                        if (s.keyCode === i.ui.keyCode.ESCAPE) {
                            var r = i.Event(s);
                            r.currentTarget = e[0], this.close(r, !0)
                        }
                    }
                };
                e[0] !== this.element[0] && (n.remove = function() {
                    this._removeTooltip(this._find(e).tooltip)
                }), t && "mouseover" !== t.type || (n.mouseleave = "close"), t && "focusin" !== t.type || (n.focusout = "close"), this._on(!0, e, n)
            },
            close: function(t) {
                var e, n = this,
                    s = i(t ? t.currentTarget : this.element),
                    r = this._find(s);
                return r ? (e = r.tooltip, void(r.closing || (clearInterval(this.delayedShow), s.data("ui-tooltip-title") && !s.attr("title") && s.attr("title", s.data("ui-tooltip-title")), this._removeDescribedBy(s), r.hiding = !0, e.stop(!0), this._hide(e, this.options.hide, function() {
                    n._removeTooltip(i(this))
                }), s.removeData("ui-tooltip-open"), this._off(s, "mouseleave focusout keyup"), s[0] !== this.element[0] && this._off(s, "remove"), this._off(this.document, "mousemove"), t && "mouseleave" === t.type && i.each(this.parents, function(l, d) {
                    i(d.element).attr("title", d.title), delete n.parents[l]
                }), r.closing = !0, this._trigger("close", t, {
                    tooltip: e
                }), r.hiding || (r.closing = !1)))) : void s.removeData("ui-tooltip-open")
            },
            _tooltip: function(t) {
                var e = i("<div>").attr("role", "tooltip"),
                    n = i("<div>").appendTo(e),
                    s = e.uniqueId().attr("id");
                return this._addClass(n, "ui-tooltip-content"), this._addClass(e, "ui-tooltip", "ui-widget ui-widget-content"), e.appendTo(this._appendTo(t)), this.tooltips[s] = {
                    element: t,
                    tooltip: e
                }
            },
            _find: function(t) {
                var e = t.data("ui-tooltip-id");
                return e ? this.tooltips[e] : null
            },
            _removeTooltip: function(t) {
                t.remove(), delete this.tooltips[t.attr("id")]
            },
            _appendTo: function(t) {
                var e = t.closest(".ui-front, dialog");
                return e.length || (e = this.document[0].body), e
            },
            _destroy: function() {
                var t = this;
                i.each(this.tooltips, function(e, n) {
                    var s = i.Event("blur"),
                        r = n.element;
                    s.target = s.currentTarget = r[0], t.close(s, !0), i("#" + e).remove(), r.data("ui-tooltip-title") && (r.attr("title") || r.attr("title", r.data("ui-tooltip-title")), r.removeData("ui-tooltip-title"))
                }), this.liveRegion.remove()
            }
        }), !1 !== i.uiBackCompat && i.widget("ui.tooltip", i.ui.tooltip, {
            options: {
                tooltipClass: null
            },
            _tooltip: function() {
                var t = this._superApply(arguments);
                return this.options.tooltipClass && t.tooltip.addClass(this.options.tooltipClass), t
            }
        })
    }), "undefined" == typeof jQuery) throw new Error("Bootstrap's JavaScript requires jQuery");
(function(i) {
    "use strict";
    var L = jQuery.fn.jquery.split(" ")[0].split(".");
    if (L[0] < 2 && L[1] < 9 || 1 == L[0] && 9 == L[1] && L[2] < 1 || 3 < L[0]) throw new Error("Bootstrap's JavaScript requires jQuery version 1.9.1 or higher, but lower than version 4")
})(),
function(i) {
    "use strict";
    i.fn.emulateTransitionEnd = function(L) {
        var ut = !1,
            it = this;
        return i(this).one("bsTransitionEnd", function() {
            ut = !0
        }), setTimeout(function() {
            ut || i(it).trigger(i.support.transition.end)
        }, L), this
    }, i(function() {
        i.support.transition = function() {
            var ut = document.createElement("bootstrap"),
                it = {
                    WebkitTransition: "webkitTransitionEnd",
                    MozTransition: "transitionend",
                    OTransition: "oTransitionEnd otransitionend",
                    transition: "transitionend"
                };
            for (var f in it)
                if (void 0 !== ut.style[f]) return {
                    end: it[f]
                };
            return !1
        }(), i.support.transition && (i.event.special.bsTransitionEnd = {
            bindType: i.support.transition.end,
            delegateType: i.support.transition.end,
            handle: function(L) {
                if (i(L.target).is(this)) return L.handleObj.handler.apply(this, arguments)
            }
        })
    })
}(jQuery),
function(i) {
    "use strict";
    var L = '[data-dismiss="alert"]',
        ut = function(f) {
            i(f).on("click", L, this.close)
        };
    ut.VERSION = "3.4.1", ut.TRANSITION_DURATION = 150, ut.prototype.close = function(f) {
        var b = i(this),
            p = b.attr("data-target");
        p || (p = (p = b.attr("href")) && p.replace(/.*(?=#[^\s]*$)/, "")), p = "#" === p ? [] : p;
        var x = i(document).find(p);

        function y() {
            x.detach().trigger("closed.bs.alert").remove()
        }
        f && f.preventDefault(), x.length || (x = b.closest(".alert")), x.trigger(f = i.Event("close.bs.alert")), f.isDefaultPrevented() || (x.removeClass("in"), i.support.transition && x.hasClass("fade") ? x.one("bsTransitionEnd", y).emulateTransitionEnd(ut.TRANSITION_DURATION) : y())
    };
    var it = i.fn.alert;
    i.fn.alert = function(b) {
        return this.each(function() {
            var p = i(this),
                x = p.data("bs.alert");
            x || p.data("bs.alert", x = new ut(this)), "string" == typeof b && x[b].call(p)
        })
    }, i.fn.alert.Constructor = ut, i.fn.alert.noConflict = function() {
        return i.fn.alert = it, this
    }, i(document).on("click.bs.alert.data-api", L, ut.prototype.close)
}(jQuery),
function(i) {
    "use strict";
    var L = function(f, b) {
        this.$element = i(f), this.options = i.extend({}, L.DEFAULTS, b), this.isLoading = !1
    };

    function ut(f) {
        return this.each(function() {
            var b = i(this),
                p = b.data("bs.button");
            p || b.data("bs.button", p = new L(this, "object" == typeof f && f)), "toggle" == f ? p.toggle() : f && p.setState(f)
        })
    }
    L.VERSION = "3.4.1", L.DEFAULTS = {
        loadingText: "loading..."
    }, L.prototype.setState = function(f) {
        var b = "disabled",
            p = this.$element,
            x = p.is("input") ? "val" : "html",
            y = p.data();
        f += "Text", null == y.resetText && p.data("resetText", p[x]()), setTimeout(i.proxy(function() {
            p[x](null == y[f] ? this.options[f] : y[f]), "loadingText" == f ? (this.isLoading = !0, p.addClass(b).attr(b, b).prop(b, !0)) : this.isLoading && (this.isLoading = !1, p.removeClass(b).removeAttr(b).prop(b, !1))
        }, this), 0)
    }, L.prototype.toggle = function() {
        var f = !0,
            b = this.$element.closest('[data-toggle="buttons"]');
        if (b.length) {
            var p = this.$element.find("input");
            "radio" == p.prop("type") ? (p.prop("checked") && (f = !1), b.find(".active").removeClass("active"), this.$element.addClass("active")) : "checkbox" == p.prop("type") && (p.prop("checked") !== this.$element.hasClass("active") && (f = !1), this.$element.toggleClass("active")), p.prop("checked", this.$element.hasClass("active")), f && p.trigger("change")
        } else this.$element.attr("aria-pressed", !this.$element.hasClass("active")), this.$element.toggleClass("active")
    };
    var it = i.fn.button;
    i.fn.button = ut, i.fn.button.Constructor = L, i.fn.button.noConflict = function() {
        return i.fn.button = it, this
    }, i(document).on("click.bs.button.data-api", '[data-toggle^="button"]', function(f) {
        var b = i(f.target).closest(".btn");
        ut.call(b, "toggle"), i(f.target).is('input[type="radio"], input[type="checkbox"]') || (f.preventDefault(), b.is("input,button") ? b.trigger("focus") : b.find("input:visible,button:visible").first().trigger("focus"))
    }).on("focus.bs.button.data-api blur.bs.button.data-api", '[data-toggle^="button"]', function(f) {
        i(f.target).closest(".btn").toggleClass("focus", /^focus(in)?$/.test(f.type))
    })
}(jQuery),
function(i) {
    "use strict";
    var L = function(b, p) {
        this.$element = i(b), this.$indicators = this.$element.find(".carousel-indicators"), this.options = p, this.paused = null, this.sliding = null, this.interval = null, this.$active = null, this.$items = null, this.options.keyboard && this.$element.on("keydown.bs.carousel", i.proxy(this.keydown, this)), "hover" == this.options.pause && !("ontouchstart" in document.documentElement) && this.$element.on("mouseenter.bs.carousel", i.proxy(this.pause, this)).on("mouseleave.bs.carousel", i.proxy(this.cycle, this))
    };

    function ut(b) {
        return this.each(function() {
            var p = i(this),
                x = p.data("bs.carousel"),
                y = i.extend({}, L.DEFAULTS, p.data(), "object" == typeof b && b),
                N = "string" == typeof b ? b : y.slide;
            x || p.data("bs.carousel", x = new L(this, y)), "number" == typeof b ? x.to(b) : N ? x[N]() : y.interval && x.pause().cycle()
        })
    }
    L.VERSION = "3.4.1", L.TRANSITION_DURATION = 600, L.DEFAULTS = {
        interval: 5e3,
        pause: "hover",
        wrap: !0,
        keyboard: !0
    }, L.prototype.keydown = function(b) {
        if (!/input|textarea/i.test(b.target.tagName)) {
            switch (b.which) {
                case 37:
                    this.prev();
                    break;
                case 39:
                    this.next();
                    break;
                default:
                    return
            }
            b.preventDefault()
        }
    }, L.prototype.cycle = function(b) {
        return b || (this.paused = !1), this.interval && clearInterval(this.interval), this.options.interval && !this.paused && (this.interval = setInterval(i.proxy(this.next, this), this.options.interval)), this
    }, L.prototype.getItemIndex = function(b) {
        return this.$items = b.parent().children(".item"), this.$items.index(b || this.$active)
    }, L.prototype.getItemForDirection = function(b, p) {
        var x = this.getItemIndex(p);
        return ("prev" == b && 0 === x || "next" == b && x == this.$items.length - 1) && !this.options.wrap ? p : this.$items.eq((x + ("prev" == b ? -1 : 1)) % this.$items.length)
    }, L.prototype.to = function(b) {
        var p = this,
            x = this.getItemIndex(this.$active = this.$element.find(".item.active"));
        if (!(b > this.$items.length - 1 || b < 0)) return this.sliding ? this.$element.one("slid.bs.carousel", function() {
            p.to(b)
        }) : x == b ? this.pause().cycle() : this.slide(x < b ? "next" : "prev", this.$items.eq(b))
    }, L.prototype.pause = function(b) {
        return b || (this.paused = !0), this.$element.find(".next, .prev").length && i.support.transition && (this.$element.trigger(i.support.transition.end), this.cycle(!0)), this.interval = clearInterval(this.interval), this
    }, L.prototype.next = function() {
        if (!this.sliding) return this.slide("next")
    }, L.prototype.prev = function() {
        if (!this.sliding) return this.slide("prev")
    }, L.prototype.slide = function(b, p) {
        var x = this.$element.find(".item.active"),
            y = p || this.getItemForDirection(b, x),
            N = this.interval,
            C = "next" == b ? "left" : "right",
            T = this;
        if (y.hasClass("active")) return this.sliding = !1;
        var B = y[0],
            tt = i.Event("slide.bs.carousel", {
                relatedTarget: B,
                direction: C
            });
        if (this.$element.trigger(tt), !tt.isDefaultPrevented()) {
            if (this.sliding = !0, N && this.pause(), this.$indicators.length) {
                this.$indicators.find(".active").removeClass("active");
                var K = i(this.$indicators.children()[this.getItemIndex(y)]);
                K && K.addClass("active")
            }
            var Y = i.Event("slid.bs.carousel", {
                relatedTarget: B,
                direction: C
            });
            return i.support.transition && this.$element.hasClass("slide") ? (y.addClass(b), x.addClass(C), y.addClass(C), x.one("bsTransitionEnd", function() {
                y.removeClass([b, C].join(" ")).addClass("active"), x.removeClass(["active", C].join(" ")), T.sliding = !1, setTimeout(function() {
                    T.$element.trigger(Y)
                }, 0)
            }).emulateTransitionEnd(L.TRANSITION_DURATION)) : (x.removeClass("active"), y.addClass("active"), this.sliding = !1, this.$element.trigger(Y)), N && this.cycle(), this
        }
    };
    var it = i.fn.carousel;
    i.fn.carousel = ut, i.fn.carousel.Constructor = L, i.fn.carousel.noConflict = function() {
        return i.fn.carousel = it, this
    };
    var f = function(b) {
        var p = i(this),
            x = p.attr("href");
        x && (x = x.replace(/.*(?=#[^\s]+$)/, ""));
        var y = p.attr("data-target") || x,
            N = i(document).find(y);
        if (N.hasClass("carousel")) {
            var C = i.extend({}, N.data(), p.data()),
                T = p.attr("data-slide-to");
            T && (C.interval = !1), ut.call(N, C), T && N.data("bs.carousel").to(T), b.preventDefault()
        }
    };
    i(document).on("click.bs.carousel.data-api", "[data-slide]", f).on("click.bs.carousel.data-api", "[data-slide-to]", f), i(window).on("load", function() {
        i('[data-ride="carousel"]').each(function() {
            var b = i(this);
            ut.call(b, b.data())
        })
    })
}(jQuery),
function(i) {
    "use strict";
    var L = function(b, p) {
        this.$element = i(b), this.options = i.extend({}, L.DEFAULTS, p), this.$trigger = i('[data-toggle="collapse"][href="#' + b.id + '"],[data-toggle="collapse"][data-target="#' + b.id + '"]'), this.transitioning = null, this.options.parent ? this.$parent = this.getParent() : this.addAriaAndCollapsedClass(this.$element, this.$trigger), this.options.toggle && this.toggle()
    };

    function ut(b) {
        var p, x = b.attr("data-target") || (p = b.attr("href")) && p.replace(/.*(?=#[^\s]+$)/, "");
        return i(document).find(x)
    }

    function it(b) {
        return this.each(function() {
            var p = i(this),
                x = p.data("bs.collapse"),
                y = i.extend({}, L.DEFAULTS, p.data(), "object" == typeof b && b);
            !x && y.toggle && /show|hide/.test(b) && (y.toggle = !1), x || p.data("bs.collapse", x = new L(this, y)), "string" == typeof b && x[b]()
        })
    }
    L.VERSION = "3.4.1", L.TRANSITION_DURATION = 350, L.DEFAULTS = {
        toggle: !0
    }, L.prototype.dimension = function() {
        return this.$element.hasClass("width") ? "width" : "height"
    }, L.prototype.show = function() {
        if (!this.transitioning && !this.$element.hasClass("in")) {
            var b, p = this.$parent && this.$parent.children(".panel").children(".in, .collapsing");
            if (!(p && p.length && (b = p.data("bs.collapse")) && b.transitioning)) {
                var x = i.Event("show.bs.collapse");
                if (this.$element.trigger(x), !x.isDefaultPrevented()) {
                    p && p.length && (it.call(p, "hide"), b || p.data("bs.collapse", null));
                    var y = this.dimension();
                    this.$element.removeClass("collapse").addClass("collapsing")[y](0).attr("aria-expanded", !0), this.$trigger.removeClass("collapsed").attr("aria-expanded", !0), this.transitioning = 1;
                    var N = function() {
                        this.$element.removeClass("collapsing").addClass("collapse in")[y](""), this.transitioning = 0, this.$element.trigger("shown.bs.collapse")
                    };
                    if (!i.support.transition) return N.call(this);
                    var C = i.camelCase(["scroll", y].join("-"));
                    this.$element.one("bsTransitionEnd", i.proxy(N, this)).emulateTransitionEnd(L.TRANSITION_DURATION)[y](this.$element[0][C])
                }
            }
        }
    }, L.prototype.hide = function() {
        if (!this.transitioning && this.$element.hasClass("in")) {
            var b = i.Event("hide.bs.collapse");
            if (this.$element.trigger(b), !b.isDefaultPrevented()) {
                var p = this.dimension();
                this.$element[p](this.$element[p]()), this.$element.addClass("collapsing").removeClass("collapse in").attr("aria-expanded", !1), this.$trigger.addClass("collapsed").attr("aria-expanded", !1), this.transitioning = 1;
                var x = function() {
                    this.transitioning = 0, this.$element.removeClass("collapsing").addClass("collapse").trigger("hidden.bs.collapse")
                };
                if (!i.support.transition) return x.call(this);
                this.$element[p](0).one("bsTransitionEnd", i.proxy(x, this)).emulateTransitionEnd(L.TRANSITION_DURATION)
            }
        }
    }, L.prototype.toggle = function() {
        this[this.$element.hasClass("in") ? "hide" : "show"]()
    }, L.prototype.getParent = function() {
        return i(document).find(this.options.parent).find('[data-toggle="collapse"][data-parent="' + this.options.parent + '"]').each(i.proxy(function(b, p) {
            var x = i(p);
            this.addAriaAndCollapsedClass(ut(x), x)
        }, this)).end()
    }, L.prototype.addAriaAndCollapsedClass = function(b, p) {
        var x = b.hasClass("in");
        b.attr("aria-expanded", x), p.toggleClass("collapsed", !x).attr("aria-expanded", x)
    };
    var f = i.fn.collapse;
    i.fn.collapse = it, i.fn.collapse.Constructor = L, i.fn.collapse.noConflict = function() {
        return i.fn.collapse = f, this
    }, i(document).on("click.bs.collapse.data-api", '[data-toggle="collapse"]', function(b) {
        var p = i(this);
        p.attr("data-target") || b.preventDefault();
        var x = ut(p),
            y = x.data("bs.collapse") ? "toggle" : p.data();
        it.call(x, y)
    })
}(jQuery),
function(i) {
    "use strict";
    var L = '[data-toggle="dropdown"]',
        ut = function(p) {
            i(p).on("click.bs.dropdown", this.toggle)
        };

    function it(p) {
        var x = p.attr("data-target");
        x || (x = (x = p.attr("href")) && /#[A-Za-z]/.test(x) && x.replace(/.*(?=#[^\s]*$)/, ""));
        var y = "#" !== x ? i(document).find(x) : null;
        return y && y.length ? y : p.parent()
    }

    function f(p) {
        p && 3 === p.which || (i(".dropdown-backdrop").remove(), i(L).each(function() {
            var x = i(this),
                y = it(x),
                N = {
                    relatedTarget: this
                };
            y.hasClass("open") && (p && "click" == p.type && /input|textarea/i.test(p.target.tagName) && i.contains(y[0], p.target) || (y.trigger(p = i.Event("hide.bs.dropdown", N)), p.isDefaultPrevented() || (x.attr("aria-expanded", "false"), y.removeClass("open").trigger(i.Event("hidden.bs.dropdown", N)))))
        }))
    }
    ut.VERSION = "3.4.1", ut.prototype.toggle = function(p) {
        var x = i(this);
        if (!x.is(".disabled, :disabled")) {
            var y = it(x),
                N = y.hasClass("open");
            if (f(), !N) {
                "ontouchstart" in document.documentElement && !y.closest(".navbar-nav").length && i(document.createElement("div")).addClass("dropdown-backdrop").insertAfter(i(this)).on("click", f);
                var C = {
                    relatedTarget: this
                };
                if (y.trigger(p = i.Event("show.bs.dropdown", C)), p.isDefaultPrevented()) return;
                x.trigger("focus").attr("aria-expanded", "true"), y.toggleClass("open").trigger(i.Event("shown.bs.dropdown", C))
            }
            return !1
        }
    }, ut.prototype.keydown = function(p) {
        if (/(38|40|27|32)/.test(p.which) && !/input|textarea/i.test(p.target.tagName)) {
            var x = i(this);
            if (p.preventDefault(), p.stopPropagation(), !x.is(".disabled, :disabled")) {
                var y = it(x),
                    N = y.hasClass("open");
                if (!N && 27 != p.which || N && 27 == p.which) return 27 == p.which && y.find(L).trigger("focus"), x.trigger("click");
                var C = y.find(".dropdown-menu li:not(.disabled):visible a");
                if (C.length) {
                    var T = C.index(p.target);
                    38 == p.which && 0 < T && T--, 40 == p.which && T < C.length - 1 && T++, ~T || (T = 0), C.eq(T).trigger("focus")
                }
            }
        }
    };
    var b = i.fn.dropdown;
    i.fn.dropdown = function(x) {
        return this.each(function() {
            var y = i(this),
                N = y.data("bs.dropdown");
            N || y.data("bs.dropdown", N = new ut(this)), "string" == typeof x && N[x].call(y)
        })
    }, i.fn.dropdown.Constructor = ut, i.fn.dropdown.noConflict = function() {
        return i.fn.dropdown = b, this
    }, i(document).on("click.bs.dropdown.data-api", f).on("click.bs.dropdown.data-api", ".dropdown form", function(p) {
        p.stopPropagation()
    }).on("click.bs.dropdown.data-api", L, ut.prototype.toggle).on("keydown.bs.dropdown.data-api", L, ut.prototype.keydown).on("keydown.bs.dropdown.data-api", ".dropdown-menu", ut.prototype.keydown)
}(jQuery),
function(i) {
    "use strict";
    var L = function(f, b) {
        this.options = b, this.$body = i(document.body), this.$element = i(f), this.$dialog = this.$element.find(".modal-dialog"), this.$backdrop = null, this.isShown = null, this.originalBodyPad = null, this.scrollbarWidth = 0, this.ignoreBackdropClick = !1, this.fixedContent = ".navbar-fixed-top, .navbar-fixed-bottom", this.options.remote && this.$element.find(".modal-content").load(this.options.remote, i.proxy(function() {
            this.$element.trigger("loaded.bs.modal")
        }, this))
    };

    function ut(f, b) {
        return this.each(function() {
            var p = i(this),
                x = p.data("bs.modal"),
                y = i.extend({}, L.DEFAULTS, p.data(), "object" == typeof f && f);
            x || p.data("bs.modal", x = new L(this, y)), "string" == typeof f ? x[f](b) : y.show && x.show(b)
        })
    }
    L.VERSION = "3.4.1", L.TRANSITION_DURATION = 300, L.BACKDROP_TRANSITION_DURATION = 150, L.DEFAULTS = {
        backdrop: !0,
        keyboard: !0,
        show: !0
    }, L.prototype.toggle = function(f) {
        return this.isShown ? this.hide() : this.show(f)
    }, L.prototype.show = function(f) {
        var b = this,
            p = i.Event("show.bs.modal", {
                relatedTarget: f
            });
        this.$element.trigger(p), this.isShown || p.isDefaultPrevented() || (this.isShown = !0, this.checkScrollbar(), this.setScrollbar(), this.$body.addClass("modal-open"), this.escape(), this.resize(), this.$element.on("click.dismiss.bs.modal", '[data-dismiss="modal"]', i.proxy(this.hide, this)), this.$dialog.on("mousedown.dismiss.bs.modal", function() {
            b.$element.one("mouseup.dismiss.bs.modal", function(x) {
                i(x.target).is(b.$element) && (b.ignoreBackdropClick = !0)
            })
        }), this.backdrop(function() {
            var x = i.support.transition && b.$element.hasClass("fade");
            b.$element.parent().length || b.$element.appendTo(b.$body), b.$element.show().scrollTop(0), b.adjustDialog(), b.$element.addClass("in"), b.enforceFocus();
            var y = i.Event("shown.bs.modal", {
                relatedTarget: f
            });
            x ? b.$dialog.one("bsTransitionEnd", function() {
                b.$element.trigger("focus").trigger(y)
            }).emulateTransitionEnd(L.TRANSITION_DURATION) : b.$element.trigger("focus").trigger(y)
        }))
    }, L.prototype.hide = function(f) {
        f && f.preventDefault(), f = i.Event("hide.bs.modal"), this.$element.trigger(f), this.isShown && !f.isDefaultPrevented() && (this.isShown = !1, this.escape(), this.resize(), i(document).off("focusin.bs.modal"), this.$element.removeClass("in").off("click.dismiss.bs.modal").off("mouseup.dismiss.bs.modal"), this.$dialog.off("mousedown.dismiss.bs.modal"), i.support.transition && this.$element.hasClass("fade") ? this.$element.one("bsTransitionEnd", i.proxy(this.hideModal, this)).emulateTransitionEnd(L.TRANSITION_DURATION) : this.hideModal())
    }, L.prototype.enforceFocus = function() {
        i(document).off("focusin.bs.modal").on("focusin.bs.modal", i.proxy(function(f) {
            document === f.target || this.$element[0] === f.target || this.$element.has(f.target).length || this.$element.trigger("focus")
        }, this))
    }, L.prototype.escape = function() {
        this.isShown && this.options.keyboard ? this.$element.on("keydown.dismiss.bs.modal", i.proxy(function(f) {
            27 == f.which && this.hide()
        }, this)) : this.isShown || this.$element.off("keydown.dismiss.bs.modal")
    }, L.prototype.resize = function() {
        this.isShown ? i(window).on("resize.bs.modal", i.proxy(this.handleUpdate, this)) : i(window).off("resize.bs.modal")
    }, L.prototype.hideModal = function() {
        var f = this;
        this.$element.hide(), this.backdrop(function() {
            f.$body.removeClass("modal-open"), f.resetAdjustments(), f.resetScrollbar(), f.$element.trigger("hidden.bs.modal")
        })
    }, L.prototype.removeBackdrop = function() {
        this.$backdrop && this.$backdrop.remove(), this.$backdrop = null
    }, L.prototype.backdrop = function(f) {
        var b = this,
            p = this.$element.hasClass("fade") ? "fade" : "";
        if (this.isShown && this.options.backdrop) {
            var x = i.support.transition && p;
            if (this.$backdrop = i(document.createElement("div")).addClass("modal-backdrop " + p).appendTo(this.$body), this.$element.on("click.dismiss.bs.modal", i.proxy(function(N) {
                    this.ignoreBackdropClick ? this.ignoreBackdropClick = !1 : N.target === N.currentTarget && ("static" == this.options.backdrop ? this.$element[0].focus() : this.hide())
                }, this)), this.$backdrop.addClass("in"), !f) return;
            x ? this.$backdrop.one("bsTransitionEnd", f).emulateTransitionEnd(L.BACKDROP_TRANSITION_DURATION) : f()
        } else if (!this.isShown && this.$backdrop) {
            this.$backdrop.removeClass("in");
            var y = function() {
                b.removeBackdrop(), f && f()
            };
            i.support.transition && this.$element.hasClass("fade") ? this.$backdrop.one("bsTransitionEnd", y).emulateTransitionEnd(L.BACKDROP_TRANSITION_DURATION) : y()
        } else f && f()
    }, L.prototype.handleUpdate = function() {
        this.adjustDialog()
    }, L.prototype.adjustDialog = function() {
        var f = this.$element[0].scrollHeight > document.documentElement.clientHeight;
        this.$element.css({
            paddingLeft: !this.bodyIsOverflowing && f ? this.scrollbarWidth : "",
            paddingRight: this.bodyIsOverflowing && !f ? this.scrollbarWidth : ""
        })
    }, L.prototype.resetAdjustments = function() {
        this.$element.css({
            paddingLeft: "",
            paddingRight: ""
        })
    }, L.prototype.checkScrollbar = function() {
        var f = window.innerWidth;
        if (!f) {
            var b = document.documentElement.getBoundingClientRect();
            f = b.right - Math.abs(b.left)
        }
        this.bodyIsOverflowing = document.body.clientWidth < f, this.scrollbarWidth = this.measureScrollbar()
    }, L.prototype.setScrollbar = function() {
        var f = parseInt(this.$body.css("padding-right") || 0, 10);
        this.originalBodyPad = document.body.style.paddingRight || "";
        var b = this.scrollbarWidth;
        this.bodyIsOverflowing && (this.$body.css("padding-right", f + b), i(this.fixedContent).each(function(p, x) {
            var y = x.style.paddingRight,
                N = i(x).css("padding-right");
            i(x).data("padding-right", y).css("padding-right", parseFloat(N) + b + "px")
        }))
    }, L.prototype.resetScrollbar = function() {
        this.$body.css("padding-right", this.originalBodyPad), i(this.fixedContent).each(function(f, b) {
            var p = i(b).data("padding-right");
            i(b).removeData("padding-right"), b.style.paddingRight = p || ""
        })
    }, L.prototype.measureScrollbar = function() {
        var f = document.createElement("div");
        f.className = "modal-scrollbar-measure", this.$body.append(f);
        var b = f.offsetWidth - f.clientWidth;
        return this.$body[0].removeChild(f), b
    };
    var it = i.fn.modal;
    i.fn.modal = ut, i.fn.modal.Constructor = L, i.fn.modal.noConflict = function() {
        return i.fn.modal = it, this
    }, i(document).on("click.bs.modal.data-api", '[data-toggle="modal"]', function(f) {
        var b = i(this),
            p = b.attr("href"),
            x = b.attr("data-target") || p && p.replace(/.*(?=#[^\s]+$)/, ""),
            y = i(document).find(x),
            N = y.data("bs.modal") ? "toggle" : i.extend({
                remote: !/#/.test(p) && p
            }, y.data(), b.data());
        b.is("a") && f.preventDefault(), y.one("show.bs.modal", function(C) {
            C.isDefaultPrevented() || y.one("hidden.bs.modal", function() {
                b.is(":visible") && b.trigger("focus")
            })
        }), ut.call(y, N, this)
    })
}(jQuery),
function(i) {
    "use strict";
    var L = ["sanitize", "whiteList", "sanitizeFn"],
        ut = ["background", "cite", "href", "itemtype", "longdesc", "poster", "src", "xlink:href"],
        f = /^(?:(?:https?|mailto|ftp|tel|file):|[^&:/?#]*(?:[/?#]|$))/gi,
        b = /^data:(?:image\/(?:bmp|gif|jpeg|jpg|png|tiff|webp)|video\/(?:mpeg|mp4|ogg|webm)|audio\/(?:mp3|oga|ogg|opus));base64,[a-z0-9+/]+=*$/i;

    function p(C, T) {
        var B = C.nodeName.toLowerCase();
        if (-1 !== i.inArray(B, T)) return -1 === i.inArray(B, ut) || Boolean(C.nodeValue.match(f) || C.nodeValue.match(b));
        for (var tt = i(T).filter(function(st, u) {
                return u instanceof RegExp
            }), K = 0, Y = tt.length; K < Y; K++)
            if (B.match(tt[K])) return !0;
        return !1
    }

    function x(C, T, B) {
        if (0 === C.length) return C;
        if (B && "function" == typeof B) return B(C);
        if (!document.implementation || !document.implementation.createHTMLDocument) return C;
        var tt = document.implementation.createHTMLDocument("sanitization");
        tt.body.innerHTML = C;
        for (var K = i.map(T, function(l, d) {
                return d
            }), Y = i(tt.body).find("*"), st = 0, u = Y.length; st < u; st++) {
            var ot = Y[st],
                t = ot.nodeName.toLowerCase();
            if (-1 !== i.inArray(t, K))
                for (var e = i.map(ot.attributes, function(l) {
                        return l
                    }), n = [].concat(T["*"] || [], T[t] || []), s = 0, r = e.length; s < r; s++) p(e[s], n) || ot.removeAttribute(e[s].nodeName);
            else ot.parentNode.removeChild(ot)
        }
        return tt.body.innerHTML
    }
    var y = function(C, T) {
        this.type = null, this.options = null, this.enabled = null, this.timeout = null, this.hoverState = null, this.$element = null, this.inState = null, this.init("tooltip", C, T)
    };
    y.VERSION = "3.4.1", y.TRANSITION_DURATION = 150, y.DEFAULTS = {
        animation: !0,
        placement: "top",
        selector: !1,
        template: '<div class="tooltip" role="tooltip"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>',
        trigger: "hover focus",
        title: "",
        delay: 0,
        html: !1,
        container: !1,
        viewport: {
            selector: "body",
            padding: 0
        },
        sanitize: !0,
        sanitizeFn: null,
        whiteList: {
            "*": ["class", "dir", "id", "lang", "role", /^aria-[\w-]*$/i],
            a: ["target", "href", "title", "rel"],
            area: [],
            b: [],
            br: [],
            col: [],
            code: [],
            div: [],
            em: [],
            hr: [],
            h1: [],
            h2: [],
            h3: [],
            h4: [],
            h5: [],
            h6: [],
            i: [],
            img: ["src", "alt", "title", "width", "height"],
            li: [],
            ol: [],
            p: [],
            pre: [],
            s: [],
            small: [],
            span: [],
            sub: [],
            sup: [],
            strong: [],
            u: [],
            ul: []
        }
    }, y.prototype.init = function(C, T, B) {
        if (this.enabled = !0, this.type = C, this.$element = i(T), this.options = this.getOptions(B), this.$viewport = this.options.viewport && i(document).find(i.isFunction(this.options.viewport) ? this.options.viewport.call(this, this.$element) : this.options.viewport.selector || this.options.viewport), this.inState = {
                click: !1,
                hover: !1,
                focus: !1
            }, this.$element[0] instanceof document.constructor && !this.options.selector) throw new Error("`selector` option must be specified when initializing " + this.type + " on the window.document object!");
        for (var tt = this.options.trigger.split(" "), K = tt.length; K--;) {
            var Y = tt[K];
            if ("click" == Y) this.$element.on("click." + this.type, this.options.selector, i.proxy(this.toggle, this));
            else if ("manual" != Y) {
                var u = "hover" == Y ? "mouseleave" : "focusout";
                this.$element.on(("hover" == Y ? "mouseenter" : "focusin") + "." + this.type, this.options.selector, i.proxy(this.enter, this)), this.$element.on(u + "." + this.type, this.options.selector, i.proxy(this.leave, this))
            }
        }
        this.options.selector ? this._options = i.extend({}, this.options, {
            trigger: "manual",
            selector: ""
        }) : this.fixTitle()
    }, y.prototype.getDefaults = function() {
        return y.DEFAULTS
    }, y.prototype.getOptions = function(C) {
        var T = this.$element.data();
        for (var B in T) T.hasOwnProperty(B) && -1 !== i.inArray(B, L) && delete T[B];
        return (C = i.extend({}, this.getDefaults(), T, C)).delay && "number" == typeof C.delay && (C.delay = {
            show: C.delay,
            hide: C.delay
        }), C.sanitize && (C.template = x(C.template, C.whiteList, C.sanitizeFn)), C
    }, y.prototype.getDelegateOptions = function() {
        var C = {},
            T = this.getDefaults();
        return this._options && i.each(this._options, function(B, tt) {
            T[B] != tt && (C[B] = tt)
        }), C
    }, y.prototype.enter = function(C) {
        var T = C instanceof this.constructor ? C : i(C.currentTarget).data("bs." + this.type);
        if (T || (T = new this.constructor(C.currentTarget, this.getDelegateOptions()), i(C.currentTarget).data("bs." + this.type, T)), C instanceof i.Event && (T.inState["focusin" == C.type ? "focus" : "hover"] = !0), T.tip().hasClass("in") || "in" == T.hoverState) T.hoverState = "in";
        else {
            if (clearTimeout(T.timeout), T.hoverState = "in", !T.options.delay || !T.options.delay.show) return T.show();
            T.timeout = setTimeout(function() {
                "in" == T.hoverState && T.show()
            }, T.options.delay.show)
        }
    }, y.prototype.isInStateTrue = function() {
        for (var C in this.inState)
            if (this.inState[C]) return !0;
        return !1
    }, y.prototype.leave = function(C) {
        var T = C instanceof this.constructor ? C : i(C.currentTarget).data("bs." + this.type);
        if (T || (T = new this.constructor(C.currentTarget, this.getDelegateOptions()), i(C.currentTarget).data("bs." + this.type, T)), C instanceof i.Event && (T.inState["focusout" == C.type ? "focus" : "hover"] = !1), !T.isInStateTrue()) {
            if (clearTimeout(T.timeout), T.hoverState = "out", !T.options.delay || !T.options.delay.hide) return T.hide();
            T.timeout = setTimeout(function() {
                "out" == T.hoverState && T.hide()
            }, T.options.delay.hide)
        }
    }, y.prototype.show = function() {
        var C = i.Event("show.bs." + this.type);
        if (this.hasContent() && this.enabled) {
            this.$element.trigger(C);
            var T = i.contains(this.$element[0].ownerDocument.documentElement, this.$element[0]);
            if (C.isDefaultPrevented() || !T) return;
            var B = this,
                tt = this.tip(),
                K = this.getUID(this.type);
            this.setContent(), tt.attr("id", K), this.$element.attr("aria-describedby", K), this.options.animation && tt.addClass("fade");
            var Y = "function" == typeof this.options.placement ? this.options.placement.call(this, tt[0], this.$element[0]) : this.options.placement,
                st = /\s?auto?\s?/i,
                u = st.test(Y);
            u && (Y = Y.replace(st, "") || "top"), tt.detach().css({
                top: 0,
                left: 0,
                display: "block"
            }).addClass(Y).data("bs." + this.type, this), this.options.container ? tt.appendTo(i(document).find(this.options.container)) : tt.insertAfter(this.$element), this.$element.trigger("inserted.bs." + this.type);
            var ot = this.getPosition(),
                t = tt[0].offsetWidth,
                e = tt[0].offsetHeight;
            if (u) {
                var n = Y,
                    s = this.getPosition(this.$viewport);
                Y = "bottom" == Y && ot.bottom + e > s.bottom ? "top" : "top" == Y && ot.top - e < s.top ? "bottom" : "right" == Y && ot.right + t > s.width ? "left" : "left" == Y && ot.left - t < s.left ? "right" : Y, tt.removeClass(n).addClass(Y)
            }
            var r = this.getCalculatedOffset(Y, ot, t, e);
            this.applyPlacement(r, Y);
            var l = function() {
                var d = B.hoverState;
                B.$element.trigger("shown.bs." + B.type), B.hoverState = null, "out" == d && B.leave(B)
            };
            i.support.transition && this.$tip.hasClass("fade") ? tt.one("bsTransitionEnd", l).emulateTransitionEnd(y.TRANSITION_DURATION) : l()
        }
    }, y.prototype.applyPlacement = function(C, T) {
        var B = this.tip(),
            tt = B[0].offsetWidth,
            K = B[0].offsetHeight,
            Y = parseInt(B.css("margin-top"), 10),
            st = parseInt(B.css("margin-left"), 10);
        isNaN(Y) && (Y = 0), isNaN(st) && (st = 0), C.top += Y, C.left += st, i.offset.setOffset(B[0], i.extend({
            using: function(r) {
                B.css({
                    top: Math.round(r.top),
                    left: Math.round(r.left)
                })
            }
        }, C), 0), B.addClass("in");
        var u = B[0].offsetWidth,
            ot = B[0].offsetHeight;
        "top" == T && ot != K && (C.top = C.top + K - ot);
        var t = this.getViewportAdjustedDelta(T, C, u, ot);
        t.left ? C.left += t.left : C.top += t.top;
        var e = /top|bottom/.test(T),
            n = e ? 2 * t.left - tt + u : 2 * t.top - K + ot,
            s = e ? "offsetWidth" : "offsetHeight";
        B.offset(C), this.replaceArrow(n, B[0][s], e)
    }, y.prototype.replaceArrow = function(C, T, B) {
        this.arrow().css(B ? "left" : "top", 50 * (1 - C / T) + "%").css(B ? "top" : "left", "")
    }, y.prototype.setContent = function() {
        var C = this.tip(),
            T = this.getTitle();
        this.options.html ? (this.options.sanitize && (T = x(T, this.options.whiteList, this.options.sanitizeFn)), C.find(".tooltip-inner").html(T)) : C.find(".tooltip-inner").text(T), C.removeClass("fade in top bottom left right")
    }, y.prototype.hide = function(C) {
        var T = this,
            B = i(this.$tip),
            tt = i.Event("hide.bs." + this.type);

        function K() {
            "in" != T.hoverState && B.detach(), T.$element && T.$element.removeAttr("aria-describedby").trigger("hidden.bs." + T.type), C && C()
        }
        if (this.$element.trigger(tt), !tt.isDefaultPrevented()) return B.removeClass("in"), i.support.transition && B.hasClass("fade") ? B.one("bsTransitionEnd", K).emulateTransitionEnd(y.TRANSITION_DURATION) : K(), this.hoverState = null, this
    }, y.prototype.fixTitle = function() {
        var C = this.$element;
        (C.attr("title") || "string" != typeof C.attr("data-original-title")) && C.attr("data-original-title", C.attr("title") || "").attr("title", "")
    }, y.prototype.hasContent = function() {
        return this.getTitle()
    }, y.prototype.getPosition = function(C) {
        var T = (C = C || this.$element)[0],
            B = "BODY" == T.tagName,
            tt = T.getBoundingClientRect();
        null == tt.width && (tt = i.extend({}, tt, {
            width: tt.right - tt.left,
            height: tt.bottom - tt.top
        }));
        var K = window.SVGElement && T instanceof window.SVGElement,
            Y = B ? {
                top: 0,
                left: 0
            } : K ? null : C.offset(),
            st = {
                scroll: B ? document.documentElement.scrollTop || document.body.scrollTop : C.scrollTop()
            },
            u = B ? {
                width: i(window).width(),
                height: i(window).height()
            } : null;
        return i.extend({}, tt, st, u, Y)
    }, y.prototype.getCalculatedOffset = function(C, T, B, tt) {
        return "bottom" == C ? {
            top: T.top + T.height,
            left: T.left + T.width / 2 - B / 2
        } : "top" == C ? {
            top: T.top - tt,
            left: T.left + T.width / 2 - B / 2
        } : "left" == C ? {
            top: T.top + T.height / 2 - tt / 2,
            left: T.left - B
        } : {
            top: T.top + T.height / 2 - tt / 2,
            left: T.left + T.width
        }
    }, y.prototype.getViewportAdjustedDelta = function(C, T, B, tt) {
        var K = {
            top: 0,
            left: 0
        };
        if (!this.$viewport) return K;
        var Y = this.options.viewport && this.options.viewport.padding || 0,
            st = this.getPosition(this.$viewport);
        if (/right|left/.test(C)) {
            var u = T.top - Y - st.scroll,
                ot = T.top + Y - st.scroll + tt;
            u < st.top ? K.top = st.top - u : ot > st.top + st.height && (K.top = st.top + st.height - ot)
        } else {
            var t = T.left - Y,
                e = T.left + Y + B;
            t < st.left ? K.left = st.left - t : e > st.right && (K.left = st.left + st.width - e)
        }
        return K
    }, y.prototype.getTitle = function() {
        var C = this.$element,
            T = this.options;
        return C.attr("data-original-title") || ("function" == typeof T.title ? T.title.call(C[0]) : T.title)
    }, y.prototype.getUID = function(C) {
        for (; C += ~~(1e6 * Math.random()), document.getElementById(C););
        return C
    }, y.prototype.tip = function() {
        if (!this.$tip && (this.$tip = i(this.options.template), 1 != this.$tip.length)) throw new Error(this.type + " `template` option must consist of exactly 1 top-level element!");
        return this.$tip
    }, y.prototype.arrow = function() {
        return this.$arrow = this.$arrow || this.tip().find(".tooltip-arrow")
    }, y.prototype.enable = function() {
        this.enabled = !0
    }, y.prototype.disable = function() {
        this.enabled = !1
    }, y.prototype.toggleEnabled = function() {
        this.enabled = !this.enabled
    }, y.prototype.toggle = function(C) {
        var T = this;
        C && ((T = i(C.currentTarget).data("bs." + this.type)) || (T = new this.constructor(C.currentTarget, this.getDelegateOptions()), i(C.currentTarget).data("bs." + this.type, T))), C ? (T.inState.click = !T.inState.click, T.isInStateTrue() ? T.enter(T) : T.leave(T)) : T.tip().hasClass("in") ? T.leave(T) : T.enter(T)
    }, y.prototype.destroy = function() {
        var C = this;
        clearTimeout(this.timeout), this.hide(function() {
            C.$element.off("." + C.type).removeData("bs." + C.type), C.$tip && C.$tip.detach(), C.$tip = null, C.$arrow = null, C.$viewport = null, C.$element = null
        })
    }, y.prototype.sanitizeHtml = function(C) {
        return x(C, this.options.whiteList, this.options.sanitizeFn)
    };
    var N = i.fn.tooltip;
    i.fn.tooltip = function(T) {
        return this.each(function() {
            var B = i(this),
                tt = B.data("bs.tooltip"),
                K = "object" == typeof T && T;
            !tt && /destroy|hide/.test(T) || (tt || B.data("bs.tooltip", tt = new y(this, K)), "string" == typeof T && tt[T]())
        })
    }, i.fn.tooltip.Constructor = y, i.fn.tooltip.noConflict = function() {
        return i.fn.tooltip = N, this
    }
}(jQuery),
function(i) {
    "use strict";
    var L = function(it, f) {
        this.init("popover", it, f)
    };
    if (!i.fn.tooltip) throw new Error("Popover requires tooltip.js");
    L.VERSION = "3.4.1", L.DEFAULTS = i.extend({}, i.fn.tooltip.Constructor.DEFAULTS, {
        placement: "right",
        trigger: "click",
        content: "",
        template: '<div class="popover" role="tooltip"><div class="arrow"></div><h3 class="popover-title"></h3><div class="popover-content"></div></div>'
    }), ((L.prototype = i.extend({}, i.fn.tooltip.Constructor.prototype)).constructor = L).prototype.getDefaults = function() {
        return L.DEFAULTS
    }, L.prototype.setContent = function() {
        var it = this.tip(),
            f = this.getTitle(),
            b = this.getContent();
        if (this.options.html) {
            var p = typeof b;
            this.options.sanitize && (f = this.sanitizeHtml(f), "string" === p && (b = this.sanitizeHtml(b))), it.find(".popover-title").html(f), it.find(".popover-content").children().detach().end()["string" === p ? "html" : "append"](b)
        } else it.find(".popover-title").text(f), it.find(".popover-content").children().detach().end().text(b);
        it.removeClass("fade top bottom left right in"), it.find(".popover-title").html() || it.find(".popover-title").hide()
    }, L.prototype.hasContent = function() {
        return this.getTitle() || this.getContent()
    }, L.prototype.getContent = function() {
        var it = this.$element,
            f = this.options;
        return it.attr("data-content") || ("function" == typeof f.content ? f.content.call(it[0]) : f.content)
    }, L.prototype.arrow = function() {
        return this.$arrow = this.$arrow || this.tip().find(".arrow")
    };
    var ut = i.fn.popover;
    i.fn.popover = function(f) {
        return this.each(function() {
            var b = i(this),
                p = b.data("bs.popover"),
                x = "object" == typeof f && f;
            !p && /destroy|hide/.test(f) || (p || b.data("bs.popover", p = new L(this, x)), "string" == typeof f && p[f]())
        })
    }, i.fn.popover.Constructor = L, i.fn.popover.noConflict = function() {
        return i.fn.popover = ut, this
    }
}(jQuery),
function(i) {
    "use strict";

    function L(f, b) {
        this.$body = i(document.body), this.$scrollElement = i(f).is(document.body) ? i(window) : i(f), this.options = i.extend({}, L.DEFAULTS, b), this.selector = (this.options.target || "") + " .nav li > a", this.offsets = [], this.targets = [], this.activeTarget = null, this.scrollHeight = 0, this.$scrollElement.on("scroll.bs.scrollspy", i.proxy(this.process, this)), this.refresh(), this.process()
    }

    function ut(f) {
        return this.each(function() {
            var b = i(this),
                p = b.data("bs.scrollspy");
            p || b.data("bs.scrollspy", p = new L(this, "object" == typeof f && f)), "string" == typeof f && p[f]()
        })
    }
    L.VERSION = "3.4.1", L.DEFAULTS = {
        offset: 10
    }, L.prototype.getScrollHeight = function() {
        return this.$scrollElement[0].scrollHeight || Math.max(this.$body[0].scrollHeight, document.documentElement.scrollHeight)
    }, L.prototype.refresh = function() {
        var f = this,
            b = "offset",
            p = 0;
        this.offsets = [], this.targets = [], this.scrollHeight = this.getScrollHeight(), i.isWindow(this.$scrollElement[0]) || (b = "position", p = this.$scrollElement.scrollTop()), this.$body.find(this.selector).map(function() {
            var x = i(this),
                y = x.data("target") || x.attr("href"),
                N = /^#./.test(y) && i(y);
            return N && N.length && N.is(":visible") && [
                [N[b]().top + p, y]
            ] || null
        }).sort(function(x, y) {
            return x[0] - y[0]
        }).each(function() {
            f.offsets.push(this[0]), f.targets.push(this[1])
        })
    }, L.prototype.process = function() {
        var f, b = this.$scrollElement.scrollTop() + this.options.offset,
            p = this.getScrollHeight(),
            x = this.options.offset + p - this.$scrollElement.height(),
            y = this.offsets,
            N = this.targets,
            C = this.activeTarget;
        if (this.scrollHeight != p && this.refresh(), x <= b) return C != (f = N[N.length - 1]) && this.activate(f);
        if (C && b < y[0]) return this.activeTarget = null, this.clear();
        for (f = y.length; f--;) C != N[f] && b >= y[f] && (void 0 === y[f + 1] || b < y[f + 1]) && this.activate(N[f])
    }, L.prototype.activate = function(f) {
        this.activeTarget = f, this.clear();
        var p = i(this.selector + '[data-target="' + f + '"],' + this.selector + '[href="' + f + '"]').parents("li").addClass("active");
        p.parent(".dropdown-menu").length && (p = p.closest("li.dropdown").addClass("active")), p.trigger("activate.bs.scrollspy")
    }, L.prototype.clear = function() {
        i(this.selector).parentsUntil(this.options.target, ".active").removeClass("active")
    };
    var it = i.fn.scrollspy;
    i.fn.scrollspy = ut, i.fn.scrollspy.Constructor = L, i.fn.scrollspy.noConflict = function() {
        return i.fn.scrollspy = it, this
    }, i(window).on("load.bs.scrollspy.data-api", function() {
        i('[data-spy="scroll"]').each(function() {
            var f = i(this);
            ut.call(f, f.data())
        })
    })
}(jQuery),
function(i) {
    "use strict";
    var L = function(b) {
        this.element = i(b)
    };

    function ut(b) {
        return this.each(function() {
            var p = i(this),
                x = p.data("bs.tab");
            x || p.data("bs.tab", x = new L(this)), "string" == typeof b && x[b]()
        })
    }
    L.VERSION = "3.4.1", L.TRANSITION_DURATION = 150, L.prototype.show = function() {
        var b = this.element,
            p = b.closest("ul:not(.dropdown-menu)"),
            x = b.data("target");
        if (x || (x = (x = b.attr("href")) && x.replace(/.*(?=#[^\s]*$)/, "")), !b.parent("li").hasClass("active")) {
            var y = p.find(".active:last a"),
                N = i.Event("hide.bs.tab", {
                    relatedTarget: b[0]
                }),
                C = i.Event("show.bs.tab", {
                    relatedTarget: y[0]
                });
            if (y.trigger(N), b.trigger(C), !C.isDefaultPrevented() && !N.isDefaultPrevented()) {
                var T = i(document).find(x);
                this.activate(b.closest("li"), p), this.activate(T, T.parent(), function() {
                    y.trigger({
                        type: "hidden.bs.tab",
                        relatedTarget: b[0]
                    }), b.trigger({
                        type: "shown.bs.tab",
                        relatedTarget: y[0]
                    })
                })
            }
        }
    }, L.prototype.activate = function(b, p, x) {
        var y = p.find("> .active"),
            N = x && i.support.transition && (y.length && y.hasClass("fade") || !!p.find("> .fade").length);

        function C() {
            y.removeClass("active").find("> .dropdown-menu > .active").removeClass("active").end().find('[data-toggle="tab"]').attr("aria-expanded", !1), b.addClass("active").find('[data-toggle="tab"]').attr("aria-expanded", !0), N ? b.addClass("in") : b.removeClass("fade"), b.parent(".dropdown-menu").length && b.closest("li.dropdown").addClass("active").end().find('[data-toggle="tab"]').attr("aria-expanded", !0), x && x()
        }
        y.length && N ? y.one("bsTransitionEnd", C).emulateTransitionEnd(L.TRANSITION_DURATION) : C(), y.removeClass("in")
    };
    var it = i.fn.tab;
    i.fn.tab = ut, i.fn.tab.Constructor = L, i.fn.tab.noConflict = function() {
        return i.fn.tab = it, this
    };
    var f = function(b) {
        b.preventDefault(), ut.call(i(this), "show")
    };
    i(document).on("click.bs.tab.data-api", '[data-toggle="tab"]', f).on("click.bs.tab.data-api", '[data-toggle="pill"]', f)
}(jQuery),
function(i) {
    "use strict";
    var L = function(f, b) {
        this.options = i.extend({}, L.DEFAULTS, b);
        var p = this.options.target === L.DEFAULTS.target ? i(this.options.target) : i(document).find(this.options.target);
        this.$target = p.on("scroll.bs.affix.data-api", i.proxy(this.checkPosition, this)).on("click.bs.affix.data-api", i.proxy(this.checkPositionWithEventLoop, this)), this.$element = i(f), this.affixed = null, this.unpin = null, this.pinnedOffset = null, this.checkPosition()
    };

    function ut(f) {
        return this.each(function() {
            var b = i(this),
                p = b.data("bs.affix");
            p || b.data("bs.affix", p = new L(this, "object" == typeof f && f)), "string" == typeof f && p[f]()
        })
    }
    L.VERSION = "3.4.1", L.RESET = "affix affix-top affix-bottom", L.DEFAULTS = {
        offset: 0,
        target: window
    }, L.prototype.getState = function(f, b, p, x) {
        var y = this.$target.scrollTop(),
            N = this.$element.offset(),
            C = this.$target.height();
        if (null != p && "top" == this.affixed) return y < p && "top";
        if ("bottom" == this.affixed) return null != p ? !(y + this.unpin <= N.top) && "bottom" : !(y + C <= f - x) && "bottom";
        var T = null == this.affixed;
        return null != p && y <= p ? "top" : null != x && f - x <= (T ? y : N.top) + (T ? C : b) && "bottom"
    }, L.prototype.getPinnedOffset = function() {
        if (this.pinnedOffset) return this.pinnedOffset;
        this.$element.removeClass(L.RESET).addClass("affix");
        var f = this.$target.scrollTop(),
            b = this.$element.offset();
        return this.pinnedOffset = b.top - f
    }, L.prototype.checkPositionWithEventLoop = function() {
        setTimeout(i.proxy(this.checkPosition, this), 1)
    }, L.prototype.checkPosition = function() {
        if (this.$element.is(":visible")) {
            var f = this.$element.height(),
                b = this.options.offset,
                p = b.top,
                x = b.bottom,
                y = Math.max(i(document).height(), i(document.body).height());
            "object" != typeof b && (x = p = b), "function" == typeof p && (p = b.top(this.$element)), "function" == typeof x && (x = b.bottom(this.$element));
            var N = this.getState(y, f, p, x);
            if (this.affixed != N) {
                null != this.unpin && this.$element.css("top", "");
                var C = "affix" + (N ? "-" + N : ""),
                    T = i.Event(C + ".bs.affix");
                if (this.$element.trigger(T), T.isDefaultPrevented()) return;
                this.affixed = N, this.unpin = "bottom" == N ? this.getPinnedOffset() : null, this.$element.removeClass(L.RESET).addClass(C).trigger(C.replace("affix", "affixed") + ".bs.affix")
            }
            "bottom" == N && this.$element.offset({
                top: y - f - x
            })
        }
    };
    var it = i.fn.affix;
    i.fn.affix = ut, i.fn.affix.Constructor = L, i.fn.affix.noConflict = function() {
        return i.fn.affix = it, this
    }, i(window).on("load", function() {
        i('[data-spy="affix"]').each(function() {
            var f = i(this),
                b = f.data();
            b.offset = b.offset || {}, null != b.offsetBottom && (b.offset.bottom = b.offsetBottom), null != b.offsetTop && (b.offset.top = b.offsetTop), ut.call(f, b)
        })
    })
}(jQuery),
function(i) {
    "use strict";

    function L(p) {
        return i.each([{
            re: /[\xC0-\xC6]/g,
            ch: "A"
        }, {
            re: /[\xE0-\xE6]/g,
            ch: "a"
        }, {
            re: /[\xC8-\xCB]/g,
            ch: "E"
        }, {
            re: /[\xE8-\xEB]/g,
            ch: "e"
        }, {
            re: /[\xCC-\xCF]/g,
            ch: "I"
        }, {
            re: /[\xEC-\xEF]/g,
            ch: "i"
        }, {
            re: /[\xD2-\xD6]/g,
            ch: "O"
        }, {
            re: /[\xF2-\xF6]/g,
            ch: "o"
        }, {
            re: /[\xD9-\xDC]/g,
            ch: "U"
        }, {
            re: /[\xF9-\xFC]/g,
            ch: "u"
        }, {
            re: /[\xC7-\xE7]/g,
            ch: "c"
        }, {
            re: /[\xD1]/g,
            ch: "N"
        }, {
            re: /[\xF1]/g,
            ch: "n"
        }], function() {
            p = p.replace(this.re, this.ch)
        }), p
    }

    function ut(p) {
        var x = {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#x27;",
                "`": "&#x60;"
            },
            y = "(?:" + Object.keys(x).join("|") + ")",
            N = new RegExp(y),
            C = new RegExp(y, "g"),
            T = null == p ? "" : "" + p;
        return N.test(T) ? T.replace(C, function(B) {
            return x[B]
        }) : T
    }

    function it(p, x) {
        var y = arguments,
            N = p,
            C = x;
        [].shift.apply(y);
        var T, B = this.each(function() {
            var tt = i(this);
            if (tt.is("select")) {
                var K = tt.data("selectpicker"),
                    Y = "object" == typeof N && N;
                if (K) {
                    if (Y)
                        for (var st in Y) Y.hasOwnProperty(st) && (K.options[st] = Y[st])
                } else {
                    var u = i.extend({}, f.DEFAULTS, i.fn.selectpicker.defaults || {}, tt.data(), Y);
                    tt.data("selectpicker", K = new f(this, u, C))
                }
                "string" == typeof N && (T = K[N] instanceof Function ? K[N].apply(K, y) : K.options[N])
            }
        });
        return void 0 !== T ? T : B
    }
    var p, x, y, N;
    String.prototype.includes || (p = {}.toString, x = function() {
        try {
            var C = {},
                T = Object.defineProperty,
                B = T(C, C, C) && T
        } catch (tt) {}
        return B
    }(), y = "".indexOf, N = function(C) {
        if (null == this) throw TypeError();
        var T = String(this);
        if (C && "[object RegExp]" == p.call(C)) throw TypeError();
        var B = T.length,
            tt = String(C),
            K = tt.length,
            Y = arguments.length > 1 ? arguments[1] : void 0,
            st = Y ? Number(Y) : 0;
        st != st && (st = 0);
        var u = Math.min(Math.max(st, 0), B);
        return !(K + u > B) && -1 != y.call(T, tt, st)
    }, x ? x(String.prototype, "includes", {
        value: N,
        configurable: !0,
        writable: !0
    }) : String.prototype.includes = N), String.prototype.startsWith || function() {
        var p = function() {
                try {
                    var N = {},
                        C = Object.defineProperty,
                        T = C(N, N, N) && C
                } catch (B) {}
                return T
            }(),
            x = {}.toString,
            y = function(N) {
                if (null == this) throw TypeError();
                var C = String(this);
                if (N && "[object RegExp]" == x.call(N)) throw TypeError();
                var T = C.length,
                    B = String(N),
                    tt = B.length,
                    K = arguments.length > 1 ? arguments[1] : void 0,
                    Y = K ? Number(K) : 0;
                Y != Y && (Y = 0);
                var st = Math.min(Math.max(Y, 0), T);
                if (tt + st > T) return !1;
                for (var u = -1; ++u < tt;)
                    if (C.charCodeAt(st + u) != B.charCodeAt(u)) return !1;
                return !0
            };
        p ? p(String.prototype, "startsWith", {
            value: y,
            configurable: !0,
            writable: !0
        }) : String.prototype.startsWith = y
    }(), Object.keys || (Object.keys = function(p, x, y) {
        for (x in y = [], p) y.hasOwnProperty.call(p, x) && y.push(x);
        return y
    }), i.expr[":"].icontains = function(p, x, y) {
        var N = i(p);
        return (N.data("tokens") || N.text()).toUpperCase().includes(y[3].toUpperCase())
    }, i.expr[":"].ibegins = function(p, x, y) {
        var N = i(p);
        return (N.data("tokens") || N.text()).toUpperCase().startsWith(y[3].toUpperCase())
    }, i.expr[":"].aicontains = function(p, x, y) {
        var N = i(p);
        return (N.data("tokens") || N.data("normalizedText") || N.text()).toUpperCase().includes(y[3].toUpperCase())
    }, i.expr[":"].aibegins = function(p, x, y) {
        var N = i(p);
        return (N.data("tokens") || N.data("normalizedText") || N.text()).toUpperCase().startsWith(y[3].toUpperCase())
    };
    var f = function(p, x, y) {
        y && (y.stopPropagation(), y.preventDefault()), this.$element = i(p), this.$newElement = null, this.$button = null, this.$menu = null, this.$lis = null, this.options = x, null === this.options.title && (this.options.title = this.$element.attr("title")), this.val = f.prototype.val, this.render = f.prototype.render, this.refresh = f.prototype.refresh, this.setStyle = f.prototype.setStyle, this.selectAll = f.prototype.selectAll, this.deselectAll = f.prototype.deselectAll, this.destroy = f.prototype.remove, this.remove = f.prototype.remove, this.show = f.prototype.show, this.hide = f.prototype.hide, this.init()
    };
    f.VERSION = "1.7.1", f.DEFAULTS = {
        noneSelectedText: "Nothing selected",
        noneResultsText: "No results matched {0}",
        countSelectedText: function(p, x) {
            return 1 == p ? "{0} item selected" : "{0} items selected"
        },
        maxOptionsText: function(p, x) {
            return [1 == p ? "Limit reached ({n} item max)" : "Limit reached ({n} items max)", 1 == x ? "Group limit reached ({n} item max)" : "Group limit reached ({n} items max)"]
        },
        selectAllText: "Select All",
        deselectAllText: "Deselect All",
        doneButton: !1,
        doneButtonText: "Close",
        multipleSeparator: ", ",
        styleBase: "btn",
        style: "btn-default",
        size: "auto",
        title: null,
        selectedTextFormat: "values",
        width: !1,
        container: !1,
        hideDisabled: !1,
        showSubtext: !1,
        showIcon: !0,
        showContent: !0,
        dropupAuto: !0,
        header: !1,
        liveSearch: !1,
        liveSearchPlaceholder: null,
        liveSearchNormalize: !1,
        liveSearchStyle: "contains",
        actionsBox: !1,
        iconBase: "glyphicon",
        tickIcon: "glyphicon-ok",
        maxOptions: !1,
        mobile: !1,
        selectOnTab: !1,
        dropdownAlignRight: !1
    }, f.prototype = {
        constructor: f,
        init: function() {
            var p = this,
                x = this.$element.attr("id");
            this.$element.addClass("bs-select-hidden"), this.liObj = {}, this.multiple = this.$element.prop("multiple"), this.autofocus = this.$element.prop("autofocus"), this.$newElement = this.createView(), this.$element.after(this.$newElement), this.$button = this.$newElement.children("button"), this.$menu = this.$newElement.children(".dropdown-menu"), this.$menuInner = this.$menu.children(".inner"), this.$searchbox = this.$menu.find("input"), this.options.dropdownAlignRight && this.$menu.addClass("dropdown-menu-right"), void 0 !== x && (this.$button.attr("data-id", x), i('label[for="' + x + '"]').click(function(y) {
                y.preventDefault(), p.$button.focus()
            })), this.checkDisabled(), this.clickListener(), this.options.liveSearch && this.liveSearchListener(), this.render(), this.setStyle(), this.setWidth(), this.options.container && this.selectPosition(), this.$menu.data("this", this), this.$newElement.data("this", this), this.options.mobile && this.mobile(), this.$newElement.on("hide.bs.dropdown", function(y) {
                p.$element.trigger("hide.bs.select", y)
            }), this.$newElement.on("hidden.bs.dropdown", function(y) {
                p.$element.trigger("hidden.bs.select", y)
            }), this.$newElement.on("show.bs.dropdown", function(y) {
                p.$element.trigger("show.bs.select", y)
            }), this.$newElement.on("shown.bs.dropdown", function(y) {
                p.$element.trigger("shown.bs.select", y)
            }), setTimeout(function() {
                p.$element.trigger("loaded.bs.select")
            })
        },
        createDropdown: function() {
            var p = this.multiple ? " show-tick" : "",
                x = this.$element.parent().hasClass("input-group") ? " input-group-btn" : "",
                y = this.autofocus ? " autofocus" : "",
                N = this.options.header ? '<div class="popover-title"><button type="button" class="close" aria-hidden="true">&times;</button>' + this.options.header + "</div>" : "",
                C = this.options.liveSearch ? '<div class="bs-searchbox"><input type="text" class="form-control" autocomplete="off"' + (null === this.options.liveSearchPlaceholder ? "" : ' placeholder="' + ut(this.options.liveSearchPlaceholder) + '"') + "></div>" : "";
            return i('<div class="btn-group bootstrap-select' + p + x + '"><button type="button" class="' + this.options.styleBase + ' dropdown-toggle" data-toggle="dropdown"' + y + '><span class="filter-option pull-left"></span>&nbsp;<span class="caret"></span></button><div class="dropdown-menu open">' + N + C + (this.multiple && this.options.actionsBox ? '<div class="bs-actionsbox"><div class="btn-group btn-group-sm btn-block"><button type="button" class="actions-btn bs-select-all btn btn-default">' + this.options.selectAllText + '</button><button type="button" class="actions-btn bs-deselect-all btn btn-default">' + this.options.deselectAllText + "</button></div></div>" : "") + '<ul class="dropdown-menu inner" role="menu"></ul>' + (this.multiple && this.options.doneButton ? '<div class="bs-donebutton"><div class="btn-group btn-block"><button type="button" class="btn btn-sm btn-default">' + this.options.doneButtonText + "</button></div></div>" : "") + "</div></div>")
        },
        createView: function() {
            var p = this.createDropdown(),
                x = this.createLi();
            return p.find("ul")[0].innerHTML = x, p
        },
        reloadLi: function() {
            this.destroyLi();
            var p = this.createLi();
            this.$menuInner[0].innerHTML = p
        },
        destroyLi: function() {
            this.$menu.find("li").remove()
        },
        createLi: function() {
            var p = this,
                x = [],
                y = 0,
                N = document.createElement("option"),
                C = -1,
                T = function(K, Y, st, u) {
                    return "<li" + (void 0 !== st & "" !== st ? ' class="' + st + '"' : "") + (void 0 !== Y & null !== Y ? ' data-original-index="' + Y + '"' : "") + (void 0 !== u & null !== u ? 'data-optgroup="' + u + '"' : "") + ">" + K + "</li>"
                },
                B = function(K, Y, st, u) {
                    return '<a tabindex="0"' + (void 0 !== Y ? ' class="' + Y + '"' : "") + (void 0 !== st ? ' style="' + st + '"' : "") + (p.options.liveSearchNormalize ? ' data-normalized-text="' + L(ut(K)) + '"' : "") + (void 0 !== u || null !== u ? ' data-tokens="' + u + '"' : "") + ">" + K + '<span class="' + p.options.iconBase + " " + p.options.tickIcon + ' check-mark"></span></a>'
                };
            if (this.options.title && !this.multiple && !this.$element.find(".bs-title-option").length) {
                C--;
                var tt = this.$element[0];
                N.className = "bs-title-option", N.appendChild(document.createTextNode(this.options.title)), N.value = "", tt.insertBefore(N, tt.firstChild), null === tt.options[tt.selectedIndex].getAttribute("selected") && (N.selected = !0)
            }
            return this.$element.find("option").each(function(K) {
                var Y = i(this);
                if (C++, !Y.hasClass("bs-title-option")) {
                    var st = this.className || "",
                        u = this.style.cssText,
                        ot = Y.data("content") ? Y.data("content") : Y.html(),
                        t = Y.data("tokens") ? Y.data("tokens") : null,
                        e = void 0 !== Y.data("subtext") ? '<small class="text-muted">' + Y.data("subtext") + "</small>" : "",
                        n = void 0 !== Y.data("icon") ? '<span class="' + p.options.iconBase + " " + Y.data("icon") + '"></span> ' : "",
                        s = this.disabled || "OPTGROUP" === this.parentElement.tagName && this.parentElement.disabled;
                    if ("" !== n && s && (n = "<span>" + n + "</span>"), !p.options.hideDisabled || !s) {
                        if (Y.data("content") || (ot = n + '<span class="text">' + ot + e + "</span>"), "OPTGROUP" === this.parentElement.tagName && !0 !== Y.data("divider")) {
                            if (0 === Y.index()) {
                                y += 1;
                                var r = this.parentElement.label,
                                    l = void 0 !== Y.parent().data("subtext") ? '<small class="text-muted">' + Y.parent().data("subtext") + "</small>" : "",
                                    d = Y.parent().data("icon") ? '<span class="' + p.options.iconBase + " " + Y.parent().data("icon") + '"></span> ' : "",
                                    g = " " + this.parentElement.className || "";
                                r = d + '<span class="text">' + r + l + "</span>", 0 !== K && x.length > 0 && (C++, x.push(T("", null, "divider", y + "div"))), C++, x.push(T(r, null, "dropdown-header" + g, y))
                            }
                            x.push(T(B(ot, "opt " + st + g, u, t), K, "", y))
                        } else !0 === Y.data("divider") ? x.push(T("", K, "divider")) : !0 === Y.data("hidden") ? x.push(T(B(ot, st, u, t), K, "hidden is-hidden")) : (this.previousElementSibling && "OPTGROUP" === this.previousElementSibling.tagName && (C++, x.push(T("", null, "divider", y + "div"))), x.push(T(B(ot, st, u, t), K)));
                        p.liObj[K] = C
                    }
                }
            }), this.multiple || 0 !== this.$element.find("option:selected").length || this.options.title || this.$element.find("option").eq(0).prop("selected", !0).attr("selected", "selected"), x.join("")
        },
        findLis: function() {
            return null == this.$lis && (this.$lis = this.$menu.find("li")), this.$lis
        },
        render: function(p) {
            var x, y = this;
            !1 !== p && this.$element.find("option").each(function(K) {
                var Y = y.findLis().eq(y.liObj[K]);
                y.setDisabled(K, this.disabled || "OPTGROUP" === this.parentElement.tagName && this.parentElement.disabled, Y), y.setSelected(K, this.selected, Y)
            }), this.tabIndex();
            var N = this.$element.find("option").map(function() {
                    if (this.selected) {
                        if (y.options.hideDisabled && (this.disabled || "OPTGROUP" === this.parentElement.tagName && this.parentElement.disabled)) return !1;
                        var K, Y = i(this),
                            st = Y.data("icon") && y.options.showIcon ? '<i class="' + y.options.iconBase + " " + Y.data("icon") + '"></i> ' : "";
                        return K = y.options.showSubtext && Y.data("subtext") && !y.multiple ? ' <small class="text-muted">' + Y.data("subtext") + "</small>" : "", void 0 !== Y.attr("title") ? Y.attr("title") : Y.data("content") && y.options.showContent ? Y.data("content") : st + Y.html() + K
                    }
                }).toArray(),
                C = this.multiple ? N.join(this.options.multipleSeparator) : N[0];
            if (this.multiple && this.options.selectedTextFormat.indexOf("count") > -1) {
                var T = this.options.selectedTextFormat.split(">");
                if (T.length > 1 && N.length > T[1] || 1 == T.length && N.length >= 2) {
                    x = this.options.hideDisabled ? ", [disabled]" : "";
                    var B = this.$element.find("option").not('[data-divider="true"], [data-hidden="true"]' + x).length;
                    C = ("function" == typeof this.options.countSelectedText ? this.options.countSelectedText(N.length, B) : this.options.countSelectedText).replace("{0}", N.length.toString()).replace("{1}", B.toString())
                }
            }
            null == this.options.title && (this.options.title = this.$element.attr("title")), "static" == this.options.selectedTextFormat && (C = this.options.title), C || (C = void 0 !== this.options.title ? this.options.title : this.options.noneSelectedText), this.$button.attr("title", i.trim(C.replace(/<[^>]*>?/g, ""))), this.$button.children(".filter-option").html(C), this.$element.trigger("rendered.bs.select")
        },
        setStyle: function(p, x) {
            this.$element.attr("class") && this.$newElement.addClass(this.$element.attr("class").replace(/selectpicker|mobile-device|bs-select-hidden|validate\[.*\]/gi, ""));
            var y = p || this.options.style;
            "add" == x ? this.$button.addClass(y) : "remove" == x ? this.$button.removeClass(y) : (this.$button.removeClass(this.options.style), this.$button.addClass(y))
        },
        liHeight: function(p) {
            if (p || !1 !== this.options.size && !this.sizeInfo) {
                var x = document.createElement("div"),
                    y = document.createElement("div"),
                    N = document.createElement("ul"),
                    C = document.createElement("li"),
                    T = document.createElement("li"),
                    B = document.createElement("a"),
                    tt = document.createElement("span"),
                    K = this.options.header ? this.$menu.find(".popover-title")[0].cloneNode(!0) : null,
                    Y = this.options.liveSearch ? document.createElement("div") : null,
                    st = this.options.actionsBox && this.multiple ? this.$menu.find(".bs-actionsbox")[0].cloneNode(!0) : null,
                    u = this.options.doneButton && this.multiple ? this.$menu.find(".bs-donebutton")[0].cloneNode(!0) : null;
                if (tt.className = "text", x.className = this.$menu[0].parentNode.className + " open", y.className = "dropdown-menu open", N.className = "dropdown-menu inner", C.className = "divider", tt.appendChild(document.createTextNode("Inner text")), B.appendChild(tt), T.appendChild(B), N.appendChild(T), N.appendChild(C), K && y.appendChild(K), Y) {
                    var ot = document.createElement("span");
                    Y.className = "bs-searchbox", ot.className = "form-control", Y.appendChild(ot), y.appendChild(Y)
                }
                st && y.appendChild(st), y.appendChild(N), u && y.appendChild(u), x.appendChild(y), document.body.appendChild(x);
                var t = B.offsetHeight,
                    e = K ? K.offsetHeight : 0,
                    n = Y ? Y.offsetHeight : 0,
                    s = st ? st.offsetHeight : 0,
                    r = u ? u.offsetHeight : 0,
                    l = i(C).outerHeight(!0),
                    d = !!getComputedStyle && getComputedStyle(y),
                    g = d ? i(y) : null,
                    k = parseInt(d ? d.paddingTop : g.css("paddingTop")) + parseInt(d ? d.paddingBottom : g.css("paddingBottom")) + parseInt(d ? d.borderTopWidth : g.css("borderTopWidth")) + parseInt(d ? d.borderBottomWidth : g.css("borderBottomWidth")),
                    D = k + parseInt(d ? d.marginTop : g.css("marginTop")) + parseInt(d ? d.marginBottom : g.css("marginBottom")) + 2;
                document.body.removeChild(x), this.sizeInfo = {
                    liHeight: t,
                    headerHeight: e,
                    searchHeight: n,
                    actionsHeight: s,
                    doneButtonHeight: r,
                    dividerHeight: l,
                    menuPadding: k,
                    menuExtras: D
                }
            }
        },
        setSize: function() {
            this.findLis(), this.liHeight();
            var p, x, y, N, C = this,
                T = this.$menu,
                B = this.$menuInner,
                tt = i(window),
                K = this.$newElement[0].offsetHeight,
                Y = this.sizeInfo.liHeight,
                st = this.sizeInfo.headerHeight,
                u = this.sizeInfo.searchHeight,
                ot = this.sizeInfo.actionsHeight,
                t = this.sizeInfo.doneButtonHeight,
                e = this.sizeInfo.dividerHeight,
                n = this.sizeInfo.menuPadding,
                s = this.sizeInfo.menuExtras,
                r = this.options.hideDisabled ? ".disabled" : "",
                l = function() {
                    y = C.$newElement.offset().top - tt.scrollTop(), N = tt.height() - y - K
                };
            if (l(), this.options.header && T.css("padding-top", 0), "auto" === this.options.size) {
                var d = function() {
                    var D, I = function(F, A) {
                            return function(O) {
                                return A ? O.classList ? O.classList.contains(F) : i(O).hasClass(F) : !(O.classList ? O.classList.contains(F) : i(O).hasClass(F))
                            }
                        },
                        R = C.$menuInner[0].getElementsByTagName("li"),
                        P = Array.prototype.filter ? Array.prototype.filter.call(R, I("hidden", !1)) : C.$lis.not(".hidden"),
                        H = Array.prototype.filter ? Array.prototype.filter.call(P, I("dropdown-header", !0)) : P.filter(".dropdown-header");
                    l(), p = N - s, C.options.container ? (T.data("height") || T.data("height", T.height()), x = T.data("height")) : x = T.height(), C.options.dropupAuto && C.$newElement.toggleClass("dropup", y > N && x > p - s), C.$newElement.hasClass("dropup") && (p = y - s), T.css({
                        "max-height": p + "px",
                        overflow: "hidden",
                        "min-height": (D = P.length + H.length > 3 ? 3 * Y + s - 2 : 0) + st + u + ot + t + "px"
                    }), B.css({
                        "max-height": p - st - u - ot - t - n + "px",
                        "overflow-y": "auto",
                        "min-height": Math.max(D - n, 0) + "px"
                    })
                };
                d(), this.$searchbox.off("input.getSize propertychange.getSize").on("input.getSize propertychange.getSize", d), tt.off("resize.getSize scroll.getSize").on("resize.getSize scroll.getSize", d)
            } else if (this.options.size && "auto" != this.options.size && this.$lis.not(r).length > this.options.size) {
                var g = this.$lis.not(".divider").not(r).children().slice(0, this.options.size).last().parent().index(),
                    k = this.$lis.slice(0, g + 1).filter(".divider").length;
                p = Y * this.options.size + k * e + n, C.options.container ? (T.data("height") || T.data("height", T.height()), x = T.data("height")) : x = T.height(), C.options.dropupAuto && this.$newElement.toggleClass("dropup", y > N && x > p - s), T.css({
                    "max-height": p + st + u + ot + t + "px",
                    overflow: "hidden",
                    "min-height": ""
                }), B.css({
                    "max-height": p - n + "px",
                    "overflow-y": "auto",
                    "min-height": ""
                })
            }
        },
        setWidth: function() {
            if ("auto" === this.options.width) {
                this.$menu.css("min-width", "0");
                var p = this.$menu.parent().clone().appendTo("body"),
                    x = this.options.container ? this.$newElement.clone().appendTo("body") : p,
                    y = p.children(".dropdown-menu").outerWidth(),
                    N = x.css("width", "auto").children("button").outerWidth();
                p.remove(), x.remove(), this.$newElement.css("width", Math.max(y, N) + "px")
            } else "fit" === this.options.width ? (this.$menu.css("min-width", ""), this.$newElement.css("width", "").addClass("fit-width")) : this.options.width ? (this.$menu.css("min-width", ""), this.$newElement.css("width", this.options.width)) : (this.$menu.css("min-width", ""), this.$newElement.css("width", ""));
            this.$newElement.hasClass("fit-width") && "fit" !== this.options.width && this.$newElement.removeClass("fit-width")
        },
        selectPosition: function() {
            var p, x, y = this,
                C = i("<div />"),
                T = function(B) {
                    C.addClass(B.attr("class").replace(/form-control|fit-width/gi, "")).toggleClass("dropup", B.hasClass("dropup")), p = B.offset(), x = B.hasClass("dropup") ? 0 : B[0].offsetHeight, C.css({
                        top: p.top + x,
                        left: p.left,
                        width: B[0].offsetWidth,
                        position: "absolute"
                    })
                };
            this.$newElement.on("click", function() {
                y.isDisabled() || (T(i(this)), C.appendTo(y.options.container), C.toggleClass("open", !i(this).hasClass("open")), C.append(y.$menu))
            }), i(window).on("resize scroll", function() {
                T(y.$newElement)
            }), this.$element.on("hide.bs.select", function() {
                y.$menu.data("height", y.$menu.height()), C.detach()
            })
        },
        setSelected: function(p, x, N) {
            N || (N = this.findLis().eq(this.liObj[p])), N.toggleClass("selected", x)
        },
        setDisabled: function(p, x, N) {
            N || (N = this.findLis().eq(this.liObj[p])), x ? N.addClass("disabled").children("a").attr("href", "#").attr("tabindex", -1) : N.removeClass("disabled").children("a").removeAttr("href").attr("tabindex", 0)
        },
        isDisabled: function() {
            return this.$element[0].disabled
        },
        checkDisabled: function() {
            var p = this;
            this.isDisabled() ? (this.$newElement.addClass("disabled"), this.$button.addClass("disabled").attr("tabindex", -1)) : (this.$button.hasClass("disabled") && (this.$newElement.removeClass("disabled"), this.$button.removeClass("disabled")), -1 != this.$button.attr("tabindex") || this.$element.data("tabindex") || this.$button.removeAttr("tabindex")), this.$button.click(function() {
                return !p.isDisabled()
            })
        },
        tabIndex: function() {
            this.$element.is("[tabindex]") && (this.$element.data("tabindex", this.$element.attr("tabindex")), this.$button.attr("tabindex", this.$element.data("tabindex")))
        },
        clickListener: function() {
            var p = this,
                x = i(document);
            this.$newElement.on("touchstart.dropdown", ".dropdown-menu", function(y) {
                y.stopPropagation()
            }), x.data("spaceSelect", !1), this.$button.on("keyup", function(y) {
                /(32)/.test(y.keyCode.toString(10)) && x.data("spaceSelect") && (y.preventDefault(), x.data("spaceSelect", !1))
            }), this.$newElement.on("click", function() {
                p.setSize(), p.$element.on("shown.bs.select", function() {
                    if (p.options.liveSearch || p.multiple) {
                        if (!p.multiple) {
                            var y = p.liObj[p.$element[0].selectedIndex];
                            if ("number" != typeof y) return;
                            var N = p.$lis.eq(y)[0].offsetTop - p.$menuInner[0].offsetTop;
                            p.$menuInner[0].scrollTop = N = N - p.$menuInner[0].offsetHeight / 2 + p.sizeInfo.liHeight / 2
                        }
                    } else p.$menu.find(".selected a").focus()
                })
            }), this.$menu.on("click", "li a", function(y) {
                var N = i(this),
                    C = N.parent().data("originalIndex"),
                    T = p.$element.val(),
                    B = p.$element.prop("selectedIndex");
                if (p.multiple && y.stopPropagation(), y.preventDefault(), !p.isDisabled() && !N.parent().hasClass("disabled")) {
                    var tt = p.$element.find("option"),
                        K = tt.eq(C),
                        Y = K.prop("selected"),
                        st = K.parent("optgroup"),
                        u = p.options.maxOptions,
                        ot = st.data("maxOptions") || !1;
                    if (p.multiple) {
                        if (K.prop("selected", !Y), p.setSelected(C, !Y), N.blur(), !1 !== u || !1 !== ot) {
                            var t = u < tt.filter(":selected").length,
                                e = ot < st.find("option:selected").length;
                            if (u && t || ot && e)
                                if (u && 1 == u) tt.prop("selected", !1), K.prop("selected", !0), p.$menu.find(".selected").removeClass("selected"), p.setSelected(C, !0);
                                else if (ot && 1 == ot) {
                                st.find("option:selected").prop("selected", !1), K.prop("selected", !0);
                                var n = N.parent().data("optgroup");
                                p.$menu.find('[data-optgroup="' + n + '"]').removeClass("selected"), p.setSelected(C, !0)
                            } else {
                                var s = "function" == typeof p.options.maxOptionsText ? p.options.maxOptionsText(u, ot) : p.options.maxOptionsText,
                                    r = s[0].replace("{n}", u),
                                    l = s[1].replace("{n}", ot),
                                    d = i('<div class="notify"></div>');
                                s[2] && (r = r.replace("{var}", s[2][u > 1 ? 0 : 1]), l = l.replace("{var}", s[2][ot > 1 ? 0 : 1])), K.prop("selected", !1), p.$menu.append(d), u && t && (d.append(i("<div>" + r + "</div>")), p.$element.trigger("maxReached.bs.select")), ot && e && (d.append(i("<div>" + l + "</div>")), p.$element.trigger("maxReachedGrp.bs.select")), setTimeout(function() {
                                    p.setSelected(C, !1)
                                }, 10), d.delay(750).fadeOut(300, function() {
                                    i(this).remove()
                                })
                            }
                        }
                    } else tt.prop("selected", !1), K.prop("selected", !0), p.$menu.find(".selected").removeClass("selected"), p.setSelected(C, !0);
                    p.multiple ? p.options.liveSearch && p.$searchbox.focus() : p.$button.focus(), (T != p.$element.val() && p.multiple || B != p.$element.prop("selectedIndex") && !p.multiple) && (p.$element.change(), p.$element.trigger("changed.bs.select", [C, K.prop("selected"), Y]))
                }
            }), this.$menu.on("click", "li.disabled a, .popover-title, .popover-title :not(.close)", function(y) {
                y.currentTarget == this && (y.preventDefault(), y.stopPropagation(), p.options.liveSearch && !i(y.target).hasClass("close") ? p.$searchbox.focus() : p.$button.focus())
            }), this.$menu.on("click", "li.divider, li.dropdown-header", function(y) {
                y.preventDefault(), y.stopPropagation(), p.options.liveSearch ? p.$searchbox.focus() : p.$button.focus()
            }), this.$menu.on("click", ".popover-title .close", function() {
                p.$button.click()
            }), this.$searchbox.on("click", function(y) {
                y.stopPropagation()
            }), this.$menu.on("click", ".actions-btn", function(y) {
                p.options.liveSearch ? p.$searchbox.focus() : p.$button.focus(), y.preventDefault(), y.stopPropagation(), i(this).hasClass("bs-select-all") ? p.selectAll() : p.deselectAll(), p.$element.change()
            }), this.$element.change(function() {
                p.render(!1)
            })
        },
        liveSearchListener: function() {
            var p = this,
                x = i('<li class="no-results"></li>');
            this.$newElement.on("click.dropdown.data-api touchstart.dropdown.data-api", function() {
                p.$menuInner.find(".active").removeClass("active"), p.$searchbox.val() && (p.$searchbox.val(""), p.$lis.not(".is-hidden").removeClass("hidden"), x.parent().length && x.remove()), p.multiple || p.$menuInner.find(".selected").addClass("active"), setTimeout(function() {
                    p.$searchbox.focus()
                }, 10)
            }), this.$searchbox.on("click.dropdown.data-api focus.dropdown.data-api touchend.dropdown.data-api", function(y) {
                y.stopPropagation()
            }), this.$searchbox.on("input propertychange", function() {
                if (p.$searchbox.val()) {
                    var y = p.$lis.not(".is-hidden").removeClass("hidden").children("a");
                    (y = y.not(p.options.liveSearchNormalize ? ":a" + p._searchStyle() + "(" + L(p.$searchbox.val()) + ")" : ":" + p._searchStyle() + "(" + p.$searchbox.val() + ")")).parent().addClass("hidden"), p.$lis.filter(".dropdown-header").each(function() {
                        var C = i(this),
                            T = C.data("optgroup");
                        0 === p.$lis.filter("[data-optgroup=" + T + "]").not(C).not(".hidden").length && (C.addClass("hidden"), p.$lis.filter("[data-optgroup=" + T + "div]").addClass("hidden"))
                    });
                    var N = p.$lis.not(".hidden");
                    N.each(function(C) {
                        var T = i(this);
                        T.hasClass("divider") && (T.index() === N.eq(0).index() || T.index() === N.last().index() || N.eq(C + 1).hasClass("divider")) && T.addClass("hidden")
                    }), p.$lis.not(".hidden, .no-results").length ? x.parent().length && x.remove() : (x.parent().length && x.remove(), x.html(p.options.noneResultsText.replace("{0}", '"' + ut(p.$searchbox.val()) + '"')).show(), p.$menuInner.append(x))
                } else p.$lis.not(".is-hidden").removeClass("hidden"), x.parent().length && x.remove();
                p.$lis.filter(".active").removeClass("active"), p.$lis.not(".hidden, .divider, .dropdown-header").eq(0).addClass("active").children("a").focus(), i(this).focus()
            })
        },
        _searchStyle: function() {
            var p = "icontains";
            switch (this.options.liveSearchStyle) {
                case "begins":
                case "startsWith":
                    p = "ibegins"
            }
            return p
        },
        val: function(p) {
            return void 0 !== p ? (this.$element.val(p), this.render(), this.$element) : this.$element.val()
        },
        selectAll: function() {
            this.findLis(), this.$element.find("option:enabled").not("[data-divider], [data-hidden]").prop("selected", !0), this.$lis.not(".divider, .dropdown-header, .disabled, .hidden").addClass("selected"), this.render(!1)
        },
        deselectAll: function() {
            this.findLis(), this.$element.find("option:enabled").not("[data-divider], [data-hidden]").prop("selected", !1), this.$lis.not(".divider, .dropdown-header, .disabled, .hidden").removeClass("selected"), this.render(!1)
        },
        keydown: function(p) {
            var x, y, N, C, T, B, tt, K, Y, st = i(this),
                u = st.is("input") ? st.parent().parent() : st.parent(),
                ot = u.data("this"),
                t = ":not(.disabled, .hidden, .dropdown-header, .divider)",
                e = {
                    32: " ",
                    48: "0",
                    49: "1",
                    50: "2",
                    51: "3",
                    52: "4",
                    53: "5",
                    54: "6",
                    55: "7",
                    56: "8",
                    57: "9",
                    59: ";",
                    65: "a",
                    66: "b",
                    67: "c",
                    68: "d",
                    69: "e",
                    70: "f",
                    71: "g",
                    72: "h",
                    73: "i",
                    74: "j",
                    75: "k",
                    76: "l",
                    77: "m",
                    78: "n",
                    79: "o",
                    80: "p",
                    81: "q",
                    82: "r",
                    83: "s",
                    84: "t",
                    85: "u",
                    86: "v",
                    87: "w",
                    88: "x",
                    89: "y",
                    90: "z",
                    96: "0",
                    97: "1",
                    98: "2",
                    99: "3",
                    100: "4",
                    101: "5",
                    102: "6",
                    103: "7",
                    104: "8",
                    105: "9"
                };
            if (ot.options.liveSearch && (u = st.parent().parent()), ot.options.container && (u = ot.$menu), x = i("[role=menu] li a", u), !(Y = ot.$menu.parent().hasClass("open")) && (p.keyCode >= 48 && p.keyCode <= 57 || event.keyCode >= 65 && event.keyCode <= 90) && (ot.options.container ? ot.$newElement.trigger("click") : (ot.setSize(), ot.$menu.parent().addClass("open"), Y = !0), ot.$searchbox.focus()), ot.options.liveSearch && (/(^9$|27)/.test(p.keyCode.toString(10)) && Y && 0 === ot.$menu.find(".active").length && (p.preventDefault(), ot.$menu.parent().removeClass("open"), ot.options.container && ot.$newElement.removeClass("open"), ot.$button.focus()), x = i("[role=menu] li:not(.disabled, .hidden, .dropdown-header, .divider)", u), st.val() || /(38|40)/.test(p.keyCode.toString(10)) || 0 === x.filter(".active").length && (x = (x = ot.$newElement.find("li")).filter(ot.options.liveSearchNormalize ? ":a" + ot._searchStyle() + "(" + L(e[p.keyCode]) + ")" : ":" + ot._searchStyle() + "(" + e[p.keyCode] + ")"))), x.length) {
                if (/(38|40)/.test(p.keyCode.toString(10))) y = x.index(x.filter(":focus")), C = x.parent(t).first().data("originalIndex"), T = x.parent(t).last().data("originalIndex"), N = x.eq(y).parent().nextAll(t).eq(0).data("originalIndex"), B = x.eq(y).parent().prevAll(t).eq(0).data("originalIndex"), tt = x.eq(N).parent().prevAll(t).eq(0).data("originalIndex"), ot.options.liveSearch && (x.each(function(d) {
                    i(this).hasClass("disabled") || i(this).data("index", d)
                }), y = x.index(x.filter(".active")), C = x.first().data("index"), T = x.last().data("index"), N = x.eq(y).nextAll().eq(0).data("index"), B = x.eq(y).prevAll().eq(0).data("index"), tt = x.eq(N).prevAll().eq(0).data("index")), K = st.data("prevIndex"), 38 == p.keyCode ? (ot.options.liveSearch && (y -= 1), y != tt && y > B && (y = B), C > y && (y = C), y == K && (y = T)) : 40 == p.keyCode && (ot.options.liveSearch && (y += 1), -1 == y && (y = 0), y != tt && N > y && (y = N), y > T && (y = T), y == K && (y = C)), st.data("prevIndex", y), ot.options.liveSearch ? (p.preventDefault(), st.hasClass("dropdown-toggle") || (x.removeClass("active").eq(y).addClass("active").children("a").focus(), st.focus())) : x.eq(y).focus();
                else if (!st.is("input")) {
                    var n, r = [];
                    x.each(function() {
                        i(this).parent().hasClass("disabled") || i.trim(i(this).text().toLowerCase()).substring(0, 1) == e[p.keyCode] && r.push(i(this).parent().index())
                    }), n = i(document).data("keycount"), n++, i(document).data("keycount", n), i.trim(i(":focus").text().toLowerCase()).substring(0, 1) != e[p.keyCode] ? (n = 1, i(document).data("keycount", n)) : n >= r.length && (i(document).data("keycount", 0), n > r.length && (n = 1)), x.eq(r[n - 1]).focus()
                }
                if ((/(13|32)/.test(p.keyCode.toString(10)) || /(^9$)/.test(p.keyCode.toString(10)) && ot.options.selectOnTab) && Y) {
                    if (/(32)/.test(p.keyCode.toString(10)) || p.preventDefault(), ot.options.liveSearch) /(32)/.test(p.keyCode.toString(10)) || (ot.$menu.find(".active a").click(), st.focus());
                    else {
                        var l = i(":focus");
                        l.click(), l.focus(), p.preventDefault(), i(document).data("spaceSelect", !0)
                    }
                    i(document).data("keycount", 0)
                }(/(^9$|27)/.test(p.keyCode.toString(10)) && Y && (ot.multiple || ot.options.liveSearch) || /(27)/.test(p.keyCode.toString(10)) && !Y) && (ot.$menu.parent().removeClass("open"), ot.options.container && ot.$newElement.removeClass("open"), ot.$button.focus())
            }
        },
        mobile: function() {
            this.$element.addClass("mobile-device").appendTo(this.$newElement), this.options.container && this.$menu.hide()
        },
        refresh: function() {
            this.$lis = null, this.reloadLi(), this.render(), this.checkDisabled(), this.liHeight(!0), this.setStyle(), this.setWidth(), this.$searchbox.trigger("propertychange"), this.$element.trigger("refreshed.bs.select")
        },
        hide: function() {
            this.$newElement.hide()
        },
        show: function() {
            this.$newElement.show()
        },
        remove: function() {
            this.$newElement.remove(), this.$element.remove()
        }
    };
    var b = i.fn.selectpicker;
    i.fn.selectpicker = it, i.fn.selectpicker.Constructor = f, i.fn.selectpicker.noConflict = function() {
        return i.fn.selectpicker = b, this
    }, i(document).data("keycount", 0).on("keydown", '.bootstrap-select [data-toggle=dropdown], .bootstrap-select [role="menu"], .bs-searchbox input', f.prototype.keydown).on("focusin.modal", '.bootstrap-select [data-toggle=dropdown], .bootstrap-select [role="menu"], .bs-searchbox input', function(p) {
        p.stopPropagation()
    }), i(window).on("load.bs.select.data-api", function() {
        i(".selectpicker").each(function() {
            var p = i(this);
            it.call(p, p.data())
        })
    })
}(jQuery),
function(i, L) {
    "function" == typeof define && define.amd ? define(["jquery"], function(ut) {
        return L(ut)
    }) : "object" == typeof exports ? module.exports = L(require("jquery")) : jQuery && !jQuery.fn.colorpicker && L(jQuery)
}(0, function(i) {
    "use strict";
    var L = function(f, b, p, x, y) {
        this.fallbackValue = p ? p && void 0 !== p.h ? p : this.value = {
            h: 0,
            s: 0,
            b: 0,
            a: 1
        } : null, this.fallbackFormat = x || "rgba", this.hexNumberSignPrefix = !0 === y, this.value = this.fallbackValue, this.origFormat = null, this.predefinedColors = b || {}, this.colors = i.extend({}, L.webColors, this.predefinedColors), f && (void 0 !== f.h ? this.value = f : this.setColor(String(f))), this.value || (this.value = {
            h: 0,
            s: 0,
            b: 0,
            a: 1
        })
    };
    L.webColors = {
        aliceblue: "f0f8ff",
        antiquewhite: "faebd7",
        aqua: "00ffff",
        aquamarine: "7fffd4",
        azure: "f0ffff",
        beige: "f5f5dc",
        bisque: "ffe4c4",
        black: "000000",
        blanchedalmond: "ffebcd",
        blue: "0000ff",
        blueviolet: "8a2be2",
        brown: "a52a2a",
        burlywood: "deb887",
        cadetblue: "5f9ea0",
        chartreuse: "7fff00",
        chocolate: "d2691e",
        coral: "ff7f50",
        cornflowerblue: "6495ed",
        cornsilk: "fff8dc",
        crimson: "dc143c",
        cyan: "00ffff",
        darkblue: "00008b",
        darkcyan: "008b8b",
        darkgoldenrod: "b8860b",
        darkgray: "a9a9a9",
        darkgreen: "006400",
        darkkhaki: "bdb76b",
        darkmagenta: "8b008b",
        darkolivegreen: "556b2f",
        darkorange: "ff8c00",
        darkorchid: "9932cc",
        darkred: "8b0000",
        darksalmon: "e9967a",
        darkseagreen: "8fbc8f",
        darkslateblue: "483d8b",
        darkslategray: "2f4f4f",
        darkturquoise: "00ced1",
        darkviolet: "9400d3",
        deeppink: "ff1493",
        deepskyblue: "00bfff",
        dimgray: "696969",
        dodgerblue: "1e90ff",
        firebrick: "b22222",
        floralwhite: "fffaf0",
        forestgreen: "228b22",
        fuchsia: "ff00ff",
        gainsboro: "dcdcdc",
        ghostwhite: "f8f8ff",
        gold: "ffd700",
        goldenrod: "daa520",
        gray: "808080",
        green: "008000",
        greenyellow: "adff2f",
        honeydew: "f0fff0",
        hotpink: "ff69b4",
        indianred: "cd5c5c",
        indigo: "4b0082",
        ivory: "fffff0",
        khaki: "f0e68c",
        lavender: "e6e6fa",
        lavenderblush: "fff0f5",
        lawngreen: "7cfc00",
        lemonchiffon: "fffacd",
        lightblue: "add8e6",
        lightcoral: "f08080",
        lightcyan: "e0ffff",
        lightgoldenrodyellow: "fafad2",
        lightgrey: "d3d3d3",
        lightgreen: "90ee90",
        lightpink: "ffb6c1",
        lightsalmon: "ffa07a",
        lightseagreen: "20b2aa",
        lightskyblue: "87cefa",
        lightslategray: "778899",
        lightsteelblue: "b0c4de",
        lightyellow: "ffffe0",
        lime: "00ff00",
        limegreen: "32cd32",
        linen: "faf0e6",
        magenta: "ff00ff",
        maroon: "800000",
        mediumaquamarine: "66cdaa",
        mediumblue: "0000cd",
        mediumorchid: "ba55d3",
        mediumpurple: "9370d8",
        mediumseagreen: "3cb371",
        mediumslateblue: "7b68ee",
        mediumspringgreen: "00fa9a",
        mediumturquoise: "48d1cc",
        mediumvioletred: "c71585",
        midnightblue: "191970",
        mintcream: "f5fffa",
        mistyrose: "ffe4e1",
        moccasin: "ffe4b5",
        navajowhite: "ffdead",
        navy: "000080",
        oldlace: "fdf5e6",
        olive: "808000",
        olivedrab: "6b8e23",
        orange: "ffa500",
        orangered: "ff4500",
        orchid: "da70d6",
        palegoldenrod: "eee8aa",
        palegreen: "98fb98",
        paleturquoise: "afeeee",
        palevioletred: "d87093",
        papayawhip: "ffefd5",
        peachpuff: "ffdab9",
        peru: "cd853f",
        pink: "ffc0cb",
        plum: "dda0dd",
        powderblue: "b0e0e6",
        purple: "800080",
        red: "ff0000",
        rosybrown: "bc8f8f",
        royalblue: "4169e1",
        saddlebrown: "8b4513",
        salmon: "fa8072",
        sandybrown: "f4a460",
        seagreen: "2e8b57",
        seashell: "fff5ee",
        sienna: "a0522d",
        silver: "c0c0c0",
        skyblue: "87ceeb",
        slateblue: "6a5acd",
        slategray: "708090",
        snow: "fffafa",
        springgreen: "00ff7f",
        steelblue: "4682b4",
        tan: "d2b48c",
        teal: "008080",
        thistle: "d8bfd8",
        tomato: "ff6347",
        turquoise: "40e0d0",
        violet: "ee82ee",
        wheat: "f5deb3",
        white: "ffffff",
        whitesmoke: "f5f5f5",
        yellow: "ffff00",
        yellowgreen: "9acd32",
        transparent: "transparent"
    }, L.prototype = {
        constructor: L,
        colors: {},
        predefinedColors: {},
        getValue: function() {
            return this.value
        },
        setValue: function(f) {
            this.value = f
        },
        _sanitizeNumber: function(f) {
            return "number" == typeof f ? f : isNaN(f) || null === f || "" === f || void 0 === f ? 1 : "" === f ? 0 : void 0 !== f.toLowerCase ? (f.match(/^\./) && (f = "0" + f), Math.ceil(100 * parseFloat(f)) / 100) : 1
        },
        isTransparent: function(f) {
            return !(!f || !("string" == typeof f || f instanceof String)) && ("transparent" === (f = f.toLowerCase().trim()) || f.match(/#?00000000/) || f.match(/(rgba|hsla)\(0,0,0,0?\.?0\)/))
        },
        rgbaIsTransparent: function(f) {
            return 0 === f.r && 0 === f.g && 0 === f.b && 0 === f.a
        },
        setColor: function(f) {
            if (f = f.toLowerCase().trim()) {
                if (this.isTransparent(f)) return this.value = {
                    h: 0,
                    s: 0,
                    b: 0,
                    a: 0
                }, !0;
                var b = this.parse(f);
                b ? (this.value = this.value = {
                    h: b.h,
                    s: b.s,
                    b: b.b,
                    a: b.a
                }, this.origFormat || (this.origFormat = b.format)) : this.fallbackValue && (this.value = this.fallbackValue)
            }
            return !1
        },
        setHue: function(f) {
            this.value.h = 1 - f
        },
        setSaturation: function(f) {
            this.value.s = f
        },
        setBrightness: function(f) {
            this.value.b = 1 - f
        },
        setAlpha: function(f) {
            this.value.a = Math.round(parseInt(100 * (1 - f), 10) / 100 * 100) / 100
        },
        toRGB: function(f, b, p, x) {
            var y, N, C, T, B;
            return 0 === arguments.length && (f = this.value.h, b = this.value.s, p = this.value.b, x = this.value.a), f = (f *= 360) % 360 / 60, y = N = C = p - (B = p * b), y += [B, T = B * (1 - Math.abs(f % 2 - 1)), 0, 0, T, B][f = ~~f], N += [T, B, B, T, 0, 0][f], C += [0, 0, T, B, B, T][f], {
                r: Math.round(255 * y),
                g: Math.round(255 * N),
                b: Math.round(255 * C),
                a: x
            }
        },
        toHex: function(f, b, p, x) {
            0 === arguments.length && (f = this.value.h, b = this.value.s, p = this.value.b, x = this.value.a);
            var y = this.toRGB(f, b, p, x);
            if (this.rgbaIsTransparent(y)) return "transparent";
            var N = (this.hexNumberSignPrefix ? "#" : "") + ((1 << 24) + (parseInt(y.r) << 16) + (parseInt(y.g) << 8) + parseInt(y.b)).toString(16).slice(1);
            return N
        },
        toHSL: function(f, b, p, x) {
            0 === arguments.length && (f = this.value.h, b = this.value.s, p = this.value.b, x = this.value.a);
            var y = f,
                N = (2 - b) * p,
                C = b * p;
            return C /= N > 0 && N <= 1 ? N : 2 - N, N /= 2, C > 1 && (C = 1), {
                h: isNaN(y) ? 0 : y,
                s: isNaN(C) ? 0 : C,
                l: isNaN(N) ? 0 : N,
                a: isNaN(x) ? 0 : x
            }
        },
        toAlias: function(f, b, p, x) {
            var y, N = 0 === arguments.length ? this.toHex() : this.toHex(f, b, p, x),
                C = "alias" === this.origFormat ? N : this.toString(this.origFormat, !1);
            for (var T in this.colors)
                if ((y = this.colors[T].toLowerCase().trim()) === N || y === C) return T;
            return !1
        },
        RGBtoHSB: function(f, b, p, x) {
            var N, C, T;
            return f /= 255, b /= 255, p /= 255, N = 0 == (T = (C = Math.max(f, b, p)) - Math.min(f, b, p)) ? 0 : T / C, {
                h: this._sanitizeNumber(((0 === T ? null : C === f ? (b - p) / T : C === b ? (p - f) / T + 2 : (f - b) / T + 4) + 360) % 6 * 60 / 360),
                s: N,
                b: C,
                a: this._sanitizeNumber(x)
            }
        },
        HueToRGB: function(f, b, p) {
            return p < 0 ? p += 1 : p > 1 && (p -= 1), 6 * p < 1 ? f + (b - f) * p * 6 : 2 * p < 1 ? b : 3 * p < 2 ? f + (b - f) * (2 / 3 - p) * 6 : f
        },
        HSLtoRGB: function(f, b, p, x) {
            var y;
            b < 0 && (b = 0);
            var N = 2 * p - (y = p <= .5 ? p * (1 + b) : p + b - p * b),
                T = f,
                B = f - 1 / 3;
            return [Math.round(255 * this.HueToRGB(N, y, f + 1 / 3)), Math.round(255 * this.HueToRGB(N, y, T)), Math.round(255 * this.HueToRGB(N, y, B)), this._sanitizeNumber(x)]
        },
        parse: function(f) {
            if (0 === arguments.length) return !1;
            var b, p, x = this,
                y = !1,
                N = void 0 !== this.colors[f];
            return N && (f = this.colors[f].toLowerCase().trim()), i.each(this.stringParsers, function(C, T) {
                var B = T.re.exec(f);
                return !(b = B && T.parse.apply(x, [B])) || (y = {}, p = N ? "alias" : T.format ? T.format : x.getValidFallbackFormat(), (y = p.match(/hsla?/) ? x.RGBtoHSB.apply(x, x.HSLtoRGB.apply(x, b)) : x.RGBtoHSB.apply(x, b)) instanceof Object && (y.format = p), !1)
            }), y
        },
        getValidFallbackFormat: function() {
            var f = ["rgba", "rgb", "hex", "hsla", "hsl"];
            return this.origFormat && -1 !== f.indexOf(this.origFormat) ? this.origFormat : this.fallbackFormat && -1 !== f.indexOf(this.fallbackFormat) ? this.fallbackFormat : "rgba"
        },
        toString: function(f, b) {
            b = b || !1;
            var p = !1;
            switch (f = f || this.origFormat || this.fallbackFormat) {
                case "rgb":
                    return p = this.toRGB(), this.rgbaIsTransparent(p) ? "transparent" : "rgb(" + p.r + "," + p.g + "," + p.b + ")";
                case "rgba":
                    return "rgba(" + (p = this.toRGB()).r + "," + p.g + "," + p.b + "," + p.a + ")";
                case "hsl":
                    return p = this.toHSL(), "hsl(" + Math.round(360 * p.h) + "," + Math.round(100 * p.s) + "%," + Math.round(100 * p.l) + "%)";
                case "hsla":
                    return p = this.toHSL(), "hsla(" + Math.round(360 * p.h) + "," + Math.round(100 * p.s) + "%," + Math.round(100 * p.l) + "%," + p.a + ")";
                case "hex":
                    return this.toHex();
                case "alias":
                    return !1 === (p = this.toAlias()) ? this.toString(this.getValidFallbackFormat()) : b && !(p in L.webColors) && p in this.predefinedColors ? this.predefinedColors[p] : p;
                default:
                    return p
            }
        },
        stringParsers: [{
            re: /rgb\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*?\)/,
            format: "rgb",
            parse: function(f) {
                return [f[1], f[2], f[3], 1]
            }
        }, {
            re: /rgb\(\s*(\d*(?:\.\d+)?)\%\s*,\s*(\d*(?:\.\d+)?)\%\s*,\s*(\d*(?:\.\d+)?)\%\s*?\)/,
            format: "rgb",
            parse: function(f) {
                return [2.55 * f[1], 2.55 * f[2], 2.55 * f[3], 1]
            }
        }, {
            re: /rgba\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*(?:,\s*(\d*(?:\.\d+)?)\s*)?\)/,
            format: "rgba",
            parse: function(f) {
                return [f[1], f[2], f[3], f[4]]
            }
        }, {
            re: /rgba\(\s*(\d*(?:\.\d+)?)\%\s*,\s*(\d*(?:\.\d+)?)\%\s*,\s*(\d*(?:\.\d+)?)\%\s*(?:,\s*(\d*(?:\.\d+)?)\s*)?\)/,
            format: "rgba",
            parse: function(f) {
                return [2.55 * f[1], 2.55 * f[2], 2.55 * f[3], f[4]]
            }
        }, {
            re: /hsl\(\s*(\d*(?:\.\d+)?)\s*,\s*(\d*(?:\.\d+)?)\%\s*,\s*(\d*(?:\.\d+)?)\%\s*?\)/,
            format: "hsl",
            parse: function(f) {
                return [f[1] / 360, f[2] / 100, f[3] / 100, f[4]]
            }
        }, {
            re: /hsla\(\s*(\d*(?:\.\d+)?)\s*,\s*(\d*(?:\.\d+)?)\%\s*,\s*(\d*(?:\.\d+)?)\%\s*(?:,\s*(\d*(?:\.\d+)?)\s*)?\)/,
            format: "hsla",
            parse: function(f) {
                return [f[1] / 360, f[2] / 100, f[3] / 100, f[4]]
            }
        }, {
            re: /#?([a-fA-F0-9]{2})([a-fA-F0-9]{2})([a-fA-F0-9]{2})/,
            format: "hex",
            parse: function(f) {
                return [parseInt(f[1], 16), parseInt(f[2], 16), parseInt(f[3], 16), 1]
            }
        }, {
            re: /#?([a-fA-F0-9])([a-fA-F0-9])([a-fA-F0-9])/,
            format: "hex",
            parse: function(f) {
                return [parseInt(f[1] + f[1], 16), parseInt(f[2] + f[2], 16), parseInt(f[3] + f[3], 16), 1]
            }
        }],
        colorNameToHex: function(f) {
            return void 0 !== this.colors[f.toLowerCase()] && this.colors[f.toLowerCase()]
        }
    };
    var ut = {
            horizontal: !1,
            inline: !1,
            color: !1,
            format: !1,
            input: "input",
            container: !1,
            component: ".add-on, .input-group-addon",
            fallbackColor: !1,
            fallbackFormat: "hex",
            hexNumberSignPrefix: !0,
            sliders: {
                saturation: {
                    maxLeft: 100,
                    maxTop: 100,
                    callLeft: "setSaturation",
                    callTop: "setBrightness"
                },
                hue: {
                    maxLeft: 0,
                    maxTop: 100,
                    callLeft: !1,
                    callTop: "setHue"
                },
                alpha: {
                    maxLeft: 0,
                    maxTop: 100,
                    callLeft: !1,
                    callTop: "setAlpha"
                }
            },
            slidersHorz: {
                saturation: {
                    maxLeft: 100,
                    maxTop: 100,
                    callLeft: "setSaturation",
                    callTop: "setBrightness"
                },
                hue: {
                    maxLeft: 100,
                    maxTop: 0,
                    callLeft: "setHue",
                    callTop: !1
                },
                alpha: {
                    maxLeft: 100,
                    maxTop: 0,
                    callLeft: "setAlpha",
                    callTop: !1
                }
            },
            template: '<div class="colorpicker dropdown-menu"><div class="colorpicker-saturation"><i><b></b></i></div><div class="colorpicker-hue"><i></i></div><div class="colorpicker-alpha"><i></i></div><div class="colorpicker-color"><div /></div><div class="colorpicker-selectors"></div></div>',
            align: "right",
            customClass: null,
            colorSelectors: null
        },
        it = function(f, b) {
            this.element = i(f).addClass("colorpicker-element"), this.options = i.extend(!0, {}, ut, this.element.data(), b), this.component = this.options.component, this.component = !1 !== this.component && this.element.find(this.component), this.component && 0 === this.component.length && (this.component = !1), this.container = !0 === this.options.container ? this.element : this.options.container, this.container = !1 !== this.container && i(this.container), this.input = this.element.is("input") ? this.element : !!this.options.input && this.element.find(this.options.input), this.input && 0 === this.input.length && (this.input = !1), this.color = this.createColor(!1 !== this.options.color ? this.options.color : this.getValue()), this.format = !1 !== this.options.format ? this.options.format : this.color.origFormat, !1 !== this.options.color && (this.updateInput(this.color), this.updateData(this.color));
            var p = this.picker = i(this.options.template);
            if (this.options.customClass && p.addClass(this.options.customClass), p.addClass(this.options.inline ? "colorpicker-inline colorpicker-visible" : "colorpicker-hidden"), this.options.horizontal && p.addClass("colorpicker-horizontal"), -1 === ["rgba", "hsla", "alias"].indexOf(this.format) && !1 !== this.options.format && "transparent" !== this.getValue() || p.addClass("colorpicker-with-alpha"), "right" === this.options.align && p.addClass("colorpicker-right"), !0 === this.options.inline && p.addClass("colorpicker-no-arrow"), this.options.colorSelectors) {
                var x = this,
                    y = x.picker.find(".colorpicker-selectors");
                y.length > 0 && (i.each(this.options.colorSelectors, function(N, C) {
                    var T = i("<i />").addClass("colorpicker-selectors-color").css("background-color", C).data("class", N).data("alias", N);
                    T.on("mousedown.colorpicker touchstart.colorpicker", function(B) {
                        B.preventDefault(), x.setValue("alias" === x.format ? i(this).data("alias") : i(this).css("background-color"))
                    }), y.append(T)
                }), y.show().addClass("colorpicker-visible"))
            }
            p.on("mousedown.colorpicker touchstart.colorpicker", i.proxy(function(N) {
                N.target === N.currentTarget && N.preventDefault()
            }, this)), p.find(".colorpicker-saturation, .colorpicker-hue, .colorpicker-alpha").on("mousedown.colorpicker touchstart.colorpicker", i.proxy(this.mousedown, this)), p.appendTo(this.container ? this.container : i("body")), !1 !== this.input && (this.input.on({
                "keyup.colorpicker": i.proxy(this.keyup, this)
            }), this.input.on({
                "change.colorpicker": i.proxy(this.change, this)
            }), !1 === this.component && this.element.on({
                "focus.colorpicker": i.proxy(this.show, this)
            }), !1 === this.options.inline && this.element.on({
                "focusout.colorpicker": i.proxy(this.hide, this)
            })), !1 !== this.component && this.component.on({
                "click.colorpicker": i.proxy(this.show, this)
            }), !1 === this.input && !1 === this.component && this.element.on({
                "click.colorpicker": i.proxy(this.show, this)
            }), !1 !== this.input && !1 !== this.component && "color" === this.input.attr("type") && this.input.on({
                "click.colorpicker": i.proxy(this.show, this),
                "focus.colorpicker": i.proxy(this.show, this)
            }), this.update(), i(i.proxy(function() {
                this.element.trigger("create")
            }, this))
        };
    it.Color = L, it.prototype = {
        constructor: it,
        destroy: function() {
            this.picker.remove(), this.element.removeData("colorpicker", "color").off(".colorpicker"), !1 !== this.input && this.input.off(".colorpicker"), !1 !== this.component && this.component.off(".colorpicker"), this.element.removeClass("colorpicker-element"), this.element.trigger({
                type: "destroy"
            })
        },
        reposition: function() {
            if (!1 !== this.options.inline || this.options.container) return !1;
            var f = this.container && this.container[0] !== window.document.body ? "position" : "offset",
                b = this.component || this.element,
                p = b[f]();
            "right" === this.options.align && (p.left -= this.picker.outerWidth() - b.outerWidth()), this.picker.css({
                top: p.top + b.outerHeight(),
                left: p.left
            })
        },
        show: function(f) {
            this.isDisabled() || (this.picker.addClass("colorpicker-visible").removeClass("colorpicker-hidden"), this.reposition(), i(window).on("resize.colorpicker", i.proxy(this.reposition, this)), !f || this.hasInput() && "color" !== this.input.attr("type") || f.stopPropagation && f.preventDefault && (f.stopPropagation(), f.preventDefault()), !this.component && this.input || !1 !== this.options.inline || i(window.document).on({
                "mousedown.colorpicker": i.proxy(this.hide, this)
            }), this.element.trigger({
                type: "showPicker",
                color: this.color
            }))
        },
        hide: function(f) {
            return (void 0 === f || !f.target || !(i(f.currentTarget).parents(".colorpicker").length > 0 || i(f.target).parents(".colorpicker").length > 0)) && (this.picker.addClass("colorpicker-hidden").removeClass("colorpicker-visible"), i(window).off("resize.colorpicker", this.reposition), i(window.document).off({
                "mousedown.colorpicker": this.hide
            }), this.update(), void this.element.trigger({
                type: "hidePicker",
                color: this.color
            }))
        },
        updateData: function(f) {
            return f = f || this.color.toString(this.format, !1), this.element.data("color", f), f
        },
        updateInput: function(f) {
            return f = f || this.color.toString(this.format, !1), !1 !== this.input && (this.input.prop("value", f), this.input.trigger("change")), f
        },
        updatePicker: function(f) {
            void 0 !== f && (this.color = this.createColor(f));
            var b = !1 === this.options.horizontal ? this.options.sliders : this.options.slidersHorz,
                p = this.picker.find("i");
            if (0 !== p.length) return !1 === this.options.horizontal ? (b = this.options.sliders, p.eq(1).css("top", b.hue.maxTop * (1 - this.color.value.h)).end().eq(2).css("top", b.alpha.maxTop * (1 - this.color.value.a))) : (b = this.options.slidersHorz, p.eq(1).css("left", b.hue.maxLeft * (1 - this.color.value.h)).end().eq(2).css("left", b.alpha.maxLeft * (1 - this.color.value.a))), p.eq(0).css({
                top: b.saturation.maxTop - this.color.value.b * b.saturation.maxTop,
                left: this.color.value.s * b.saturation.maxLeft
            }), this.picker.find(".colorpicker-saturation").css("backgroundColor", (this.options.hexNumberSignPrefix ? "" : "#") + this.color.toHex(this.color.value.h, 1, 1, 1)), this.picker.find(".colorpicker-alpha").css("backgroundColor", (this.options.hexNumberSignPrefix ? "" : "#") + this.color.toHex()), this.picker.find(".colorpicker-color, .colorpicker-color div").css("backgroundColor", this.color.toString(this.format, !0)), f
        },
        updateComponent: function(f) {
            var b;
            if (b = void 0 !== f ? this.createColor(f) : this.color, !1 !== this.component) {
                var p = this.component.find("i").eq(0);
                p.length > 0 ? p.css({
                    backgroundColor: b.toString(this.format, !0)
                }) : this.component.css({
                    backgroundColor: b.toString(this.format, !0)
                })
            }
            return b.toString(this.format, !1)
        },
        update: function(f) {
            var b;
            return !1 === this.getValue(!1) && !0 !== f || (b = this.updateComponent(), this.updateInput(b), this.updateData(b), this.updatePicker()), b
        },
        setValue: function(f) {
            this.color = this.createColor(f), this.update(!0), this.element.trigger({
                type: "changeColor",
                color: this.color,
                value: f
            })
        },
        createColor: function(f) {
            return new L(f || null, this.options.colorSelectors, this.options.fallbackColor ? this.options.fallbackColor : this.color, this.options.fallbackFormat, this.options.hexNumberSignPrefix)
        },
        getValue: function(f) {
            var b;
            return f = void 0 === f ? this.options.fallbackColor : f, void 0 !== (b = this.hasInput() ? this.input.val() : this.element.data("color")) && "" !== b && null !== b || (b = f), b
        },
        hasInput: function() {
            return !1 !== this.input
        },
        isDisabled: function() {
            return !!this.hasInput() && !0 === this.input.prop("disabled")
        },
        disable: function() {
            return !!this.hasInput() && (this.input.prop("disabled", !0), this.element.trigger({
                type: "disable",
                color: this.color,
                value: this.getValue()
            }), !0)
        },
        enable: function() {
            return !!this.hasInput() && (this.input.prop("disabled", !1), this.element.trigger({
                type: "enable",
                color: this.color,
                value: this.getValue()
            }), !0)
        },
        currentSlider: null,
        mousePointer: {
            left: 0,
            top: 0
        },
        mousedown: function(f) {
            !f.pageX && !f.pageY && f.originalEvent && f.originalEvent.touches && (f.pageX = f.originalEvent.touches[0].pageX, f.pageY = f.originalEvent.touches[0].pageY), f.stopPropagation(), f.preventDefault();
            var p = i(f.target).closest("div"),
                x = this.options.horizontal ? this.options.slidersHorz : this.options.sliders;
            if (!p.is(".colorpicker")) {
                if (p.is(".colorpicker-saturation")) this.currentSlider = i.extend({}, x.saturation);
                else if (p.is(".colorpicker-hue")) this.currentSlider = i.extend({}, x.hue);
                else {
                    if (!p.is(".colorpicker-alpha")) return !1;
                    this.currentSlider = i.extend({}, x.alpha)
                }
                var y = p.offset();
                this.currentSlider.guide = p.find("i")[0].style, this.currentSlider.left = f.pageX - y.left, this.currentSlider.top = f.pageY - y.top, this.mousePointer = {
                    left: f.pageX,
                    top: f.pageY
                }, i(window.document).on({
                    "mousemove.colorpicker": i.proxy(this.mousemove, this),
                    "touchmove.colorpicker": i.proxy(this.mousemove, this),
                    "mouseup.colorpicker": i.proxy(this.mouseup, this),
                    "touchend.colorpicker": i.proxy(this.mouseup, this)
                }).trigger("mousemove")
            }
            return !1
        },
        mousemove: function(f) {
            !f.pageX && !f.pageY && f.originalEvent && f.originalEvent.touches && (f.pageX = f.originalEvent.touches[0].pageX, f.pageY = f.originalEvent.touches[0].pageY), f.stopPropagation(), f.preventDefault();
            var b = Math.max(0, Math.min(this.currentSlider.maxLeft, this.currentSlider.left + ((f.pageX || this.mousePointer.left) - this.mousePointer.left))),
                p = Math.max(0, Math.min(this.currentSlider.maxTop, this.currentSlider.top + ((f.pageY || this.mousePointer.top) - this.mousePointer.top)));
            return this.currentSlider.guide.left = b + "px", this.currentSlider.guide.top = p + "px", this.currentSlider.callLeft && this.color[this.currentSlider.callLeft].call(this.color, b / this.currentSlider.maxLeft), this.currentSlider.callTop && this.color[this.currentSlider.callTop].call(this.color, p / this.currentSlider.maxTop), !1 !== this.options.format || "setAlpha" !== this.currentSlider.callTop && "setAlpha" !== this.currentSlider.callLeft || (1 !== this.color.value.a ? (this.format = "rgba", this.color.origFormat = "rgba") : (this.format = "hex", this.color.origFormat = "hex")), this.update(!0), this.element.trigger({
                type: "changeColor",
                color: this.color
            }), !1
        },
        mouseup: function(f) {
            return f.stopPropagation(), f.preventDefault(), i(window.document).off({
                "mousemove.colorpicker": this.mousemove,
                "touchmove.colorpicker": this.mousemove,
                "mouseup.colorpicker": this.mouseup,
                "touchend.colorpicker": this.mouseup
            }), !1
        },
        change: function(f) {
            this.keyup(f)
        },
        keyup: function(f) {
            38 === f.keyCode ? (this.color.value.a < 1 && (this.color.value.a = Math.round(100 * (this.color.value.a + .01)) / 100), this.update(!0)) : 40 === f.keyCode ? (this.color.value.a > 0 && (this.color.value.a = Math.round(100 * (this.color.value.a - .01)) / 100), this.update(!0)) : (this.color = this.createColor(this.input.val()), this.color.origFormat && !1 === this.options.format && (this.format = this.color.origFormat), !1 !== this.getValue(!1) && (this.updateData(), this.updateComponent(), this.updatePicker())), this.element.trigger({
                type: "changeColor",
                color: this.color,
                value: this.input.val()
            })
        }
    }, i.colorpicker = it, i.fn.colorpicker = function(f) {
        var b = Array.prototype.slice.call(arguments, 1),
            p = 1 === this.length,
            x = null,
            y = this.each(function() {
                var N = i(this),
                    C = N.data("colorpicker");
                C || (C = new it(this, "object" == typeof f ? f : {}), N.data("colorpicker", C)), "string" == typeof f ? i.isFunction(C[f]) ? x = C[f].apply(C, b) : (b.length && (C[f] = b[0]), x = C[f]) : x = N
            });
        return p ? x : y
    }, i.fn.colorpicker.constructor = it
});