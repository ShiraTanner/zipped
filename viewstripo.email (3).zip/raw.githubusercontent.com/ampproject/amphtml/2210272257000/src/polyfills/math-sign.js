/**
 * Parses the number x and returns its sign. For positive x returns 1, for
 * negative, -1. For 0 and -0, returns 0 and -0 respectively. For any number
 * that parses to NaN, returns NaN.
 *
 * @param {number} x
 * @return {number}
 */
export function sign(x) {
    x = Number(x);

    // If x is 0, -0, or NaN, return it.
    if (!x) {
        return x;
    }

    return x > 0 ? 1 : -1;
}

/**
 * Sets the Math.sign polyfill if it does not exist.
 * @param {!Window} win
 */
export function install(win) {
    if (!win.Math.sign) {
        win.Object.defineProperty(win.Math, 'sign', {
            enumerable: false,
            configurable: true,
            writable: true,
            value: sign,
        });
    }
}