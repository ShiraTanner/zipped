;
(self.AMP = self.AMP || []).push({
    m: 0,
    v: "2210272257000",
    n: "amp-mustache",
    ev: "0.2",
    l: !0,
    f: function(t, e) {
        ! function() {
            function e(t, e, n) {
                return e in t ? Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = n, t
            }

            function n(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(t);
                    e && (r = r.filter((function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable
                    }))), n.push.apply(n, r)
                }
                return n
            }

            function r(t) {
                for (var r = 1; r < arguments.length; r++) {
                    var i = null != arguments[r] ? arguments[r] : {};
                    r % 2 ? n(Object(i), !0).forEach((function(n) {
                        e(t, n, i[n])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(i)) : n(Object(i)).forEach((function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(i, e))
                    }))
                }
                return t
            }

            function i(t) {
                return (i = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                    return typeof t
                } : function(t) {
                    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                })(t)
            }

            function o(t, e) {
                return (o = Object.setPrototypeOf || function(t, e) {
                    return t.__proto__ = e, t
                })(t, e)
            }

            function a(t) {
                return (a = Object.setPrototypeOf ? Object.getPrototypeOf : function(t) {
                    return t.__proto__ || Object.getPrototypeOf(t)
                })(t)
            }

            function u(t, e) {
                if (e && ("object" === i(e) || "function" == typeof e)) return e;
                if (void 0 !== e) throw new TypeError("Derived constructors may only return object or undefined");
                return function(t) {
                    if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                    return t
                }(t)
            }

            function s(t, e) {
                for (var n = [], r = 0, i = 0; i < t.length; i++) {
                    var o = t[i];
                    e(o, i, t) ? n.push(o) : (r < i && (t[r] = o), r++)
                }
                return r < t.length && (t.length = r), n
            }
            Array.isArray;
            var f = Object.prototype;

            function c(t) {
                var e = Object.create(null);
                return t && Object.assign(e, t), e
            }

            function l(t) {
                return 1 == (null == t ? void 0 : t.nodeType)
            }

            function p(t) {
                return l(t) ? (t = t).tagName.toLowerCase() + (t.id ? "#".concat(t.id) : "") : t
            }

            function m(t, e, n, r, i, o, a, u, s, f, c) {
                return t
            }

            function h(t, e) {
                return t
            }

            function d(t, e, n, r, i, o, a, u, f, c, l) {
                return function(t, e) {
                    var n, r, i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "Assertion failed";
                    if (e) return e;
                    t && -1 == i.indexOf(t) && (i += t);
                    for (var o = 3, a = i.split("%s"), u = a.shift(), f = [u]; a.length;) {
                        var c = arguments[o++],
                            l = a.shift();
                        u += p(c) + l, f.push(c, l.trim())
                    }
                    var m = new Error(u);
                    throw m.messageArray = s(f, (function(t) {
                        return "" !== t
                    })), null === (n = (r = self).__AMP_REPORT_ERROR) || void 0 === n || n.call(r, m), m
                }("​​​", t, e, n, r, i, o, a, u, f, c, l)
            }
            f.hasOwnProperty, f.toString;
            var v = Object.hasOwnProperty,
                g = Object.setPrototypeOf,
                b = Object.isFrozen,
                y = Object.getPrototypeOf,
                w = Object.getOwnPropertyDescriptor,
                x = Object.freeze,
                k = Object.seal,
                S = Object.create,
                O = "undefined" != typeof Reflect && Reflect,
                j = O.apply,
                E = O.construct;
            j || (j = function(t, e, n) {
                return t.apply(e, n)
            }), x || (x = function(t) {
                return t
            }), k || (k = function(t) {
                return t
            }), E || (E = function(t, e) {
                return new(Function.prototype.bind.apply(t, [null].concat(function(t) {
                    if (Array.isArray(t)) {
                        for (var e = 0, n = Array(t.length); e < t.length; e++) n[e] = t[e];
                        return n
                    }
                    return Array.from(t)
                }(e))))
            });
            var A, R = U(Array.prototype.forEach),
                T = U(Array.prototype.pop),
                _ = U(Array.prototype.push),
                z = U(String.prototype.toLowerCase),
                D = U(String.prototype.match),
                F = U(String.prototype.replace),
                L = U(String.prototype.indexOf),
                M = U(String.prototype.trim),
                I = U(RegExp.prototype.test),
                N = (A = TypeError, function() {
                    for (var t = arguments.length, e = Array(t), n = 0; n < t; n++) e[n] = arguments[n];
                    return E(A, e)
                });

            function U(t) {
                return function(e) {
                    for (var n = arguments.length, r = Array(n > 1 ? n - 1 : 0), i = 1; i < n; i++) r[i - 1] = arguments[i];
                    return j(t, e, r)
                }
            }

            function C(t, e) {
                g && g(t, null);
                for (var n = e.length; n--;) {
                    var r = e[n];
                    if ("string" == typeof r) {
                        var i = z(r);
                        i !== r && (b(e) || (e[n] = i), r = i)
                    }
                    t[r] = !0
                }
                return t
            }

            function B(t) {
                var e = S(null),
                    n = void 0;
                for (n in t) j(v, t, [n]) && (e[n] = t[n]);
                return e
            }

            function q(t, e) {
                for (; null !== t;) {
                    var n = w(t, e);
                    if (n) {
                        if (n.get) return U(n.get);
                        if ("function" == typeof n.value) return U(n.value)
                    }
                    t = y(t)
                }
                return function(t) {
                    return console.warn("fallback value for", t), null
                }
            }
            var P = x(["a", "abbr", "acronym", "address", "area", "article", "aside", "audio", "b", "bdi", "bdo", "big", "blink", "blockquote", "body", "br", "button", "canvas", "caption", "center", "cite", "code", "col", "colgroup", "content", "data", "datalist", "dd", "decorator", "del", "details", "dfn", "dialog", "dir", "div", "dl", "dt", "element", "em", "fieldset", "figcaption", "figure", "font", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "map", "mark", "marquee", "menu", "menuitem", "meter", "nav", "nobr", "ol", "optgroup", "option", "output", "p", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "section", "select", "shadow", "small", "source", "spacer", "span", "strike", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead", "time", "tr", "track", "tt", "u", "ul", "var", "video", "wbr"]),
                G = x(["svg", "a", "altglyph", "altglyphdef", "altglyphitem", "animatecolor", "animatemotion", "animatetransform", "circle", "clippath", "defs", "desc", "ellipse", "filter", "font", "g", "glyph", "glyphref", "hkern", "image", "line", "lineargradient", "marker", "mask", "metadata", "mpath", "path", "pattern", "polygon", "polyline", "radialgradient", "rect", "stop", "style", "switch", "symbol", "text", "textpath", "title", "tref", "tspan", "view", "vkern"]),
                W = x(["feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence"]),
                $ = x(["animate", "color-profile", "cursor", "discard", "fedropshadow", "feimage", "font-face", "font-face-format", "font-face-name", "font-face-src", "font-face-uri", "foreignobject", "hatch", "hatchpath", "mesh", "meshgradient", "meshpatch", "meshrow", "missing-glyph", "script", "set", "solidcolor", "unknown", "use"]),
                Y = x(["math", "menclose", "merror", "mfenced", "mfrac", "mglyph", "mi", "mlabeledtr", "mmultiscripts", "mn", "mo", "mover", "mpadded", "mphantom", "mroot", "mrow", "ms", "mspace", "msqrt", "mstyle", "msub", "msup", "msubsup", "mtable", "mtd", "mtext", "mtr", "munder", "munderover"]),
                H = x(["maction", "maligngroup", "malignmark", "mlongdiv", "mscarries", "mscarry", "msgroup", "mstack", "msline", "msrow", "semantics", "annotation", "annotation-xml", "mprescripts", "none"]),
                V = x(["#text"]),
                K = x(["accept", "action", "align", "alt", "autocapitalize", "autocomplete", "autopictureinpicture", "autoplay", "background", "bgcolor", "border", "capture", "cellpadding", "cellspacing", "checked", "cite", "class", "clear", "color", "cols", "colspan", "controls", "controlslist", "coords", "crossorigin", "datetime", "decoding", "default", "dir", "disabled", "disablepictureinpicture", "disableremoteplayback", "download", "draggable", "enctype", "enterkeyhint", "face", "for", "headers", "height", "hidden", "high", "href", "hreflang", "id", "inputmode", "integrity", "ismap", "kind", "label", "lang", "list", "loading", "loop", "low", "max", "maxlength", "media", "method", "min", "minlength", "multiple", "muted", "name", "noshade", "novalidate", "nowrap", "open", "optimum", "pattern", "placeholder", "playsinline", "poster", "preload", "pubdate", "radiogroup", "readonly", "rel", "required", "rev", "reversed", "role", "rows", "rowspan", "spellcheck", "scope", "selected", "shape", "size", "sizes", "span", "srclang", "start", "src", "srcset", "step", "style", "summary", "tabindex", "title", "translate", "type", "usemap", "valign", "value", "width", "xmlns", "slot"]),
                Z = x(["accent-height", "accumulate", "additive", "alignment-baseline", "ascent", "attributename", "attributetype", "azimuth", "basefrequency", "baseline-shift", "begin", "bias", "by", "class", "clip", "clippathunits", "clip-path", "clip-rule", "color", "color-interpolation", "color-interpolation-filters", "color-profile", "color-rendering", "cx", "cy", "d", "dx", "dy", "diffuseconstant", "direction", "display", "divisor", "dur", "edgemode", "elevation", "end", "fill", "fill-opacity", "fill-rule", "filter", "filterunits", "flood-color", "flood-opacity", "font-family", "font-size", "font-size-adjust", "font-stretch", "font-style", "font-variant", "font-weight", "fx", "fy", "g1", "g2", "glyph-name", "glyphref", "gradientunits", "gradienttransform", "height", "href", "id", "image-rendering", "in", "in2", "k", "k1", "k2", "k3", "k4", "kerning", "keypoints", "keysplines", "keytimes", "lang", "lengthadjust", "letter-spacing", "kernelmatrix", "kernelunitlength", "lighting-color", "local", "marker-end", "marker-mid", "marker-start", "markerheight", "markerunits", "markerwidth", "maskcontentunits", "maskunits", "max", "mask", "media", "method", "mode", "min", "name", "numoctaves", "offset", "operator", "opacity", "order", "orient", "orientation", "origin", "overflow", "paint-order", "path", "pathlength", "patterncontentunits", "patterntransform", "patternunits", "points", "preservealpha", "preserveaspectratio", "primitiveunits", "r", "rx", "ry", "radius", "refx", "refy", "repeatcount", "repeatdur", "restart", "result", "rotate", "scale", "seed", "shape-rendering", "specularconstant", "specularexponent", "spreadmethod", "startoffset", "stddeviation", "stitchtiles", "stop-color", "stop-opacity", "stroke-dasharray", "stroke-dashoffset", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke", "stroke-width", "style", "surfacescale", "systemlanguage", "tabindex", "targetx", "targety", "transform", "text-anchor", "text-decoration", "text-rendering", "textlength", "type", "u1", "u2", "unicode", "values", "viewbox", "visibility", "version", "vert-adv-y", "vert-origin-x", "vert-origin-y", "width", "word-spacing", "wrap", "writing-mode", "xchannelselector", "ychannelselector", "x", "x1", "x2", "xmlns", "y", "y1", "y2", "z", "zoomandpan"]),
                J = x(["accent", "accentunder", "align", "bevelled", "close", "columnsalign", "columnlines", "columnspan", "denomalign", "depth", "dir", "display", "displaystyle", "encoding", "fence", "frame", "height", "href", "id", "largeop", "length", "linethickness", "lspace", "lquote", "mathbackground", "mathcolor", "mathsize", "mathvariant", "maxsize", "minsize", "movablelimits", "notation", "numalign", "open", "rowalign", "rowlines", "rowspacing", "rowspan", "rspace", "rquote", "scriptlevel", "scriptminsize", "scriptsizemultiplier", "selection", "separator", "separators", "stretchy", "subscriptshift", "supscriptshift", "symmetric", "voffset", "width", "xmlns"]),
                Q = x(["xlink:href", "xml:id", "xlink:title", "xml:space", "xmlns:xlink"]),
                X = k(/\{\{[\s\S]*|[\s\S]*\}\}/gm),
                tt = k(/<%[\s\S]*|[\s\S]*%>/gm),
                et = k(/^data-[\-\w.\u00B7-\uFFFF]/),
                nt = k(/^aria-[\-\w]+$/),
                rt = k(/^(?:(?:(?:f|ht)tps?|mailto|tel|callto|cid|xmpp):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i),
                it = k(/^(?:\w+script|data):/i),
                ot = k(/[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g),
                at = "function" == typeof Symbol && "symbol" === i(Symbol.iterator) ? function(t) {
                    return i(t)
                } : function(t) {
                    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : i(t)
                };

            function ut(t) {
                if (Array.isArray(t)) {
                    for (var e = 0, n = Array(t.length); e < t.length; e++) n[e] = t[e];
                    return n
                }
                return Array.from(t)
            }
            var st = function() {
                    return "undefined" == typeof window ? null : window
                },
                ft = function(t, e) {
                    if ("object" !== (void 0 === t ? "undefined" : at(t)) || "function" != typeof t.createPolicy) return null;
                    var n = null,
                        r = "data-tt-policy-suffix";
                    e.currentScript && e.currentScript.hasAttribute(r) && (n = e.currentScript.getAttribute(r));
                    var i = "dompurify" + (n ? "#" + n : "");
                    try {
                        return t.createPolicy(i, {
                            createHTML: function(t) {
                                return t
                            }
                        })
                    } catch (t) {
                        return console.warn("TrustedTypes policy " + i + " could not be created."), null
                    }
                },
                ct = function t() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : st(),
                        n = function(e) {
                            return t(e)
                        };
                    if (n.version = "2.3.3", n.removed = [], !e || !e.document || 9 !== e.document.nodeType) return n.isSupported = !1, n;
                    var r = e.document,
                        i = e.document,
                        o = e.DocumentFragment,
                        a = e.HTMLTemplateElement,
                        u = e.Node,
                        s = e.Element,
                        f = e.NodeFilter,
                        c = e.NamedNodeMap,
                        l = void 0 === c ? e.NamedNodeMap || e.MozNamedAttrMap : c,
                        p = e.Text,
                        m = e.Comment,
                        h = e.DOMParser,
                        d = e.trustedTypes,
                        v = s.prototype,
                        g = q(v, "cloneNode"),
                        b = q(v, "nextSibling"),
                        y = q(v, "childNodes"),
                        w = q(v, "parentNode");
                    if ("function" == typeof a) {
                        var k = i.createElement("template");
                        k.content && k.content.ownerDocument && (i = k.content.ownerDocument)
                    }
                    var S = ft(d, r),
                        O = S && Nt ? S.createHTML("") : "",
                        j = i,
                        E = j.implementation,
                        A = j.createNodeIterator,
                        U = j.createDocumentFragment,
                        ct = j.getElementsByTagName,
                        lt = r.importNode,
                        pt = {};
                    try {
                        pt = B(i).documentMode ? i.documentMode : {}
                    } catch (t) {}
                    var mt = {};
                    n.isSupported = "function" == typeof w && E && void 0 !== E.createHTMLDocument && 9 !== pt;
                    var ht = X,
                        dt = tt,
                        vt = et,
                        gt = nt,
                        bt = it,
                        yt = ot,
                        wt = rt,
                        xt = null,
                        kt = C({}, [].concat(ut(P), ut(G), ut(W), ut(Y), ut(V))),
                        St = null,
                        Ot = C({}, [].concat(ut(K), ut(Z), ut(J), ut(Q))),
                        jt = null,
                        Et = null,
                        At = !0,
                        Rt = !0,
                        Tt = !1,
                        _t = !1,
                        zt = !1,
                        Dt = !1,
                        Ft = !1,
                        Lt = !1,
                        Mt = !1,
                        It = !0,
                        Nt = !1,
                        Ut = !0,
                        Ct = !0,
                        Bt = !1,
                        qt = {},
                        Pt = null,
                        Gt = C({}, ["annotation-xml", "audio", "colgroup", "desc", "foreignobject", "head", "iframe", "math", "mi", "mn", "mo", "ms", "mtext", "noembed", "noframes", "noscript", "plaintext", "script", "style", "svg", "template", "thead", "title", "video", "xmp"]),
                        Wt = null,
                        $t = C({}, ["audio", "video", "img", "source", "image", "track"]),
                        Yt = null,
                        Ht = C({}, ["alt", "class", "for", "id", "label", "name", "pattern", "placeholder", "role", "summary", "title", "value", "style", "xmlns"]),
                        Vt = "http://www.w3.org/1998/Math/MathML",
                        Kt = "http://www.w3.org/2000/svg",
                        Zt = "http://www.w3.org/1999/xhtml",
                        Jt = Zt,
                        Qt = !1,
                        Xt = void 0,
                        te = ["application/xhtml+xml", "text/html"],
                        ee = "text/html",
                        ne = void 0,
                        re = null,
                        ie = i.createElement("form"),
                        oe = function(t) {
                            re && re === t || (t && "object" === (void 0 === t ? "undefined" : at(t)) || (t = {}), t = B(t), xt = "ALLOWED_TAGS" in t ? C({}, t.ALLOWED_TAGS) : kt, St = "ALLOWED_ATTR" in t ? C({}, t.ALLOWED_ATTR) : Ot, Yt = "ADD_URI_SAFE_ATTR" in t ? C(B(Ht), t.ADD_URI_SAFE_ATTR) : Ht, Wt = "ADD_DATA_URI_TAGS" in t ? C(B($t), t.ADD_DATA_URI_TAGS) : $t, Pt = "FORBID_CONTENTS" in t ? C({}, t.FORBID_CONTENTS) : Gt, jt = "FORBID_TAGS" in t ? C({}, t.FORBID_TAGS) : {}, Et = "FORBID_ATTR" in t ? C({}, t.FORBID_ATTR) : {}, qt = "USE_PROFILES" in t && t.USE_PROFILES, At = !1 !== t.ALLOW_ARIA_ATTR, Rt = !1 !== t.ALLOW_DATA_ATTR, Tt = t.ALLOW_UNKNOWN_PROTOCOLS || !1, _t = t.SAFE_FOR_TEMPLATES || !1, zt = t.WHOLE_DOCUMENT || !1, Lt = t.RETURN_DOM || !1, Mt = t.RETURN_DOM_FRAGMENT || !1, It = !1 !== t.RETURN_DOM_IMPORT, Nt = t.RETURN_TRUSTED_TYPE || !1, Ft = t.FORCE_BODY || !1, Ut = !1 !== t.SANITIZE_DOM, Ct = !1 !== t.KEEP_CONTENT, Bt = t.IN_PLACE || !1, wt = t.ALLOWED_URI_REGEXP || wt, Jt = t.NAMESPACE || Zt, Xt = Xt = -1 === te.indexOf(t.PARSER_MEDIA_TYPE) ? ee : t.PARSER_MEDIA_TYPE, ne = "application/xhtml+xml" === Xt ? function(t) {
                                return t
                            } : z, _t && (Rt = !1), Mt && (Lt = !0), qt && (xt = C({}, [].concat(ut(V))), St = [], !0 === qt.html && (C(xt, P), C(St, K)), !0 === qt.svg && (C(xt, G), C(St, Z), C(St, Q)), !0 === qt.svgFilters && (C(xt, W), C(St, Z), C(St, Q)), !0 === qt.mathMl && (C(xt, Y), C(St, J), C(St, Q))), t.ADD_TAGS && (xt === kt && (xt = B(xt)), C(xt, t.ADD_TAGS)), t.ADD_ATTR && (St === Ot && (St = B(St)), C(St, t.ADD_ATTR)), t.ADD_URI_SAFE_ATTR && C(Yt, t.ADD_URI_SAFE_ATTR), t.FORBID_CONTENTS && (Pt === Gt && (Pt = B(Pt)), C(Pt, t.FORBID_CONTENTS)), Ct && (xt["#text"] = !0), zt && C(xt, ["html", "head", "body"]), xt.table && (C(xt, ["tbody"]), delete jt.tbody), x && x(t), re = t)
                        },
                        ae = C({}, ["mi", "mo", "mn", "ms", "mtext"]),
                        ue = C({}, ["foreignobject", "desc", "title", "annotation-xml"]),
                        se = C({}, G);
                    C(se, W), C(se, $);
                    var fe = C({}, Y);
                    C(fe, H);
                    var ce = function(t) {
                            var e = w(t);
                            e && e.tagName || (e = {
                                namespaceURI: Zt,
                                tagName: "template"
                            });
                            var n = z(t.tagName),
                                r = z(e.tagName);
                            if (t.namespaceURI === Kt) return e.namespaceURI === Zt ? "svg" === n : e.namespaceURI === Vt ? "svg" === n && ("annotation-xml" === r || ae[r]) : Boolean(se[n]);
                            if (t.namespaceURI === Vt) return e.namespaceURI === Zt ? "math" === n : e.namespaceURI === Kt ? "math" === n && ue[r] : Boolean(fe[n]);
                            if (t.namespaceURI === Zt) {
                                if (e.namespaceURI === Kt && !ue[r]) return !1;
                                if (e.namespaceURI === Vt && !ae[r]) return !1;
                                var i = C({}, ["title", "style", "font", "a", "script"]);
                                return !fe[n] && (i[n] || !se[n])
                            }
                            return !1
                        },
                        le = function(t) {
                            _(n.removed, {
                                element: t
                            });
                            try {
                                t.parentNode.removeChild(t)
                            } catch (e) {
                                try {
                                    t.outerHTML = O
                                } catch (e) {
                                    t.remove()
                                }
                            }
                        },
                        pe = function(t, e) {
                            try {
                                _(n.removed, {
                                    attribute: e.getAttributeNode(t),
                                    from: e
                                })
                            } catch (t) {
                                _(n.removed, {
                                    attribute: null,
                                    from: e
                                })
                            }
                            if (e.removeAttribute(t), "is" === t && !St[t])
                                if (Lt || Mt) try {
                                    le(e)
                                } catch (t) {} else try {
                                    e.setAttribute(t, "")
                                } catch (t) {}
                        },
                        me = function(t) {
                            var e = void 0,
                                n = void 0;
                            if (Ft) t = "<remove></remove>" + t;
                            else {
                                var r = D(t, /^[\r\n\t ]+/);
                                n = r && r[0]
                            }
                            "application/xhtml+xml" === Xt && (t = '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' + t + "</body></html>");
                            var o = S ? S.createHTML(t) : t;
                            if (Jt === Zt) try {
                                e = (new h).parseFromString(o, Xt)
                            } catch (t) {}
                            if (!e || !e.documentElement) {
                                e = E.createDocument(Jt, "template", null);
                                try {
                                    e.documentElement.innerHTML = Qt ? "" : o
                                } catch (t) {}
                            }
                            var a = e.body || e.documentElement;
                            return t && n && a.insertBefore(i.createTextNode(n), a.childNodes[0] || null), Jt === Zt ? ct.call(e, zt ? "html" : "body")[0] : zt ? e.documentElement : a
                        },
                        he = function(t) {
                            return A.call(t.ownerDocument || t, t, f.SHOW_ELEMENT | f.SHOW_COMMENT | f.SHOW_TEXT, null, !1)
                        },
                        de = function(t) {
                            return !(t instanceof p || t instanceof m || "string" == typeof t.nodeName && "string" == typeof t.textContent && "function" == typeof t.removeChild && t.attributes instanceof l && "function" == typeof t.removeAttribute && "function" == typeof t.setAttribute && "string" == typeof t.namespaceURI && "function" == typeof t.insertBefore)
                        },
                        ve = function(t) {
                            return "object" === (void 0 === u ? "undefined" : at(u)) ? t instanceof u : t && "object" === (void 0 === t ? "undefined" : at(t)) && "number" == typeof t.nodeType && "string" == typeof t.nodeName
                        },
                        ge = function(t, e, r) {
                            mt[t] && R(mt[t], (function(t) {
                                t.call(n, e, r, re)
                            }))
                        },
                        be = function(t) {
                            var e = void 0;
                            if (ge("beforeSanitizeElements", t, null), de(t)) return le(t), !0;
                            if (D(t.nodeName, /[\u0080-\uFFFF]/)) return le(t), !0;
                            var r = ne(t.nodeName);
                            if (ge("uponSanitizeElement", t, {
                                    tagName: r,
                                    allowedTags: xt
                                }), !ve(t.firstElementChild) && (!ve(t.content) || !ve(t.content.firstElementChild)) && I(/<[/\w]/g, t.innerHTML) && I(/<[/\w]/g, t.textContent)) return le(t), !0;
                            if ("select" === r && I(/<template/i, t.innerHTML)) return le(t), !0;
                            if (!xt[r] || jt[r]) {
                                if (Ct && !Pt[r]) {
                                    var i = w(t) || t.parentNode,
                                        o = y(t) || t.childNodes;
                                    if (o && i)
                                        for (var a = o.length - 1; a >= 0; --a) i.insertBefore(g(o[a], !0), b(t))
                                }
                                return le(t), !0
                            }
                            return t instanceof s && !ce(t) ? (le(t), !0) : "noscript" !== r && "noembed" !== r || !I(/<\/no(script|embed)/i, t.innerHTML) ? (_t && 3 === t.nodeType && (e = t.textContent, e = F(e, ht, " "), e = F(e, dt, " "), t.textContent !== e && (_(n.removed, {
                                element: t.cloneNode()
                            }), t.textContent = e)), ge("afterSanitizeElements", t, null), !1) : (le(t), !0)
                        },
                        ye = function(t, e, n) {
                            if (Ut && ("id" === e || "name" === e) && (n in i || n in ie)) return !1;
                            if (Rt && !Et[e] && I(vt, e));
                            else if (At && I(gt, e));
                            else {
                                if (!St[e] || Et[e]) return !1;
                                if (Yt[e]);
                                else if (I(wt, F(n, yt, "")));
                                else if ("src" !== e && "xlink:href" !== e && "href" !== e || "script" === t || 0 !== L(n, "data:") || !Wt[t])
                                    if (Tt && !I(bt, F(n, yt, "")));
                                    else if (n) return !1
                            }
                            return !0
                        },
                        we = function(t) {
                            var e = void 0,
                                r = void 0,
                                i = void 0,
                                o = void 0;
                            ge("beforeSanitizeAttributes", t, null);
                            var a = t.attributes;
                            if (a) {
                                var u = {
                                    attrName: "",
                                    attrValue: "",
                                    keepAttr: !0,
                                    allowedAttributes: St
                                };
                                for (o = a.length; o--;) {
                                    var s = e = a[o],
                                        f = s.name,
                                        c = s.namespaceURI;
                                    if (r = M(e.value), i = ne(f), u.attrName = i, u.attrValue = r, u.keepAttr = !0, u.forceKeepAttr = void 0, ge("uponSanitizeAttribute", t, u), r = u.attrValue, !u.forceKeepAttr && (pe(f, t), u.keepAttr))
                                        if (I(/\/>/i, r)) pe(f, t);
                                        else {
                                            _t && (r = F(r, ht, " "), r = F(r, dt, " "));
                                            var l = ne(t.nodeName);
                                            if (ye(l, i, r)) try {
                                                c ? t.setAttributeNS(c, f, r) : t.setAttribute(f, r), T(n.removed)
                                            } catch (t) {}
                                        }
                                }
                                ge("afterSanitizeAttributes", t, null)
                            }
                        },
                        xe = function t(e) {
                            var n = void 0,
                                r = he(e);
                            for (ge("beforeSanitizeShadowDOM", e, null); n = r.nextNode();) ge("uponSanitizeShadowNode", n, null), be(n) || (n.content instanceof o && t(n.content), we(n));
                            ge("afterSanitizeShadowDOM", e, null)
                        };
                    return n.sanitize = function(t, i) {
                        var a = void 0,
                            s = void 0,
                            f = void 0,
                            c = void 0,
                            l = void 0;
                        if ((Qt = !t) && (t = "\x3c!--\x3e"), "string" != typeof t && !ve(t)) {
                            if ("function" != typeof t.toString) throw N("toString is not a function");
                            if ("string" != typeof(t = t.toString())) throw N("dirty is not a string, aborting")
                        }
                        if (!n.isSupported) {
                            if ("object" === at(e.toStaticHTML) || "function" == typeof e.toStaticHTML) {
                                if ("string" == typeof t) return e.toStaticHTML(t);
                                if (ve(t)) return e.toStaticHTML(t.outerHTML)
                            }
                            return t
                        }
                        if (Dt || oe(i), n.removed = [], "string" == typeof t && (Bt = !1), Bt);
                        else if (t instanceof u) 1 === (s = (a = me("\x3c!----\x3e")).ownerDocument.importNode(t, !0)).nodeType && "BODY" === s.nodeName || "HTML" === s.nodeName ? a = s : a.appendChild(s);
                        else {
                            if (!Lt && !_t && !zt && -1 === t.indexOf("<")) return S && Nt ? S.createHTML(t) : t;
                            if (!(a = me(t))) return Lt ? null : O
                        }
                        a && Ft && le(a.firstChild);
                        for (var p = he(Bt ? t : a); f = p.nextNode();) 3 === f.nodeType && f === c || be(f) || (f.content instanceof o && xe(f.content), we(f), c = f);
                        if (c = null, Bt) return t;
                        if (Lt) {
                            if (Mt)
                                for (l = U.call(a.ownerDocument); a.firstChild;) l.appendChild(a.firstChild);
                            else l = a;
                            return It && (l = lt.call(r, l, !0)), l
                        }
                        var m = zt ? a.outerHTML : a.innerHTML;
                        return _t && (m = F(m, ht, " "), m = F(m, dt, " ")), S && Nt ? S.createHTML(m) : m
                    }, n.setConfig = function(t) {
                        oe(t), Dt = !0
                    }, n.clearConfig = function() {
                        re = null, Dt = !1
                    }, n.isValidAttribute = function(t, e, n) {
                        re || oe({});
                        var r = ne(t),
                            i = ne(e);
                        return ye(r, i, n)
                    }, n.addHook = function(t, e) {
                        "function" == typeof e && (mt[t] = mt[t] || [], _(mt[t], e))
                    }, n.removeHook = function(t) {
                        mt[t] && T(mt[t])
                    }, n.removeHooks = function(t) {
                        mt[t] && (mt[t] = [])
                    }, n.removeAllHooks = function() {
                        mt = {}
                    }, n
                }(),
                lt = ct;

            function pt(t) {
                return function(t, e) {
                    var n = e.documentElement;
                    return ["⚡4email", "amp4email"].some((function(t) {
                        return n.hasAttribute(t)
                    }))
                }(0, t)
            }
            var mt = /(?:^[#?]?|&)([^=&]+)(?:=([^&]*))?/g;

            function ht(t) {
                var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
                try {
                    return decodeURIComponent(t)
                } catch (t) {
                    return e
                }
            }
            self.__AMP_LOG = self.__AMP_LOG || {
                user: null,
                dev: null,
                userForEmbed: null
            };
            var dt = self.__AMP_LOG;

            function vt(t) {
                return dt.user || (dt.user = gt()),
                    function(t, e) {
                        return e && e.ownerDocument.defaultView != t
                    }(dt.user.win, t) ? dt.userForEmbed || (dt.userForEmbed = gt()) : dt.user
            }

            function gt(t) {
                return function(t, e) {
                    throw new Error("failed to call initLogConstructor")
                }()
            }

            function bt(t, e, n, r, i, o, a, u, s, f, c) {
                return t
            }

            function yt(t, e, n, r, i, o, a, u, s, f, c) {
                return vt().assert(t, e, n, r, i, o, a, u, s, f, c)
            }
            var wt = /(\S+)(?:\s+(?:(-?\d+(?:\.\d+)?)([a-zA-Z]*)))?\s*(?:,|$)/g,
                xt = function() {
                    function t(t) {
                        d(t.length > 0, "Srcset must have at least one source"), this.ZT = t;
                        for (var e = !1, n = !1, r = 0; r < t.length; r++) {
                            var i = t[r];
                            e = e || !!i.width, n = n || !!i.dpr
                        }
                        d(!(e === n), "Srcset must have width or dpr sources, but not both"), t.sort(e ? kt : St), this.gR = e
                    }
                    var e = t.prototype;
                    return e.select = function(t, e) {
                        var n;
                        return m(t), m(e), n = this.gR ? this.yR(t * e) : this.wR(e), this.ZT[n].url
                    }, e.yR = function(t) {
                        for (var e = this.ZT, n = 0, r = 1 / 0, i = 1 / 0, o = 0; o < e.length; o++) {
                            var a, u = null !== (a = e[o].width) && void 0 !== a ? a : 0,
                                s = Math.abs(u - t);
                            if (!(s <= 1.1 * r || t / i > 1.2)) break;
                            n = o, r = s, i = u
                        }
                        return n
                    }, e.wR = function(t) {
                        for (var e = this.ZT, n = 0, r = 1 / 0, i = 0; i < e.length; i++) {
                            var o = Math.abs(e[i].dpr - t);
                            if (!(o <= r)) break;
                            n = i, r = o
                        }
                        return n
                    }, e.getUrls = function() {
                        return this.ZT.map((function(t) {
                            return t.url
                        }))
                    }, e.stringify = function(t) {
                        for (var e = [], n = this.ZT, r = 0; r < n.length; r++) {
                            var i = n[r],
                                o = i.url;
                            t && (o = t(o)), this.gR ? o += " ".concat(i.width, "w") : o += " ".concat(i.dpr, "x"), e.push(o)
                        }
                        return e.join(", ")
                    }, t
                }();

            function kt(t, e) {
                return d(t.width != e.width, "Duplicate width: %s", t.width), t.width - e.width
            }

            function St(t, e) {
                return d(t.dpr != e.dpr, "Duplicate dpr: %s", t.dpr), t.dpr - e.dpr
            }
            var Ot = function() {
                function t(t) {
                    this.Wt = t, this.Kt = 0, this.Qt = 0, this.Xt = c()
                }
                var e = t.prototype;
                return e.has = function(t) {
                    return !!this.Xt[t]
                }, e.get = function(t) {
                    var e = this.Xt[t];
                    if (e) return e.access = ++this.Qt, e.payload
                }, e.put = function(t, e) {
                    this.has(t) || this.Kt++, this.Xt[t] = {
                        payload: e,
                        access: this.Qt
                    }, this.Yt()
                }, e.Yt = function() {
                    if (!(this.Kt <= this.Wt)) {
                        var t, e = this.Xt,
                            n = this.Qt + 1;
                        for (var r in e) {
                            var i = e[r].access;
                            i < n && (n = i, t = r)
                        }
                        void 0 !== t && (delete e[t], this.Kt--)
                    }
                }, t
            }();

            function jt(t, e) {
                return Rt(t = Et(t), e)
            }

            function Et(t) {
                return t.__AMP_TOP || (t.__AMP_TOP = t)
            }

            function At(t) {
                return t.nodeType ? (n = t, e = (n.ownerDocument || n).defaultView, jt(e, "ampdoc")).getAmpDoc(t) : t;
                var e, n
            }

            function Rt(t, e) {
                bt(function(t, e) {
                    var n = t.__AMP_SERVICES && t.__AMP_SERVICES[e];
                    return !(!n || !n.ctor)
                }(t, e));
                var n = Tt(t)[e];
                return n.obj || (bt(n.ctor), bt(n.context), n.obj = new n.ctor(n.context), bt(n.obj), n.context = null, n.resolve && n.resolve(n.obj)), n.obj
            }

            function Tt(t) {
                var e = t.__AMP_SERVICES;
                return e || (e = t.__AMP_SERVICES = {}), e
            }
            var _t, zt, Dt = function() {
                    return self.AMP.config.urls
                }(),
                Ft = new Set(["c", "v", "a", "ad"]),
                Lt = function(t) {
                    return "string" == typeof t ? Mt(t) : t
                };

            function Mt(t, e) {
                return _t || (_t = self.document.createElement("a"), zt = self.__AMP_URL_CACHE || (self.__AMP_URL_CACHE = new Ot(100))),
                    function(t, e, n) {
                        if (n && n.has(e)) return n.get(e);
                        t.href = e, t.protocol || (t.href = t.href);
                        var r, i = {
                            href: t.href,
                            protocol: t.protocol,
                            host: t.host,
                            hostname: t.hostname,
                            port: "0" == t.port ? "" : t.port,
                            pathname: t.pathname,
                            search: t.search,
                            hash: t.hash,
                            origin: null
                        };
                        "/" !== i.pathname[0] && (i.pathname = "/" + i.pathname), ("http:" == i.protocol && 80 == i.port || "https:" == i.protocol && 443 == i.port) && (i.port = "", i.host = i.hostname), r = t.origin && "null" != t.origin ? t.origin : "data:" != i.protocol && i.host ? i.protocol + "//" + i.host : i.href, i.origin = r;
                        var o = i;
                        return n && n.put(e, o), o
                    }(_t, t, e ? null : zt)
            }

            function It(t) {
                return Dt.cdnProxyRegex.test(Lt(t).origin)
            }

            function Nt(t, e) {
                return e = Lt(e), "function" == typeof URL ? new URL(t, e.href).toString() : function(t, e) {
                    e = Lt(e);
                    var n = Mt(t = t.replace(/\\/g, "/"));
                    return t.toLowerCase().startsWith(n.protocol) ? n.href : t.startsWith("//") ? e.protocol + t : t.startsWith("/") ? e.origin + t : e.origin + e.pathname.replace(/\/[^/]*$/, "/") + t
                }(t, e)
            }
            var Ut = function() {
                return self.AMP.config.urls
            }();

            function Ct(t, e, n) {
                return Bt(e) ? function(t, e, n, r) {
                    var i;
                    yt(!("__amp_source_origin" in function(t) {
                        var e, n = c();
                        if (!t) return n;
                        for (; e = mt.exec(t);) {
                            var r = ht(e[1], e[1]),
                                i = e[2] ? ht(e[2].replace(/\+/g, " "), e[2]) : "";
                            n[r] = i
                        }
                        return n
                    }(Mt(i = n).search)), "Source origin is not allowed in %s", i);
                    var o = It(r),
                        a = Mt(function(t) {
                            if (!It(t = Lt(t))) return t.href;
                            var e = t.pathname.split("/"),
                                n = e[1];
                            yt(Ft.has(n), "Unknown path prefix in url %s", t.href);
                            var r = e[2],
                                i = "s" == r ? "https://" + decodeURIComponent(e[3]) : "http://" + decodeURIComponent(r);
                            return yt(i.indexOf(".") > 0, "Expected a . in origin %s", i), e.splice(1, "s" == r ? 3 : 2), i + e.join("/") + function(t, e) {
                                if (!t || "?" == t) return "";
                                var n = new RegExp("[?&]".concat("(amp_(js[^&=]*|gsa|r|kit)|usqp)", "\\b[^&]*"), "g"),
                                    r = t.replace(n, "").replace(/^[?&]/, "");
                                return r ? "?" + r : ""
                            }(t.search) + (t.hash || "")
                        }(r));
                    if ("href" == e && !n.startsWith("#")) return Nt(n, a);
                    if ("src" == e) return "amp-img" == t ? qt(n, a, o) : Nt(n, a);
                    if ("srcset" == e) {
                        var u;
                        try {
                            u = function(t) {
                                for (var e, n = []; e = wt.exec(t);) {
                                    var r = e[1],
                                        i = void 0,
                                        o = void 0;
                                    if (e[2]) {
                                        var a = e[3].toLowerCase();
                                        if ("w" == a) i = parseInt(e[2], 10);
                                        else {
                                            if ("x" != a) continue;
                                            o = parseFloat(e[2])
                                        }
                                    } else o = 1;
                                    n.push({
                                        url: r,
                                        width: i,
                                        dpr: o
                                    })
                                }
                                return new xt(n)
                            }(n)
                        } catch (t) {
                            return vt().error("URL-REWRITE", "Failed to parse srcset: ", t), n
                        }
                        return u.stringify((function(t) {
                            return qt(t, a, o)
                        }))
                    }
                    return n
                }(t, e, n, self.location) : n
            }

            function Bt(t) {
                return "src" == t || "href" == t || "xlink:href" == t || "srcset" == t
            }

            function qt(t, e, n) {
                var r = Mt(Nt(t, e));
                return "data:" == r.protocol || It(r) || !n ? r.href : "".concat(Ut.cdn, "/i/") + ("https:" == r.protocol ? "s/" : "") + encodeURIComponent(r.host) + r.pathname + (r.search || "") + (r.hash || "")
            }
            var Pt = "data-amp-bind-",
                Gt = "i-amphtml-key",
                Wt = {
                    "AMP-IMG": ["src", "srcset", "layout", "width", "height"]
                },
                $t = {
                    "applet": !0,
                    "audio": !0,
                    "base": !0,
                    "embed": !0,
                    "frame": !0,
                    "frameset": !0,
                    "iframe": !0,
                    "img": !0,
                    "link": !0,
                    "meta": !0,
                    "object": !0,
                    "style": !0,
                    "video": !0
                },
                Yt = {
                    "amp-accordion": !0,
                    "amp-anim": !0,
                    "amp-bind-macro": !0,
                    "amp-carousel": !0,
                    "amp-fit-text": !0,
                    "amp-img": !0,
                    "amp-layout": !0,
                    "amp-selector": !0,
                    "amp-sidebar": !0,
                    "amp-timeago": !0
                },
                Ht = ["a", "amp-img", "article", "aside", "b", "blockquote", "br", "caption", "code", "col", "colgroup", "dd", "del", "details", "div", "dl", "dt", "em", "figcaption", "figure", "footer", "h1", "h2", "h3", "header", "hr", "i", "ins", "li", "main", "mark", "nav", "ol", "p", "pre", "q", "s", "section", "small", "span", "strong", "sub", "summary", "sup", "table", "tbody", "td", "tfoot", "th", "thead", "time", "tr", "u", "ul"],
                Vt = ["a", "article", "aside", "b", "blockquote", "br", "caption", "code", "col", "colgroup", "dd", "del", "details", "div", "dl", "dt", "em", "figcaption", "figure", "footer", "h1", "h2", "h3", "header", "hr", "i", "ins", "li", "main", "mark", "nav", "ol", "p", "pre", "q", "s", "section", "small", "span", "strong", "sub", "summary", "sup", "table", "tbody", "td", "tfoot", "th", "thead", "time", "tr", "u", "ul"],
                Kt = ["amp-fx", "fallback", "heights", "layout", "min-font-size", "max-font-size", "on", "option", "placeholder", "submitting", "submit-success", "submit-error", "validation-for", "verify-error", "visible-when-invalid", "href", "style", "text", "subscriptions-action", "subscriptions-actions", "subscriptions-decorate", "subscriptions-dialog", "subscriptions-display", "subscriptions-section", "subscriptions-service", "subscriptions-google-rtc", "amp-nested-submenu", "amp-nested-submenu-open", "amp-nested-submenu-close", "itemprop"],
                Zt = {
                    "a": ["rel", "target"],
                    "div": ["template"],
                    "form": ["action-xhr", "verify-xhr", "custom-validation-reporting", "target"],
                    "input": ["mask-output"],
                    "template": ["type"],
                    "textarea": ["autoexpand"]
                },
                Jt = ["_top", "_blank"],
                Qt = /^(?:\w+script|data|blob):/i,
                Xt = /^(?:blob):/i,
                te = /[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205f\u3000]/g,
                ee = Object.freeze({
                    "input": {
                        "type": /(?:image|button)/i
                    }
                }),
                ne = Object.freeze({
                    "input": {
                        "type": /(?:button|file|image|password)/i
                    }
                }),
                re = Object.freeze(["form", "formaction", "formmethod", "formtarget", "formnovalidate", "formenctype"]),
                ie = Object.freeze({
                    "input": re,
                    "textarea": re,
                    "select": re
                }),
                oe = Object.freeze({
                    "amp-anim": ["controls"],
                    "form": ["name"]
                }),
                ae = /!important|position\s*:\s*fixed|position\s*:\s*sticky/i;

            function ue(t, e, n, r) {
                var i = arguments.length > 4 && void 0 !== arguments[4] && arguments[4],
                    o = n ? n.replace(te, "") : "";
                if (!i) {
                    if (e.startsWith("on") && "on" != e) return !1;
                    var a = o.toLowerCase();
                    if (a.indexOf("<script") >= 0 || a.indexOf("</script") >= 0) return !1;
                    if (Qt.test(o)) return !1
                }
                if (Xt.test(o)) return !1;
                if ("style" == e) return !ae.test(n);
                if ("class" == e && n && /(^|\W)i-amphtml-/i.test(n)) return !1;
                if (Bt(e) && /__amp_source_origin/.test(n)) return !1;
                var u = pt(r),
                    s = Object.assign(c(), ie, u ? oe : {})[t];
                if (s && -1 != s.indexOf(e)) return !1;
                var f = Object.assign(c(), ee, u ? ne : {})[t];
                if (f) {
                    var l = f[e];
                    if (l && -1 != n.search(l)) return !1
                }
                return !0
            }
            var se = "purifier",
                fe = {
                    "script": {
                        "attribute": "type",
                        "values": ["application/json", "application/ld+json"]
                    }
                },
                ce = {
                    USE_PROFILES: {
                        html: !0,
                        svg: !0,
                        svgFilters: !0
                    }
                },
                le = function() {
                    function t(t, e, n) {
                        this.tp = t, this.xR = 1, this.kR = lt(self), this.SR = lt(self);
                        var i = Object.assign(e || {}, r(r({}, ce), {}, {
                            ADD_ATTR: Kt,
                            ADD_TAGS: ["use"],
                            FORBID_TAGS: Object.keys($t),
                            FORCE_BODY: !0,
                            RETURN_DOM: !0,
                            ALLOW_UNKNOWN_PROTOCOLS: !0
                        }));
                        this.kR.setConfig(i), this.OR(this.kR, n), this.jR(this.SR)
                    }
                    var e = t.prototype;
                    return e.purifyHtml = function(t) {
                        return this.kR.sanitize(t)
                    }, e.purifyTagsForTripleMustache = function(t) {
                        var e = this.SR.sanitize(t, {
                                "ALLOWED_TAGS": pt(this.tp) ? Vt : Ht,
                                "FORCE_BODY": !0,
                                "RETURN_DOM_FRAGMENT": !0
                            }),
                            n = this.tp.createElement("div");
                        return n.appendChild(e), n.innerHTML
                    }, e.getAllowedTags = function() {
                        var t = {};
                        this.kR.addHook("uponSanitizeElement", (function(e, n) {
                            Object.assign(t, n.allowedTags)
                        }));
                        var e = this.tp.createElement("p");
                        return this.kR.sanitize(e), Object.keys($t).forEach((function(e) {
                            t[e] = !1
                        })), this.kR.removeHook("uponSanitizeElement"), t
                    }, e.validateAttributeChange = function(t, e, n) {
                        var r = t.nodeName.toLowerCase(),
                            i = fe[r];
                        if (i) {
                            var o = i.attribute,
                                a = i.values;
                            if (o === e && (null == n || !a.includes(n))) return !1
                        }
                        if ("a" === r && "target" === e && (null == n || !Jt.includes(n))) return !1;
                        if (null == n) return !0;
                        if (me(e) !== pe.NONE) return !1;
                        if (!this.kR.isValidAttribute(r, e, n)) {
                            var u = Zt[r];
                            if (!(u && u.includes(e) || r.startsWith("amp-"))) return !1
                        }
                        var s = t.ownerDocument ? t.ownerDocument : t;
                        return !(n && !ue(r, e, n, s, !0))
                    }, e.OR = function(t, e) {
                        var n, r, i = this,
                            o = pt(this.tp),
                            a = [],
                            u = [];
                        t.addHook("uponSanitizeElement", (function(t, e) {
                            var r = e.tagName;
                            if (n = e.allowedTags, r.startsWith("amp-") && (n[r] = !o || Yt[r]), "a" === r) {
                                var i = h(t);
                                i.hasAttribute("href") && !i.hasAttribute("target") && i.setAttribute("target", "_top")
                            }
                            var u = fe[r];
                            if (u) {
                                var s = u.attribute,
                                    f = u.values,
                                    c = h(t);
                                c.hasAttribute(s) && f.includes(c.getAttribute(s)) && (n[r] = !0, a.push(r))
                            }
                        })), t.addHook("afterSanitizeElements", (function(t) {
                            a.forEach((function(t) {
                                delete n[t]
                            })), a.length = 0
                        })), t.addHook("uponSanitizeAttribute", (function(t, n) {
                            var o = t.nodeName.toLowerCase(),
                                a = n.attrName,
                                s = n.attrValue;
                            r = n.allowedAttributes;
                            var f = function() {
                                r[a] || (r[a] = !0, u.push(a))
                            };
                            if (o.startsWith("amp-")) f();
                            else {
                                if ("a" == o && "target" == a) {
                                    var c = s.toLowerCase();
                                    s = Jt.includes(c) ? c : "_top"
                                }
                                var l = Zt[o];
                                l && l.includes(a) && f()
                            }
                            var p = me(a);
                            if (p === pe.CLASSIC) {
                                var m = a.substring(1, a.length - 1);
                                t.setAttribute("".concat(Pt).concat(m), s)
                            }
                            p !== pe.NONE && t.setAttribute("i-amphtml-binding", ""), ue(o, a, s, i.tp, !0) ? e && s && !a.startsWith(Pt) && (s = e(o, a, s)) : (n.keepAttr = !1, vt().error(se, 'Removed invalid attribute %s[%s="%s"].', o, a, s)), n.attrValue = s
                        })), t.addHook("afterSanitizeAttributes", (function(t) {
                            ! function(t, e) {
                                var n = t.tagName.startsWith("AMP-"),
                                    r = t.hasAttribute("i-amphtml-binding");
                                !r && Wt[t.tagName] ? t.setAttribute("i-amphtml-ignore", "") : (r || n) && (t.hasAttribute(Gt) || t.setAttribute(Gt, String(i.xR++)))
                            }(t), u.forEach((function(t) {
                                delete r[t]
                            })), u.length = 0, "use" === t.nodeName.toLowerCase() && ["href", "xlink:href"].forEach((function(e) {
                                t.hasAttribute(e) && !t.getAttribute(e).startsWith("#") && (function(t) {
                                    var e;
                                    null === (e = t.parentElement) || void 0 === e || e.removeChild(t)
                                }(t), vt().error(se, 'Removed invalid <use>. use[href] must start with "#".'))
                            }))
                        }))
                    }, e.jR = function(t) {
                        var e;
                        t.addHook("uponSanitizeElement", (function(t, n) {
                            var r = n.tagName;
                            if (e = n.allowedTags, "template" === r) {
                                var i = t.getAttribute("type");
                                i && "amp-mustache" === i.toLowerCase() && (e.template = !0)
                            }
                        })), t.addHook("afterSanitizeElements", (function(t) {
                            e.template = !1
                        }))
                    }, t
                }(),
                pe = {
                    NONE: 0,
                    CLASSIC: 1,
                    ALTERNATIVE: 2
                };

            function me(t) {
                return "[" == t[0] && "]" == t[t.length - 1] ? pe.CLASSIC : t.startsWith(Pt) ? pe.ALTERNATIVE : pe.NONE
            }
            var he = {};
            ! function(t) {
                var e = Object.prototype.toString,
                    n = Array.isArray || function(t) {
                        return "[object Array]" === e.call(t)
                    };

                function r(t) {
                    return "function" == typeof t
                }

                function o(t) {
                    return t.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, "\\$&")
                }

                function a(t, e) {
                    return null != t && "object" === i(t) && Object.prototype.hasOwnProperty.call(t, e)
                }
                var u = RegExp.prototype.test,
                    s = /\S/,
                    f = {
                        "&": "&amp;",
                        "<": "&lt;",
                        ">": "&gt;",
                        '"': "&quot;",
                        "'": "&#39;",
                        "/": "&#x2F;",
                        "`": "&#x60;",
                        "=": "&#x3D;"
                    },
                    c = /\s*/,
                    l = /\s+/,
                    p = /\s*=/,
                    m = /\s*\}/,
                    h = /#|\^|\/|>|\{|&|=|!/;

                function d(t) {
                    this.string = t, this.tail = t, this.pos = 0
                }

                function v(t, e) {
                    this.view = t, this.cache = {
                        ".": this.view
                    }, this.parent = e
                }

                function g() {
                    this.cache = {}
                }
                d.prototype.eos = function() {
                    return "" === this.tail
                }, d.prototype.scan = function(t) {
                    var e = this.tail.match(t);
                    if (!e || 0 !== e.index) return "";
                    var n = e[0];
                    return this.tail = this.tail.substring(n.length), this.pos += n.length, n
                }, d.prototype.scanUntil = function(t) {
                    var e, n = this.tail.search(t);
                    switch (n) {
                        case -1:
                            e = this.tail, this.tail = "";
                            break;
                        case 0:
                            e = "";
                            break;
                        default:
                            e = this.tail.substring(0, n), this.tail = this.tail.substring(n)
                    }
                    return this.pos += e.length, e
                }, v.prototype.push = function(t) {
                    return new v(t, this)
                }, v.prototype.lookup = function(t) {
                    var e, n = this.cache;
                    if (n.hasOwnProperty(t)) e = n[t];
                    else {
                        for (var i, o, u = this, s = !1; u;) {
                            if (t.indexOf(".") > 0)
                                for (e = u.view, i = t.split("."), o = 0; null != e && o < i.length;) {
                                    if (!a(e, i[o])) {
                                        e = null;
                                        break
                                    }
                                    o === i.length - 1 && (s = !0), e = e[i[o++]]
                                } else a(u.view, t) ? (e = u.view[t], s = !0) : e = null;
                            if (s) break;
                            u = u.parent
                        }
                        n[t] = e
                    }
                    return r(e) && (e = e.call(this.view)), e
                }, g.prototype.clearCache = function() {
                    this.cache = {}
                }, g.prototype.parse = function(e, r) {
                    var i = this.cache,
                        a = i[e];
                    return null == a && (a = i[e] = function(e, r) {
                        if (!e) return [];
                        var i, a, f, v, g = [],
                            b = [],
                            y = [],
                            w = !1,
                            x = !1;

                        function k() {
                            if (w && !x)
                                for (; y.length;) delete b[y.pop()];
                            else y = [];
                            w = !1, x = !1
                        }! function(t) {
                            if ("string" == typeof t && (t = t.split(l, 2)), !n(t) || 2 !== t.length) throw new Error("Invalid tags: " + t);
                            i = new RegExp(o(t[0]) + "\\s*"), a = new RegExp("\\s*" + o(t[1])), f = new RegExp("\\s*" + o("}" + t[1]))
                        }(r || t.tags);
                        for (var S, O, j, E, A, R, T = new d(e); !T.eos();) {
                            if (S = T.pos, j = T.scanUntil(i))
                                for (var _ = 0, z = j.length; _ < z; ++_) v = E = j.charAt(_),
                                    function(t, e) {
                                        return u.call(t, e)
                                    }(s, v) ? x = !0 : y.push(b.length), b.push(["text", E, S, S + 1]), S += 1, "\n" === E && k();
                            if (!T.scan(i)) break;
                            if (w = !0, O = T.scan(h) || "name", T.scan(c), "=" === O ? (j = T.scanUntil(p), T.scan(p), T.scanUntil(a)) : "{" === O ? (j = T.scanUntil(f), T.scan(m), T.scanUntil(a), O = "&") : j = T.scanUntil(a), !T.scan(a)) throw new Error("Unclosed tag at " + T.pos);
                            if (A = [O, j, S, T.pos], b.push(A), "#" === O || "^" === O) g.push(A);
                            else if ("/" === O) {
                                if (!(R = g.pop())) throw new Error('Unopened section "' + j + '" at ' + S);
                                if (R[1] !== j) throw new Error('Unclosed section "' + R[1] + '" at ' + S)
                            } else "name" !== O && "{" !== O && "&" !== O || (x = !0)
                        }
                        if (R = g.pop()) throw new Error('Unclosed section "' + R[1] + '" at ' + T.pos);
                        return function(t) {
                            for (var e, n = [], r = n, i = [], o = 0, a = t.length; o < a; ++o) switch ((e = t[o])[0]) {
                                case "#":
                                case "^":
                                    r.push(e), i.push(e), r = e[4] = [];
                                    break;
                                case "/":
                                    i.pop()[5] = e[2], r = i.length > 0 ? i[i.length - 1][4] : n;
                                    break;
                                default:
                                    r.push(e)
                            }
                            return n
                        }(function(t) {
                            for (var e, n, r = [], i = 0, o = t.length; i < o; ++i)(e = t[i]) && ("text" === e[0] && n && "text" === n[0] ? (n[1] += e[1], n[3] = e[3]) : (r.push(e), n = e));
                            return r
                        }(b))
                    }(e, r)), a
                }, g.prototype.render = function(t, e, n) {
                    var r = this.parse(t),
                        i = e instanceof v ? e : new v(e);
                    return this.renderTokens(r, i, n, t)
                }, g.prototype.renderTokens = function(t, e, n, r) {
                    for (var i, o, a, u = "", s = 0, f = t.length; s < f; ++s) a = void 0, "#" === (o = (i = t[s])[0]) ? a = this.renderSection(i, e, n, r) : "^" === o ? a = this.renderInverted(i, e, n, r) : ">" === o ? a = this.renderPartial(i, e, n, r) : "&" === o ? a = this.unescapedValue(i, e) : "name" === o ? a = this.escapedValue(i, e) : "text" === o && (a = this.rawValue(i)), void 0 !== a && (u += a);
                    return u
                }, g.prototype.renderSection = function(t, e, o, a) {
                    var u = this,
                        s = "",
                        f = e.lookup(t[1]);
                    if (f) {
                        if (n(f))
                            for (var c = 0, l = f.length; c < l; ++c) s += this.renderTokens(t[4], e.push(f[c]), o, a);
                        else if ("object" === i(f) || "string" == typeof f || "number" == typeof f) s += this.renderTokens(t[4], e.push(f), o, a);
                        else if (r(f)) {
                            if ("string" != typeof a) throw new Error("Cannot use higher-order sections without the original template");
                            null != (f = f.call(e.view, a.slice(t[3], t[5]), (function(t) {
                                return u.render(t, e, o)
                            }))) && (s += f)
                        } else s += this.renderTokens(t[4], e, o, a);
                        return s
                    }
                }, g.prototype.renderInverted = function(t, e, r, i) {
                    var o = e.lookup(t[1]);
                    if (!o || n(o) && 0 === o.length) return this.renderTokens(t[4], e, r, i)
                }, g.prototype.renderPartial = function(t, e, n) {
                    if (n) {
                        var i = r(n) ? n(t[1]) : n[t[1]];
                        return null != i ? this.renderTokens(this.parse(i), e, n, i) : void 0
                    }
                }, g.prototype.unescapedValue = function(e, n) {
                    var r = n.lookup(e[1]);
                    if (null != r) return t.sanitizeUnescaped ? t.sanitizeUnescaped(r) : r
                }, g.prototype.escapedValue = function(e, n) {
                    var r = n.lookup(e[1]);
                    if (null != r) return t.escape(r)
                }, g.prototype.rawValue = function(t) {
                    return t[1]
                }, t.name = "mustache.js", t.version = "2.2.0", t.tags = ["{{", "}}"];
                var b = new g;
                t.clearCache = function() {
                    return b.clearCache()
                }, t.parse = function(t, e) {
                    return b.parse(t, e)
                }, t.render = function(t, e, r) {
                    if ("string" != typeof t) throw new TypeError('Invalid template! Template should be a "string" but "' + (n(o = t) ? "array" : i(o)) + '" was given as the first argument for mustache#render(template, view, partials)');
                    var o;
                    return b.render(t, e, r)
                }, t.to_html = function(e, n, i, o) {
                    var a = t.render(e, n, i);
                    if (!r(o)) return a;
                    o(a)
                }, t.escape = function(t) {
                    return String(t).replace(/[&<>"'`=\/]/g, (function(t) {
                        return f[t]
                    }))
                }, t.sanitizeUnescaped = null, t.setUnescapedSanitizer = function(e) {
                    t.sanitizeUnescaped = e
                }, t.Scanner = d, t.Context = v, t.Writer = g
            }(he);
            var de = he,
                ve = "amp-mustache",
                ge = function(t) {
                    ! function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && o(t, e)
                    }(f, t);
                    var e, n, s = (e = f, n = function() {
                        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                        if (Reflect.construct.sham) return !1;
                        if ("function" == typeof Proxy) return !0;
                        try {
                            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                        } catch (t) {
                            return !1
                        }
                    }(), function() {
                        var t, r = a(e);
                        if (n) {
                            var i = a(this).constructor;
                            t = Reflect.construct(r, arguments, i)
                        } else t = r.apply(this, arguments);
                        return u(this, t)
                    });

                    function f(t, e) {
                        var n;
                        return n = s.call(this, t, e),
                            function(t, e, n, r) {
                                ! function(t, e, n, r, i, o) {
                                    var a = Tt(t),
                                        u = a[n];
                                    u || (u = a[n] = {
                                        obj: null,
                                        promise: null,
                                        resolve: null,
                                        reject: null,
                                        context: null,
                                        ctor: null,
                                        sharedInstance: !1
                                    }), u.ctor || (u.ctor = r, u.context = e, u.sharedInstance = !1, u.resolve && Rt(t, n))
                                }(t = Et(t), t, e, n)
                            }(e, "purifier", (function() {
                                return new le(e.document, {}, Ct)
                            })), n.ER = jt(e, "purifier"), de.setUnescapedSanitizer((function(t) {
                                return n.ER.purifyTagsForTripleMustache(t)
                            })), n
                    }
                    var c = f.prototype;
                    return c.compileCallback = function() {
                        if (!this.viewerCanRenderTemplates()) {
                            this.AR = {}, this.RR = this.TR();
                            try {
                                de.parse(this.RR, void 0)
                            } catch (t) {
                                vt().error(ve, t.message, this.element)
                            }
                        }
                    }, c.TR = function() {
                        if ("TEMPLATE" == this.element.tagName) {
                            var t = function(t) {
                                if ("content" in t) return t.content.cloneNode(!0);
                                var e = t.ownerDocument.createDocumentFragment();
                                return function(t, e) {
                                    for (var n = e.ownerDocument.createDocumentFragment(), r = t.firstChild; r; r = r.nextSibling) n.appendChild(r.cloneNode(!0));
                                    e.appendChild(n)
                                }(t, e), e
                            }(this.element);
                            this._R(t);
                            var e = this.element.ownerDocument.createElement("div");
                            return e.appendChild(t), e.innerHTML
                        }
                        return "SCRIPT" == this.element.tagName ? this.element.textContent : ""
                    }, c._R = function(t) {
                        var e = this;
                        t.querySelectorAll("template").forEach((function(t, n) {
                            var r = "__AMP_NESTED_TEMPLATE_".concat(n);
                            e.AR[r] = t.outerHTML;
                            var i = e.element.ownerDocument.createTextNode("{{{".concat(r, "}}}"));
                            t.parentNode.replaceChild(i, t)
                        }))
                    }, c.setHtml = function(t) {
                        var e = "<div>".concat(t, "</div>"),
                            n = this.tryUnwrap(this.zR(e));
                        return this.unwrapChildren(n)
                    }, c.render = function(t) {
                        return this.tryUnwrap(this.ea(t))
                    }, c.renderAsString = function(t) {
                        return this.ea(t).innerHTML
                    }, c.ea = function(t) {
                        var e = t;
                        "object" === i(t) && (e = r(r({}, t), this.AR));
                        var n = de.render(this.RR, e, void 0);
                        return this.zR(n)
                    }, c.zR = function(t) {
                        return this.ER.purifyHtml("<div>".concat(t, "</div>")).firstElementChild
                    }, f
                }(function() {
                    function t(t, e) {
                        var n, r, i, o;
                        this.element = t, this.win = t.ownerDocument.defaultView || e, this.ls = (n = this.element, r = "viewer", Rt((i = At(n), (o = At(i)).isSingleDoc() ? o.win : o), r)), this.compileCallback()
                    }
                    var e = t.prototype;
                    return e.compileCallback = function() {}, e.setHtml = function(t) {}, e.render = function(t) {}, e.renderAsString = function(t) {}, e.DR = function(t, e) {
                        for (var n = t.firstChild; null != n; n = n.nextSibling)
                            if (3 == n.nodeType) {
                                var r = n.textContent.trim();
                                r && e(r)
                            } else 8 == n.nodeType || l(n) && e(n)
                    }, e.tryUnwrap = function(t) {
                        var e;
                        return this.DR(t, (function(t) {
                            e = void 0 === e && t.nodeType ? t : null
                        })), e || t
                    }, e.unwrapChildren = function(t) {
                        var e = this,
                            n = [];
                        return this.DR(t, (function(t) {
                            if ("string" == typeof t) {
                                var r = e.win.document.createElement("div");
                                r.textContent = t, n.push(r)
                            } else n.push(t)
                        })), n
                    }, e.viewerCanRenderTemplates = function() {
                        return this.ls.hasCapability("viewerRenderTemplate")
                    }, t
                }());
            t.registerTemplate(ve, ge)
        }();
        /*!
         * mustache.js - Logic-less {{mustache}} templates with JavaScript
         * http://github.com/janl/mustache.js
         */
        /*! @license DOMPurify 2.3.3 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/2.3.3/LICENSE */
        /*! https://mths.be/cssescape v1.5.1 by @mathias | MIT license */
    }
});
//# sourceMappingURL=amp-mustache-0.2.js.map